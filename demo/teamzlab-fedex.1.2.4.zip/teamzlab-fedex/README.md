# Fedex Shipping for WooCommerce

> The REST-first FedEx tool for WooCommerce. Real-time webhooks. Automatic
> customs. Residential surcharge shield. Zero SOAP. Built by one developer.

**Fedex Shipping** is a WooCommerce plugin that wires the full FedEx REST
API suite into a single WordPress admin — no SOAP, no legacy XML, no paid
middleware. It was built against the June 2026 FedEx SOAP retirement
window and the research brief in
[`docs/FedEx_API_Research_and_Integration_Strategy.docx`](docs/FedEx_API_Research_and_Integration_Strategy.docx).

## Install

1. Copy this folder to `wp-content/plugins/fedex-shipping/`.
2. Activate **Fedex Shipping** in **Plugins → Installed Plugins**.
3. Ensure **WooCommerce** is installed and active (this plugin depends on it).
4. Navigate to **Fedex → Settings** in wp-admin.
5. Fill in the five tabs:
   - **Authorization** — core client ID / client secret.
   - **Tracking** — tracking-family client ID / client secret (separate FedEx project).
   - **Account** — account number, shipper name, address, environment (sandbox/production).
   - **Shipping** — pickup type, rate request type, allowed services.
   - **Labeling** — packaging, label format, stock type, image type.
6. Go to **WooCommerce → Settings → Shipping → Zones** and add the
   **Fedex Shipping** method to every shipping zone you want rates in.

## Checkout FedEx rates logging

When WooCommerce requests live rates, the plugin calls FedEx **`/rate/v1/rates/quotes`**. For each attempt (**initial**, and optional retries), it logs **Payload** and **Response** as JSON in **WooCommerce → Status → Logs** with the log file name **`teamzlab_fedex_shippnig`**. The OAuth token is never included. All other former `debug.log` / generic WooCommerce HTTP mirrors from this plugin are disabled.

## Shipment create logging

When a shipment is created (FedEx **`/ship/v1/shipments`**), the plugin writes **Payload** and **Response** JSON to **WooCommerce → Status → Logs** with source **`teamz_shipment_create`**.

## Features

| Category | Feature |
|---|---|
| Rates | Live FedEx rates at checkout with account-specific discounts |
| Validation | Address Validation (residential/commercial auto-classify) + Postal Code Validation |
| Shipments | Single-package Ship, multi-package Open Ship, cancel + return tags |
| Labels | PDF/PNG/ZPLII labels saved to `/wp-content/uploads/fedex-labels/` |
| Tracking | Pull (Basic Track) + push (AIV webhooks) with shortcode `[fshipping_track]` |
| Pickup | Schedule / cancel pickups from the Shipments admin list |
| Shipment Ops | Search by tracking ID, mark label printed (single/bulk), and row-state highlighting |
| Locations | `[fshipping_locations]` shortcode: find nearest FedEx drop-off |
| Customs | Global Trade advisories + electronic Trade Documents Upload |
| Freight | FedEx Freight LTL rates and BOL creation (requires 9-digit Freight account) |
| Admin | Dashboard widget with the 10 latest shipments and current statuses |

## Screenshots

> _Placeholder._ Screenshots live under `assets/screenshots/` and will be
> dropped in alongside the marketing landing page. See
> [`marketing/landing-copy.md`](marketing/landing-copy.md).

- `screenshot-1.png` — admin settings, five tabs.
- `screenshot-2.png` — Shipments CPT list with **Track** / **Cancel** / **Pickup** actions and Label Printed toggle.
- `screenshot-3.png` — `[fshipping_track]` shortcode rendered on a frontend page.
- `screenshot-4.png` — `[fshipping_locations]` drop-off finder.
- `screenshot-5.png` — dashboard widget with last 10 shipments.

## New to this codebase?

Start with **[`docs/ONBOARDING.md`](docs/ONBOARDING.md)** — a step-by-step
walkthrough that takes you from zero to a running local dev environment
in about an afternoon. Then read [`CONTRIBUTING.md`](CONTRIBUTING.md) for
day-to-day workflow and [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)
for the big picture. Pick a first task from
[`docs/STARTER_TASKS.md`](docs/STARTER_TASKS.md).

Data model reference for shipment table integrations:
[`docs/shipment-schema.md`](docs/shipment-schema.md).

One-shot environment bootstrap:

```bash
./scripts/setup.sh
```

Scaffold a new FedEx API client + matching test in one command:

```bash
./scripts/new-http-client.sh MyNewApi
```

## Running the test suite

PHPUnit tests live under `tests/phpunit/`. They mock WordPress with
Brain\Monkey — no live WP install required.

```bash
composer install                  # one-time
composer test                     # full suite
./vendor/bin/phpunit --filter Rates  # one class
composer lint                     # php -l across includes/
```

Enable the git pre-commit hook (runs `php -l` + PHPUnit before every commit):

```bash
git config core.hooksPath .githooks
```

Claude Code runs the suite automatically after every PHP file edit via the
`PostToolUse` hook in `.claude/settings.json`. Cursor users: see
`.cursor/rules/tests.mdc` for the test-first rule.

## Roadmap

The public roadmap lives at
[`docs/ROADMAP.md`](docs/ROADMAP.md) — it mirrors Section 8 of the
research brief (the 7-day solo-dev growth sprint). Longer-term business
strategy lives at [`docs/MARKETING.md`](docs/MARKETING.md).

## For Claude Code sessions

Start at [`CLAUDE.md`](CLAUDE.md). It points to the per-module
`CLAUDE.md` files inside each `includes/*/` folder, plus the strategic
brain at [`docs/CLAUDE.md`](docs/CLAUDE.md).

## License

Proprietary — Teamz Lab. See file header for details.
