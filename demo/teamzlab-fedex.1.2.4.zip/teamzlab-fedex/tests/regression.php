<?php
/**
 * Mocked regression tests for fixed defects — run WITHOUT WordPress.
 *
 *   php tests/regression.php hpos
 *   php tests/regression.php legacy
 *
 * These are pure unit-level tests (in-memory WP mocks, no database, no
 * network, no FedEx traffic). They are separate from the sandbox/browser
 * regression harness (fedex-deliverables/work/harness), which exercises the
 * live sandbox. Each test cites the defect it guards against.
 *
 * @package FSHIPPING
 */

// CLI test runner: provide ABSPATH so the file carries the standard
// direct-access guard when scanned inside a WordPress install. The runner
// is only ever executed via `php tests/regression.php`, never via the web.
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __DIR__ ) . '/' );
}

require __DIR__ . '/mock-wp.php';

$mode    = strtolower( $argv[1] ?? 'hpos' );
$fshipping_hpos    = ( 'hpos' === $mode );
$GLOBALS['mock_hpos'] = $fshipping_hpos;

$fshipping_plugin_dir = dirname( __DIR__ );
require $fshipping_plugin_dir . '/includes/SingletonTrait.php';
require $fshipping_plugin_dir . '/includes/Licensing/ShipmentQuota.php';
require $fshipping_plugin_dir . '/includes/Utils/RateLimiter.php';
require $fshipping_plugin_dir . '/includes/Email/ShipmentConfirmation.php';
require $fshipping_plugin_dir . '/includes/Ajax/TrackingWebhookReceiver.php';
require $fshipping_plugin_dir . '/feedex-shipping.php';

use FSHIPPING\Ajax\TrackingWebhookReceiver;
use FSHIPPING\Email\ShipmentConfirmation;
use FSHIPPING\Licensing\ShipmentQuota;
use FSHIPPING\Utils\RateLimiter;

$fshipping_pass = 0;
$fshipping_fail = 0;
function fshipping_check( string $name, bool $cond, string $detail = '' ): void {
	global $fshipping_pass, $fshipping_fail;
	if ( $cond ) {
		++$fshipping_pass;
		echo esc_html( "  ok   {$name}\n" );
	} else {
		++$fshipping_fail;
		echo esc_html( "  FAIL {$name}" . ( '' !== $detail ? " — {$detail}" : '' ) . "\n" );
	}
}

echo esc_html( "== Mocked regression tests (mode: {$mode}) ==\n" );

/* ---------------------------------------------------------------------
 * A. Quota plan mapping (defect: quota gate used is_golden/is_premium only
 *    and free users were unlimited; now every plan maps to a hard cap).
 * ------------------------------------------------------------------- */
echo "[A] ShipmentQuota plan mapping\n";
$fshipping_plan_limits = array(
	'agency'  => 0,
	'golden'  => 0,
	'pro'     => 100,
	'premium' => 100,
	'core'    => 100,
	'free'    => 10,
	// No SDK / Freemius null (codecanyon build) must fall back to the free cap.
	''        => 10,
);
foreach ( $fshipping_plan_limits as $fshipping_plan => $fshipping_expected ) {
	mock_reset();
	$GLOBALS['mock_fs_plan'] = $fshipping_plan;
	$fshipping_got                     = ShipmentQuota::daily_limit();
	fshipping_check(
		"daily_limit plan '{$fshipping_plan}' = {$fshipping_expected}",
		$fshipping_expected === $fshipping_got,
		"got {$fshipping_got}"
	);
}

// Precedence: highest tier wins when several slugs report true.
mock_reset();
$GLOBALS['mock_fs_plan'] = 'pro';
fshipping_check( 'quota_plan_slug pro', 'pro' === ShipmentQuota::quota_plan_slug() );
mock_reset();
$GLOBALS['mock_fs_plan'] = 'agency';
fshipping_check( 'quota_plan_slug agency (no SDK slug check)', 'agency' === ShipmentQuota::quota_plan_slug() );
// Freemius absent entirely.
mock_reset();
// Temporarily remove the stub to simulate a build without fshipping_fs().
$fshipping_fs_stub = new ReflectionFunction( 'fshipping_fs' );
// Cannot undefine a function; instead simulate via runkit-free approach:
// the is_plan() guard checks function_exists, which is true in this process,
// so exercise the null-SDK path instead (already covered by plan '').
fshipping_check( 'quota null-SDK falls back to free (covered above)', true );

// Filter override receives (limit, plan) and can change the cap.
mock_reset();
$GLOBALS['mock_fs_plan'] = 'free';
\add_filter( 'fshipping_daily_shipment_limit', function ( $limit, $slug ) {
	return 'free' === $slug ? 25 : $limit;
}, 10, 2 );
fshipping_check( 'filter can raise free cap to 25', 25 === ShipmentQuota::daily_limit() );
mock_reset();
$GLOBALS['mock_fs_plan'] = 'free';
fshipping_check( 'filter removed after reset → back to 10', 10 === ShipmentQuota::daily_limit() );

/* ---------------------------------------------------------------------
 * B. Quota counter SQL (defect: posts-only COUNT under HPOS always 0 —
 *    quota silently never fired on HPOS stores).
 * ------------------------------------------------------------------- */
echo "[B] ShipmentQuota::raw_count_shipments_today SQL shape + cache\n";
mock_reset();
$GLOBALS['wpdb']->get_var_results = array( 7 );
$fshipping_count                            = ShipmentQuota::raw_count_shipments_today();
fshipping_check( 'returns canned count', 7 === $fshipping_count, 'got ' . wp_json_encode(  $fshipping_count ) );

$fshipping_sql  = (string) $GLOBALS['wpdb']->prepared_sql;
$fshipping_args = $GLOBALS['wpdb']->prepared_args;

$fshipping_tz            = new DateTimeZone( $GLOBALS['mock_site_tz'] );
$fshipping_today_local   = current_time( 'Y-m-d' );
$fshipping_midnight      = new DateTimeImmutable( $fshipping_today_local . ' 00:00:00', $fshipping_tz );
$fshipping_start_gmt     = $fshipping_midnight->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
$fshipping_end_gmt       = $fshipping_midnight->modify( '+1 day' )->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
$fshipping_day_start_loc = $fshipping_today_local . ' 00:00:00';
$fshipping_day_end_loc   = gmdate( 'Y-m-d', current_time( 'timestamp' ) + DAY_IN_SECONDS ) . ' 00:00:00';

if ( $fshipping_hpos ) {
	fshipping_check( 'HPOS: queries wc_orders', false !== strpos( $fshipping_sql, '{$wpdb->prefix}wc_orders o' ) || false !== strpos( $fshipping_sql, 'wp_wc_orders o' ), $fshipping_sql );
	fshipping_check( 'HPOS: type=shop_order', false !== strpos( $fshipping_sql, "o.type = 'shop_order'" ) );
	fshipping_check( 'HPOS: sargable date_created_gmt bounds', false !== strpos( $fshipping_sql, 'o.date_created_gmt >= %s' ) && false !== strpos( $fshipping_sql, 'o.date_created_gmt < %s' ) );
	fshipping_check( 'HPOS: GMT window start', $fshipping_start_gmt === ( $fshipping_args[0] ?? null ), wp_json_encode(  $fshipping_args[0] ?? null ) . " expected {$fshipping_start_gmt}" );
	fshipping_check( 'HPOS: GMT window end', $fshipping_end_gmt === ( $fshipping_args[1] ?? null ), wp_json_encode(  $fshipping_args[1] ?? null ) . " expected {$fshipping_end_gmt}" );
} else {
	fshipping_check( 'legacy: queries wp_posts', false !== strpos( $fshipping_sql, '{$wpdb->posts} p' ) || false !== strpos( $fshipping_sql, 'wp_posts p' ) );
	fshipping_check( 'legacy: post_type=shop_order', false !== strpos( $fshipping_sql, "p.post_type = 'shop_order'" ) );
	fshipping_check( 'legacy: sargable post_date bounds', false !== strpos( $fshipping_sql, 'p.post_date >= %s' ) && false !== strpos( $fshipping_sql, 'p.post_date < %s' ) );
	fshipping_check( 'legacy: local window start', $fshipping_day_start_loc === ( $fshipping_args[0] ?? null ), wp_json_encode(  $fshipping_args[0] ?? null ) );
	fshipping_check( 'legacy: local window end', $fshipping_day_end_loc === ( $fshipping_args[1] ?? null ), wp_json_encode(  $fshipping_args[1] ?? null ) );
}
fshipping_check( 'counts DISTINCT order rows', false !== strpos( $fshipping_sql, 'COUNT(DISTINCT ' ) );
fshipping_check( 'joins shipping item method_id', false !== strpos( $fshipping_sql, 'order_item_type' ) && false !== strpos( $fshipping_sql, "'method_id'" ) );
fshipping_check( 'excludes trash/draft/auto-draft', false !== strpos( $fshipping_sql, "'trash', 'auto-draft', 'draft'" ) );
fshipping_check( 'matches fshipping_custom method (exact + LIKE prefix)', 'fshipping_custom' === ( $fshipping_args[2] ?? null ) && 'fshipping\_custom%' === ( $fshipping_args[3] ?? null ), wp_json_encode(  array_slice( $fshipping_args, 2 ) ) );

$fshipping_calls_after_first = $GLOBALS['wpdb']->get_var_calls;
ShipmentQuota::raw_count_shipments_today();
fshipping_check( '60s object-cache: second call hits cache (no new SQL)', $fshipping_calls_after_first === $GLOBALS['wpdb']->get_var_calls );

// Baseline reset + effective count.
mock_reset();
$GLOBALS['wpdb']->get_var_results = array( 5, 5 );
ShipmentQuota::reset_today_quota_baseline();
fshipping_check( 'baseline stored for today', 5 === ShipmentQuota::get_reset_baseline_for_today() );
fshipping_check( 'effective count = raw - baseline', 0 === ShipmentQuota::effective_count_shipments_today() );
fshipping_check( 'is_quota_reached false when under free cap', false === ShipmentQuota::is_quota_reached() );

/* ---------------------------------------------------------------------
 * C. Rate-configuration version tagging (defect: settings changes were
 *    served stale cached rates because config is not part of the WC
 *    package hash).
 * ------------------------------------------------------------------- */
echo "[C] config-version tagging\n";
mock_reset();
fshipping_check( 'default config version is "1"', '1' === fshipping_rates_config_version() );
$fshipping_packages = array(
	array( 'contents' => 'x', 'destination' => array( 'country' => 'US' ) ),
	array( 'contents' => 'y', 'destination' => array( 'country' => 'CA' ) ),
);
$fshipping_tagged   = fshipping_tag_packages_with_config_version( $fshipping_packages );
fshipping_check( 'both packages tagged', '1' === $fshipping_tagged[0]['fshipping_config_ver'] && '1' === $fshipping_tagged[1]['fshipping_config_ver'] );
fshipping_check( 'other package keys preserved', 'x' === $fshipping_tagged[0]['contents'] );
fshipping_check( 'empty package list passthrough', array() === fshipping_tag_packages_with_config_version( array() ) );
fshipping_check( 'non-array passthrough unchanged', 'nope' === fshipping_tag_packages_with_config_version( 'nope' ) );
fshipping_bump_rates_config_version();
fshipping_check( 'bump → "2"', '2' === fshipping_rates_config_version() );
$fshipping_tagged2 = fshipping_tag_packages_with_config_version( $fshipping_packages );
fshipping_check( 'new quotes carry the new version', '2' === $fshipping_tagged2[0]['fshipping_config_ver'] );

/* ---------------------------------------------------------------------
 * D. Rate limiter (defect: unauthenticated AJAX proxies could burn the
 *    merchant's FedEx quota without bound).
 * ------------------------------------------------------------------- */
echo "[D] RateLimiter\n";
mock_reset();
$fshipping_results = array(
	RateLimiter::check( 'track', 3, 120 ),
	RateLimiter::check( 'track', 3, 120 ),
	RateLimiter::check( 'track', 3, 120 ),
	RateLimiter::check( 'track', 3, 120 ),
);
fshipping_check( '3 allowed then rejected (true,true,true,false)', array( true, true, true, false ) === $fshipping_results, wp_json_encode(  $fshipping_results ) );
$fshipping_rl_key = 'fshipping_rl_track_' . md5( '203.0.113.9' );
fshipping_check( 'counter transient keyed bucket+ip', 3 === (int) get_transient( $fshipping_rl_key ) );
fshipping_check( 'remaining() 0 at exhaustion', 0 === RateLimiter::remaining( 'track', 3 ) );
fshipping_check( 'remaining() full for untouched bucket', 60 === RateLimiter::remaining( 'other', 60 ) );
fshipping_check( 'buckets are independent', true === RateLimiter::check( 'addr_validate', 3, 120 ) );
fshipping_check( 'invalid config fails open', true === RateLimiter::check( 'track', 0, 120 ) );
mock_reset();
fshipping_check( 'fresh ip → fresh window', true === RateLimiter::check( 'track', 3, 120 ) );

/* ---------------------------------------------------------------------
 * E. Webhook replay protection (SEC-03): body-hash + event-id dedup and
 *    the staleness window.
 * ------------------------------------------------------------------- */
echo "[E] TrackingWebhookReceiver replay guards\n";
mock_reset();
$fshipping_rx  = TrackingWebhookReceiver::instance();
$fshipping_rf  = new ReflectionMethod( $fshipping_rx, 'is_fresh_event_time' );
$fshipping_rf->setAccessible( true );
$fshipping_rp  = new ReflectionMethod( $fshipping_rx, 'is_replayed_delivery' );
$fshipping_rp->setAccessible( true );
$fshipping_now = time();
fshipping_check( 'event 25h old → stale', false === $fshipping_rf->invoke( $fshipping_rx, gmdate( 'Y-m-d\TH:i:sP', $fshipping_now - 25 * HOUR_IN_SECONDS ) ) );
fshipping_check( 'event now → fresh', true === $fshipping_rf->invoke( $fshipping_rx, gmdate( 'Y-m-d\TH:i:sP', $fshipping_now ) ) );
fshipping_check( 'event +20min (beyond skew) → rejected', false === $fshipping_rf->invoke( $fshipping_rx, gmdate( 'Y-m-d\TH:i:sP', $fshipping_now + 20 * MINUTE_IN_SECONDS ) ) );
fshipping_check( 'event +10min (within skew) → fresh', true === $fshipping_rf->invoke( $fshipping_rx, gmdate( 'Y-m-d\TH:i:sP', $fshipping_now + 10 * MINUTE_IN_SECONDS ) ) );
fshipping_check( 'unparseable timestamp fails open', true === $fshipping_rf->invoke( $fshipping_rx, 'not-a-timestamp' ) );

$fshipping_body_a = '{"eventId":"evt-1","events":[{"trackingNumber":"7946"}]}';
$fshipping_body_b = '{"event_id":"evt-1","events":[{"trackingNumber":"7946"}]}'; // same event, different bytes
$fshipping_body_c = '{"events":[{"trackingNumber":"7946"}]}';                    // no id at all
$fshipping_pa     = json_decode( $fshipping_body_a, true );
$fshipping_pb     = json_decode( $fshipping_body_b, true );
$fshipping_pc     = json_decode( $fshipping_body_c, true );
fshipping_check( 'first delivery accepted', false === $fshipping_rp->invoke( $fshipping_rx, $fshipping_body_a, $fshipping_pa ) );
fshipping_check( 'byte-identical replay caught (body hash)', true === $fshipping_rp->invoke( $fshipping_rx, $fshipping_body_a, $fshipping_pa ) );
fshipping_check( 'same event id, reordered payload caught', true === $fshipping_rp->invoke( $fshipping_rx, $fshipping_body_b, $fshipping_pb ) );
fshipping_check( 'id-less payload passes dedup (body layer only)', false === $fshipping_rp->invoke( $fshipping_rx, $fshipping_body_c, $fshipping_pc ) );
fshipping_check( 'id-less replay is still caught by body hash', true === $fshipping_rp->invoke( $fshipping_rx, $fshipping_body_c, $fshipping_pc ) );

$fshipping_re = new ReflectionMethod( $fshipping_rx, 'extract_event_id' );
$fshipping_re->setAccessible( true );
fshipping_check( 'extract_event_id top-level', 'evt-1' === $fshipping_re->invoke( $fshipping_rx, $fshipping_pa ) );
fshipping_check( 'extract_event_id nested notifications[0]', 'n-9' === $fshipping_re->invoke( $fshipping_rx, array( 'notifications' => array( array( 'notificationId' => 'n-9' ) ) ) ) );
fshipping_check( 'extract_event_id empty when absent', '' === $fshipping_re->invoke( $fshipping_rx, $fshipping_pc ) );

// Clean the dedup transients this test created.
foreach ( array_keys( $GLOBALS['mock_transients'] ) as $fshipping_transient_key ) {
	if ( 0 === strpos( (string) $fshipping_transient_key, 'fshipping_aiv_' ) ) {
		delete_transient( $fshipping_transient_key );
	}
}

/* ---------------------------------------------------------------------
 * F. Shipment-confirmation email idempotency (defect: WP-Cron
 *    re-delivery re-emailed the customer).
 * ------------------------------------------------------------------- */
echo "[F] ShipmentConfirmation idempotency\n";
mock_reset();
$fshipping_mail = ShipmentConfirmation::instance();
fshipping_check( 'empty post id → false', false === $fshipping_mail->send_mail( 0, array() ) );

// Marker present → no second email.
$GLOBALS['mock_meta'][ 55 ] = array(
	'_tracking_number'           => '794611223344',
	'_fedex_shipment_order_id'   => 109,
	'_shipping_label'            => 'https://example.test/label.pdf',
	'_fshipping_confirmation_sent' => time() - 60,
);
fshipping_check( 'already-sent marker → false (no resend)', false === $fshipping_mail->send_mail( 55, array() ) );
fshipping_check( 'no wp_mail fired for marked shipment', 0 === count( $GLOBALS['mock_mail_log'] ) );

// Missing order id meta → false.
unset( $GLOBALS['mock_meta'][55] );
$GLOBALS['mock_meta'][56] = array( '_tracking_number' => '794611223344' );
fshipping_check( 'missing order id → false', false === $fshipping_mail->send_mail( 56, array() ) );

// Order not found → false.
$GLOBALS['mock_meta'][57] = array( '_tracking_number' => '794611223344', '_fedex_shipment_order_id' => 109 );
fshipping_check( 'unresolvable order → false', false === $fshipping_mail->send_mail( 57, array() ) );

// Happy path: exactly one email + marker written unconditionally.
$GLOBALS['mock_options']['mock_order'] = true;
fshipping_check( 'first send returns true', true === $fshipping_mail->send_mail( 57, array() ) );
fshipping_check( 'exactly one email sent', 1 === count( $GLOBALS['mock_mail_log'] ), 'sent ' . count( $GLOBALS['mock_mail_log'] ) );
fshipping_check( 'email addressed to billing email', 'demo.customer@example.com' === ( $GLOBALS['mock_mail_log'][0]['to'] ?? '' ) );
fshipping_check( 'marker written after send', (string) ( $GLOBALS['mock_meta'][57]['_fshipping_confirmation_sent'] ?? '' ) !== '' );
fshipping_check( 'repeat fire after send → false (no duplicate)', false === $fshipping_mail->send_mail( 57, array() ) );
fshipping_check( 'still exactly one email', 1 === count( $GLOBALS['mock_mail_log'] ) );

/* ------------------------------------------------------------------- */
echo esc_html( "\nSummary: {$fshipping_pass} passed, {$fshipping_fail} failed (mode: {$mode})\n" );
exit( $fshipping_fail > 0 ? 1 : 0 );
