<?php
/**
 * Minimal WordPress function mocks for the plugin's mocked regression tests.
 *
 * Loaded by tests/regression.php BEFORE any plugin file. Provides just the
 * surface the tested classes touch, backed by in-memory stores so tests run
 * with `php tests/regression.php` — no WordPress install, no database, no
 * network. Real (unmocked) PHP functions are used wherever possible.
 *
 * All global code lives in explicit braced `namespace { }` blocks because a
 * braced Automattic\...\OrderUtil stub is declared below and PHP forbids
 * mixing braced and unbraced namespace declarations in one file.
 *
 * @package FSHIPPING
 */

// This file intentionally declares WordPress core functions under their core
// names (add_action, get_option, …) — it is a mock of the WP API surface, not
// plugin code, so plugin prefixing rules cannot apply to it.
// phpcs:ignoreFile

namespace {
	if ( defined( 'FSHIPPING_MOCKWP_LOADED' ) ) {
		return;
	}
	define( 'FSHIPPING_MOCKWP_LOADED', true );

	if ( ! defined( 'ABSPATH' ) ) {
		define( 'ABSPATH', dirname( __DIR__ ) . '/' );
	}
	// Time / interval constants used by the tested classes.
	if ( ! defined( 'MINUTE_IN_SECONDS' ) ) {
		define( 'MINUTE_IN_SECONDS', 60 );
	}
	if ( ! defined( 'HOUR_IN_SECONDS' ) ) {
		define( 'HOUR_IN_SECONDS', 3600 );
	}
	if ( ! defined( 'DAY_IN_SECONDS' ) ) {
		define( 'DAY_IN_SECONDS', 86400 );
	}

	$GLOBALS['mock_options']    = array();
	$GLOBALS['mock_transients'] = array();
	$GLOBALS['mock_meta']       = array();
	$GLOBALS['mock_filters']    = array();
	$GLOBALS['mock_actions']    = array();
	$GLOBALS['mock_mail_log']   = array();
	$GLOBALS['mock_wpdb_calls'] = array();
	$GLOBALS['mock_hpos']       = false;
	$GLOBALS['mock_fs_plan']    = '';
	$GLOBALS['mock_site_tz']    = 'America/Chicago';

	function mock_reset() {
		$GLOBALS['mock_options']    = array();
		$GLOBALS['mock_transients'] = array();
		$GLOBALS['mock_meta']       = array();
		$GLOBALS['mock_filters']    = array();
		$GLOBALS['mock_actions']    = array();
		$GLOBALS['mock_mail_log']   = array();
		$GLOBALS['mock_wpdb_calls'] = array();
		$_SERVER['REMOTE_ADDR']     = '203.0.113.9';
	}

	function add_action( $hook, $cb = null, $prio = 10, $args = 1 ) {
		$GLOBALS['mock_actions'][ $hook ][] = $cb;
		return true;
	}
	function add_filter( $tag, $cb = null, $prio = 10, $args = 1 ) {
		$GLOBALS['mock_filters'][ $tag ][] = $cb;
		return true;
	}
	function apply_filters( $tag, $value, ...$args ) {
		foreach ( $GLOBALS['mock_filters'][ $tag ] ?? array() as $cb ) {
			$value = call_user_func_array( $cb, array_merge( array( $value ), $args ) );
		}
		return $value;
	}
	function register_deactivation_hook( $file, $cb = null ) {
		return true;
	}
	function plugin_dir_path( $file ) {
		return dirname( $file ) . '/';
	}

	function get_option( $name, $default = false ) {
		return array_key_exists( $name, $GLOBALS['mock_options'] ) ? $GLOBALS['mock_options'][ $name ] : $default;
	}
	function update_option( $name, $value, $autoload = null ) {
		$GLOBALS['mock_options'][ $name ] = $value;
		return true;
	}
	function get_transient( $key ) {
		$entry = $GLOBALS['mock_transients'][ $key ] ?? false;
		if ( false === $entry ) {
			return false;
		}
		if ( is_array( $entry ) && $entry['expires'] < time() ) {
			unset( $GLOBALS['mock_transients'][ $key ] );
			return false;
		}
		return is_array( $entry ) ? $entry['value'] : $entry;
	}
	function set_transient( $key, $value, $ttl = 0 ) {
		$GLOBALS['mock_transients'][ $key ] = array(
			'value'   => $value,
			'expires' => $ttl <= 0 ? PHP_INT_MAX : time() + $ttl,
		);
		return true;
	}
	function delete_transient( $key ) {
		unset( $GLOBALS['mock_transients'][ $key ] );
		return true;
	}
	function wp_cache_get( $key, $group = '' ) {
		return get_transient( 'cache_' . $group . '_' . $key );
	}
	function wp_cache_set( $key, $value, $group = '', $ttl = 0 ) {
		return set_transient( 'cache_' . $group . '_' . $key, $value, $ttl );
	}
	function wp_cache_delete( $key, $group = '' ) {
		return delete_transient( 'cache_' . $group . '_' . $key );
	}

	function get_post_meta( $post_id, $key, $single = false ) {
		return $GLOBALS['mock_meta'][ $post_id ][ $key ] ?? '';
	}
	function update_post_meta( $post_id, $key, $value ) {
		$GLOBALS['mock_meta'][ $post_id ][ $key ] = $value;
		return true;
	}

	function wp_timezone() {
		return new DateTimeZone( $GLOBALS['mock_site_tz'] );
	}
	/**
	 * Mirrors WP's current_time(): 'Y-m-d'/'mysql' return site-local strings;
	 * 'timestamp' returns GMT time plus the site's UTC offset (WP's documented
	 * behavior — DST-naive by design).
	 */
	function current_time( $type ) {
		$tz    = wp_timezone();
		$now   = new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) );
		$local = $now->setTimezone( $tz );
		if ( 'timestamp' === $type ) {
			return $now->getTimestamp() + $local->getOffset();
		}
		if ( 'mysql' === $type ) {
			return $local->format( 'Y-m-d H:i:s' );
		}
		return $local->format( $type );
	}

	function wp_unslash( $v ) {
		return $v;
	}
	function sanitize_key( $k ) {
		return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $k ) );
	}
	function sanitize_text_field( $v ) {
		return trim( preg_replace( '/[\r\n\t ]+/', ' ', (string) $v ) );
	}
	function sanitize_email( $v ) {
		return filter_var( (string) $v, FILTER_SANITIZE_EMAIL );
	}
	function esc_html( $v ) {
		return htmlspecialchars( (string) $v, ENT_QUOTES, 'UTF-8', false );
	}
	function esc_url( $v ) {
		return (string) $v;
	}
	function __( $text, $domain = 'default' ) {
		return $text;
	}
	function wp_json_encode( $v ) {
		return json_encode( $v );
	}
	function wp_mail( $to, $subject, $message, $headers = array() ) {
		$GLOBALS['mock_mail_log'][] = compact( 'to', 'subject', 'message', 'headers' );
		return true;
	}
	function wc_get_logger() {
		return new MockLogger();
	}
	class MockLogger {
		public $lines = array();
		public function __call( $level, $args ) {
			$this->lines[] = $level . ': ' . (string) ( $args[0] ?? '' );
			return true;
		}
	}

	/**
	 * Freemius stub. Returning non-null only when a plan is simulated lets
	 * the tests exercise plan-gated logic; returning null exercises the
	 * no-SDK path. Pre-defining fshipping_fs() also prevents
	 * feedex-shipping.php from loading the bundled SDK in tests (its
	 * function_exists guard).
	 */
	function fshipping_fs() {
		if ( '' === $GLOBALS['mock_fs_plan'] ) {
			return null;
		}
		return new MockFreemius( $GLOBALS['mock_fs_plan'] );
	}
	class MockFreemius {
		private $plan;
		public function __construct( $plan ) {
			$this->plan = $plan;
		}
		public function is_plan( $slug ) {
			return $slug === $this->plan;
		}
	}

	/**
	 * Mock $wpdb: captures prepare() calls and serves canned results so SQL
	 * shape and bound parameters can be asserted without a database.
	 */
	class MockWpdb {
		public $prefix          = 'wp_';
		public $posts           = 'wp_posts';
		public $prepared_sql    = '';
		public $prepared_args   = array();
		public $get_var_results = array();
		public $get_var_calls   = 0;

		public function prepare( $sql, ...$args ) {
			$this->prepared_sql  = $sql;
			$this->prepared_args = $args;
			return $sql; // assertions read prepared_sql/prepared_args, not the rendered SQL.
		}
		public function get_var( $sql ) {
			++$this->get_var_calls;
			$GLOBALS['mock_wpdb_calls'][] = array( 'get_var', $sql, $this->prepared_args );
			return array_shift( $this->get_var_results );
		}
		public function esc_like( $s ) {
			return addcslashes( (string) $s, '_%\\' );
		}
	}

	$GLOBALS['wpdb'] = new MockWpdb();
}

namespace Automattic\WooCommerce\Utilities {
	/**
	 * WooCommerce OrderUtil stub — the plugin probes storage via
	 * class_exists + method call, so a same-named stub switches the tested
	 * branches. Set $GLOBALS['mock_hpos'] before calling the code under test.
	 */
	if ( ! class_exists( 'Automattic\WooCommerce\Utilities\OrderUtil' ) ) {
		class OrderUtil {
			public static function custom_orders_table_usage_is_enabled() {
				return $GLOBALS['mock_hpos'];
			}
		}
	}
}

namespace {
	// Mock order object for the email idempotency test.
	class MockOrder {
		public function get_billing_email() {
			return 'demo.customer@example.com';
		}
		public function get_billing_first_name() {
			return 'Demo';
		}
		public function get_order_number() {
			return '1099';
		}
		public function get_formatted_order_total() {
			return '$25.00';
		}
	}
	function wc_get_order( $id ) {
		unset( $id );
		return isset( $GLOBALS['mock_options']['mock_order'] ) ? new MockOrder() : null;
	}
}
