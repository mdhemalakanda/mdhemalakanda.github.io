(function ($) {
    const BOX_LIST = '#fshipping-product-box-list';
    const COLLAPSED_CLASS = 'fshipping-box-collapsed';

    function getBoxTitle($box, boxIndex) {
        const name = (($box.find('.fshipping-box-name-field').val() || '') + '').trim();
        const labelName = name || 'Unnamed';
        return 'Box - ' + labelName + ' - ' + (boxIndex + 1);
    }

    function syncBoxTitles() {
        $(BOX_LIST).find('.fshipping-box-card').not('.fshipping-template').each(function (boxIndex) {
            const $box = $(this);
            $box.find('.fshipping-box-toggle-label').text(getBoxTitle($box, boxIndex));
        });
    }

    function setBoxCollapsed($box, isCollapsed) {
        $box.toggleClass(COLLAPSED_CLASS, isCollapsed);
        $box.find('.fshipping-box-toggle').attr('aria-expanded', isCollapsed ? 'false' : 'true');
    }

    function reindexBoxes() {
        $(BOX_LIST).find('.fshipping-box-card').not('.fshipping-template').each(function (boxIndex) {
            const $box = $(this);
            $box.find('[name]').each(function () {
                const $field = $(this);
                let name = $field.attr('name') || '';
                name = name.replace(/boxes\[\d+\]/g, 'boxes[' + boxIndex + ']');
                $field.attr('name', name);
            });

            $box.find('tbody tr').not('.fshipping-template').each(function (ruleIndex) {
                $(this).find('[name]').each(function () {
                    const $field = $(this);
                    let name = $field.attr('name') || '';
                    name = name.replace(/\[rules\]\[\d+\]/g, '[rules][' + ruleIndex + ']');
                    $field.attr('name', name);
                });
            });
        });
        syncBoxTitles();
    }

    function initSelect2(scope) {
        if (!$.fn.select2) {
            return;
        }
        $(scope).find('.fedex-select2').each(function () {
            const $select = $(this);
            if ($select.hasClass('select2-hidden-accessible')) {
                $select.select2('destroy');
            }
            $select.select2({
                width: '100%',
                dropdownParent: $(document.body),
            });
        });
    }

    function addRuleRow($box) {
        const template = $('#tmpl-fshipping-box-rule-row').html();
        if (!template) {
            return;
        }
        const $row = $(template.trim());
        $row.removeClass('fshipping-template');
        $box.find('tbody').append($row);
        reindexBoxes();
        initSelect2($row);
    }

    function addBoxCard() {
        const template = $('#tmpl-fshipping-box-card').html();
        if (!template) {
            return;
        }
        const $card = $(template.trim());
        $card.removeClass('fshipping-template');
        $(BOX_LIST).append($card);
        reindexBoxes();
        initSelect2($card);
    }

    // FedEx packaging presets: option data-* attrs carry the published
    // supply dimensions in inches (BoxCatalog::packaging_presets()). Convert
    // to the box's unit and fill the fields; the name only fills when empty.
    function applyPackagingPreset($select) {
        const preset = String($select.val() || '');
        if (!preset) {
            return;
        }
        const $option = $select.find('option:selected');
        const inches = {
            length: parseFloat($option.attr('data-length')),
            width: parseFloat($option.attr('data-width')),
            height: parseFloat($option.attr('data-height')),
        };
        if (!isFinite(inches.length) || !isFinite(inches.width) || !isFinite(inches.height)) {
            return;
        }
        const $box = $select.closest('.fshipping-box-card');
        const unit = ($box.find('select[name$="[dimension_unit]"]').val() || 'CM').toUpperCase();
        const factor = unit === 'IN' ? 1 : 2.54;
        const convert = (value) => Math.round(value * factor * 100) / 100;
        $box.find('input[name$="[length]"]').val(convert(inches.length));
        $box.find('input[name$="[width]"]').val(convert(inches.width));
        $box.find('input[name$="[height]"]').val(convert(inches.height));
        const $name = $box.find('.fshipping-box-name-field');
        if (!(($name.val() || '') + '').trim()) {
            $name.val(($option.attr('data-name') || preset).trim());
            $name.trigger('input');
        }
    }

    $(document).ready(function () {
        initSelect2(document);

        $(document).on('change', '.fshipping-box-preset', function (e) {
            e.preventDefault();
            applyPackagingPreset($(this));
        });

        $(document).on('click', '#fshipping-add-box', function (e) {
            e.preventDefault();
            addBoxCard();
        });

        $(document).on('click', '.fshipping-remove-box', function (e) {
            e.preventDefault();
            const $cards = $(BOX_LIST).find('.fshipping-box-card').not('.fshipping-template');
            if ($cards.length <= 1) {
                const $card = $(this).closest('.fshipping-box-card');
                $card.find('input[type="text"], input[type="number"]').val('');
                $card.find('select').prop('selectedIndex', 0).trigger('change');
                syncBoxTitles();
                return;
            }
            $(this).closest('.fshipping-box-card').remove();
            reindexBoxes();
        });

        $(document).on('click', '.fshipping-box-toggle', function (e) {
            e.preventDefault();
            const $box = $(this).closest('.fshipping-box-card');
            const isCollapsed = $box.hasClass(COLLAPSED_CLASS);
            setBoxCollapsed($box, !isCollapsed);
        });

        $(document).on('click', '.fshipping-add-rule', function (e) {
            e.preventDefault();
            addRuleRow($(this).closest('.fshipping-box-card'));
        });

        $(document).on('click', '.fshipping-remove-rule', function (e) {
            e.preventDefault();
            const $tbody = $(this).closest('tbody');
            const $rows = $tbody.find('tr').not('.fshipping-template');
            if ($rows.length <= 1) {
                $rows.find('input[type="number"]').val('1');
                $rows.find('select').prop('selectedIndex', 0).trigger('change');
                return;
            }
            $(this).closest('tr').remove();
            reindexBoxes();
        });

        $(document).on('input', '.fshipping-box-name-field', function () {
            const $box = $(this).closest('.fshipping-box-card');
            const boxIndex = $(BOX_LIST).find('.fshipping-box-card').not('.fshipping-template').index($box);
            if (boxIndex >= 0) {
                $box.find('.fshipping-box-toggle-label').text(getBoxTitle($box, boxIndex));
            }
        });

        $(BOX_LIST).find('.fshipping-box-card').not('.fshipping-template').each(function () {
            setBoxCollapsed($(this), true);
        });
        syncBoxTitles();
    });
})(jQuery);

