(function ($) {
  function showAlerts(errors, warnings) {
    var $box = $('#fshipping-os-alerts');
    $box.empty().removeAttr('hidden');
    function add(cls, text) {
      $box.append(
        $('<div class="notice"/>')
          .addClass(cls)
          .text(text)
      );
    }
    (errors || []).forEach(function (m) {
      add('notice-error', m);
    });
    (warnings || []).forEach(function (m) {
      add('notice-warning', m);
    });
    if (!$box.children().length) {
      $box.attr('hidden', 'hidden');
    }
  }

  function collectShipmentOverrides() {
    return {
      serviceType: $('#fshipping-os-service').val() || '',
      pickupType: $('#fshipping-os-pickup').val() || '',
      packagingType: $('#fshipping-os-packaging').val() || '',
      paymentType: $('#fshipping-os-payment').val() || '',
    };
  }

  function getOrderLineQtyMap() {
    var el = document.getElementById('fshipping-os-order-items');
    if (!el || !el.textContent) {
      return {};
    }
    try {
      var rows = JSON.parse(el.textContent);
      var map = {};
      if (!Array.isArray(rows)) {
        return {};
      }
      rows.forEach(function (r) {
        if (r && r.order_item_id != null) {
          map[parseInt(r.order_item_id, 10)] = parseInt(r.max, 10) || 0;
        }
      });
      return map;
    } catch (e) {
      return {};
    }
  }

  var fshippingOsCapsUpdating = false;

  /**
   * Append dropdown to body so positioning matches the viewport and nested meta-box /
   * accordion layout does not pin menus to the wrong coordinates (e.g. top of the page).
   */
  function openshipDropdownParent() {
    return $(document.body);
  }

  /**
   * @param {Record<string, unknown>} obj
   * @param {string[]} parts
   * @param {unknown} value
   */
  function deepSet(obj, parts, value) {
    var i;
    var cur = obj;
    for (i = 0; i < parts.length - 1; i++) {
      var k = parts[i];
      if (!cur[k] || typeof cur[k] !== 'object' || Object.prototype.toString.call(cur[k]) === '[object Array]') {
        cur[k] = {};
      }
      cur = cur[k];
    }
    cur[parts[parts.length - 1]] = value;
  }

  function initOpenshipSelect2($root) {
    function run() {
      $root.find('select.fedex-select2').each(function () {
        var $s = $(this);
        if ($s.data('select2')) {
          try {
            $s.select2('destroy');
          } catch (e) {}
        }
        var ph = $s.data('placeholder');
        var w = $s.data('width');
        if (w == null || w === '') {
          w = '100%';
        }
        $s.select2({
          width: w,
          placeholder: ph || undefined,
          allowClear: !$s.prop('multiple'),
          dropdownParent: openshipDropdownParent(),
        });
      });
    }
    if (window.requestAnimationFrame) {
      window.requestAnimationFrame(function () {
        window.requestAnimationFrame(run);
      });
    } else {
      window.setTimeout(run, 0);
    }
  }

  function destroyOpenshipSelect2($root) {
    $root.find('select.fedex-select2').each(function () {
      var $s = $(this);
      if ($s.data('select2')) {
        try {
          $s.select2('destroy');
        } catch (e) {}
      }
    });
  }

  function refreshAlcoholVisibility($box) {
    var $sel = $box.find('select[data-json-key="packageSpecialServices.specialServiceTypes"]');
    if (!$sel.length) {
      return;
    }
    var vals = $sel.val();
    var show = Array.isArray(vals) ? vals.indexOf('ALCOHOL') >= 0 : false;
    $box.find('.fshipping-pss-alcohol').each(function () {
      var $p = $(this);
      if (show) {
        $p.removeAttr('hidden');
      } else {
        $p.attr('hidden', 'hidden');
      }
    });
  }

  /**
   * Serialize optional FedEx line-item fields from one package box.
   *
   * @param {JQuery} $box
   * @returns {Record<string, unknown>}
   */
  function collectPackageLineExtras($box) {
    var $ex = $box.find('.fshipping-os-package-extras');
    if (!$ex.length) {
      return {};
    }
    /** @type {Record<string, unknown>} */
    var out = {};

    $ex.find('.fshipping-x-field').each(function () {
      var $el = $(this);
      var key = $el.data('json-key');
      if (!key) {
        return;
      }
      var parts = String(key).split('.');
      var tag = ($el.prop('tagName') || '').toUpperCase();

      if (tag === 'SELECT' && $el.prop('multiple')) {
        var mval = $el.val();
        if (!mval || !mval.length) {
          return;
        }
        deepSet(out, parts, mval);
        return;
      }

      if (tag === 'INPUT' && $el.attr('type') === 'checkbox') {
        if ($el.prop('checked')) {
          deepSet(out, parts, true);
        }
        return;
      }

      var raw = ($el.val() != null ? String($el.val()) : '').trim();
      if (raw === '') {
        return;
      }

      var leaf = parts[parts.length - 1];
      if (leaf === 'groupPackageCount' || leaf === 'receivedQuantity' || leaf === 'pieceCountVerificationBoxCount') {
        var ni = parseInt(raw, 10);
        if (isNaN(ni)) {
          return;
        }
        deepSet(out, parts, ni);
        return;
      }
      if (leaf === 'percentValue' || leaf === 'value' || leaf === 'amount') {
        var nf = parseFloat(raw);
        if (isNaN(nf)) {
          return;
        }
        deepSet(out, parts, nf);
        return;
      }
      if (leaf === 'sequenceNumber') {
        deepSet(out, parts, raw);
        return;
      }

      deepSet(out, parts, raw);
    });

    var cr = [];
    $ex.find('.fshipping-cr-tbody tr.fshipping-cr-row').not('.fshipping-cr-template').each(function () {
      var $tr = $(this);
      var inum = ($tr.find('.fshipping-cr-inum').val() || '').trim();
      var rqty = $tr.find('.fshipping-cr-qty').val();
      var part = ($tr.find('.fshipping-cr-part').val() || '').trim();
      if (!inum && !part && (rqty === '' || rqty == null)) {
        return;
      }
      /** @type {Record<string, unknown>} */
      var row = {};
      if (inum) {
        row.itemNumber = inum;
      }
      if (rqty !== '' && rqty != null) {
        var qi = parseInt(String(rqty), 10);
        if (!isNaN(qi)) {
          row.receivedQuantity = qi;
        }
      }
      if (part) {
        row.partNumber = part;
      }
      if (Object.keys(row).length) {
        cr.push(row);
      }
    });
    if (cr.length) {
      out.contentRecord = cr;
    }

    $ex.find('.fshipping-str-list').each(function () {
      var $ul = $(this);
      var parent = $ul.data('json-parent');
      if (!parent) {
        return;
      }
      var arr = [];
      $ul.find('.fshipping-x-str').each(function () {
        var t = ($(this).val() || '').trim();
        if (t) {
          arr.push(t);
        }
      });
      if (arr.length) {
        deepSet(out, String(parent).split('.'), arr);
      }
    });

    var batteryDetails = [];
    $ex.find('.fshipping-battery-rows .fshipping-battery-row').not('.fshipping-battery-template').each(function () {
      var $row = $(this);
      var bpt = ($row.find('.fshipping-b-bpt').val() || '').trim();
      var brt = ($row.find('.fshipping-b-brt').val() || '').trim();
      var bmt = ($row.find('.fshipping-b-bmt').val() || '').trim();
      if (!bpt || !bmt) {
        return;
      }
      /** @type {Record<string, string>} */
      var bd = { batteryPackingType: bpt, batteryMaterialType: bmt };
      if (brt) {
        bd.batteryRegulatoryType = brt;
      }
      batteryDetails.push(bd);
    });
    if (batteryDetails.length) {
      if (!out.packageSpecialServices || typeof out.packageSpecialServices !== 'object') {
        out.packageSpecialServices = {};
      }
      out.packageSpecialServices.batteryDetails = batteryDetails;
    }

    var standalone = [];
    $ex.find('.fshipping-sbatt-rows .fshipping-sbatt-row').each(function () {
      var bmt = ($(this).find('.fshipping-sbatt-mt').val() || '').trim();
      if (bmt) {
        standalone.push({ batteryMaterialType: bmt });
      }
    });
    if (standalone.length) {
      if (!out.packageSpecialServices || typeof out.packageSpecialServices !== 'object') {
        out.packageSpecialServices = {};
      }
      out.packageSpecialServices.standaloneBatteryDetails = standalone;
    }

    return out;
  }

  function resetExtrasPanel($panel) {
    $panel.find('input[type=text],input[type=number],textarea').each(function () {
      var $el = $(this);
      if ($el.closest('.fshipping-cr-template,.fshipping-battery-template').length) {
        return;
      }
      $el.val('');
    });
    $panel.find('input[type=checkbox]').each(function () {
      var $el = $(this);
      if ($el.closest('.fshipping-cr-template,.fshipping-battery-template').length) {
        return;
      }
      $el.prop('checked', false);
    });
    $panel.find('select').each(function () {
      var $el = $(this);
      if ($el.closest('.fshipping-cr-template,.fshipping-battery-template').length) {
        return;
      }
      if ($el.prop('multiple')) {
        $el.val(null);
      } else {
        $el.prop('selectedIndex', 0);
      }
    });
    $panel.find('.fshipping-cr-tbody tr.fshipping-cr-row').not('.fshipping-cr-template').slice(1).remove();
    $panel.find('.fshipping-cr-tbody tr.fshipping-cr-row').not('.fshipping-cr-template').first().find('input').val('');
    $panel.find('.fshipping-str-list').each(function () {
      var $ul = $(this);
      $ul.find('li').slice(1).remove();
      $ul.find('li').first().find('.fshipping-x-str').val('');
    });
    $panel.find('.fshipping-battery-rows .fshipping-battery-row').not('.fshipping-battery-template').slice(1).remove();
    var $b0 = $panel.find('.fshipping-battery-rows .fshipping-battery-row').not('.fshipping-battery-template').first();
    if ($b0.length) {
      $b0.find('input').val('');
      $b0.find('select').prop('selectedIndex', 0);
    }
    $panel.find('.fshipping-sbatt-rows .fshipping-sbatt-row').slice(1).remove();
    var $s0 = $panel.find('.fshipping-sbatt-rows .fshipping-sbatt-row').first();
    if ($s0.length) {
      $s0.find('select').prop('selectedIndex', 0);
    }
  }

  /**
   * Per-box max = order line qty minus qty assigned in other boxes. Clamps inputs to [0, max].
   */
  function updateBoxItemQtyCaps() {
    if (fshippingOsCapsUpdating) {
      return;
    }
    fshippingOsCapsUpdating = true;
    var lineMax = getOrderLineQtyMap();
    try {
    $('#fshipping-os-boxes .fshipping-os-box').each(function () {
      var $box = $(this);
      var sumsOther = {};
      $('#fshipping-os-boxes .fshipping-os-box')
        .not($box)
        .each(function () {
          $(this)
            .find('.fshipping-box-item-qty')
            .each(function () {
              var $i = $(this);
              var id = parseInt($i.data('order-item-id'), 10);
              var q = parseInt($i.val(), 10) || 0;
              sumsOther[id] = (sumsOther[id] || 0) + q;
            });
        });
      $box.find('.fshipping-box-item-qty').each(function () {
        var $i = $(this);
        var id = parseInt($i.data('order-item-id'), 10);
        var lm =
          lineMax[id] != null
            ? lineMax[id]
            : parseInt($i.attr('data-order-line-qty'), 10) || 0;
        var used = sumsOther[id] || 0;
        var cap = Math.max(0, lm - used);
        $i.attr('max', cap);
        var v = parseInt($i.val(), 10) || 0;
        if (v > cap) {
          $i.val(cap);
        }
      });
    });
    } finally {
      fshippingOsCapsUpdating = false;
    }
  }

  function collectPackages() {
    var rows = [];
    $('#fshipping-os-boxes .fshipping-os-box').each(function () {
      var $box = $(this);
      var items = [];
      $box.find('.fshipping-box-item-qty').each(function () {
        var $i = $(this);
        var q = parseInt($i.val(), 10) || 0;
        var cap = parseInt($i.attr('max'), 10);
        if (!isNaN(cap) && q > cap) {
          q = cap;
          $i.val(q);
        }
        if (q > 0) {
          items.push({
            order_item_id: parseInt($i.data('order-item-id'), 10),
            qty: q,
          });
        }
      });
      var row = {
        fedex_package_id: ($box.find('.fshipping-pkg-fedex-id').val() || '').trim(),
        fedex_delete_id: ($box.find('.fshipping-pkg-fedex-del').val() || '').trim(),
        fedex_sequence: ($box.find('.fshipping-pkg-fedex-seq').val() || '').trim(),
        box_name: ($box.find('.fshipping-pkg-name').val() || '').trim(),
        weight: parseFloat($box.find('.fshipping-pkg-weight').val()) || 0,
        weight_unit: $box.find('.fshipping-pkg-wu').val() || 'LB',
        length: parseInt($box.find('.fshipping-pkg-l').val(), 10) || 0,
        width: parseInt($box.find('.fshipping-pkg-w').val(), 10) || 0,
        height: parseInt($box.find('.fshipping-pkg-h').val(), 10) || 0,
        dimension_unit: $box.find('.fshipping-pkg-du').val() || 'IN',
        declared_value_amount: parseFloat($box.find('.fshipping-pkg-dv').val()) || 0,
        declared_value_currency: ($box.find('.fshipping-pkg-dvc').val() || 'USD').trim(),
        items: items,
      };
      var extras = collectPackageLineExtras($box);
      if (extras && Object.keys(extras).length) {
        row.package_line_extras = extras;
      }
      rows.push(row);
    });
    return rows;
  }

  function updateTotalWeight() {
    var totalLb = 0;
    collectPackages().forEach(function (p) {
      var w = p.weight || 0;
      if (p.weight_unit === 'KG') {
        totalLb += w * 2.20462;
      } else {
        totalLb += w;
      }
    });
    $('#fshipping-os-total-w').text(
      (fshippingOpenShip.i18n.totalWeightPrefix || 'Total (est. lb): ') + totalLb.toFixed(2)
    );
  }

  function renderPushResultsTable(rows) {
    var $wrap = $('#fshipping-os-push-results-wrap');
    var $tb = $('#fshipping-os-push-results-body');
    if (!$tb.length) {
      return;
    }
    $tb.empty();
    if (!rows || !rows.length) {
      $wrap.attr('hidden', 'hidden');
      return;
    }
    $wrap.removeAttr('hidden');
    var locked = !!fshippingOpenShip.confirmed;
    rows.forEach(function (row) {
      var num = row.package_number != null ? String(row.package_number) : '';
      var tr = $('<tr/>');
      var ok = !!row.success;
      var stLabel = ok
        ? fshippingOpenShip.i18n.success || 'Success'
        : fshippingOpenShip.i18n.failed || 'Failed';
      var pill = $('<span class="fshipping-os-status-pill"/>')
        .addClass(ok ? 'is-ok' : 'is-fail')
        .text(stLabel);
      tr.append($('<td/>').text(num === '0' ? '—' : num));
      tr.append($('<td/>').append($('<code/>').text(row.tracking_number || '—')));
      tr.append($('<td/>').text(row.sequence_number || '—'));
      tr.append($('<td/>').append(pill));
      tr.append($('<td/>').text(row.message || ''));
      tr.append($('<td/>').append($('<code/>').text(row.transaction_id || '—')));
      var trackingNum = row.tracking_number != null ? String(row.tracking_number).trim() : '';
      var hasTracking = trackingNum !== '' && trackingNum !== '—';
      var $act = $('<td/>');
      var showPkgActions =
        num !== '0' && row.action !== 'update_shipment' && parseInt(num, 10) > 0 && hasTracking;
      if (showPkgActions) {
        var pIdx = parseInt(num, 10) - 1;
        if (locked) {
          $act.append(
            $('<span class="description"/>').text(fshippingOpenShip.i18n.lockedActions || '')
          );
        } else {
          var $edit = $('<button type="button" class="button button-small"/>')
            .text(fshippingOpenShip.i18n.editRow || 'Edit')
            .attr('data-pkg-idx', String(pIdx));
          var $del = $('<button type="button" class="button button-small"/>')
            .text(fshippingOpenShip.i18n.deleteRow || 'Delete')
            .attr('data-pkg-idx', String(pIdx))
            .attr('data-fedex-id', trackingNum);
          $act.append($edit, ' ', $del);
        }
      } else {
        var txnId = row.transaction_id != null ? String(row.transaction_id).trim() : '';
        if (txnId !== '' && txnId !== '—') {
          $act.append(
            $('<button type="button" class="button button-small fshipping-os-copy-txn"/>')
              .text(fshippingOpenShip.i18n.copyTxnId || 'Copy transaction ID')
              .attr('data-txn-id', txnId)
          );
        } else {
          $act.text('—');
        }
      }
      tr.append($act);
      $tb.append(tr);
    });
  }

  function post(action, extra, cb) {
    var data = {
      action: action,
      nonce: fshippingOpenShip.nonce,
      order_id: fshippingOpenShip.orderId,
    };
    $.extend(data, extra || {});
    return $.ajax({
      url: fshippingOpenShip.ajaxUrl,
      type: 'POST',
      data: data,
      dataType: 'json',
    })
      .done(function (res) {
        if (!res || typeof res.success === 'undefined') {
          console.error('fshipping openship: not JSON', res);
          window.alert(
            (fshippingOpenShip.i18n.requestFailed || 'Request failed') +
              ' (server did not return JSON — check PHP errors / plugins outputting HTML).'
          );
          return;
        }
        if (res.success) {
          var warnings = res.data && res.data.warnings ? res.data.warnings : [];
          showAlerts([], warnings);
          if (res.data && res.data.notice) {
            var $box = $('#fshipping-os-alerts');
            $box.removeAttr('hidden');
            $box.append(
              $('<div class="notice notice-success is-dismissible"/>').text(res.data.notice)
            );
          }
          if (res.data && res.data.push_rows) {
            renderPushResultsTable(res.data.push_rows);
          }
          if (cb) {
            cb(res);
          } else {
            window.setTimeout(function () {
              window.location.reload();
            }, 900);
          }
        } else {
          var msg = res.data && res.data.message ? res.data.message : 'Error';
          var errs = res.data && res.data.errors && res.data.errors.length ? res.data.errors : null;
          if (errs) {
            msg = errs.join('\n\n');
          }
          if (res.data && res.data.openship_create_request) {
            console.info('[teamzlab-fedex] openshipments/create request (error path):\n', res.data.openship_create_request);
          }
          if (res.data && res.data.openship_create_response) {
            console.info('[teamzlab-fedex] openshipments/create response (error path):\n', res.data.openship_create_response);
          }
          showAlerts([msg], res.data && res.data.warnings ? res.data.warnings : []);
          window.alert(msg);
        }
      })
      .fail(function (xhr, status, err) {
        var snippet = '';
        var wpMsg = '';
        try {
          if (xhr.responseJSON && xhr.responseJSON.data) {
            var d = xhr.responseJSON.data;
            if (typeof d === 'string') {
              wpMsg = d;
            } else if (d && d.errors && Array.isArray(d.errors) && d.errors.length) {
              wpMsg = d.errors.join('\n\n');
            } else if (d && d.message) {
              wpMsg = d.message;
            }
            if (d && d.openship_create_request) {
              console.info('[teamzlab-fedex] openshipments/create request (HTTP error path):\n', d.openship_create_request);
            }
            if (d && d.openship_create_response) {
              console.info('[teamzlab-fedex] openshipments/create response (HTTP error path):\n', d.openship_create_response);
            }
          }
          snippet = xhr.responseText
            ? xhr.responseText.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().substring(0, 500)
            : '';
        } catch (e) {}
        console.error('fshipping openship ajax', status, err, xhr.status, xhr.responseText);
        if (wpMsg) {
          window.alert(wpMsg);
          return;
        }
        window.alert(
          (fshippingOpenShip.i18n.requestFailed || 'Request failed') +
            (xhr.status ? ' HTTP ' + xhr.status : '') +
            (snippet ? ': ' + snippet : '')
        );
      });
  }

  $(document).on('click', '#fshipping-os-save-settings', function () {
    var $btn = $(this);
    $btn.prop('disabled', true);
    post('fshipping_openship_save_shipment_settings', {
      shipment_overrides: JSON.stringify(collectShipmentOverrides()),
    }, function () {
      window.location.reload();
    }).always(function () {
      $btn.prop('disabled', false);
    });
  });

  $(document).on('click', '#fshipping-os-save-push', function () {
    var pkgs = collectPackages();
    if (!pkgs.length) {
      window.alert(fshippingOpenShip.i18n.needOneBox);
      return;
    }
    var $btn = $(this);
    $btn.prop('disabled', true);
    post(
      'fshipping_openship_save_packages',
      {
        packages: JSON.stringify(pkgs),
      }
    ).always(function () {
      $btn.prop('disabled', false);
    });
  });

  $(document).on('click', '#fshipping-os-clear-all-pkgs', function () {
    if (!window.confirm(fshippingOpenShip.i18n.confirmClearAll)) {
      return;
    }
    if (fshippingOpenShip.confirmed) {
      window.alert(fshippingOpenShip.i18n.lockedActions || '');
      return;
    }
    var $btn = $(this);
    $btn.prop('disabled', true);
    post('fshipping_openship_clear_all_packages', {}, function () {
      window.location.reload();
    }).always(function () {
      $btn.prop('disabled', false);
    });
  });

  $(document).on('click', '#fshipping-os-push-results .fshipping-os-copy-txn', function () {
    var $btn = $(this);
    var id = ($btn.data('txn-id') || '').toString().trim();
    if (!id) {
      return;
    }
    var prev = $btn.text();
    var flashCopied = function () {
      $btn.text(fshippingOpenShip.i18n.copiedTxn || 'Copied.');
      window.setTimeout(function () {
        $btn.text(prev);
      }, 1500);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(id).then(flashCopied).catch(function () {
        window.prompt(fshippingOpenShip.i18n.copyTxnId || 'Copy transaction ID', id);
      });
    } else {
      window.prompt(fshippingOpenShip.i18n.copyTxnId || 'Copy transaction ID', id);
    }
  });

  $(document).on('click', '#fshipping-os-push-results .button[data-pkg-idx]', function () {
    var $b = $(this);
    var idx = parseInt($b.data('pkg-idx'), 10);
    if (isNaN(idx)) {
      return;
    }
    var $box = $('#fshipping-os-boxes .fshipping-os-box').eq(idx);
    if (!$box.length) {
      return;
    }
    var tEdit = fshippingOpenShip.i18n.editRow || 'Edit';
    var tSave = fshippingOpenShip.i18n.saveRow || 'Save';
    var tDel = fshippingOpenShip.i18n.deleteRow || 'Delete';
    var txt = ($b.text() || '').trim();

    if (txt === tEdit) {
      var el = $box[0];
      if (el && el.scrollIntoView) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      $box.find('.fshipping-pkg-weight').first().trigger('focus');
      return;
    }

    if (txt === tSave) {
      var liveTracking = ($box.find('.fshipping-pkg-fedex-id').val() || '').toString().trim();
      if (!liveTracking) {
        window.alert(fshippingOpenShip.i18n.noTrackingActions || 'No tracking number on this row yet.');
        return;
      }
      var patch = {
        weight: parseFloat($box.find('.fshipping-pkg-weight').val()) || 0,
        weight_unit: $box.find('.fshipping-pkg-wu').val() || 'LB',
        length: parseInt($box.find('.fshipping-pkg-l').val(), 10) || 0,
        width: parseInt($box.find('.fshipping-pkg-w').val(), 10) || 0,
        height: parseInt($box.find('.fshipping-pkg-h').val(), 10) || 0,
        dimension_unit: $box.find('.fshipping-pkg-du').val() || 'IN',
      };
      $b.prop('disabled', true);
      post(
        'fshipping_openship_modify_package',
        {
          package_index: idx,
          package: JSON.stringify(patch),
        },
        function () {
          window.location.reload();
        }
      ).always(function () {
        $b.prop('disabled', false);
      });
      return;
    }

    if (txt === tDel) {
      if (!window.confirm(fshippingOpenShip.i18n.confirmDeletePkg)) {
        return;
      }
      var fid = ($b.data('fedex-id') || '').toString();
      if (!fid) {
        window.alert(fshippingOpenShip.i18n.noTrackingActions || 'No tracking number on this row yet.');
        return;
      }
      $b.prop('disabled', true);
      post(
        'fshipping_openship_delete_package',
        {
          package_index: idx,
          fedex_package_id: fid,
        },
        function () {
          window.location.reload();
        }
      ).always(function () {
        $b.prop('disabled', false);
      });
    }
  });

  $(document).on('click', '#fshipping-os-recalc', function () {
    updateTotalWeight();
  });

  $(document).on('click', '#fshipping-os-restart', function () {
    if (!window.confirm(fshippingOpenShip.i18n.confirmRestart)) {
      return;
    }
    var pkgs = collectPackages();
    if (!pkgs.length) {
      window.alert(fshippingOpenShip.i18n.needOneBox);
      return;
    }
    var $btn = $(this);
    $btn.prop('disabled', true);
    post('fshipping_openship_restart_session', {
      packages: JSON.stringify(pkgs),
      shipment_overrides: JSON.stringify(collectShipmentOverrides()),
    }).always(function () {
      $btn.prop('disabled', false);
    });
  });

  $(document).on('click', '#fshipping-os-add-box', function () {
    var $first = $('#fshipping-os-boxes .fshipping-os-box').first();
    if (!$first.length) {
      return;
    }
    var $clone = $first.clone(true, true);
    destroyOpenshipSelect2($clone);
    $clone.find('input[type="text"],input[type="number"]').each(function () {
      var $el = $(this);
      if ($el.closest('.fshipping-os-package-extras').length) {
        return;
      }
      if ($el.hasClass('fshipping-pkg-name')) {
        var n = $('#fshipping-os-boxes .fshipping-os-box').length + 1;
        $el.val((fshippingOpenShip.i18n.boxPrefix || 'Box') + ' ' + n);
      } else if ($el.hasClass('fshipping-pkg-dv')) {
        $el.val('');
      } else if ($el.hasClass('fshipping-box-item-qty')) {
        $el.val('0');
      } else if ($el.hasClass('fshipping-pkg-weight')) {
        $el.val('1');
      } else if (
        $el.hasClass('fshipping-pkg-l') ||
        $el.hasClass('fshipping-pkg-w') ||
        $el.hasClass('fshipping-pkg-h')
      ) {
        $el.val('10');
      }
    });
    $clone.find('.fshipping-pkg-fedex').text('—');
    $clone.find('.fshipping-pkg-fedex-id').val('');
    $clone.find('.fshipping-pkg-fedex-del').val('');
    $clone.find('.fshipping-pkg-fedex-seq').val('');
    var $extras = $clone.find('.fshipping-os-package-extras');
    resetExtrasPanel($extras);
    $extras.attr('hidden', 'hidden');
    $clone.find('.fshipping-os-extras-toggle').attr('aria-expanded', 'false').removeClass('is-open');
    $('#fshipping-os-boxes').append($clone);
    refreshAlcoholVisibility($clone);
    updateBoxItemQtyCaps();
    updateTotalWeight();
  });

  $(document).on('click', '.fshipping-os-extras-toggle', function (e) {
    e.preventDefault();
    var $btn = $(this);
    var $panel = $btn.next('.fshipping-os-package-extras');
    if (!$panel.length) {
      return;
    }
    var open = !!$panel.prop('hidden');
    if (open) {
      $panel.removeAttr('hidden');
      $btn.attr('aria-expanded', 'true').addClass('is-open');
      initOpenshipSelect2($panel);
      refreshAlcoholVisibility($btn.closest('.fshipping-os-box'));
    } else {
      $panel.attr('hidden', 'hidden');
      $btn.attr('aria-expanded', 'false').removeClass('is-open');
    }
  });

  $(document).on('change select2:select', '.fshipping-os-box select[data-json-key="packageSpecialServices.specialServiceTypes"]', function () {
    refreshAlcoholVisibility($(this).closest('.fshipping-os-box'));
  });

  $(document).on('click', '.fshipping-cr-add', function () {
    var $tb = $(this).closest('p').prev('table').find('.fshipping-cr-tbody');
    var $tpl = $tb.find('tr.fshipping-cr-template');
    if (!$tpl.length) {
      return;
    }
    var $row = $tpl.clone(true);
    $row.removeClass('fshipping-cr-template').removeAttr('hidden');
    $row.find('input').val('');
    $tpl.before($row);
  });

  $(document).on('click', '.fshipping-cr-remove', function () {
    var $tr = $(this).closest('tr');
    var $tb = $tr.closest('tbody');
    if ($tr.hasClass('fshipping-cr-template')) {
      return;
    }
    if ($tb.find('tr.fshipping-cr-row').not('.fshipping-cr-template').length < 2) {
      $tr.find('input').val('');
      return;
    }
    $tr.remove();
  });

  $(document).on('click', '.fshipping-str-add', function () {
    var $btn = $(this);
    var $ul = $btn.closest('p').prev('.fshipping-str-list');
    if (!$ul.length) {
      return;
    }
    var $li = $ul.find('li').first().clone(false);
    $li.find('input').val('');
    $ul.append($li);
  });

  $(document).on('click', '.fshipping-str-remove', function () {
    var $li = $(this).closest('li');
    var $ul = $li.parent();
    if ($ul.find('li').length < 2) {
      $li.find('input').val('');
      return;
    }
    $li.remove();
  });

  $(document).on('click', '.fshipping-battery-add', function () {
    var $rows = $(this).closest('p').prev('.fshipping-battery-rows');
    var $tpl = $rows.find('.fshipping-battery-template');
    if (!$tpl.length) {
      return;
    }
    var $row = $tpl.clone(false);
    $row.removeClass('fshipping-battery-template').removeAttr('hidden').show();
    $row.find('input').val('');
    $row.find('select').prop('selectedIndex', 0);
    $tpl.before($row);
    initOpenshipSelect2($row);
  });

  $(document).on('click', '.fshipping-battery-remove', function () {
    var $row = $(this).closest('.fshipping-battery-row');
    var $wrap = $row.parent();
    if ($row.hasClass('fshipping-battery-template')) {
      return;
    }
    if ($wrap.find('.fshipping-battery-row').not('.fshipping-battery-template').length < 2) {
      $row.find('input').val('');
      $row.find('select').prop('selectedIndex', 0);
      return;
    }
    $row.remove();
  });

  $(document).on('click', '.fshipping-sbatt-add', function () {
    var $wrap = $(this).closest('p').prev('.fshipping-sbatt-rows');
    if (!$wrap.length) {
      return;
    }
    var $first = $wrap.find('.fshipping-sbatt-row').first();
    var $row = $first.clone(false);
    $row.find('select').prop('selectedIndex', 0);
    $wrap.append($row);
    initOpenshipSelect2($row);
  });

  $(document).on('click', '.fshipping-sbatt-remove', function () {
    var $row = $(this).closest('.fshipping-sbatt-row');
    var $wrap = $row.parent();
    if ($wrap.find('.fshipping-sbatt-row').length < 2) {
      $row.find('select').prop('selectedIndex', 0);
      return;
    }
    $row.remove();
  });

  $(document).on('click', '.fshipping-os-remove-box', function () {
    if ($('#fshipping-os-boxes .fshipping-os-box').length < 2) {
      window.alert(fshippingOpenShip.i18n.needOneBox);
      return;
    }
    $(this).closest('.fshipping-os-box').remove();
    updateBoxItemQtyCaps();
    updateTotalWeight();
  });

  $(document).on('input change', '.fshipping-box-item-qty', function () {
    updateBoxItemQtyCaps();
  });

  $(document).on('click', '#fshipping-openship-confirm', function () {
    if (!window.confirm(fshippingOpenShip.i18n.confirmFinalize)) {
      return;
    }
    var $btn = $(this);
    $btn.prop('disabled', true);
    post('fshipping_openship_confirm', {}).always(function () {
      $btn.prop('disabled', false);
    });
  });

  $(function () {
    updateBoxItemQtyCaps();
    updateTotalWeight();
    renderPushResultsTable(
      Array.isArray(fshippingOpenShip.lastPushRows) ? fshippingOpenShip.lastPushRows : []
    );
    $('#fshipping-os-boxes .fshipping-os-box').each(function () {
      refreshAlcoholVisibility($(this));
    });
  });
})(jQuery);
