(function($) {
    $(document).ready(() => {
        // Wide data tables scroll horizontally inside their own container at
        // every breakpoint, instead of WP stacking cell letters per line.
        $('.wp-list-table, table.widefat').each(function() {
            const $table = $(this);
            if ($table.parent('.fsa-table-scroll').length) {
                return;
            }
            // The Open Ship push-results wrapper already scrolls itself.
            if ($table.closest('.fshipping-os-push-results-wrap').length) {
                return;
            }
            $table.wrap('<div class="fsa-table-scroll" />');
        });

        if ($.fn.select2) {
            $('.fedex-select2').each(function () {
                var $s = $(this);
                $s.select2({
                    width: $s.data('width') != null && $s.data('width') !== '' ? $s.data('width') : 'style',
                    dropdownParent: $(document.body),
                });
            });
        }
        $(document).on('click', '.fshipping-tab-head button', function(e) {
            const $this = $(e.currentTarget);
            const id = $this.attr('data-id');
            $this.parent().find('button').removeClass('active').attr('aria-selected', 'false');
            $this.addClass('active').attr('aria-selected', 'true');
            $(document).find('.fshipping-tab-content .fshipping-tab-content-single').removeClass('active');
            $('#'+ id).addClass('active');
        })

        // Keyboard support for the settings tablist: Left/Right/Home/End
        // move focus + activate, matching the ARIA tabs pattern.
        $(document).on('keydown', '.fshipping-tab-head button[role="tab"]', function(e) {
            const keys = ['ArrowLeft', 'ArrowRight', 'Home', 'End'];
            if (keys.indexOf(e.key) === -1) {
                return;
            }
            const $tabs = $(e.currentTarget).parent().find('button[role="tab"]');
            const index = $tabs.index(e.currentTarget);
            if (index < 0) {
                return;
            }
            let next = index;
            if (e.key === 'ArrowLeft') {
                next = (index - 1 + $tabs.length) % $tabs.length;
            } else if (e.key === 'ArrowRight') {
                next = (index + 1) % $tabs.length;
            } else if (e.key === 'Home') {
                next = 0;
            } else {
                next = $tabs.length - 1;
            }
            e.preventDefault();
            $tabs.eq(next).trigger('focus').trigger('click');
        })

        // "Show" / "Hide" reveal for password fields on the settings screen.
        $(document).on('click', '.fshipping-secret-toggle', function(e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const $input = $('#' + $btn.attr('data-target'));
            if (!$input.length) {
                return;
            }
            const show = $input.attr('type') === 'password';
            $input.attr('type', show ? 'text' : 'password');
            $btn.text(show ? $btn.attr('data-label-hide') || 'Hide' : $btn.attr('data-label-show') || 'Show');
            $btn.attr('aria-pressed', show ? 'true' : 'false');
        })

        // Copy-to-clipboard helper (webhook URLs, etc.).
        $(document).on('click', '.fshipping-copy-inline', function(e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const text = $btn.attr('data-copy') || '';
            if (!text) {
                return;
            }
            const flash = () => {
                const original = $btn.attr('data-label-original') || $btn.text();
                $btn.attr('data-label-original', original);
                $btn.text('Copied');
                setTimeout(() => $btn.text(original), 1600);
            };
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(flash, () => {});
            } else {
                const $tmp = $('<textarea>').val(text).css({position: 'fixed', opacity: 0}).appendTo('body');
                $tmp[0].select();
                try { document.execCommand('copy'); flash(); } catch (err) {}
                $tmp.remove();
            }
        })

        $(document).on('click', '.fedex-cancel-shipment', function(e) {
            e.preventDefault();
            const $this = $(e.currentTarget);
            const trackingId = $this.attr('data-tracking_id');
            const originalText = $this.text();
            $this.prop('disabled', true).text('Canceling...');
            
            $.ajax({
                url: fshipping_params.ajax_url,
                method: 'POST',
                data: {
                    action: 'fshipping_cancel_shipment',
                    nonce: fshipping_params.nonce,
                    trackingId
                },
                success: function(response) {
                    if (response?.success) {
                        $this.text('Canceled');
                        const $row = $this.closest('tr');
                        if ($row.length) {
                            $row.addClass('fshipping-row-canceled').removeClass('fshipping-row-printed');
                        }
                        showActionNotice('Your shipment has been canceled.', false, 'Shipment canceled');
                    } else {
                        $this.prop('disabled', false).text(originalText);
                        showActionNotice(formatAjaxError(response, 'Please try again.'), true, 'Shipment could not be canceled');
                    }
                },
                error: function(xhr, status, error) {
                    $this.prop('disabled', false).text(originalText);
                    const res = xhr?.responseJSON || {};
                    showActionNotice(formatAjaxError(res, 'Please try again.'), true, 'Shipment could not be canceled');
                }
            });
        })

        $(document).on('click', '.fedex-shipping-track', function(e) {
            e.preventDefault();
            const $this = $(e.currentTarget);
            const trackingId = $this.attr('data-tracking_id');
            const originalText = $this.text();

            $this.prop('disabled', true).text('Tracking...');
            
            $.ajax({
                url: fshipping_params.ajax_url,
                method: 'POST',
                data: {
                    action: 'fshipping_track_shipment',
                    nonce: fshipping_params.nonce,
                    trackingId
                },
                success: function(response) {
                    $(document).find('.display-fedex-shipping-poup').html(response?.data?.html);
                    $(document).find('.display-fedex-shipping-poup').addClass('active');
                    $this.text('Track Again');
                },
                error: function(xhr, status, error) {
                    alert('AJAX error: ' + error);
                    $this.text(originalText);
                },
                complete: function() {
                    $this.prop('disabled', false);
                }
            });
        })

        $(document).on('click', '.display-fedex-shipping-poup', function(e) {
            if ($(e.target).closest('.fshipping-tracking-card').length) {
                return;
            }

            $(document).find('.display-fedex-shipping-poup').removeClass('active');

        });

        const dismissNotice = ($notice) => {
            if (!$notice.length || $notice.data('fshipping-dismissed')) return;
            $notice.data('fshipping-dismissed', true);
            $notice.addClass('fshipping-notice--leaving');
            setTimeout(() => $notice.remove(), 200);
        };

        const showActionNotice = (message, isError = false, title = '') => {
            if (!message) return;
            const type = isError ? 'error' : 'success';
            const icon = isError ? 'dashicons-warning' : 'dashicons-yes-alt';
            const $notice = $(
                `<div class="fshipping-notice fshipping-notice--${type}" role="alert">` +
                    `<span class="fshipping-notice__icon" aria-hidden="true"><span class="dashicons ${icon}"></span></span>` +
                    `<div class="fshipping-notice__body">` +
                        (title ? `<p class="fshipping-notice__title"></p>` : '') +
                        `<p class="fshipping-notice__message"></p>` +
                    `</div>` +
                    `<button type="button" class="fshipping-notice__dismiss" aria-label="Dismiss">` +
                        `<span class="dashicons dashicons-no-alt"></span>` +
                    `</button>` +
                `</div>`
            );
            if (title) {
                $notice.find('.fshipping-notice__title').text(title);
            }
            $notice.find('.fshipping-notice__message').text(message);
            $notice.on('click', '.fshipping-notice__dismiss', () => dismissNotice($notice));
            const $wrap = $('.wrap').first();
            let $stack = $wrap.find('.fshipping-notice-stack').first();
            if (!$stack.length) {
                $stack = $('<div class="fshipping-notice-stack"></div>');
                const $h1 = $wrap.find('h1').first();
                if ($h1.length) {
                    $h1.after($stack);
                } else {
                    $wrap.prepend($stack);
                }
            }
            $stack.prepend($notice);
            setTimeout(() => dismissNotice($notice), 7000);
        };

        // Keep a notice visible across window.location.reload().
        const flashNoticeAfterReload = (message, isError = false, title = '') => {
            try {
                window.sessionStorage.setItem('fshipping_flash_notice', JSON.stringify({ message, isError, title }));
            } catch (e) {}
        };

        const showFlashNotice = () => {
            let flash = null;
            try {
                flash = window.sessionStorage.getItem('fshipping_flash_notice');
                window.sessionStorage.removeItem('fshipping_flash_notice');
            } catch (e) {}
            if (!flash) return;
            try {
                const data = JSON.parse(flash);
                if (data && data.message) showActionNotice(data.message, !!data.isError, data.title || '');
            } catch (e) {}
        };
        showFlashNotice();

        // Plain-language rewrites for API error codes store owners may hit.
        const FRIENDLY_ERROR_MESSAGES = {
            forbidden: "You don't have permission to do this.",
            missing_shipment_id: 'This shipment could not be found. Refresh the page and try again.',
            no_ready_shipments: 'There are no shipments ready for pickup yet.',
            pickup_missing_confirmation: 'FedEx did not return a confirmation number. Please try again.'
        };

        // Soften carrier jargon so the message reads plainly.
        const humanizeApiMessage = (message) => String(message)
            .replace(/\btimestamp\b/gi, 'date/time')
            .replace(/\bpayload\b/gi, 'request')
            .replace(/^pickup ready date\/time\b/i, 'The pickup date/time')
            .trim();

        const formatAjaxError = (response, fallbackText) => {
            const raw = response?.data?.message || response?.data?.fedex_error || '';
            const code = response?.data?.error || '';
            if (raw && !/[{}<>"]/.test(raw)) {
                return humanizeApiMessage(raw);
            }
            if (code && FRIENDLY_ERROR_MESSAGES[code]) {
                return FRIENDLY_ERROR_MESSAGES[code];
            }
            return fallbackText;
        };

        const applyShipmentRowState = ($toggle, isPrinted) => {
            const $row = $toggle.closest('tr');
            if (!$row.length || $row.hasClass('fshipping-row-canceled')) {
                return;
            }
            $row.toggleClass('fshipping-row-printed', !!isPrinted);
        };

        const updateToggleText = ($toggle, isPrinted) => {
            const $text = $toggle.closest('td').find('.fshipping-toggle-text').first();
            if ($text.length) {
                $text.text(isPrinted ? 'Printed' : 'Not printed');
            }
        };

        $(document).on('change', '.fshipping-label-printed-toggle', function(e) {
            const $toggle = $(e.currentTarget);
            const shipmentId = $toggle.data('shipment_id');
            const openshipOrderId = $toggle.data('order_id');
            if (!shipmentId && !openshipOrderId) {
                return;
            }

            const isPrinted = $toggle.is(':checked');
            $toggle.prop('disabled', true);

            $.ajax({
                url: fshipping_params.ajax_url,
                method: 'POST',
                data: {
                    action: 'fshipping_toggle_label_printed',
                    nonce: fshipping_params.nonce,
                    shipment_id: shipmentId,
                    openship_order_id: openshipOrderId,
                    printed: isPrinted ? '1' : '0'
                },
                success: function(response) {
                    if (!response?.success) {
                        $toggle.prop('checked', !isPrinted);
                        updateToggleText($toggle, !isPrinted);
                        showActionNotice(formatAjaxError(response, 'Please try again.'), true, 'Label status not updated');
                        return;
                    }
                    applyShipmentRowState($toggle, isPrinted);
                    updateToggleText($toggle, isPrinted);
                    showActionNotice(isPrinted ? 'This label is now marked as printed.' : 'This label is now marked as not printed.', false, 'Label status updated');
                },
                error: function(xhr) {
                    const res = xhr?.responseJSON || {};
                    $toggle.prop('checked', !isPrinted);
                    updateToggleText($toggle, !isPrinted);
                    showActionNotice(formatAjaxError(res, 'Please try again.'), true, 'Label status not updated');
                },
                complete: function() {
                    $toggle.prop('disabled', false);
                }
            });
        });

        $(document).on('click', '.fshipping-request-pickup', function(e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const shipmentId = $btn.data('shipment_id');
            if (!shipmentId) return;

            $btn.prop('disabled', true).text('Requesting...');
            $.ajax({
                url: fshipping_params.ajax_url,
                method: 'POST',
                data: {
                    action: 'fshipping_request_pickup',
                    nonce: fshipping_params.nonce,
                    shipment_id: shipmentId
                },
                success: function(response) {
                    if (!response?.success) {
                        showActionNotice(formatAjaxError(response, 'Please try again.'), true, 'Pickup could not be scheduled');
                        $btn.prop('disabled', false).text('Request pickup');
                        return;
                    }
                    const confirmation = response?.data?.confirmation || '';
                    if (confirmation) {
                        $btn.replaceWith(`<span class="fshipping-pickup-confirmation">${confirmation}</span>`);
                    } else {
                        $btn.text('Requested');
                    }
                    flashNoticeAfterReload('Your pickup was scheduled with FedEx.', false, 'Pickup scheduled');
                    window.location.reload();
                },
                error: function(xhr) {
                    const res = xhr?.responseJSON || {};
                    showActionNotice(formatAjaxError(res, 'Please try again.'), true, 'Pickup could not be scheduled');
                    $btn.prop('disabled', false).text('Request pickup');
                },
                complete: function() {
                    // Safety net: never leave the row stuck on "Requesting...".
                    if ($btn.closest('body').length && $btn.text() === 'Requesting...') {
                        $btn.prop('disabled', false).text('Request pickup');
                    }
                }
            });
        });

        $(document).on('click', '.fshipping-cancel-pickup', function(e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const shipmentId = $btn.data('shipment_id');
            if (!shipmentId) return;

            $btn.prop('disabled', true).text('Canceling...');
            $.ajax({
                url: fshipping_params.ajax_url,
                method: 'POST',
                data: {
                    action: 'fshipping_cancel_pickup',
                    nonce: fshipping_params.nonce,
                    shipment_id: shipmentId
                },
                success: function(response) {
                    if (!response?.success) {
                        showActionNotice(formatAjaxError(response, 'Please try again.'), true, 'Pickup could not be canceled');
                        $btn.prop('disabled', false).text('Cancel');
                        return;
                    }
                    const affected = response?.data?.shipment_ids?.length || 1;
                    flashNoticeAfterReload(
                        affected === 1 ? 'The pickup was canceled.' : `The pickup was canceled for ${affected} shipments.`,
                        false,
                        'Pickup canceled'
                    );
                    window.location.reload();
                },
                error: function(xhr) {
                    const res = xhr?.responseJSON || {};
                    showActionNotice(formatAjaxError(res, 'Please try again.'), true, 'Pickup could not be canceled');
                    $btn.prop('disabled', false).text('Cancel');
                }
            });
        });

        $(document).on('click', '.fshipping-create-return', function(e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const orderId = $btn.data('order_id');
            if (!orderId) return;

            $btn.prop('disabled', true).text('Creating...');
            $.ajax({
                url: fshipping_params.ajax_url,
                method: 'POST',
                data: {
                    action: 'fshipping_create_return',
                    nonce: fshipping_params.nonce,
                    order_id: orderId
                },
                success: function(response) {
                    if (!response?.success) {
                        showActionNotice(formatAjaxError(response, 'Please try again.'), true, 'Return label could not be created');
                        return;
                    }
                    const labelUrl = response?.data?.label_url || '';
                    if (labelUrl) {
                        $btn.replaceWith(`<a href="${labelUrl}" target="_blank" class="button button-small">Return label</a>`);
                    } else {
                        $btn.text('Created');
                    }
                    showActionNotice('The return label is ready.', false, 'Return created');
                },
                error: function(xhr) {
                    const res = xhr?.responseJSON || {};
                    showActionNotice(formatAjaxError(res, 'Please try again.'), true, 'Return label could not be created');
                    $btn.prop('disabled', false).text('Create return');
                }
            });
        });

        $(document).on('click', '.fshipping-download-spod', function(e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const trackingId = $btn.data('tracking_id');
            if (!trackingId) return;

            const originalText = $btn.text();
            $btn.prop('disabled', true).text('Downloading...');

            $.ajax({
                url: fshipping_params.ajax_url,
                method: 'POST',
                data: {
                    action: 'fshipping_download_spod',
                    nonce: fshipping_params.nonce,
                    trackingId
                },
                success: function(response) {
                    if (!response?.success || !response?.data?.url) {
                        showActionNotice(formatAjaxError(response, 'This document is not ready yet. Please try again in a few minutes.'), true, 'Proof of delivery not available');
                        $btn.prop('disabled', false).text(originalText);
                        return;
                    }

                    const spodUrl = response.data.url;
                    const $cell = $btn.closest('td');
                    if ($cell.length) {
                        $cell.html(`<a href="${spodUrl}" target="_blank" class="button button-small">SPOD PDF</a>`);
                    }
                    window.open(spodUrl, '_blank', 'noopener');
                    showActionNotice('The document was downloaded.', false, 'Proof of delivery ready');
                },
                error: function(xhr) {
                    const res = xhr?.responseJSON || {};
                    showActionNotice(formatAjaxError(res, 'This document is not ready yet. Please try again in a few minutes.'), true, 'Proof of delivery not available');
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        });

        const tradeDocTypes = [
            'COMMERCIAL_INVOICE',
            'CERTIFICATE_OF_ORIGIN',
            'ETD_LABEL',
            'USMCA_CERTIFICATION_OF_ORIGIN',
            'USMCA_COMMERCIAL_INVOICE_CERTIFICATION_OF_ORIGIN',
            'PRO_FORMA_INVOICE',
            'OTHER'
        ];

        const ensureTradeModal = () => {
            let $modal = $('#fshipping-trade-docs-modal');
            if ($modal.length) {
                return $modal;
            }
            const html = `
                <div id="fshipping-trade-docs-modal" class="fshipping-trade-modal" style="display:none;">
                    <div class="fshipping-trade-modal-card">
                        <button type="button" class="fshipping-trade-modal-close" aria-label="Close">×</button>
                        <div class="fshipping-trade-header">
                            <div>
                                <h3>Trade Documents Upload</h3>
                                <p class="description">Upload customs documents in a clean, paperless flow.</p>
                            </div>
                            <span class="fshipping-trade-pill">FedEx ETD</span>
                        </div>
                        <div class="fshipping-trade-tracking-line"><strong class="fshipping-trade-modal-tracking"></strong></div>
                        <div class="fshipping-trade-section">
                            <h4>Request Details</h4>
                            <div class="fshipping-trade-fields">
                            <label>Mode
                                <select class="fshipping-trade-mode">
                                    <option value="documents">Upload Documents</option>
                                    <option value="images">Upload Images</option>
                                </select>
                            </label>
                            <label>Workflow
                                <select class="fshipping-trade-workflow">
                                    <option value="ETDPreshipment">ETDPreshipment</option>
                                    <option value="ETDPostshipment" selected>ETDPostshipment</option>
                                </select>
                            </label>
                            <label>Carrier
                                <input type="text" class="fshipping-trade-carrier" value="FDXE" />
                            </label>
                            <label>Tracking Number
                                <input type="text" class="fshipping-trade-tracking" />
                            </label>
                            <label>Shipment Date
                                <input type="datetime-local" class="fshipping-trade-date" />
                            </label>
                            <label>Form Code
                                <input type="text" class="fshipping-trade-formcode" placeholder="USMCA (optional)" />
                            </label>
                            <label>Origin Country
                                <input type="text" class="fshipping-trade-origin-country" placeholder="US" />
                            </label>
                            <label>Destination Country
                                <input type="text" class="fshipping-trade-dest-country" placeholder="IN" />
                            </label>
                            <label>Origin Location
                                <input type="text" class="fshipping-trade-origin-location" placeholder="GVTKK (optional)" />
                            </label>
                            <label>Destination Location
                                <input type="text" class="fshipping-trade-dest-location" placeholder="DEL (optional)" />
                            </label>
                            </div>
                            <p class="fshipping-trade-mode-help"></p>
                        </div>
                        <div class="fshipping-trade-section">
                            <h4>Documents</h4>
                            <div class="fshipping-trade-docs-rows"></div>
                        </div>
                        <div class="fshipping-trade-modal-actions">
                            <button type="button" class="button button-small fshipping-add-trade-doc-row">Add document</button>
                            <button type="button" class="button button-primary button-small fshipping-submit-trade-docs">Upload to FedEx</button>
                        </div>
                        <div class="fshipping-trade-inline-status" aria-live="polite"></div>
                        <p class="description">Max 5 items per request.</p>
                    </div>
                </div>
            `;
            $('body').append(html);
            return $('#fshipping-trade-docs-modal');
        };

        const setTradeInlineStatus = ($modal, message, isError = false) => {
            const $status = $modal.find('.fshipping-trade-inline-status');
            if (!$status.length) return;
            if (!message) {
                $status.removeClass('is-error is-success').text('').hide();
                return;
            }
            $status
                .removeClass('is-error is-success')
                .addClass(isError ? 'is-error' : 'is-success')
                .text(message)
                .show();
        };

        const setTradeModeHelp = ($modal) => {
            const mode = $modal.find('.fshipping-trade-mode').val() || 'documents';
            const map = {
                documents: 'Use regular file uploads (PDF, DOCX, XLSX, images, etc.).',
                images: 'Use PNG/GIF logo or signature for FedEx-generated docs.'
            };
            $modal.find('.fshipping-trade-mode-help').text(map[mode] || '');
        };

        const tradeDocRowHtml = (mode = 'documents') => {
            const opts = tradeDocTypes
                .map((item) => `<option value="${item}">${item}</option>`)
                .join('');
            if (mode === 'images') {
                return `
                    <div class="fshipping-trade-doc-row">
                        <input type="file" class="fshipping-trade-doc-file" accept=".png,.gif" />
                        <select class="fshipping-trade-image-type">
                            <option value="LETTER_HEAD">LETTER_HEAD</option>
                            <option value="SIGNATURE">SIGNATURE</option>
                        </select>
                        <select class="fshipping-trade-doc-type">${opts}</select>
                        <input type="text" class="fshipping-trade-doc-description" placeholder="Optional description" />
                        <button type="button" class="button-link-delete fshipping-remove-trade-doc-row">Remove</button>
                    </div>
                `;
            }
            return `
                <div class="fshipping-trade-doc-row">
                    <input type="file" class="fshipping-trade-doc-file" accept=".pdf,.txt,.png,.jpg,.jpeg,.gif,.bmp,.tif,.tiff,.rtf,.doc,.docx,.xls,.xlsx" />
                    <select class="fshipping-trade-doc-type">${opts}</select>
                    <input type="text" class="fshipping-trade-doc-description" placeholder="Optional description" />
                    <button type="button" class="button-link-delete fshipping-remove-trade-doc-row">Remove</button>
                </div>
            `;
        };

        const ensureTradeRows = ($ctx) => {
            const $rows = $ctx.find('.fshipping-trade-docs-rows');
            if (!$rows.find('.fshipping-trade-doc-row').length) {
                const mode = $ctx.find('.fshipping-trade-mode').val() || 'documents';
                $rows.append(tradeDocRowHtml(mode));
            }
        };

        $(document).on('click', '.fshipping-toggle-trade-docs', function(e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const shipmentId = $btn.data('shipment_id');
            const openshipOrderId = $btn.data('order_id');
            const tracking = $btn.data('tracking') || '';
            const $modal = ensureTradeModal();
            $modal.data('shipment_id', shipmentId);
            $modal.data('openship_order_id', openshipOrderId);
            $modal.find('.fshipping-trade-modal-tracking').text(tracking ? `Tracking: ${tracking}` : '');
            $modal.find('.fshipping-trade-tracking').val(tracking || '');
            $modal.find('.fshipping-trade-docs-rows').empty();
            setTradeInlineStatus($modal, '');
            ensureTradeRows($modal);
            setTradeModeHelp($modal);
            $modal.fadeIn(120);
        });

        $(document).on('change', '.fshipping-trade-mode', function(e) {
            const $modal = $('#fshipping-trade-docs-modal');
            $modal.find('.fshipping-trade-docs-rows').empty();
            ensureTradeRows($modal);
            setTradeModeHelp($modal);
        });

        $(document).on('click', '.fshipping-trade-modal, .fshipping-trade-modal-close', function(e) {
            if (
                $(e.target).is('.fshipping-trade-modal') ||
                $(e.target).is('.fshipping-trade-modal-close')
            ) {
                $('#fshipping-trade-docs-modal').fadeOut(120);
            }
        });

        $(document).on('click', '.fshipping-add-trade-doc-row', function(e) {
            e.preventDefault();
            const $modal = $('#fshipping-trade-docs-modal');
            const $rows = $modal.find('.fshipping-trade-docs-rows');
            const current = $rows.find('.fshipping-trade-doc-row').length;
            if (current >= 5) {
                showActionNotice('You can upload up to 5 documents at a time.', true, 'Too many files');
                return;
            }
            const mode = $modal.find('.fshipping-trade-mode').val() || 'documents';
            $rows.append(tradeDocRowHtml(mode));
        });

        $(document).on('click', '.fshipping-remove-trade-doc-row', function(e) {
            e.preventDefault();
            const $row = $(e.currentTarget).closest('.fshipping-trade-doc-row');
            const $rows = $row.parent();
            $row.remove();
            if (!$rows.find('.fshipping-trade-doc-row').length) {
                $rows.append(tradeDocRowHtml());
            }
        });

        $(document).on('click', '.fshipping-submit-trade-docs', function(e) {
            e.preventDefault();
            const $btn = $(e.currentTarget);
            const $modal = $('#fshipping-trade-docs-modal');
            const shipmentId = $modal.data('shipment_id');
            const openshipOrderId = $modal.data('openship_order_id');
            const $rows = $modal.find('.fshipping-trade-doc-row');
            const formData = new window.FormData();
            let validFiles = 0;
            const mode = $modal.find('.fshipping-trade-mode').val() || 'documents';
            const workflowName = $modal.find('.fshipping-trade-workflow').val() || 'ETDPostshipment';

            formData.append('action', 'fshipping_upload_trade_documents');
            formData.append('nonce', fshipping_params.nonce);
            if (shipmentId) {
                formData.append('shipment_id', shipmentId);
            }
            if (openshipOrderId) {
                formData.append('openship_order_id', openshipOrderId);
            }
            formData.append('upload_mode', mode);
            formData.append('workflow_name', workflowName);
            formData.append('carrier_code', $modal.find('.fshipping-trade-carrier').val() || 'FDXE');
            formData.append('tracking_number', $modal.find('.fshipping-trade-tracking').val() || '');
            formData.append('shipment_date', $modal.find('.fshipping-trade-date').val() || '');
            formData.append('form_code', $modal.find('.fshipping-trade-formcode').val() || '');
            formData.append('origin_country', $modal.find('.fshipping-trade-origin-country').val() || '');
            formData.append('destination_country', $modal.find('.fshipping-trade-dest-country').val() || '');
            formData.append('origin_location_code', $modal.find('.fshipping-trade-origin-location').val() || '');
            formData.append('destination_location_code', $modal.find('.fshipping-trade-dest-location').val() || '');

            $rows.each(function(index) {
                const $row = $(this);
                const file = $row.find('.fshipping-trade-doc-file')[0]?.files?.[0];
                if (!file) {
                    return;
                }
                validFiles += 1;
                formData.append('trade_doc_files[]', file);
                formData.append('doc_types[]', $row.find('.fshipping-trade-doc-type').val() || 'OTHER');
                formData.append('doc_descriptions[]', $row.find('.fshipping-trade-doc-description').val() || '');
                if (mode === 'images') {
                    formData.append('image_types[]', $row.find('.fshipping-trade-image-type').val() || 'LETTER_HEAD');
                }
            });

            if (!validFiles) {
                setTradeInlineStatus($modal, 'Attach at least one item before upload.', true);
                showActionNotice('Attach at least one document before uploading.', true, 'No file selected');
                return;
            }

            const original = $btn.text();
            setTradeInlineStatus($modal, 'Uploading to FedEx...');
            $btn.prop('disabled', true).text('Uploading...');
            $.ajax({
                url: fshipping_params.ajax_url,
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (!response?.success) {
                        setTradeInlineStatus($modal, formatAjaxError(response, 'Please try again.'), true);
                        showActionNotice(formatAjaxError(response, 'Please try again.'), true, 'Documents could not be uploaded');
                        return;
                    }
                    const count = response?.data?.uploads?.length || 0;
                    setTradeInlineStatus($modal, `Upload successful (${count}).`);
                    flashNoticeAfterReload(
                        count === 1 ? 'Your document was uploaded to FedEx.' : `Your ${count} documents were uploaded to FedEx.`,
                        false,
                        'Documents uploaded'
                    );
                    $('#fshipping-trade-docs-modal').hide();
                    window.location.reload();
                },
                error: function(xhr) {
                    const res = xhr?.responseJSON || {};
                    setTradeInlineStatus($modal, formatAjaxError(res, 'Please try again.'), true);
                    showActionNotice(formatAjaxError(res, 'Please try again.'), true, 'Documents could not be uploaded');
                },
                complete: function() {
                    $btn.prop('disabled', false).text(original);
                }
            });
        });
    })
})(jQuery);