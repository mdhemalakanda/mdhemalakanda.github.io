(function($) {
    const cfg = window.fshipping_checkout_params || {};
    if (!cfg.ajax_url || !cfg.nonce) {
        return;
    }

    const state = {
        timer: null,
        lastHash: '',
        mounted: false,
        activeRequestByScope: {},
        requestSeqByScope: {},
        lastFailedHashByScope: {},
        activePostalRequestByScope: {},
        postalRequestSeqByScope: {},
        lastPostalHashByScope: {},
        lastPostalFailedHashByScope: {},
    };

    const selectorMap = {
        shipping: {
            address_1: [
                '#shipping_address_1',
                'input[name="shipping_address_1"]',
                'input[name="shipping-address_1"]',
                'input[id*="shipping"][id*="address_1"]',
            ],
            city: [
                '#shipping_city',
                'input[name="shipping_city"]',
                'input[name="shipping-city"]',
                'input[id*="shipping"][id*="city"]',
            ],
            state: [
                '#shipping_state',
                'select[name="shipping_state"]',
                'input[name="shipping_state"]',
                'select[name="shipping-state"]',
                'input[name="shipping-state"]',
                '[id*="shipping"][id*="state"]',
            ],
            postal_code: [
                '#shipping_postcode',
                'input[name="shipping_postcode"]',
                'input[name="shipping-postcode"]',
                'input[id*="shipping"][id*="postcode"]',
                'input[id*="shipping"][id*="postal"]',
            ],
            country: [
                '#shipping_country',
                'select[name="shipping_country"]',
                'select[name="shipping-country"]',
                '[id*="shipping"][id*="country"]',
            ],
        },
        billing: {
            address_1: [
                '#billing_address_1',
                'input[name="billing_address_1"]',
                'input[name="billing-address_1"]',
                'input[id*="billing"][id*="address_1"]',
            ],
            city: [
                '#billing_city',
                'input[name="billing_city"]',
                'input[name="billing-city"]',
                'input[id*="billing"][id*="city"]',
            ],
            state: [
                '#billing_state',
                'select[name="billing_state"]',
                'input[name="billing_state"]',
                'select[name="billing-state"]',
                'input[name="billing-state"]',
                '[id*="billing"][id*="state"]',
            ],
            postal_code: [
                '#billing_postcode',
                'input[name="billing_postcode"]',
                'input[name="billing-postcode"]',
                'input[id*="billing"][id*="postcode"]',
                'input[id*="billing"][id*="postal"]',
            ],
            country: [
                '#billing_country',
                'select[name="billing_country"]',
                'select[name="billing-country"]',
                '[id*="billing"][id*="country"]',
            ],
        },
    };

    const contactSelectorMap = {
        first_name: [
            '#billing_first_name',
            'input[name="billing_first_name"]',
            'input[name="billing-first_name"]',
            'input[id*="billing"][id*="first_name"]',
        ],
        last_name: [
            '#billing_last_name',
            'input[name="billing_last_name"]',
            'input[name="billing-last_name"]',
            'input[id*="billing"][id*="last_name"]',
        ],
        email: [
            '#billing_email',
            'input[name="billing_email"]',
            'input[name="billing-email"]',
            'input[type="email"][name*="billing"]',
        ],
        phone: [
            '#billing_phone',
            'input[name="billing_phone"]',
            'input[name="billing-phone"]',
            'input[type="tel"][name*="billing"]',
        ],
    };

    const firstValue = (selectors) => {
        for (let i = 0; i < selectors.length; i++) {
            const el = document.querySelector(selectors[i]);
            if (!el) {
                continue;
            }
            if (el.value !== undefined) {
                return String(el.value || '').trim();
            }
        }
        return '';
    };

    const getActiveAddressScope = () => {
        const wantsShipping = (
            $('#ship-to-different-address-checkbox').is(':checked') ||
            $('[name="ship_to_different_address"]').is(':checked') ||
            $('.wc-block-components-checkbox__input[name*="use-shipping"]').is(':checked')
        );
        return wantsShipping ? 'shipping' : 'billing';
    };

    const getAddressPayload = () => {
        const scope = getActiveAddressScope();
        const selectors = selectorMap[scope];
        const payload = {
            street_lines: firstValue(selectors.address_1),
            city: firstValue(selectors.city),
            state: firstValue(selectors.state),
            postal_code: firstValue(selectors.postal_code),
            country: firstValue(selectors.country) || 'US',
        };
        return { scope, payload };
    };

    const getContactPayload = () => ({
        first_name: firstValue(contactSelectorMap.first_name),
        last_name: firstValue(contactSelectorMap.last_name),
        email: firstValue(contactSelectorMap.email),
        phone: firstValue(contactSelectorMap.phone),
    });

    const canValidate = (payload) => {
        const country = String(payload.country || '').toUpperCase();
        const needsState = country === 'US' || country === 'CA';
        const hasBase = !!(payload.street_lines && payload.city && payload.postal_code && payload.country);
        return hasBase && (!needsState || !!payload.state);
    };

    const canValidatePostal = (payload) => {
        const country = String(payload.country || '').toUpperCase();
        const needsState = country === 'US' || country === 'CA';
        return !!(payload.postal_code && payload.country && (!needsState || !!payload.state));
    };

    const hasAnyAddressInput = (payload) => {
        return !!(
            payload.street_lines ||
            payload.city ||
            payload.state ||
            payload.postal_code ||
            payload.country
        );
    };

    const hasMeaningfulInput = (payload, contact) => {
        return !!(
            payload.street_lines ||
            payload.city ||
            payload.state ||
            payload.postal_code ||
            contact.first_name ||
            contact.last_name ||
            contact.email ||
            contact.phone
        );
    };

    const scopeContainer = (scope) => {
        const id = `fshipping-address-validation-${scope}`;
        let $node = $('#' + id);
        if ($node.length) {
            return $node;
        }

        const scopeRoots = scope === 'shipping'
            ? [
                '.woocommerce-shipping-fields',
                '.woocommerce-shipping-fields__field-wrapper',
                '.wc-block-components-checkout-step--shipping-address',
                '.wc-block-components-shipping-address',
                '.wc-block-components-address-form',
            ]
            : [
                '.woocommerce-billing-fields',
                '.woocommerce-billing-fields__field-wrapper',
                '.wc-block-components-checkout-step--billing-address',
                '.wc-block-components-billing-address',
                '.wc-block-components-address-form',
            ];

        for (let i = 0; i < scopeRoots.length; i++) {
            const $root = $(scopeRoots[i]).first();
            if (!$root.length) {
                continue;
            }
            $root.prepend(`<div id="${id}" class="fshipping-address-validation"></div>`);
            return $('#' + id);
        }

        const $checkout = $('.woocommerce-checkout, .wc-block-checkout, form.checkout').first();
        if ($checkout.length) {
            $checkout.prepend(`<div id="${id}" class="fshipping-address-validation"></div>`);
            return $('#' + id);
        }
        return $();
    };

    const postalStatusContainer = (scope) => {
        const id = `fshipping-postal-validation-${scope}`;
        let $node = $('#' + id);
        if ($node.length) {
            return $node;
        }
        const $postal = getFieldElement('postal_code', scope);
        if (!$postal.length) {
            return $();
        }
        const $mount = $postal.closest('.form-row, .wc-block-components-text-input, .wc-block-components-address-form');
        if (!$mount.length) {
            return $();
        }
        $mount.append(`<div id="${id}" class="fshipping-postal-validation"></div>`);
        return $('#' + id);
    };

    const renderClassification = (scope, classification, message, isError) => {
        const $node = scopeContainer(scope);
        if (!$node.length) {
            return;
        }
        const type = isError ? 'warning' : (classification || 'unknown').toLowerCase();
        $node
            .removeClass('is-business is-residential is-mixed is-unknown is-warning is-loading')
            .addClass(`is-${type}`)
            .text(message || cfg.messages.unknown || 'Address classification unavailable.');
    };

    const renderLoading = (scope) => {
        const $node = scopeContainer(scope);
        if (!$node.length) {
            return;
        }
        $node
            .removeClass('is-business is-residential is-mixed is-unknown is-warning')
            .addClass('is-loading')
            .text(cfg.messages.validating || 'Validating address...');
    };

    const renderIncomplete = (scope) => {
        const $node = scopeContainer(scope);
        if (!$node.length) {
            return;
        }
        $node
            .removeClass('is-business is-residential is-mixed is-unknown is-warning is-loading')
            .addClass('is-warning')
            .text(cfg.messages.incomplete || 'Complete all required address fields to validate.');
    };

    const renderPostalStatus = (scope, type, message) => {
        const $node = postalStatusContainer(scope);
        if (!$node.length) {
            return;
        }
        $node
            .removeClass('is-valid is-warning is-loading')
            .addClass(`is-${type}`)
            .text(message || '');
    };

    const clearPostalStatus = (scope) => {
        const $node = postalStatusContainer(scope);
        if (!$node.length) {
            return;
        }
        $node.removeClass('is-valid is-warning is-loading').text('');
    };

    const getFieldElement = (fieldKey, scope) => {
        const map = {
            street_lines: selectorMap[scope].address_1,
            city: selectorMap[scope].city,
            state: selectorMap[scope].state,
            postal_code: selectorMap[scope].postal_code,
            country: selectorMap[scope].country,
            first_name: contactSelectorMap.first_name,
            last_name: contactSelectorMap.last_name,
            email: contactSelectorMap.email,
            phone: contactSelectorMap.phone,
        };
        const selectors = map[fieldKey] || [];
        for (let i = 0; i < selectors.length; i++) {
            const $el = $(selectors[i]).first();
            if ($el.length) {
                return $el;
            }
        }
        return $();
    };

    const clearFieldErrors = () => {
        $('.fshipping-field-validation').remove();
        $('.fshipping-field-invalid').removeClass('fshipping-field-invalid');
    };

    const renderFieldErrors = (scope, fieldErrors) => {
        clearFieldErrors();
        const entries = Object.entries(fieldErrors || {});
        for (let i = 0; i < entries.length; i++) {
            const fieldKey = entries[i][0];
            const message = entries[i][1];
            const $field = getFieldElement(fieldKey, scope);
            if (!$field.length || !message) {
                continue;
            }
            $field.addClass('fshipping-field-invalid');
            const $mount = $field.closest('.form-row, .wc-block-components-text-input, .wc-block-components-address-form');
            const id = `fshipping-field-validation-${scope}-${fieldKey}`;
            $('#' + id).remove();
            if ($mount.length) {
                $mount.append(`<div id="${id}" class="fshipping-field-validation">${message}</div>`);
            }
        }
    };

    const classMessage = (classification) => {
        const c = String(classification || 'UNKNOWN').toUpperCase();
        if (c === 'BUSINESS') {
            return cfg.messages.business;
        }
        if (c === 'RESIDENTIAL') {
            return cfg.messages.residential;
        }
        if (c === 'MIXED') {
            return cfg.messages.mixed;
        }
        return cfg.messages.unknown;
    };

    const requestPostalValidation = (scope, payload, strict, sourceLabel, force) => {
        if (!canValidatePostal(payload)) {
            clearPostalStatus(scope);
            return;
        }
        const postalHash = JSON.stringify({
            postal_code: payload.postal_code,
            country: payload.country,
            state: payload.state,
        });
        if (!force && sourceLabel !== 'submit' && state.lastPostalHashByScope[scope] === postalHash) {
            return;
        }
        if (!force && sourceLabel !== 'submit' && state.lastPostalFailedHashByScope[scope] === postalHash) {
            return;
        }
        state.lastPostalHashByScope[scope] = postalHash;
        state.lastPostalFailedHashByScope[scope] = '';
        if (state.activePostalRequestByScope[scope] && state.activePostalRequestByScope[scope].readyState !== 4) {
            state.activePostalRequestByScope[scope].abort();
        }
        const postalRequestSeq = (state.postalRequestSeqByScope[scope] || 0) + 1;
        state.postalRequestSeqByScope[scope] = postalRequestSeq;
        renderPostalStatus(scope, 'loading', cfg.messages.validating_zip || 'Validating ZIP code...');

        state.activePostalRequestByScope[scope] = $.ajax({
            url: cfg.ajax_url,
            method: 'POST',
            data: {
                action: 'fshipping_validate_postal_code',
                nonce: cfg.nonce,
                street_lines: payload.street_lines,
                city: payload.city,
                state: payload.state,
                postal_code: payload.postal_code,
                country: payload.country,
                strict: strict ? 1 : 0,
            },
            success: function(res) {
                if (postalRequestSeq !== state.postalRequestSeqByScope[scope]) {
                    return;
                }
                if (!res || !res.success) {
                    state.lastPostalFailedHashByScope[scope] = postalHash;
                    renderPostalStatus(scope, 'warning', cfg.messages.zip_unknown || 'ZIP validation unavailable.');
                    return;
                }
                const fieldErrors = (res.data && res.data.field_errors) ? res.data.field_errors : {};
                if (fieldErrors.postal_code) {
                    state.lastPostalFailedHashByScope[scope] = postalHash;
                    renderPostalStatus(scope, 'warning', fieldErrors.postal_code);
                    return;
                }
                const warning = (res.data && res.data.postal_warning) ? res.data.postal_warning : '';
                if (warning) {
                    renderPostalStatus(scope, 'warning', warning);
                    return;
                }
                if (res.data && res.data.postal_valid) {
                    renderPostalStatus(scope, 'valid', cfg.messages.zip_valid || 'ZIP/postal code validated.');
                    return;
                }
                const postalUnknown = !!(res.data && res.data.postal_unknown);
                if (postalUnknown && !strict) {
                    renderPostalStatus(scope, 'valid', cfg.messages.zip_unknown_continue || 'ZIP check finished. You can continue checkout.');
                    return;
                }
                if (postalUnknown && strict) {
                    renderPostalStatus(scope, 'valid', cfg.messages.zip_unknown_continue || 'ZIP check finished. You can continue checkout.');
                    return;
                }
                renderPostalStatus(scope, 'warning', cfg.messages.zip_unknown || 'ZIP validation unavailable.');
            },
            error: function(xhr, status) {
                if (postalRequestSeq !== state.postalRequestSeqByScope[scope] || status === 'abort') {
                    return;
                }
                state.lastPostalFailedHashByScope[scope] = postalHash;
                renderPostalStatus(scope, 'warning', cfg.messages.zip_error || 'ZIP validation request failed.');
            },
        });
    };

    const validateNow = (sourceLabel, force) => {
        const { scope, payload } = getAddressPayload();
        const contact = getContactPayload();
        const strict = sourceLabel === 'submit';
        const hasInput = hasMeaningfulInput(payload, contact);
        requestPostalValidation(scope, payload, strict, sourceLabel, force);

        if (!canValidate(payload)) {
            if (strict || hasAnyAddressInput(payload)) {
                renderIncomplete(scope);
            }
            if (strict) {
                renderFieldErrors(scope, {
                    street_lines: !payload.street_lines ? (cfg.messages.incomplete || 'Required') : '',
                    city: !payload.city ? (cfg.messages.incomplete || 'Required') : '',
                    postal_code: !payload.postal_code ? (cfg.messages.incomplete || 'Required') : '',
                    country: !payload.country ? (cfg.messages.incomplete || 'Required') : '',
                });
            }
            return;
        }

        if (!strict && !hasInput) {
            if (hasAnyAddressInput(payload)) {
                renderIncomplete(scope);
            }
            return;
        }

        const hash = JSON.stringify(payload);
        if (!force && sourceLabel !== 'submit' && state.lastHash === hash) {
            return;
        }
        if (!force && sourceLabel !== 'submit' && state.lastFailedHashByScope[scope] === hash) {
            return;
        }
        state.lastHash = hash;
        state.lastFailedHashByScope[scope] = '';

        if (state.activeRequestByScope[scope] && state.activeRequestByScope[scope].readyState !== 4) {
            state.activeRequestByScope[scope].abort();
        }
        const requestSeq = (state.requestSeqByScope[scope] || 0) + 1;
        state.requestSeqByScope[scope] = requestSeq;
        renderLoading(scope);

        state.activeRequestByScope[scope] = $.ajax({
            url: cfg.ajax_url,
            method: 'POST',
            data: {
                action: 'fshipping_validate_address',
                nonce: cfg.nonce,
                street_lines: payload.street_lines,
                city: payload.city,
                state: payload.state,
                postal_code: payload.postal_code,
                country: payload.country,
                first_name: contact.first_name,
                last_name: contact.last_name,
                email: contact.email,
                phone: contact.phone,
                strict: strict ? 1 : 0,
            },
            success: function(res) {
                if (requestSeq !== state.requestSeqByScope[scope]) {
                    return;
                }
                if (!res || !res.success) {
                    state.lastFailedHashByScope[scope] = hash;
                    renderClassification(scope, 'UNKNOWN', cfg.messages.unknown, true);
                    return;
                }
                const fieldErrors = (res.data && res.data.field_errors) ? res.data.field_errors : {};
                renderFieldErrors(scope, fieldErrors);
                if (Object.keys(fieldErrors).length > 0) {
                    state.lastFailedHashByScope[scope] = hash;
                    renderClassification(scope, 'UNKNOWN', cfg.messages.invalid_fields || 'Please fix highlighted fields.', true);
                    return;
                }
                state.lastFailedHashByScope[scope] = '';
                const classification = (res.data && res.data.classification) ? res.data.classification : 'UNKNOWN';
                renderClassification(scope, classification, classMessage(classification), false);
            },
            error: function(xhr, status) {
                if (requestSeq !== state.requestSeqByScope[scope] || status === 'abort') {
                    return;
                }
                state.lastFailedHashByScope[scope] = hash;
                renderClassification(scope, 'UNKNOWN', cfg.messages.error, true);
            },
        });

    };

    const scheduleValidate = (force) => {
        clearTimeout(state.timer);
        state.timer = setTimeout(function() {
            validateNow('change', !!force);
        }, 500);
    };

    const bindChangeListeners = () => {
        if (state.mounted) {
            return;
        }
        state.mounted = true;

        $(document).on('blur change', [
            '#billing_address_1',
            '#billing_city',
            '#billing_state',
            '#billing_postcode',
            '#billing_country',
            '#shipping_address_1',
            '#shipping_city',
            '#shipping_state',
            '#shipping_postcode',
            '#shipping_country',
            '[name="billing-address_1"]',
            '[name="billing-city"]',
            '[name="billing-state"]',
            '[name="billing-postcode"]',
            '[name="billing-country"]',
            '[name="shipping-address_1"]',
            '[name="shipping-city"]',
            '[name="shipping-state"]',
            '[name="shipping-postcode"]',
            '[name="shipping-country"]',
        ].join(','), function() {
            state.lastHash = '';
            state.lastPostalHashByScope = {};
            scheduleValidate();
        });

        // Country/state changes often trigger checkout fragment redraws.
        $(document).on('change', [
            '#billing_country',
            '#billing_state',
            '#shipping_country',
            '#shipping_state',
            'select[name="billing_country"]',
            'select[name="billing_state"]',
            'select[name="shipping_country"]',
            'select[name="shipping_state"]',
            'select[name="billing-country"]',
            'select[name="billing-state"]',
            'select[name="shipping-country"]',
            'select[name="shipping-state"]',
            '[id*="billing"][id*="country"]',
            '[id*="billing"][id*="state"]',
            '[id*="shipping"][id*="country"]',
            '[id*="shipping"][id*="state"]',
        ].join(','), function() {
            state.lastHash = '';
            state.lastPostalHashByScope = {};
            scheduleValidate();
        });

        // Classic checkout submit.
        $(document).on('click', '#place_order', function(e) {
            clearFieldErrors();
            validateNow('submit');
        });
        $(document).on('submit', 'form.checkout', function() {
            clearFieldErrors();
            validateNow('submit');
        });

        // Checkout Blocks place-order button.
        $(document).on('click', '.wc-block-components-checkout-place-order-button', function() {
            clearFieldErrors();
            validateNow('submit', true);
        });
    };

    $(function() {
        bindChangeListeners();
        scheduleValidate();
    });
})(jQuery);
