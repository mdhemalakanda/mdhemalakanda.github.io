/**
 * Client-side filter/sort for [fshipping_locations] results list.
 *
 * @package teamzlab-fedex
 */
(function () {
    'use strict';

    var KM_PER_MI = 1.60934;

    function parseKm(row) {
        var v = row.getAttribute('data-teamzzlab-km');
        if (v === null || v === '') {
            return NaN;
        }
        var n = parseFloat(v, 10);
        return isNaN(n) ? NaN : n;
    }

    function displayToKm(value, unit) {
        if (value === '' || value === null) {
            return null;
        }
        var n = parseFloat(value, 10);
        if (isNaN(n)) {
            return null;
        }
        return unit === 'km' ? n : n * KM_PER_MI;
    }

    function init(block) {
        var results = block.querySelector('.teamzzlab-fedex-locations-results');
        if (!results) {
            return;
        }
        var list = results.querySelector('.teamzzlab-fedex-locations-list');
        if (!list) {
            return;
        }

        var unit = results.getAttribute('data-distance-unit') || 'mile';
        var search = results.querySelector('.teamzzlab-fedex-locations-filter-search');
        var sort = results.querySelector('.teamzzlab-fedex-locations-sort');
        var maxDist = results.querySelector('.teamzzlab-fedex-locations-max-dist');
        var phoneOnly = results.querySelector('.teamzzlab-fedex-locations-phone-only');
        var visibleEl = results.querySelector('.teamzzlab-fedex-locations-visible-count');
        var rows = Array.prototype.slice.call(list.querySelectorAll('.teamzzlab-fedex-location-row'));

        function rowMatches(row) {
            var q = (search && search.value ? search.value : '').trim().toLowerCase();
            var hay = (row.getAttribute('data-teamzzlab-text') || '').toLowerCase();
            if (q && hay.indexOf(q) === -1) {
                return false;
            }
            var maxK = maxDist && maxDist.value !== '' ? displayToKm(maxDist.value, unit) : null;
            var km = parseKm(row);
            if (maxK !== null) {
                if (isNaN(km)) {
                    return false;
                }
                if (km > maxK) {
                    return false;
                }
            }
            if (phoneOnly && phoneOnly.checked && row.getAttribute('data-teamzzlab-has-phone') !== '1') {
                return false;
            }
            return true;
        }

        function apply() {
            var matched = [];
            var i;
            for (i = 0; i < rows.length; i += 1) {
                if (rowMatches(rows[i])) {
                    matched.push(rows[i]);
                }
            }

            var sortVal = sort ? sort.value : 'distance-asc';
            matched.sort(function (a, b) {
                if (sortVal === 'name-asc') {
                    var na = (a.getAttribute('data-teamzzlab-name') || '').toLowerCase();
                    var nb = (b.getAttribute('data-teamzzlab-name') || '').toLowerCase();
                    return na.localeCompare(nb);
                }
                var ka = parseKm(a);
                var kb = parseKm(b);
                if (sortVal === 'distance-desc') {
                    if (isNaN(kb)) {
                        return 1;
                    }
                    if (isNaN(ka)) {
                        return -1;
                    }
                    return kb - ka;
                }
                if (isNaN(ka)) {
                    return 1;
                }
                if (isNaN(kb)) {
                    return -1;
                }
                return ka - kb;
            });

            var set = new Set(matched);
            for (i = 0; i < matched.length; i += 1) {
                list.appendChild(matched[i]);
            }
            for (i = 0; i < rows.length; i += 1) {
                if (!set.has(rows[i])) {
                    list.appendChild(rows[i]);
                }
            }

            for (i = 0; i < rows.length; i += 1) {
                rows[i].classList.toggle('teamzzlab-fedex-location-row--hidden', !set.has(rows[i]));
            }

            if (visibleEl) {
                visibleEl.textContent = String(matched.length);
            }
        }

        if (search) {
            search.addEventListener('input', apply);
        }
        if (sort) {
            sort.addEventListener('change', apply);
        }
        if (maxDist) {
            maxDist.addEventListener('input', apply);
        }
        if (phoneOnly) {
            phoneOnly.addEventListener('change', apply);
        }

        apply();
    }

    var blocks = document.querySelectorAll('.teamzzlab-fedex-locations-shortcode');
    for (var b = 0; b < blocks.length; b += 1) {
        init(blocks[b]);
    }
}());
