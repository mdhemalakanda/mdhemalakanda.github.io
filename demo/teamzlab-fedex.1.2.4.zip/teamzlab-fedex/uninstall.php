<?php
/**
 * Uninstall cleanup for Teamzlab FedEx.
 *
 * Runs when the plugin is deleted via WP Admin (Plugins → Delete).
 * Removes plugin-owned data: settings, pickup history, quota baseline,
 * cached API tokens, scheduled events, and shipment records (CPT).
 *
 * WooCommerce order meta ( `_fshipping_*` on shop_order records ) is
 * intentionally kept: it is part of the store's order history rather
 * than plugin-owned data.
 *
 * @package FSHIPPING
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/**
 * Delete all plugin-owned data for the current site.
 */
$fshipping_uninstall_delete_site = static function () {
	// Plugin options.
	delete_option( 'fshipping_options' );
	delete_option( 'fshipping_pickup_history' );
	delete_option( 'fshipping_last_close_manifest' );
	delete_option( 'fshipping_quota_daily_reset_baseline' );
	delete_option( 'fshipping_secure_upload_dirs' );
	delete_option( 'fshipping_rates_config_version' );
	delete_option( 'fshipping_staging_log' );
	delete_option( 'woocommerce_fshipping_custom_settings' );
	delete_option( 'fshipping_staging_mode' );
	delete_option( 'fshipping_savings_events' );

	// Per-instance shipping-method settings (one option per zone instance).
	// No WP API can LIKE-delete these rows; caching is irrelevant during uninstall.
	global $wpdb;
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Bulk cleanup of per-zone-instance option rows on delete; no wildcard-delete API exists.
	$wpdb->query(
		"DELETE FROM {$wpdb->options} WHERE option_name LIKE 'woocommerce\\_fshipping\\_custom%\\_settings'"
	);

	// Cached API tokens (expiring transients; notices expire on their own).
	delete_transient( 'fshipping_auth_token' );
	delete_transient( 'fshipping_track_auth_token' );

	// Scheduled events.
	wp_clear_scheduled_hook( 'fshipping_send_shipment_email' );

	// Shipment records (plugin CPT).
	$fshipping_post_ids = get_posts(
		array(
			'post_type'   => 'fedex_shipping',
			'post_status' => 'any',
			'numberposts' => -1,
			'fields'      => 'ids',
		)
	);
	foreach ( $fshipping_post_ids as $fshipping_post_id ) {
		wp_delete_post( $fshipping_post_id, true );
	}
};

if ( is_multisite() ) {
	$fshipping_site_ids = get_sites( array( 'fields' => 'ids', 'number' => 0 ) );
	foreach ( $fshipping_site_ids as $fshipping_site_id ) {
		switch_to_blog( $fshipping_site_id );
		$fshipping_uninstall_delete_site();
		restore_current_blog();
	}
} else {
	$fshipping_uninstall_delete_site();
}
