# Contributing to Fedex Shipping

New to the project? Start with **[`docs/ONBOARDING.md`](docs/ONBOARDING.md)** —
it walks you from zero to a running local dev environment with hot-reload tests.

This file is the canonical rulebook. Everything you need to pick up a task
and ship it without breaking things.

---

## TL;DR

1. Clone → run `scripts/setup.sh` → open in Cursor → pick a task.
2. Add a class under `includes/` → scaffold tests with `scripts/new-http-client.sh`.
3. Every file edit auto-runs `php -l` + PHPUnit (Claude Code hook).
4. Commit with Conventional Commits → push → open PR → CI runs on 4 PHP versions.

---

## Environment

- **PHP 7.4+** (prod target); 8.1+ recommended for local dev.
- **WordPress 6.0+** via [LocalWP](https://localwp.com) — see `docs/ONBOARDING.md` step 2.
- **WooCommerce 8.0+** installed and active in your LocalWP site.
- **Composer 2.x** for the dev-only test harness (the plugin ships without `vendor/`).
- **Node / npm** — **not used**. No bundler, no TypeScript. PHP + jQuery only.

## First-time setup

```bash
# From the repo root:
./scripts/setup.sh
```

That script runs `composer install`, enables the git hooks path, and
tells you if any prerequisite is missing. Re-run it any time you want to
double-check your environment.

## Day-to-day workflow

```bash
# Create a branch
git checkout -b feat/my-new-thing

# Scaffold a new FedEx API client (takes a class name, generates both the
# class file and its matching test file from templates):
./scripts/new-http-client.sh MyNewApi

# Make your edits. Tests auto-run after every Claude Code / Cursor save
# via the hooks in .claude/settings.json and .cursor/rules/.

# Run tests manually any time:
composer test
./vendor/bin/phpunit --filter MyNewApi   # just your class

# Live TDD — re-runs tests whenever any PHP file changes:
./scripts/watch-tests.sh

# Before you commit, the git pre-commit hook will auto-run php -l + phpunit.
git commit -m "feat(http): add MyNewApi client"
git push -u origin feat/my-new-thing
```

## Code standards

**The 13 rules** (copied verbatim from [`CLAUDE.md`](CLAUDE.md)). Cursor is
configured to enforce most of these automatically via
[`.cursor/rules/`](.cursor/rules/).

1. Namespace + file path mirror. `FSHIPPING\HTTP\Pickup` → `includes/HTTP/Pickup.php`.
2. Every outward-facing class uses `SingletonTrait` and is called as `ClassName::instance()->method()`.
3. Every PHP file starts with `<?php` + namespace + `use` + docblock + `defined('ABSPATH') || exit;`.
4. Credential reads go through `get_option('fshipping_options')` + `sanitize_text_field`.
5. Token caching via `set_transient('fshipping_<purpose>_token', $token, $expires_in)`.
6. HTTP: always `wp_remote_post`/`wp_remote_get` → `is_wp_error` → `wp_remote_retrieve_body` → `json_decode(..., true)`.
7. Logging: `wc_get_logger()->info()` + `error_log()`. Never `echo`, `var_dump`, `dd`.
8. Errors: return `[]`/`''` on failure. Never throw across a module boundary.
9. Sanitize inputs, escape outputs. `sanitize_text_field`, `esc_html`, `esc_attr`, `esc_url`.
10. 4-space indent. English-only comments.
11. Docblocks on every public method: `@param`, `@return`, `@since`.
12. Commit messages: Conventional Commits. One logical change per commit.
13. **Test-first.** Every new class under `includes/` has a matching test in `tests/phpunit/`.

## Testing

The full suite lives at `tests/phpunit/`. Read
[`tests/phpunit/CLAUDE.md`](tests/phpunit/CLAUDE.md) for the template and
base classes.

Key commands:

```bash
composer test             # full suite
composer test:unit        # same, via the `unit` testsuite
./vendor/bin/phpunit -f Foo   # --filter Foo
composer lint             # php -l across every .php file in includes/
./scripts/watch-tests.sh  # auto-rerun on save (uses fswatch)
```

Coverage report lands at `tests/_coverage/html/index.html` after a
coverage-enabled run.

## Commit messages

Use [Conventional Commits](https://www.conventionalcommits.org):

```
feat(http): add Foo client
fix(events): DL event short-circuits when order already completed
docs(onboarding): clarify LocalWP symlink step
chore(ci): bump PHP matrix to 8.3
test(rates): cover weight-unit normalization edge cases
refactor(utils): extract shared logger trait
```

Rule of thumb:
- `feat:` — new user-visible capability
- `fix:` — bug fix
- `docs:` — documentation only
- `chore:` — tooling / CI / deps
- `test:` — test changes only
- `refactor:` — behavior-preserving code change

One logical change per commit. Don't bundle a new API client with an
unrelated CSS tweak.

## Pull requests

Every PR should:

- [ ] Have a description explaining the **why** (the what is in the diff).
- [ ] Pass CI on all PHP versions (7.4 / 8.0 / 8.1 / 8.2).
- [ ] Include tests for any new behavior. **Zero-test PRs are rejected.**
- [ ] Update `CHANGELOG.md` under `## [Unreleased]` if user-visible.
- [ ] Keep `TODO: verify against live sandbox` markers intact unless you've actually verified against sandbox.

The PR template (`.github/pull_request_template.md`) formats this for you.

## Branch protection

- `main` is the release branch. Never push directly.
- Feature branches: `feat/<kebab>`, `fix/<kebab>`, `chore/<kebab>`.
- PRs merge into `main` via squash-merge so `main`'s history stays linear.

## Security

- Never commit secrets. `.env` is in `.gitignore`. Run the bundled
  `git-secrets` scan before pushing if you're handling credentials:
  `./scripts/scan-secrets.sh`.
- FedEx credentials live in `get_option('fshipping_options')` — they never
  touch git. If you accidentally paste one in a commit, **rotate it
  immediately** at developer.fedex.com.
- Any file marked `TODO: verify against live sandbox` is untrusted until
  verified — treat that code as a stub.

## Who to ask

- **Architecture / product questions** → open an issue with the
  `question` label or ping @Teamz-Lab-LTD.
- **Stuck on a bug** → paste the failing test output in the issue.
- **Lost in the codebase** → read `docs/ARCHITECTURE.md` first, then
  `docs/CLAUDE.md` (the strategic brain), then ask.
