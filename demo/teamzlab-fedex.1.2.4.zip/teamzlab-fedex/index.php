<?php
#Silence is golden.