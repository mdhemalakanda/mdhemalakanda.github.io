# Changelog

All notable changes to the Fedex Shipping plugin are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
this project adheres to [Semantic Versioning](https://semver.org/).

## [1.2.4] - 2026-10-22

### Added
- **FedEx packaging presets on Product Box** — Each box card now starts with a **FedEx packaging** dropdown (FedEx Envelope / Pak / Tube / Small–Extra Large Box / 10kg / 25kg Box, plus *Custom*). Picking a supply auto-fills the box **dimensions** from FedEx's published interior sizes (inches are converted to the box's selected IN/CM unit) and fills the **Name** when it is empty — mirroring Shopify-style packaging presets. Stored values (`fshipping_product_boxes.boxes[].preset`) are whitelisted in `Boxing\BoxCatalog::sanitize_box()` against `BoxCatalog::packaging_presets()`; presets only prefill fields and never change API payloads.

### Changed
- **Human-readable dropdown labels everywhere** — Settings selects no longer show raw FedEx API enums: **Label Order** (`Shipping Label First` / `Shipping Label Last`), **Label Format Type** (`Common 2D`, `Label Data Only`), **Label Rotation** (`Right`, `Upside Down`, `None`), **Label Printing Orientation** (`Bottom/Top Edge of Text First`), and in `Utils\Helper::get_field_options()` **Rate Request** (`List`, `Incentive`, …), **Payment Type** (`Sender`, `Recipient`, `Third Party`, `Collect`), and all 19 **Label Stock Type** entries (`Paper 4×6`, `Stock 8.5×11 Top Half Label`, …). The shipments list **Service** column now uses the same map (`FEDEX_GROUND` → `FedEx International/Domestic Ground®`, unknown codes prettified). Option **values** (what is stored and sent to FedEx) are unchanged. The dead duplicate raw `pickup_type` branch (unreachable `elseif`) was removed — the humanized labels were already the ones in use.
- **Tables scroll cleanly at every breakpoint** — `main.js` wraps every `wp-list-table` / `widefat` table on plugin admin screens in a full-width `overflow-x: auto` container (`.fsa-table-scroll`) with per-table min-widths (shipments 1150px, pickup/drafts-detail 980px, product-box rules 560px). Narrow viewports now get a tidy horizontal scroll instead of WP's letter-per-line stacking. The shipments list additionally drops WP core's `table-layout: fixed` (which gave all 15 unstyled columns an equal 71px share narrower than the action buttons) in favor of auto layout with 3px cell gutters and 11px row buttons, and its **Download SPOD** column is pinned with `position: sticky` to the right edge — so the primary row action stays reachable while the rest scrolls at any viewport width.

### Fixed
- **Open Ship weight-normalization fatal** — `includes/OpenShip/Draft.php` called `Helper::instance()->normalize_store_weight()` without importing the class, so PHP 8 fataled with `Class "FSHIPPING\OpenShip\Helper" not found` whenever that code path ran; the `use FSHIPPING\Utils\Helper;` import is now present. (Also in this release, comment-only PHPCS annotation cleanups in `Licensing/ShipmentQuota.php` and `uninstall.php` — no behavior change.)
- **Invisible primary-button labels** — The brand ghost-button block loaded after the primary-button block with equal specificity, repainting `.button-primary` labels purple on the purple fill: **Schedule pickup** (Pickup History) and **Save Product Box** rendered as blank purple rectangles. All ghost selectors now exclude `.button-primary`/`.button-danger` so primary labels are white again (and danger stays red).
- **Select2 multi-select chips** — The chip `×` (absolutely positioned by stock Select2 CSS) overlapped the label text and the inline search field collapsed to a sliver; chips are now inline-flex with the remove button static beside the text and the search field keeps a 9em minimum width.
- **"Remove box" / "Remove" buttons showed raw browser chrome** — `button-link-delete` alone does not reset UA button styling, so both buttons rendered as gray gradient buttons with red text; they are now bordered danger-ghost buttons consistent with the design system, and the box-card collapse chevron is larger (15px glyph in a 22px tile).
- **Ghost pills bleeding through the sticky Settings save bar** — The bar used a 92%-translucent white with `backdrop-filter` blur; where the blur wasn't applied (headless rendering, some environments), form controls underneath showed through as faint unreadable pills. The bar is now opaque white.
- **Freemius "Upgrade" menu missing** — The SDK config in `feedex-shipping.php` still declared the pre-redesign admin menu slug `fedex_shipping_activation` as its top-level menu, so after the menu was renamed to `fedex_shipping` the SDK's **Upgrade ➤ / Account / Contact Us** submenus attached to a nonexistent parent and silently disappeared. Config now points at the real slug; items verified present in `$submenu['fedex_shipping']`.

## [1.2.3] - 2026-10-21

### Changed
- **Admin UI redesign (design system rollout)** — Every wp-admin screen now shares a token-based design system in `assets/admin/css/style.css` (version bumped to `1.1.0`): FedEx purple/orange brand tokens (`--fsa-*`, mirroring the frontend `--fsx-*` palette), page headers with subtitle + environment badge (Sandbox/Production), accessible tab navigation (ARIA `tablist`/`tab`/`tabpanel`, arrow/Home/End keyboard support), card components, status badges (`fshipping-status-badge--ok/--warn/--danger/--info`), purple focus rings, and a sticky save bar on Settings. Screens updated: **FedEx Settings** (5 tabs, quota panel with progress bar, Show/Hide reveal for API secrets, copy button for the AIV webhook URL, field descriptions), **Shipments & Printings** list (class-based badges, no inline styles), **Pickup History** (card layout, status badges), **Dashboard widget**, **Product Box** page, **Open Ship** drafts list + order meta box, and the AJAX tracking popup (which now colors the status pill by real status instead of always green). Top-level menu renamed **Fedex → FedEx Shipping** with an airplane icon; asset loading for the Pickup History and Open Ship drafts screens fixed (the drafts stylesheet previously never loaded due to a wrong `load-` hook).
- **Brand-cohesive button accents on plugin screens** — Core WP-primary and secondary/action buttons on plugin screens no longer use WP's stock accent blue: **Add Post**, **Search by Tracking ID**, **Apply**/**Filter**, **Schedule pickup**, **Save Product Box**, Open Ship action buttons, and the row action links render in the FedEx purple system (brand ghost style with purple focus rings); destructive **Cancel** buttons stay red. Scoped so WooCommerce/order screens and shared overlays (media modal) keep core styling. The Settings **Show/Hide** secret toggle is brand-styled and exposes `aria-pressed`.
- **Select2 stylesheet restored** — `assets/admin/css/select2.css` shipped empty (0 bytes) while the bundled JS was the full Select2 4.1.0-rc.0 library; the official 4.1.0-rc.0 stylesheet is now included (all multi-selects/single selects previously rendered unstyled), re-skinned to the plugin palette.
- **Checkout & locations frontend palette alignment** — `teamzzlab-fedex-locations.css` off-palette blues (submit hover `#1d4ed8`, blue focus rings, slate grays) replaced with the FedEx purple system, and `checkout-validation.css` focus/invalid styling aligned to the brand (semantic state hues preserved).

### Fixed
- **Settings tabs rendered empty panels** — The redesigned Settings screen passed tab panel element ids (`fshipping-auth`, …) to `do_settings_sections()` instead of the registered settings page slugs (`fshipping_auth_tab`, …), so every tab rendered with zero fields. Panel element ids (the JS tab contract) are unchanged; only the `do_settings_sections()` argument was corrected.
- **Stray `"=>` text inside shipments list buttons** — The **Cancel** / **Canceled** / **Track** buttons in `edit.php?post_type=fedex_shipping` rendered a literal `=>` before their labels due to malformed HTML concatenation; markup corrected.
- **Duplicate "Tracking ID" row in tracking popup** — The AJAX tracking popup showed the same number twice under two labels; now a single "Tracking Number" row.

### Changed
- **Daily shipment quota by Freemius plan** — Free **10**/day (was 3), Premium **100**/day (was 5), **Golden** unlimited (no daily cap). Enforced with `tf_fs()->is_plan( 'premium' )` and `tf_fs()->is_plan( 'golden' )` in `Licensing\ShipmentQuota` (`is_premium_plan()`, `is_golden_plan()`, `quota_plan_slug()`). Filter `fshipping_daily_shipment_limit` passes plan slug `free`, `premium`, or `golden` (replaces the previous `professional` slug for this filter). FedEx Settings shows Golden as “unlimited daily quota”.
- **Checkout Ship API Woo logger source name** — `HTTP\Shipment::create_shipment()` now writes checkout Ship request payload and response logs to WooCommerce logger source **`teamz_fedex_shipping_type`** (replacing `fedex_shipment_checkout`) so shipment-type roundtrip logs are easier to filter.
- **FedEx Settings quota section is read-only** — Removed the **Clear limit for today** action/button and related admin-post reset flow from `Dashboard\Settings`; the page now displays daily plan usage only (no manual quota clear action in UI).

### Added
- **Redesigned public shortcode UI** — New shared frontend stylesheet `assets/frontend/css/fshipping-shortcodes.css` (FedEx purple/orange design system: card layouts, labeled grid fields, branded buttons, stat-tile results, soft notices) enqueued only on pages using `[fshipping_dim_weight]`, `[fshipping_rate_widget]`, `[fshipping_track]`, `[fshipping_tracking_timeline]`, or `[fshipping_return_portal]`. The dim-weight calculator markup was rebuilt (unit suffixes that follow the IN/CM toggle, live results after the first calculation, dim/actual/billable weight tiles, formula footnote with unique per-instance field ids) and the `[fshipping_rate_widget]` embed snippet now renders as a dark code block with a copy-to-clipboard button. `[fshipping_locations]` accent recolored from blue to FedEx purple for page-level consistency.
- **Shipments list table — Date column width cap** — On `edit.php?post_type=fedex_shipping`, the default **Date** column is limited to **147px** (ellipsis) so wide custom columns (e.g. **Box info**) have more horizontal space. Styles live in `assets/admin/css/style.css` (admin bundle version bumped to `1.0.3`).
- **Shipments list “Box info” column** — `edit.php?post_type=fedex_shipping` now includes a **Box info** column showing each packed box name (with occurrence index) and `product * qty` lines, sourced from order meta `_fshipping_product_box_display_json` written when Product Box packing runs at Ship time (`Events\ProductBoxPayloadInjector`).
- **Daily checkout shipment quota by plan (with shipping-method warning)** — FedEx rates now stop rendering at checkout when daily shipment quota is reached, and the shipping section shows a warning message instead of service options. Per-plan daily limits are defined in `Licensing\ShipmentQuota` (see **Changed** above for current Free / Premium / Golden values). Checkout is also blocked for FedEx-selected orders when quota is reached, and shipment label creation is hard-blocked server-side to prevent over-limit Ship/OpenShip label requests. Filters: `fshipping_daily_shipment_limit`, `fshipping_quota_reached_checkout_message`.
- **FedEx Settings daily quota reset button** — Added a **Clear limit for today** admin action on the FedEx Settings page. The reset uses a safe soft-baseline model (no shipment deletion): it stores today’s current raw shipment count as baseline, and quota checks use `max(0, raw_today - baseline_today)`. This applies to plans with a finite daily cap (not Golden unlimited). Added internals: `ShipmentQuota::raw_count_shipments_today()`, `ShipmentQuota::effective_count_shipments_today()`, `ShipmentQuota::get_reset_baseline_for_today()`, and `ShipmentQuota::reset_today_quota_baseline()`.

### Fixed
- **Product Box declared value now uses real per-box product totals (not equal split)** — `Events\ProductBoxPayloadInjector` now carries order-item unit price into packing (`line_subtotal / qty` fallback chain), sets each packed package `declaredValue` from that box’s product total, and when fallback unmatched package is appended it receives the remaining product declared amount. This removes misleading repeated values (for example `216.83`) and aligns box declared values with actual product math (for example `55 * 4 = 220`).
- **Freight minimum clamp now skips Product Box exact package weights by default** — `HTTP\Shipment::enforce_minimum_package_weight_for_freight_service()` now receives the order context and bypasses the `150.01 LB / 68.05 KG` freight floor when Product Box sequence mapping exists (`Draft::META_PACKAGE_BOX_NAME_MAP`). This preserves actual per-box calculated weights (for example `27.06 LB` for `4 x Belt (3 KG each) + 0.6 LB box`) instead of overwriting each line to freight minimum. Filter: `fshipping_ship_freight_min_package_weight_skip_for_product_boxes`.
- **Product Box debug log now includes weight equation per package** — Packing summary entries now include a formula-style line per box (for example `6 kg + 0.6804 kg = 6.6804 kg - so large box 1 is 6.68kg onproduct (Product A *3, Product B *2)`), using `weight_breakdown` values from `Boxing\BoxPacker` so merchants can verify product subtotal + empty box weight math directly in `debug.log`.
- **Product Box debug log now includes per-product price equation + total per box** — Packing summary now logs price math for each packed box (for example `price large box 1: Belt 55 * 4 = 220 | total product price = 220 USD`) so product price and box-level product totals can be verified alongside weight equations in `debug.log`.
- **Product Box packing summary now includes per-box numbering format** — `Events\ProductBoxPayloadInjector::log_packing_summary()` now writes box-specific sequence labels in `debug.log` (for example `Album 2 quantity + Beanie 2 quantity - Large Box 1`, then `... - Large Box 2`) so repeated box names are easier to match against shipment payload rows.
- **Product Box package weight and dimensions for Ship API** — `Boxing\BoxPacker` now adds **empty box weight** using the configured `empty_weight.unit` (LB/KG/G/OZ) converted into the catalog **Weight output unit**, instead of treating the empty-weight number as already in that output unit. `Events\ProductBoxPayloadInjector` now always emits **inch** `requestedPackageLineItems[].dimensions` (converting per-box dimensions from CM or IN), after which `HTTP\Shipment` may still normalize to the lane’s effective unit (e.g. CM for international). This fixes wrong totals when empty box was entered in pounds and products in kilograms.
- **Quota counter now tracks successful FedEx checkout orders (not rate display/API requests)** — Daily usage now counts created WooCommerce orders (`shop_order`) for the current site-local day where shipping `method_id` is `fshipping_custom` (or suffixed variant), instead of counting `fedex_shipping` label CPT rows. This aligns limit usage with completed checkout creation behavior.
- **Product Box debug log now prints per-box product mapping** — Packing now appends a human-readable summary line to `debug.log` with order id and per-box contents (for example `Product A (quantity: 2), Product B (quantity: 1) inserted into Large`). Unmatched items are listed as fallback-package contents.
- **Product Box cards are now collapsed by default with live titles** — **Fedex → Product Box** box cards now render in a collapsed state by default for cleaner multi-box management. Clicking the box header toggles expand/collapse, and header text now follows `Box - {name} - {index}` with live updates as the **Name** input changes.
- **Product Box label naming now uses configured box names** — Shipments list label actions now render per-package buttons as box-name indexed labels (for example `Large 1 label`, `Large 2 label`, `Small 1 label`) when package label metadata includes box names, instead of generic `Box N label`. `Events\ProductBoxPayloadInjector` now persists sequence→box-name mapping and `HTTP\Shipment::persist_shipment_from_api_response()` carries that map into `_fshipping_package_label_files` rows for stable UI naming.
- **Shipments list “Label” column now shows per-box labels** — `CPT\Shipments::display_shipping_columns_content()` now renders all saved package-label URLs from `_fshipping_package_label_files` (shipment meta with order-meta fallback), in addition to the primary “View Label” button. This lets staff open/print every box label directly from **Fedex → Shipments & Labeling** so no package label is missed.
- **Freight minimum package weight clamp (`FEDEXINTLEXPRESS.WEIGHT.BELOWSTANDARDLIMIT`)** — `HTTP\Shipment` now enforces a preflight minimum per-package weight for freight-style services (`serviceType` containing `FREIGHT`) before Ship API POST. Underweight package lines are clamped to FedEx floor (`150.01 LB` / `68.05 KG`) to prevent “Your shipment weight is below minimum required.” errors on lanes such as `FEDEX_1_DAY_FREIGHT`. Filters: `fshipping_ship_freight_min_package_weight_enabled`, `fshipping_ship_freight_min_package_weight_lb`, `fshipping_ship_freight_min_package_weight_kg`.
- **Ship API domestic Express unit enforcement (`IN` dimensions + `LB` weight)** — `HTTP\Shipment` now resolves lane-aware outbound units before final payload normalization. For domestic parcel Express services (`FIRST_OVERNIGHT`, `PRIORITY_OVERNIGHT`, `STANDARD_OVERNIGHT`, `FEDEX_2_DAY`, `FEDEX_2_DAY_AM`, `FEDEX_EXPRESS_SAVER`, `SAME_DAY`, `SAME_DAY_CITY`), payloads are forced to imperial units so FedEx no longer rejects requests with “Dimensions ... must be expressed in inches (IN)” / weight-unit mismatch errors. Added filter `fshipping_ship_effective_units` for merchant overrides.
- **Open Ship admin package weights now auto-calculate from order products** — `OpenShip\AjaxHandler` now rehydrates each package row’s `weight` from assigned box items before validation/push, and `OpenShip\Draft::hydrate_package_weights_from_order_items()` converts product weights to that row’s selected `weight_unit` (`LB`/`KG`). This prevents manual/unit drift between package rows and master shipment values on order edit screens (`post.php?...&action=edit`), reducing FedEx weight-unit mismatch errors.
- **Open Ship confirm — international trade / commercial PDFs** — `OpenShip::confirm_full()` now passes the WooCommerce order and merges **`shippingDocumentSpecification`** (and optional **`documentRequirements`**) from **`HTTP\Shipment::build_processed_ship_payload_for_order()`**, matching the instant Ship API pipeline. Open Ship **start** strips document specs by design; without this, FedEx confirm did not return the same commercial invoice / license-style PDFs as Ship create. Filter **`fshipping_openship_confirm_merge_ship_document_spec`** (default `true`) can disable the merge. **`fshipping_openship_confirm_payload`** receives an optional fourth argument: the order object.
- **Persist all `packageDocuments` URLs** — `HTTP\Shipment::collect_shipment_label_urls()` / persist now saves every document URL per piece (not only **`packageDocuments[0]`**), with extra files named **`fedex-{tracking}_docN`**. JSON meta rows may include optional **`content_type`**.

### Added
- **Open Shipments — All labels PDF** — **Fedex → Open Shipments** list adds an **All labels PDF** column; **View FedEx details** adds an **All labels (PDF)** summary row. Both use `OpenShip\Draft::best_all_labels_pdf_url()` (merged multi-piece PDF, else single saved piece, else primary `_fedex_label_url`). Multi-piece orders without a merged PDF link to the per-package table on the detail screen (`#fshipping-os-saved-label-files`).
- **Trade Documents Upload admin workflow (post-shipment)** — `Shipments & Labeling` list now has a **Trade docs** column with inline multi-file upload (max 5 per request), per-file document type/description, and upload history chips. New Ajax action `fshipping_upload_trade_documents` validates nonce/capability/plan gate, uploads supported file types, calls `HTTP\TradeDocuments::upload()`, persists IDs to `_fshipping_trade_doc_upload_ids`, stores failures in `_fshipping_trade_doc_last_error`, and adds linked Woo order notes.
- **Trade Documents popup supports all FedEx modes** — Trade-doc popup now supports `Upload Documents`, `Upload Images`, and `Upload Multiple Encoded Documents` with workflow (`ETDPreshipment` / `ETDPostShipment`) and metadata fields (tracking, shipment date, countries, form/location codes).
- **Product Box package manager + Ship payload boxing** — Added **Fedex → Product Box** admin submenu with Select2 product search and repeater rows for product capacities per box. New boxing services (`Boxing\BoxCatalog`, `Boxing\BoxPacker`, `Boxing\UnitConverter`) plus `Events\ProductBoxPayloadInjector` (filter `fshipping_ship_payload`, priority 35) now build `requestedShipment.requestedPackageLineItems` from configured box dimensions and formula `(product weight × quantity) + empty box weight`, with mixed-mode fallback that appends the legacy default package line for unmatched items.

### Fixed
- **Upload Images document-context validation** — `HTTP\TradeDocuments::upload_images()` now sends `meta.shipDocumentType` (from selected document type) alongside `imageType` for Document API image uploads. This resolves FedEx `1024` errors such as “Please enter a valid Document type.”
- **Trade docs mode simplification** — Removed **Upload Multiple Encoded Documents** from the popup UI and disabled encoded-mode backend handling. The build now supports only **Upload Documents** and **Upload Images** for a simpler, more reliable admin flow.
- **Trade Documents request normalization hardening** — Upload handler now normalizes common invalid inputs before Document API calls: maps `UK` → `GB`, normalizes shipment datetime to include seconds, strips invalid location-code free text, validates ISO-2 origin/destination country codes, and auto-detects encoded file content types (JPEG/PNG/GIF/PDF) from base64 headers. Singular `/document/...` retry is now disabled by default and only runs when `fshipping_trade_documents_retry_singular_document_path` filter is explicitly enabled.
- **Licensing gates disabled (fully unlocked build)** — Removed remaining runtime plan enforcement by making `Licensing\Freemius::can_use()` and `Licensing\FeatureGate::allows()` always return `true`. This ensures all features are accessible without Freemius/pro-tier checks in this distribution.
- **Trade docs UI table-break regression** — Replaced inline per-row uploader in `Shipments & Labeling` with a centered modal popup (`Trade Documents Upload`) so list-table columns no longer overflow/collapse. Upload flow and Ajax endpoint remain the same while the form now opens/closes cleanly without breaking row layout.
- **Trade Documents API host/payload alignment** — `HTTP\TradeDocuments` now uses Document API hosts (`documentapitest.prod.fedex.com` sandbox / `documentapi.prod.fedex.com` production) and request shape (`workflowName`, `carrierCode`, `name`, `contentType`, `meta`, optional `attachment`) with response parsing by `output.meta.docId`.
- **Trade Documents debug trace in `debug.log`** — Each Document API upload attempt now logs request and response blocks (URL, payload/meta, attachment info, HTTP status, and decoded body) using `[FedEx TradeDocuments][DocumentAPI][request|response]` markers for faster troubleshooting.
- **FedEx `COMMODITYWEIGHT.GREATERTHAN.PACKAGEWEIGHT` (package/commodity parity)** — `HTTP\Shipment::prepare_shipment_payload()` now applies the same minimum per-item weight fallback used by commodity generation (0.1 KG, converted to global unit) when a product has no valid weight. This keeps `requestedPackageLineItems[].weight` from undershooting the summed commodity weights and prevents package-vs-commodity weight drift.
- **FedEx `REQUESTEDSHIPMENT.TOTALDECLAREDVALUE.MISMATCH`** — `Utils\Helper::normalize_declared_value()` now also reconciles shipment-level declared value with package-level declared values before Ship API calls. If package `declaredValue` blocks already exist, shipment `totalDeclaredValue` is aligned to their sum; otherwise per-package `declaredValue` is injected across `requestedPackageLineItems` (same currency) so the package sum equals `totalDeclaredValue`. This removes FedEx mismatch warnings for declared-value totals.
- **FedEx `INVALID.STOCK.TYPE` for `COMMERCIAL_INVOICE` (debug-driven fix)** — Ship preflight now sets `requestedShipment.shippingDocumentSpecification.commercialInvoiceDetail.documentFormat.stockType = PAPER_LETTER` whenever `COMMERCIAL_INVOICE` is requested. This prevents invoice docs from inheriting thermal shipping-label stock types (e.g. `STOCK_4X675`) that FedEx rejects for commercial-invoice document generation.
- **FedEx commercial invoice format isolation (live debug follow-up)** — When `shippingDocumentSpecification.shippingDocumentTypes` includes `COMMERCIAL_INVOICE`, Ship preflight now enforces `shippingDocumentSpecification.commercialInvoiceDetail.documentFormat.docType = PDF` and removes any `imageType` keys from document sections. This prevents FedEx from interpreting label `imageType` as commercial-invoice image settings while keeping label output in `labelSpecification.imageType`.
- **Ship payload document split hardening (label vs commercial invoice)** — `HTTP\Shipment` now forces `requestedShipment.labelSpecification.imageType` to `PDF` for shipping labels and strips any `imageType` keys from `requestedShipment.shippingDocumentSpecification` and `requestedShipment.customsClearanceDetail.commercialInvoice` during final preflight. This guarantees COMMERCIAL_INVOICE generation never inherits label image format settings.
- **Commercial invoice vs label config separation (`COMMERCIAL_INVOICE`, `LABELSPECIFICATION.IMAGETYPE.INVALID`)** — Added final Ship preflight sanitizer in `HTTP\Shipment` to enforce payload boundaries: `imageType` is allowed only under `requestedShipment.labelSpecification`; any `imageType` keys injected into `shippingDocumentSpecification` or `customsClearanceDetail.commercialInvoice` are removed before API send. Label `imageType` is normalized and validated against supported values (`PDF`, `PNG`, `ZPLII`, `EPL2`) with automatic fallback to `PDF` when invalid to prevent `LABELSPECIFICATION.IMAGETYPE.INVALID`. This prevents document-config mixing and keeps commercial invoice generation on FedEx default document handling (no invoice-level `imageType` override).
- **Shipment unit/value preflight normalization (`INCONSISTANTWEIGHTDIMENSION.ERROR`, `TOTALCARRIAGEVALUE.EXCEEDS.CUSTOMSVALUE`)** — Added global measurement-system normalization so outbound Ship/Rate payloads use one consistent system end-to-end: **metric (`KG` + `CM`)** or **imperial (`LB` + `IN`)**. `Utils\Helper` now provides dimension conversion helpers and recursive dimension normalization (`normalize_fedex_payload_dimension_units`) alongside weight normalization. `HTTP\Shipment::create_shipment()` now performs a final preflight pass before API send: normalize all weights, normalize all dimensions, align `requestedShipment.totalDeclaredValue` and `requestedShipment.customsClearanceDetail.totalCustomsValue` via `normalize_declared_value()`, then log the final normalized payload. Warning logs now flag mixed unit systems (e.g., `KG` with `IN`) before request dispatch.
- **FedEx weight-unit consistency hardening (`INCONSISTENT.WEIGHTUNITS.ENTERED`)** — Outbound FedEx payloads now enforce one global weight unit (`KG` by default) via shared helpers in `Utils\Helper`: `fedex_weight_unit()`, `normalize_fedex_weight()`, `normalize_store_weight()`, and recursive payload normalization for all weight nodes before request dispatch. `HTTP\Shipment` now converts Woo product weights with `wc_get_weight` semantics (through helper), removes hardcoded `LB`, logs the final normalized Ship payload before API call, and warns in `debug.log` when mixed units are detected. `HTTP\GlobalTrade` now normalizes commodity weights to the same global unit and traces `GLOBAL_TRADE_WEIGHT_UNIT_WARNING` if inconsistencies remain. `Trade\CommercialInvoiceBuilder` commodity weights now use the same normalized unit path. PHPUnit: `tests/phpunit/HTTP/GlobalTradeTest.php` adds coverage for normalized KG commodity weights from LB input.
- **Destination address validation (UK + mapping)** — `HTTP\GlobalTrade::normalize_address_block()` previously truncated `stateOrProvinceCode` to **three characters**, turning values such as **Westminster** into **WES** (invalid for FedEx). UK/IE/JE/GG/IM destinations now **omit** `stateOrProvinceCode` in Global Trade and Ship payloads; postcodes are normalized (GB spacing, US ZIP+4, CA `A1A 1A1`). Shared helper **`Utils\AddressNormalizer`** feeds checkout server-side validation (`Frontend\Checkout::validate_order_for_fedex`), **`HTTP\AddressValidation`**, **`HTTP\Shipment::prepare_shipment_payload`**, **`HTTP\Shipping`** rates, and **`Ajax`** checkout validation. When Address Validation returns no `resolvedAddresses`, the plugin logs the full FedEx JSON (`errors`, `output`, `transactionId`) to **`debug.log`**; optional **Fedex → Settings → If address validation fails: allow shipment anyway** plus order meta **`_fshipping_address_validation_override`** = **`yes`** (or filters **`fshipping_allow_shipment_without_address_validation`**, **`fshipping_address_validation_override`**) can allow label creation without blocking checkout. **`WP_DEBUG` + `WP_DEBUG_LOG`**: request/response round-trip logging for Address Validation; filter **`fshipping_log_address_validation_roundtrip`**. Filter **`fshipping_address_validation_payload`** can adjust the resolve request (FedEx REST does not expose a documented strict vs. “suggestion” toggle; behavior is driven by reference matching and annotations). PHPUnit: **`tests/phpunit/Utils/AddressNormalizerTest.php`**, **`GlobalTradeTest::test_uk_destination_does_not_send_truncated_state`**.

- **ShipmentGuard — international lane detection + runtime tracing** — Destination country resolution prioritizes checkout package (`meta.package.destination.country`) then `WC_Order::get_shipping_country()`. Added `WP_DEBUG` traces for init wiring (`attached_filter=fshipping_pre_ship_check`), handler start (`ShipmentGuard RUNNING`), and lane comparison (`origin/meta_dest/order_dest/final dest/compare`). Temporary diagnostic switch `FSHIPPING_SHIPMENT_GUARD_FORCE_GLOBAL_TRADE=true` forces Global Trade call-path to validate `GLOBAL_TRADE_REQUEST` logging without changing default behavior when unset. Docs: **`tests/manual/19_shipment_guard.md`**.
- **Checkout pre-ship guard trigger hardening** — `Frontend\Checkout::create_shipment()` now logs `SHIPMENT_GUARD_TRIGGERED` immediately before `apply_filters('fshipping_pre_ship_check', ...)`, treats method ids starting with `fshipping_custom_` as FedEx lanes in addition to exact `fshipping_custom`, and runs the guard filter before checkout address-validation exits. This ensures ShipmentGuard pre-flight executes for FedEx shipments prior to any block/allow return path.
- **Global Trade request hardening (production)** — `HTTP\GlobalTrade` now normalizes shipper/recipient address fields, enforces specific commodity descriptions + non-empty HS code format (min 6 digits), blocks empty/invalid commodity payloads before request, logs `GLOBAL_TRADE_NORMALIZED_PAYLOAD`, and retries once with empty fields removed when FedEx returns `NOT.FOUND.ERROR` (`GLOBAL_TRADE_RETRY_NOT_FOUND`). Retry logs include entitlement-check guidance for production accounts. `Events\ShipmentGuard` now builds commodities with product HS meta (`_fshipping_hs_code`) + `HSCodeSuggester` fallback and blocks shipment guard flow when commodities are invalid for Global Trade pre-check.
- **Global Trade endpoint migration (Regulatory Details API)** — `HTTP\GlobalTrade` now posts to `/globaltrade/v1/shipments/regulatorydetails/retrieve` (replacing `/commerce/v1/globaltrade`), includes `carrierCode` when available, and maps Regulatory Details responses into `documentsRequired` / `advisories` / `prohibitions` for `ShipmentGuard` decisions (BLOCK/WARN/ALLOW). Full request/response tracing remains enabled in debug logs.
- **Checkout hard-stop before order creation** — Added `woocommerce_checkout_process` pre-flight in `Frontend\Checkout` to run `fshipping_pre_ship_check` (and thus ShipmentGuard/Global Trade) before Woo creates the order. When guard returns BLOCK, checkout now logs `SHIPMENT_BLOCKED` + `CHECKOUT_BLOCKED`, surfaces a checkout error notice, and throws an exception to stop order creation. Post-order `woocommerce_checkout_order_processed` flow remains for actual shipment creation only.
- **Commodity normalization layer for ShipmentGuard** — Added `Trade\CommodityNormalizer` to normalize line-item commodities before pre-ship compliance: enforces complete commodity shape, auto-fills HS code via product meta → HS suggester → category mapping → default fallback, converts store weight units to `KG`, and ensures Global Trade sees normalized data. ShipmentGuard no longer hard-blocks checkout for fixable commodity data; it logs `SHIPMENT_GUARD_COMMODITIES_AUTOFIX` and continues through Global Trade request/fail-open path.

### Removed
- **Fedex → Migration Doctor** — Removed submenu `fshipping_migration_doctor`, deleted `Admin\MigrationDoctorPage`, and dropped `admin_post_fshipping_toggle_staging` (action `fshipping_toggle_staging`) handling. **Staging mode** remains available via the `fshipping_staging_mode` option (`yes` / `no`) and `Migration\StagingMode` (used by `RuntimeIntegrator`). **Credential checks** for developers/operators: **Fedex → Settings** plus CLI `scripts/fedex-api-probe.php` (`CredentialValidator`, `SandboxPing` unchanged). Removed `migration_doctor` from `Licensing\FeatureGate` matrix.

### Fixed
- **Fedex → Pickup History** — Filter form no longer sends `post_type=fedex_shipping` on `admin.php` (that combination made WordPress resolve the wrong `get_plugin_page_hook()` parent and die with **Cannot load fshipping_pickup_history**). Form `action` is explicitly `admin.php`. Search matches confirmation, tracking, shipment CPT ids, linked Woo order ids, and order numbers; multi-word / comma-separated queries require every token to match. Placeholder text is **Confirmation/Tracking**.

### Removed
- **Fedex → Settings — Notifications & Services tabs** — Removed the admin tabs and field registration for customs-hold email alerts (`fshipping_customs_alerts_enabled`, `fshipping_customs_alert_email`) and for global special-service defaults plus third-party billing (`fshipping_saturday_delivery`, `fshipping_signature_option`, `fshipping_third_party_account`). **FedEx Freight (LTL)** remains under **Fedex → Settings → Freight** (`fshipping_freight_account_number`, 9-digit FedEx Freight account). Existing `fshipping_options` values for removed keys are preserved on save via `Settings::sanitize_fshipping_options()` merge. Runtime (`CustomsAlerts`, `SpecialServicesInjector`) still honors those keys when present or set programmatically.
- **End of day admin feature** — Removed **Fedex → End of day** submenu and its `wp_ajax_fshipping_close_day` handler (`Admin\CloseDayPage`). End-of-day close is no longer exposed in plugin admin UI.
- **Settings → International (FX)** — Removed the **`fshipping_fx_rates`** admin tab and option registration. Open Ship **Add Package** no longer converts declared value, COD, or variable-handling fixed amounts through a merchant FX table; amounts use the ISO currency entered (or order currency). **`OpenShipPushValidator`** no longer blocks Save & push for non-USD money without a configured rate. **`GlobalSupport`** no longer exposes `convert()`, `fx_rates()`, or related FX helpers. Deprecated: `FedExMoneyUsd::money_block_to_usd()` (calls `normalize_money_block()`). Docs: **`docs/OPEN_SHIP.md`**, manual **`tests/manual/24_fedex_cli_probe.md`**.

### Changed
- **Pickup schedule date handling hardened** — Consolidated/single pickup now builds `readyDateTimestamp` as a local timestamp (without UTC offset) and clamps requested pickup dates to a FedEx-safe near-term horizon (`fshipping_pickup_max_days_ahead`, default `0`) to avoid `PICKUPDATE.TOO.FAR`. New debug log marker: `[FedEx Pickup][DateClamp]`.
- **Pickup scheduling UI moved to Pickup History** — The global consolidated pickup trigger was removed from **Fedex → Shipments & Printings** and added to **Fedex → Pickup History** with a **pickup date** field. Scheduling remains global (all ready shipments) and no longer infers default carrier from shipment service type. Batch pickup now accepts optional `pickup_date` and resolves `ready_datetime` from that date (weekends roll to next business day). Docs: **`tests/manual/06_pickup.md`**, **`docs/API_MAP.md`**, **`docs/ARCHITECTURE.md`**.
- **Open Ship — delete session API** — **`OpenShip::delete_open_shipment()`** now uses **`PUT /ship/v1/openshipments/delete`** with JSON **`accountNumber`** + root **`index`** (session key). **`shipmentIndex`** / **`shipmentIdIndex`** are no longer sent. Filter **`fshipping_openship_delete_payload`** signature is `( $payload, $shipment_index )` (removed third argument). Docs: **`docs/OPEN_SHIP.md`**.
- **Open Ship — UI only in Advanced mode** — **Open Shipments** admin URL guard, list `render()`, row GET actions, order meta box registration, Open Ship **Ajax** hooks, and **`wc_order_statuses`** labels for FedEx draft stati run only when **`Helper::get_shipping_mode()`** is **`advanced`** (Instant hides menu/UI; bookmarked URLs get a settings link). **`register_post_status`** for `wc-fedex-draft` / `wc-fedex-openship` remains on **`init`** so historic orders stay valid. Docs: **`docs/OPEN_SHIP.md`**.
- **Open Ship — shorter root `index` on create** — Default allocation for **`POST /ship/v1/openshipments/create`** is now **`wc_order_{order_id}_{6 hex}`** (example **`wc_order_1456_a3f7c1`**) instead of **`wc-os-{order_id}-{unix_timestamp}-{16 hex}`**, for smaller **`debug.log`** / request bodies while keeping per-call uniqueness. Filter default for **`fshipping_openship_create_index`** is **`wc_order_{order_id}`** (bare form is still upgraded to a suffixed value). Legacy bare **`wc-os-{order_id}`** is still replaced automatically. Docs: **`docs/OPEN_SHIP.md`**, **`docs/ERROR_HANDBOOK.md`**. PHPUnit: **`OpenShipTest`**.
- **Open Ship — confirm API shape aligned to `index` payload** — Confirm now posts to **`/ship/v1/openshipments/`** (not `/confirm`) with body keys **`accountNumber`**, **`index`**, **`labelResponseOptions`**, and **`labelSpecification`** (`labelStockType` + `imageType` from FedEx → Settings → Labeling). Confirm payload no longer sends **`shipmentIndex`** / **`shipmentIdIndex`**.

### Removed
- **Open Shipments — bulk FedEx cancel and lifecycle actions** — **Fedex → Open Shipments** no longer offers bulk **Cancel on FedEx + clear local session**, **Cancel on FedEx + clear then trash orders**, **Set lifecycle: draft**, or **Set lifecycle: in_progress** (per-order row links **Cancel on FedEx**, **Trash after FedEx cancel**, etc. unchanged). `OpenShipDraftsListTable`. See **`docs/OPEN_SHIP.md`**.
- **Open Ship — “Save draft (local only)” and “Abandon session (local)”** — Removed order meta box buttons, **`fshipping_openship_abandon`** Ajax, **`Draft::abandon_session_local()`**, and **`mode=draft`** handling in **`AjaxHandler::save_packages()`** (save always pushes to FedEx). **Fedex → Open Ship drafts** bulk/row “Abandon session” actions removed; use **Cancel on FedEx** to clear a session. Admin assets **1.6.0**. See **`docs/OPEN_SHIP.md`**.

### Added
- **Open Ship — admin Save & push pipeline** — Before per-package calls, **`PUT /ship/v1/openshipments`** (`OpenShip::put_update_open_shipment_from_order`) refreshes session-level shipment data. Existing FedEx pieces use **`PUT /ship/v1/openshipments/packages`** with **`trackingIds`** (`put_modify_package_full`); new boxes use **`POST …/packages`**. Orphan remote pieces are removed with **`DELETE …/packages/{id}`**. **`SHIPMENT.INDEX.REQUIRED`** on qualifying **PUT**s is retried once (`request_with_index_retry_once`). Order screen shows a **Last FedEx response** table (`push_rows`), **Clear all packages (FedEx session)** (`PUT …/openshipments/delete`), and per-row **Edit / Save / Delete** (Ajax: `fshipping_openship_modify_package`, `fshipping_openship_delete_package`, `fshipping_openship_clear_all_packages`). **REST:** `POST /wp-json/fshipping/v1/orders/{id}/openship/push` with `X-WP-Nonce` and `{ "packages": [ … ] }`. Order line meta **`_fshipping_openship_piece_tracking`**; optional read alias **`_fshipping_openship_index`** for session index. Docs: **`docs/OPEN_SHIP.md`**, **`docs/API_MAP.md`**. Assets **1.7.0**.
- **Open Shipments — bulk Delete permanently always logs FedEx delete** — Bulk **Delete permanently** calls **`Draft::cancel_fedex_open_shipment_and_clear( $order, true )`**, which forces **`OpenShip::delete_open_shipment()`** to append full **URL / JSON request / JSON response** for each **PUT …/openshipments/delete** to **`wp-content/debug.log`** (no **`WP_DEBUG_LOG`** required). Orders **without** a stored session get the **same section layout** via **`OpenShip::log_bulk_audit_openship_delete_not_applicable()`** (payload/response JSON explains **FedEx PUT not sent** vs **WooCommerce delete still runs**). Each row also logs **`bulk_audit: WooCommerce permanent delete succeeded|FAILED`**. Summary line counts **`rows_with_fedex_put`** / **`rows_without_fedex_session`**. Filter **`fshipping_openship_log_delete_request_response`** receives a sixth argument **`$force_audit_log`**. Docs: **`docs/OPEN_SHIP.md`**.
- **Open Shipments — confirm before row Delete permanently** — On the **Trash** tab, the per-order **Delete permanently** row link shows a browser **Are you sure you want to delete?** confirmation (bulk actions unchanged). `OpenShipDraftsListTable`.
- **Open Ship — `openshipments/delete` in `debug.log`** — **`OpenShip::delete_open_shipment()`** appends **`FedEx REST URL`**, **`API (requested)`**, **`request (JSON body)`**, and **`response (full body)`** to **`wp-content/debug.log`** when push-debug is on (`WP_DEBUG` + `WP_DEBUG_LOG` or **`FSHIPPING_OPENSHIP_LOG_PUSH`**) or when FedEx returns **`errors`**. Filter **`fshipping_openship_log_delete_request_response`** overrides the default gate.
- **Open Ship — Trash: Delete permanently cancels FedEx first** — Row and bulk **Delete permanently** call **`Draft::cancel_fedex_open_shipment_and_clear()`** before **`WC_Order::delete( true )`** (same pattern as **FedEx cancel + trash**), so **`PUT /ship/v1/openshipments/delete`** runs when a session index exists and failures surface before the order is removed. Docs: **`docs/OPEN_SHIP.md`**.
- **Admin — Open Shipments hub + FedEx detail view** — Submenu renamed **Fedex → Open Shipments** (was “Open Ship drafts”). The list includes **all** Advanced orders (awaiting confirm through **shipped** / **delivered**), with filters **Awaiting confirm** / **Shipped** / **Delivered** and lifecycle **confirmed**. Row **View FedEx details** opens `admin.php?page=fshipping_openship_drafts&fshipping_os_detail=1&order_id=` showing order summary, saved per-piece label URLs, and pretty-printed **`_fshipping_openship_last_confirm_json`** + packages JSON. Styles: **`assets/admin/css/fshipping-openship-shipments.css`**. Docs: **`docs/OPEN_SHIP.md`**.
- **Ship / Open Ship — multi-piece label files + admin links** — After Ship API create or Open Ship confirm, **`HTTP\Shipment::persist_shipment_from_api_response()`** downloads **every** `pieceResponses[].packageDocuments[0].url` to **`uploads/fedex-labels/fedex-{tracking}.pdf`**, optional **merged** PDF from `shipmentDocuments` as **`fedex-{master}_merged.pdf`**, and stores order meta **`_fshipping_package_label_files`** (JSON) plus **`_fshipping_merged_label_url`**. The locked **FedEx Open Ship** order meta box lists **merged** and **per-package** download buttons. **`Utils\Shipment::save_shipment_meta()`** copies the same meta to the **`fedex_shipping`** post and no longer assumes **`shipmentRating`** is always present. Docs: **`docs/OPEN_SHIP.md`**.
- **Open Ship — full start payload passthrough filter** — New filter **`fshipping_openship_start_keep_full_requested_shipment`** (default `false`) keeps full `requestedShipment` on `openshipments/create` (no first-line reduction and no start-field stripping/minimalization), useful for strict schema alignment use-cases.
- **Open Ship — exact wire JSON before create** — **`POST /ship/v1/openshipments/create`** logs a **`request (wire body)`** block (same string as **`wp_json_encode`** in **`Teamz\Wp\Kit\Http\BaseClient`**) immediately before the HTTP call when order-scoped create logging applies, push debug is on, or filter **`fshipping_openship_log_exact_wire_json_before_create`** returns true. Docs: **`docs/OPEN_SHIP.md`**.
- **Rates — debug.log payload/response** — When **`FSHIPPING_DEBUG_RATES_LOG`** is `true` in `wp-config.php` (or filter **`fshipping_rates_debug_log`**), checkout **`POST /rate/v1/rates/quotes`** writes pretty-printed **request** and **response** to **`wp-content/debug.log`** per attempt (initial / safe-packaging retry / transient HTTP retry). Bearer token is not logged. Docs: **`docs/ERROR_HANDBOOK.md`**, **`docs/TECH_SPEC.md`**.

### Fixed
- **Open Ship — package delete endpoint/payload corrected** — Package delete now calls **`PUT /ship/v1/openshipments/packages/delete`** (not `DELETE …/packages/{id}`) with dynamic payload: root **`index`**, **`trackingIds[]`** (`trackingIdType`, `formId`, `trackingNumber`), and **`accountNumber`**. This aligns row delete/orphan cleanup requests with the expected FedEx Open Ship API shape. Filter added: **`fshipping_openship_delete_tracking_id_payload`**.
- **Open Ship — Save & push package row vs session ids** — **`PUT …/openshipments/packages`** is skipped when the stored **`fedex_package_id`** equals **`shipmentIdIndex`** (master tracking) or **`shipmentIndex`** (open-shipment key); those values are not piece tracking ids, so the first package no longer fails by default with FedEx “Package Tracking Number” errors. If a modify still returns that validation message, the plugin clears the row’s FedEx ids and retries once as **`POST …/packages`** (disable via filter **`fshipping_openship_retry_add_after_modify_tracking_error`**). **`OpenShip::is_likely_invalid_piece_tracking_for_modify()`**, **`Draft::fedex_local_id_is_piece_tracking_for_modify()`** (private). Docs: **`docs/OPEN_SHIP.md`**. Assets **1.7.2**.
- **Open Ship order admin — Last FedEx response actions** — Rows that are not per-package (for example successful **Update shipment** / **`update_shipment`**) show **Copy transaction ID** instead of a bare em dash. Admin script i18n: **`copyTxnId`**, **`copiedTxn`**. Assets **1.7.2**.
- **Open Ship order admin — no Save/Delete on rows without tracking** — In **Last FedEx response (packages)**, package actions are now shown only when the row has a real FedEx piece tracking number. This prevents **Save** (PUT modify) and **Delete** calls from firing on failed/no-tracking rows and replaces generic “Request failed” with a clear message to run **Save & push** first. Admin assets **1.7.3**.
- **Open Ship order admin — row action buttons simplified** — In **Last FedEx response (packages)**, package rows now show only **Edit / Delete** (the per-row **Save** button was removed). Persist changes using **Save & push to FedEx** after editing package fields in the box UI. Admin assets **1.7.4**.
- **Open Ship order admin — Delete now removes local row and table line** — After successful package delete on FedEx, the matching package row is now removed from `_fshipping_openship_packages_json` (edit box disappears after reload) and the corresponding entry is removed from `_fshipping_openship_last_push_rows` (table row disappears), instead of only clearing tracking fields.
- **Open Ship order admin — Clear all now clears rows too** — **Clear all packages (FedEx session)** now removes local package rows (`_fshipping_openship_packages_json`) and stored push-result rows (`_fshipping_openship_last_push_rows`) after successful session cancel, so both the package editor and Last FedEx response table are empty after reload.
- **Open Ship order admin — result table now survives refresh** — Save & push rows are now persisted to order meta **`_fshipping_openship_last_push_rows`** and rehydrated into the **Last FedEx response (packages)** table on page load. Clear all packages wipes the stored rows.
- **Open Shipments — bulk actions only saw one order** — Bulk checkboxes used **`name="order[]"`**, which collides with WordPress’s reserved **`order`** query variable (list sort direction). **`$_REQUEST['order']`** became a string (e.g. **`asc`**), so only one id was processed and **`debug.log`** could show a single delete index. Checkboxes now use **`fshipping_os_ids[]`** and bulk handlers read **`fshipping_os_ids`** (with a safe fallback only when **`order`** is already an **array**). ID list is de-duplicated. **`openshipments/delete`** log blocks include **`WooCommerce order_id`** when known. `OpenShipDraftsListTable`, `OpenShip::delete_open_shipment()`, `Draft::cancel_fedex_open_shipment_and_clear()`.
- **Open Ship order meta box — “View shipment record” opened wrong page** — The locked-state button now routes to **`admin.php?page=fshipping_openship_drafts&fshipping_os_detail=1&order_id={order_id}`** so staff land on the Open Ship detail view for the current order, not the shipment CPT edit/permalink page. `OpenShipOrderMetaBox`.
- **Open Ship details — confirm JSON is collapsible** — **Last FedEx confirm response (full JSON)** on the detail screen now renders as a collapsed-by-default toggle panel (click title to expand/collapse) with an arrow indicator showing state. `OpenShipDraftsPage`, `fshipping-openship-shipments.css`.
- **Open Ship details — extra top spacing for confirm JSON panel** — Added additional top margin above the collapsible **Last FedEx confirm response (full JSON)** box for cleaner visual separation from the section above. `fshipping-openship-shipments.css`.
- **Open Shipments admin screen** — `OpenShipDraftsPage::render()` defined `$stage` / `$life` after a closing `?>`, so PHP never ran those assignments and `debug.log` showed undefined variable warnings; assignments now run before HTML output.
- **Open Ship — `SERVICE.COD.UNAVAILABLE` on confirm** — Add Package now checks COD capability via `OpenShip::canUseCOD(serviceType, destinationCountry)` and strips package-level COD fields (`specialServiceTypes[]=COD`, `packageCODDetail`) when the service/country pair is not COD-capable before posting to FedEx, preventing confirm failures for COD-ineligible combinations (for example non-US or known non-COD services such as `INTERNATIONAL_PRIORITY`). Override filters: **`fshipping_openship_can_use_cod`** and legacy **`fshipping_openship_allow_cod_for_service_type`**.
- **Open Ship — Confirm request/response debug logging** — `OpenShip::confirm_full()` now writes `openshipments/confirm` diagnostics to `wp-content/debug.log` with **formatted request JSON** and **formatted full response JSON** (plus URL/API line), so admin **Confirm shipment** errors such as “The resource you requested is no longer available…” can be diagnosed from a single log block. New filter: **`fshipping_openship_log_confirm_request_response`** (default `true`).
- **Open Ship — scalar `requestedShipment.totalWeight` on create** — Minimal `openshipments/create` now sends scalar total weight (example `20.6`) instead of `{ "units": "LB", "value": ... }`, except when `shipmentSpecialServices.shipmentDryIceDetail.totalWeight` exists.
- **Open Ship — no forced `sequenceNumber` on create line item** — `openshipments/create` no longer auto-injects `requestedShipment.requestedPackageLineItems[0].sequenceNumber = "1"` during start payload preparation. Existing package data is preserved, and fallback synthesized lines now omit `sequenceNumber`.
- **Open Ship — Dry Ice totalWeight shape in minimal create payload** — When `requestedShipment.shipmentSpecialServices.shipmentDryIceDetail.totalWeight` is already present, minimal `openshipments/create` now preserves `shipmentSpecialServices` and does **not** inject top-level `requestedShipment.totalWeight`. This avoids conflicting weight shapes for Dry Ice flows while keeping existing total-weight fallback for non-Dry-Ice requests.
- **Open Ship — `requestedShipment.totalWeight` on create** — Minimal **`openshipments/create`** payloads now send **`totalWeight`** as FedEx **Weight** (`units` + `value`). A scalar total weight could fail strict schema validation and return misleading **`SHIPMENT.INDEX.REQUIRED`**. See **`docs/ERROR_HANDBOOK.md`** (`SHIPMENT.INDEX.REQUIRED`).
- **Open Ship — `SHIPMENT.INDEX.REQUIRED` on production create** — **`POST /ship/v1/openshipments/create`** no longer sends root **`shipmentIndex`** by default (it duplicated **`index`**). Production FedEx often rejects that shape while **Ship API** create is unchanged. Opt-in for legacy gateways: **`add_filter('fshipping_openship_create_mirror_shipmentIndex', '__return_true');`**. Docs: **`docs/OPEN_SHIP.md`**, **`docs/ERROR_HANDBOOK.md`**. PHPUnit: **`OpenShipTest`**.
- **Rates — HTTP 502/503/504 retry** — Checkout/cart calls **`POST /rate/v1/rates/quotes`**; FedEx **Sandbox** often returns **503** (transient). `HTTP\Shipping::get_shipping_rates()` now retries **once** after a short delay (filters **`fshipping_rates_retry_on_transient_http`**, **`fshipping_rates_transient_retry_delay_us`**) and logs a clearer **`debug.log`** hint for sandbox **5xx**. See **`docs/ERROR_HANDBOOK.md`** (HTTP 502/503/504 on Rates).
- **Open Ship — Advanced checkout must not complete when create fails** — FedEx **`openshipments/create`** responses with **`errors`** (e.g. **`SHIPMENT.INDEX.REQUIRED`**) were misread as success because **`extract_openship_session_from_create_output()`** echoed the **request** root **`index`** when no master tracking existed, so **`set_openship_session_meta`** stored a fake session. **`OpenShip::openship_create_response_body_indicates_success()`** now requires **`output.transactionShipments[0].masterTrackingNumber`** (or **`completedShipmentDetail.masterTrackingId`**) unless filtered; **`start_from_order()`** returns **`[]`** when the body is not a real session. **Checkout** defaults to **`throw new \Exception`** (WooCommerce shows checkout error and skips payment) with filter **`fshipping_openship_throw_on_checkout_start_failure`** (return **`false`** to restore soft **wc-fedex-draft** behavior). Admin Ajax uses the same success check. Docs: **`docs/OPEN_SHIP.md`**.
- **Open Ship — root `index` + `SHIPMENT.INDEX.REQUIRED`** — After **`prepare_start_payload()`** / **`fshipping_openship_start_payload`**, **`OpenShip::ensure_openship_create_payload_has_root_index()`** guarantees a non-empty root **`index`**. **`Draft::allocate_unique_openship_index_for_order_id()`** uses **`wc-os-{order_id}-{unix_timestamp}-{16 hex}`** (never the legacy bare **`wc-os-{order_id}`** default). If still missing, **`openshipments/create`** is **not** called; **`debug.log`** records **Missing FedEx Open Ship index** and the body returns **`TEAMZ.OPENSHIP.INDEX.MISSING`**. On FedEx **`SHIPMENT.INDEX.REQUIRED`**, **`post_openshipments_start()`** clears cached create payload, **rebuilds** the full JSON from **`prepare_start_payload()`**, forces a **new** root **`index`** via **`_teamz_force_openship_root_index`**, logs **`differs_from_failed`**, and POSTs **once**. Sandbox **`NOT.FOUND`** retry reuses the current payload’s **`index`**. **`start_from_order()`** still retries (filter **`fshipping_openship_create_max_attempts_on_index_error`**) with a fresh index. **`groupPackageCount`** still defaults to **`1`** on create lines when unset. **`summarize_fedex_start_failure`**, **`docs/OPEN_SHIP.md`**, **`docs/ERROR_HANDBOOK.md`** updated.
- **Open Ship — AjaxHandler parse error** — Docblock for `restart_session()` accidentally contained the substring `*/` (from markdown `**/**`), which terminated the block comment early and caused a PHP parse error on load. Comment text corrected (no `*/` inside docblocks).
- **Open Ship — `SHIPMENT.INDEX.INUSE` + session reuse** — Order meta **`_fshipping_openship_session_status`** tracks **open** / **active** / **closed** / **abandoned**. **`openshipments/create`** uses a **unique** root index per attempt (`OpenShip::start_from_order()` → **`Draft::allocate_unique_openship_index()`**). On **`SHIPMENT.INDEX.INUSE`**, the client retries with a new index (filter **`fshipping_openship_create_max_attempts_on_index_error`**) and can recover when local **`shipmentIndex`** matches the failed request. **Restart FedEx session** skips duplicate create when the session is **open**/**active** and re-syncs packages only. Confirm sets **closed**; **Cancel on FedEx** sets **abandoned**. Docs: **`docs/OPEN_SHIP.md`**, **`docs/ERROR_HANDBOOK.md`**.
- **Open Ship — `debug.log` URL + `SHIPMENT.INDEX.INUSE`** — Every **`debug_log_push_json_blocks`** entry for create/add-package (and admin Ajax start failure) now includes a **`FedEx REST URL`** section with the bare HTTPS URL. Admin alerts for create failures append guidance when FedEx returns **`SHIPMENT.INDEX.INUSE`**. Documented in `docs/ERROR_HANDBOOK.md`.
- **Open Ship — Restart / session start JSON** — `OpenShip::start()` now returns the **full** `openshipments/create` body (not only `output`) so `extract_openship_session_from_create_output()` sees root-level `transactionShipments` / `index` when FedEx omits or nests `output` differently (avoids false empty session / misleading failures). `start_from_order()` returns `[]` when the body contains FedEx `errors`. Admin Ajax errors include **`openship_create_request`** / **`openship_create_response`** strings and always append a **debug.log** block; the order script logs those to the **browser console** on failure. Assets **1.5.8**.

### Added
- **Settings → International (FX)** — Admin tab on **Fedex → Settings** to edit **`fshipping_fx_rates`** (one line per ISO currency: units per **1 USD**, e.g. `UZS 12500` for variable handling / declared value / COD conversion to USD on Open Ship Add Package). **`GlobalSupport::stored_fx_rates()`** returns the option without the **`fshipping_fx_rates`** filter (so filter-only codes are not lost on save). **`GlobalSupport::parse_fx_rates_text()`** parses the textarea. See `docs/OPEN_SHIP.md`.
- **CLI FedEx API probe** — `scripts/fedex-api-probe.php` loads WordPress and runs OAuth (core + tracking), a domestic **Rates** quote, and a minimal **Open Ship create**, without printing secrets. Requires CLI PHP with `mysqli`. Documented in `tests/manual/24_fedex_cli_probe.md`.
- **Open Ship create — root `shipmentIndex` mirror (optional)** — Filter **`fshipping_openship_create_mirror_shipmentIndex`** (default **`false`**) can duplicate root **`index`** into **`shipmentIndex`** for rare legacy gateways; default off matches FedEx **Create** docs and avoids production **`SHIPMENT.INDEX.REQUIRED`** when both keys are sent. Docs: `docs/ERROR_HANDBOOK.md`, `docs/OPEN_SHIP.md`. PHPUnit: `OpenShipTest` start payload.
- **Open Ship — FedEx money in USD** — Add Package normalizes **`declaredValue`**, COD collection amounts, and variable-handling fixed values to **USD** using `FedExMoneyUsd` and the merchant FX option **`fshipping_fx_rates`** (units of foreign currency per 1 USD). `OpenShipPushValidator` rejects Save & push when a non-USD amount needs conversion but no rate is configured. `GlobalSupport::has_fx_rate_for()`. PHPUnit: `OpenShipTest::test_add_package_converts_declared_value_uzs_to_usd_when_fx_rate_configured`, `GlobalSupportTest` (`has_fx_rate_for`), `OpenShipPushValidatorTest` (declared value + FX). See `docs/OPEN_SHIP.md`. Assets **1.5.7**.

### Changed
- **Open Ship — package notes removed** — The per-box **Notes / handling** field is removed from the order UI and from stored package rows. **`customerReferences`** are no longer built from package notes; use **`package_line_extras.extraCustomerReferences`** (or **`fshipping_openship_package_line_item`**) if you need references on the Add Package line item. PHPUnit: `OpenShipTest::test_add_package_with_order_merges_extras_without_package_notes`. Assets **1.5.6**.
- **Open Ship — content record UI** — Removed the **Description** column from the **Content record** table under **Other information** (Item/SKU, Qty, Part # only). `contentRecord[].description` is no longer saved in `PackageLineExtras::sanitize()`. Assets **1.5.5**.

### Added
- **Open Ship — Save & push validation** — Before calling FedEx **Add Package**, `OpenShipPushValidator` enforces completeness for selected special services (COD, alcohol, DG, batteries, priority alert, dry ice), variable handling (`CUSTOM` requires amount/percent), blocks **`groupPackageCount` > 1** by default (filter `fshipping_openship_allow_group_package_count`), and flags an overly heavy special-service combo (filters `fshipping_openship_validate_blocking_combos`, `fshipping_openship_push_validation`). **Save draft** is unchanged. Admin alerts show multiple **`errors`** lines. **FedEx package sequence** (response `packageSequenceNumber`) is stored and shown separately from optional **Sequence number** in Other information. PHPUnit: `tests/phpunit/OpenShip/OpenShipPushValidatorTest.php`. See `docs/OPEN_SHIP.md`. Assets **1.5.4**.

### Changed
- **Open Ship — “Other information” UI** — Package extras are grouped in **cards** with compact **label + control** rows (narrow Select2 / native selects instead of full-width). **Battery rows** use a header with a visible **Remove** button; sub-sections (priority alert, alcohol, DG, COD, batteries, dry ice, standalone) sit in nested groups. Assets **1.5.3**.
- **Open Ship — Add Package `customerReferences`** — **`ORDER_NUMBER`** is not injected automatically; references come from **`package_line_extras.extraCustomerReferences`** (and filters), not from a package notes field. See `docs/OPEN_SHIP.md`.

### Added
- **Open Ship — per-package “Other information” (FedEx line-item extras)** — Optional accordion on the order **FedEx Open Ship** meta box for extra **`RequestedPackageLineItem`** fields (sub-packaging, clearance/content record, variable handling, package special services, batteries, dry ice, etc.). Values persist per package row as **`package_line_extras`** in `_fshipping_openship_packages_json` (`PackageLineExtras::sanitize`). **`add_package`** merges **`package_line_extras`** into the line item; admin JS (`fshipping-openship-order.js`) collects nested JSON, repeaters, and multi-selects; **Select2** is enqueued on this screen. Assets **1.5.1**. See `docs/OPEN_SHIP.md`. PHPUnit: `OpenShipTest::test_add_package_with_order_merges_extras_without_package_notes`.

### Fixed
- **Open Ship — `customerReferences` on Add Package** — Aligns with FedEx rules: **`customerReferenceType`** limited to documented enums; **`value`** truncated per type; **`CUSTOMER_REFERENCE`** uses **30** chars when the session **service type** is Ground-like, **40** otherwise (filter **`fshipping_openship_customer_reference_value_max_length`** now receives optional service type). When the line has **`customerReferences`** and **`groupPackageCount`** is not set, the request sends **`groupPackageCount`: `1`**. Push **`debug.log`** includes a **`customerReferences (debug)`** block (service type, Ground flag, counts, effective max length). See `docs/OPEN_SHIP.md`.
- **Admin Select2 alignment** — Normalized single- and multi-select **Select2** field height/rendered-value alignment so selected values no longer sit at the bottom of FedEx admin dropdowns, including the Open Ship package extras UI. Updated CSS asset versions: general admin **1.0.1**, Open Ship **1.5.2**.
- **Admin Select2 layout (Open Ship + settings)** — Open Ship Select2 now uses **`dropdownParent: document.body`**, **`width: '100%'`**, and a short deferred init after opening the accordion so dropdowns are not positioned at the top of the page and fields are not measured at **0px** width while hidden. Removed the **350px** cap on `.select2` containers in the general admin stylesheet (replaced with **`max-width: 100%`**) so settings fields with **`min-width: 25rem`** render full width. FedEx settings **`main.js`** passes **`dropdownParent: body`**. CSS z-index for dropdowns on the order screen; assets **Open Ship 1.5.3**, general admin **1.0.2**.
- **Open Ship order UI — products per box qty** — Quantity inputs now respect the order line maximum: HTML `max` is the **remaining** qty for that box (order line total minus qty in other boxes), invalid saved values are clamped on render, admin JS recalculates caps when editing or adding/removing boxes, and saves run through `Draft::clamp_package_line_items_to_order_quantities()` so totals cannot exceed the order. Asset version **1.4.5**.

### Changed
- **Open Ship — Add Package request body** — `POST /ship/v1/openshipments/packages` sends the open-shipment key (e.g. `wc-os-{order_id}`) as JSON **`index`** (string), **not** **`shipmentIndex`**. Master tracking is **`shipmentIdIndex`**. **`confirm_full`**, **`delete_open_shipment`**, and **DELETE package** keep using **`shipmentIndex`** + **`shipmentIdIndex`** where those FedEx paths expect them. See `docs/OPEN_SHIP.md` and `OpenShipTest::test_add_package_posts_to_packages_endpoint`.
- **WooCommerce order edit — FedEx sidebar meta boxes removed** — The order screen no longer registers the sidebar boxes for **FedEx special services**, **FedEx ETD commercial invoice**, **FedEx dangerous goods**, **FedEx service preferences**, or **FedEx Freight accessorials** (`Main.php` no longer initializes those `Admin\*MetaBox` classes). Ship/rate/ETD runtime behavior is unchanged when `_fshipping_*` order meta is set by other means. See `docs/TECH_SPEC.md` — **WooCommerce order edit (FedEx sidebar)** (after §12 Open Ship).
- **Open Ship — Minimal create payload** — Default minimal **`requestedShipment`** for **`openshipments/create`** now includes **`shipDatestamp`** (order date / site timezone, filter **`fshipping_openship_ship_datestamp`**), **`totalWeight`** (sum of package line weights in **LB**), **`requestedPackageLineItems[].sequenceNumber`** as **`"1"`**, and payor **address/contact** when the Ship payload supplies them (matches FedEx samples more closely). Optional create body **`index`** / **`version`**: filters **`fshipping_openship_create_index`**, **`fshipping_openship_create_version`**. `start_from_order()` passes **`order_id`** into the start args for those filters.
- **Open Ship — Start failure UX + debug.log** — Failed **`openshipments/create`** returns **HTTP 400** with **`message`** built from FedEx **`errors`** (and optional **`fedex_errors`**) instead of a generic 500. **`debug.log`** records **pretty-printed** request/response blocks for **`/openshipments/create`** and **`/openshipments/packages`** when push logging is enabled (`OpenShip::debug_log_push_json_blocks()`).
- **Open Ship — NOT.FOUND.ERROR on `/start`** — Before **`POST openshipments/start`**, `OpenShip::finalize_requested_shipment_for_openship_start()` strips **`labelSpecification`**, **`shippingDocumentSpecification`**, **`emailNotificationDetail`**, and **`documentRequirements`** from the shared Ship payload (labels print at **confirm**). By default also strips **`specialServicesRequested`**, then replaces with **`OpenShip::build_minimal_openship_requested_shipment()`** (no `shipTimestamp` / `totalDeclaredValue`, billing payor **account only**, **`DROPOFF_AT_FEDEX_LOCATION`** → **`USE_SCHEDULED_PICKUP`**). Disable minimal body with filter `fshipping_openship_use_minimal_start_payload`; restore strips via `fshipping_openship_start_strip_special_services` / `fshipping_openship_start_requested_shipment`.
- **Open Ship — Sandbox `NOT.FOUND` + account** — FedEx **Sandbox** APIs do not accept arbitrary production account numbers; **`NOT.FOUND.ERROR`** on **`openshipments/start`** is resolved by using the developer-portal **test account** (see **`docs/RUNBOOK_CREDENTIALS.md`**, typically **`510087100`**). **`prepare_start_payload()`** now syncs root **`accountNumber`** with **`shippingChargesPayment.payor.responsibleParty.accountNumber`**. When environment is Sandbox and FedEx returns **`NOT.FOUND.ERROR`**, the client **retries once** with the documented sandbox test account (override via filter `fshipping_fedex_shared_sandbox_account_number`; disable retry via `fshipping_openship_retry_start_with_doc_sandbox_account`). **`Helper::is_sandbox_environment()`** added.
- **Open Ship — Save & push without session** — If `_fshipping_openship_shipment_index` is empty, **Save & push to FedEx** now calls **`openshipments/start`** automatically (when the order has a FedEx `fshipping_custom` line), stores the session id, then **`add_package`** for each box. Matches operator expectation for the button label; **Restart FedEx session** remains for replacing an existing session.

### Added
- **Open Ship — `debug.log` on order-scoped create** — When **`POST …/openshipments/create`** runs with **`order_id`** in the start args (`start_from_order` — Advanced checkout or admin **Save & push** / **Restart session**), request/response JSON blocks are **appended** to **`wp-content/debug.log`** even if `WP_DEBUG_LOG` / `FSHIPPING_OPENSHIP_LOG_PUSH` are off (same write path as FedEx-error diagnostics). Filter **`fshipping_openship_log_create_for_order`** (return `false` to disable). Log title includes **`(order_id=N)`**.
- **Open Ship — debug.log on Save & push** — When `WP_DEBUG` + `WP_DEBUG_LOG` (or `FSHIPPING_OPENSHIP_LOG_PUSH`), logs normalized packages plus each FedEx Add Package payload/response (`OpenShip::add_package`, filter `fshipping_openship_debug_log_push`). Documented in `docs/OPEN_SHIP.md`.

### Fixed
- **Open Ship — `SHIPMENT.INDEX.REQUIRED` on Add Package** — FedEx **Add / Confirm / Delete** bodies require **both** **`shipmentIndex`** (open-shipment key; root **`index`** on **Create**, default **`wc-os-{order_id}`**) and **`shipmentIdIndex`** (master **tracking** from **`transactionShipments[0]`**). Sending only **`shipmentIdIndex`** with the tracking number caused **`SHIPMENT.INDEX.REQUIRED`**. The client now stores **`_fshipping_openship_shipment_index`** + **`_fshipping_openship_shipment_id_index`**, passes both to **`add_package`**, **`confirm_full`**, **`delete_open_shipment`**, and **DELETE package** query strings. **`OpenShip::extract_openship_session_from_create_output()`** derives the pair; **`extract_shipment_id_index()`** remains as the **`shipmentIndex`** string for back-compat.
- **Open Ship — Session index from `POST …/openshipments/create`** — FedEx often returns **`transactionShipments[0].masterTrackingNumber`** (and omits top-level correlation fields). Session extraction uses **`transactionShipments`** / **`completedShipmentDetail.masterTrackingId`** for **`shipmentIdIndex`**, and the create request’s root **`index`** (or **`output.shipmentIndex`** / **`index`**) for **`shipmentIndex`**.
- **Open Ship — Create endpoint + `openShipmentAction`** — FedEx Ship API Open Ship **Create** is **`POST /ship/v1/openshipments/create`** (e.g. `https://apis.fedex.com/ship/v1/openshipments/create`), not **`/openshipments/start`**. Root **`openShipmentAction`** is a string enum (**`STRONG_VALIDATION`**, **`WEAK_VALIDATION`**, **`CREATE_PACKAGE`**, **`PROVIDE_DOCUMENTS_INCREMENTALLY`**); default **`CREATE_PACKAGE`**. Filter **`fshipping_openship_start_open_shipment_action`**.
- **Open Ship — `debug.log` on FedEx errors** — When **`openshipments/create`** or **`add_package`** returns a FedEx **`errors`** payload, request/response blocks are **always appended** to **`wp-content/debug.log`** (unless filter **`fshipping_openship_force_log_on_fedex_errors`** disables it), so failures are visible without **`WP_DEBUG_LOG`** or **`FSHIPPING_OPENSHIP_LOG_PUSH`**. **`emit_openship_log_output()`** centralizes writes; the NOT.FOUND sandbox-skip line is forced too.
- **Open Ship — Add / Confirm payloads (Open Ship v1 docs)** — **`POST …/openshipments/packages`** now includes root **`accountNumber`** (was missing; required for *Add Open Shipment Packages*). **`POST …/openshipments/confirm`** now sends **`accountNumber`**, **`shipmentIdIndex`**, and **`labelResponseOptions`** (default `URL_ONLY`, filter `fshipping_openship_confirm_label_response_options`) per *Confirm Open Shipment*. Filters: `fshipping_openship_add_package_payload`, `fshipping_openship_confirm_payload`.
- **Open Ship — Create Open Shipment payload** — `POST /ship/v1/openshipments/create` sends **`openShipmentAction`** (default **`CREATE_PACKAGE`** per FedEx enum; filter `fshipping_openship_start_open_shipment_action`). Filters: `fshipping_openship_start_payload`. Package **`dimensions`** on create are normalized to **integers** (FedEx uses whole units). **debug.log** blocks for create/add-package include **`API (requested)`** with **method + full URL + Settings → environment + host**.
- **Open Ship — `/start` without package lines** — After overrides / intl patch / `fshipping_openship_requested_shipment`, **`requestedPackageLineItems`** could be empty while **`debug.log`** showed a minimal body; **`OpenShip::ensure_master_requested_package_line_for_openship_start()`** restores a master line (first saved box or **1 lb / 10×10×10 in**). **Sandbox NOT.FOUND retry** now treats **sandbox host or sandbox setting** as eligible (not host-only), and when push logging is on, **`NOT.FOUND`** without a retry logs a short **skip reason** (production, filter off, or account already the doc test number).
- **Open Ship admin (order screen)** — **Abandon session** no longer referenced an undefined `$btn` in the Ajax `always` callback (could break the script). **Confirm shipment** now re-enables the button after the request completes. Asset version **1.4.4**; Ajax **fail** handler shows **`responseJSON.data.message`** when WordPress returns JSON (e.g. FedEx start errors). Localized string **`requestFailed`** for non-JSON error alerts.
- **Open Ship — FedEx package id / tracking** — Add Package `output` is parsed with fallbacks (`trackingIds`, alternate keys) so `_fedex_package_id` is stored reliably; **Delete package** path uses **tracking number first** (FedEx Ship API path `{id}`), with filter `fshipping_openship_delete_package_path_id`. Order UI: package id and label **tracking** link to FedEx Track (`fshipping_openship_public_tracking_url`).
- **Open Ship drafts — Trash tab empty** — `wc_get_orders( [ 'status' => 'any' ] )` excludes trashed orders (WooCommerce HPOS `OrdersTableQuery` and CPT `post_status`). The drafts list now queries all registered order statuses **plus** `trash` so moved orders appear under **Trash**.

### Added
- **Open Ship drafts — Trash tab** — **All | Trash** subviews (with counts), trashed draft orders listed under Trash, **Restore** / **Delete permanently** (row + bulk), redirects preserve the active tab via `fshipping_os_status=trash` and `OpenShipDraftsPage::base_list_url()`.
- **Open Ship drafts screen** — `includes/Admin/OpenShipDraftsListTable.php` wired from `OpenShipDraftsPage.php`: search, lifecycle filter, bulk actions (abandon local, FedEx session delete + clear, combined FedEx cancel + trash, lifecycle quick-edit, trash), row actions (including trash after FedEx cancel), admin notices, per-page screen option. Menu capability **`edit_shop_orders`** (was `manage_options`). FedEx **Delete Open Ship session**: `HTTP\OpenShip::delete_open_shipment()` → `POST /ship/v1/openshipments/delete` with filter `fshipping_openship_delete_payload`; `OpenShip\Draft::cancel_fedex_open_shipment_and_clear()` and shared `Draft::abandon_session_local()` (also used by Ajax abandon). Documented in `docs/OPEN_SHIP.md`. PHPUnit: `OpenShipTest::test_delete_open_shipment_*`.

### Changed
- **Open Ship drafts screen copy** — Removed the two introductory helper paragraphs from `Fedex → Open Ship drafts` so the list table opens directly without extra descriptive text.
- **`docs/OPEN_SHIP.md`** — Full process aligned with operator reference: numbered
  sections **1–8** (modes with `_fshipping_fulfillment_mode`, preconditions, checkout
  merge/overrides/`totalPackageCount`, admin discovery, save `draft`/`push`, confirm,
  lifecycle, mental model), updated Ajax/shipment steps, implementation table.
- **Open Ship admin (order screen)** — Full **FedEx Open Ship** meta box: status
  strip, shipment settings (service / pickup / packaging / payor) with order meta
  overrides, international JSON patch field, per-box editor (name, weight + units,
  dimensions + units, declared value, notes → FedEx `declaredValue` /
  `customerReferences`), product-to-box qty mapping with validation, actions (save
  draft, save & push with delete-then-re-add on FedEx session, recalc total
  weight, restart session, abandon, confirm), label/tracking after confirm.
  New assets: `assets/admin/css/fshipping-openship-order.css`. Extended
  `HTTP\OpenShip::add_package`, `OpenShip\Draft` (overrides, intl merge, validation),
  and Ajax handlers. Filters: `fshipping_openship_requested_shipment`,
  `fshipping_openship_package_line_item`.
- **`docs/OPEN_SHIP.md`** — Added **Full process (current behavior)**: checkout
  preconditions (`woocommerce_checkout_order_processed` priority 20), mermaid
  flowchart, step-by-step Advanced checkout/admin Ajax, lifecycle table, mental
  model vs Instant, and links to source files.
- **`docs/TECH_SPEC.md` §12** — Plugin map row references the **Full process**
  section in `OPEN_SHIP.md`.
- **`Admin\OpenShipDraftsPage`** — Order list uses `meta_key`/`meta_value` instead
  of `meta_query` so WooCommerce 9.2+ does not trigger `_doing_it_wrong` on the
  CPT order datastore (HPOS-compatible).
- **`docs/TECH_SPEC.md` §12, `docs/API_MAP.md`** — Open Ship section updated for
  WooCommerce Advanced mode and class map.
- **AIV docs vs FedEx portal** — `docs/TECH_SPEC.md` §10, `docs/ARCHITECTURE.md`,
  `tests/manual/08_tracking_webhook.md`, and Fedex → Settings → Webhook copy now
  cite FedEx shipper rules (Security Token length/complexity, URL validation
  **200/202**), the Feb 2025 visibility webhook announcement, and the distinction
  between FedEx’s **async job** subscription docs and this plugin’s **`trck-sub/v2`**
  REST client (verify against your project’s Production Keys OpenAPI).

### Added
- **Advanced Shipping (Open Ship) — product flow** — Global **Shipping mode** under
  Fedex → Settings → Shipping: **Instant** (Ship API, unchanged) vs **Advanced**
  (Open Ship). Checkout starts an Open Ship session and stores draft state on the
  order; **`fedex_shipping`** is created only after admin **Confirm shipment**.
  Classes: `Utils\Helper::get_shipping_mode()`, `HTTP\OpenShip::start_from_order()`,
  `HTTP\Shipment::persist_shipment_from_api_response()`, `OpenShip\Draft`,
  `OpenShip\OrderStatuses`, `OpenShip\AjaxHandler`, `Admin\OpenShipDraftsPage`,
  `Admin\OpenShipOrderMetaBox`, `assets/admin/js/fshipping-openship-order.js`.
  **Fedex → Open Ship drafts** lists unconfirmed Advanced orders; **Shipments &
  Printings** submenu is hidden while mode is Advanced.
- **`docs/OPEN_SHIP.md`** — Rewritten for Advanced mode: settings, checkout/admin
  flows, order meta keys, Ajax actions, tests, sandbox caveats. Linked from
  `docs/API_MAP.md`.
- **`tests/manual/23_openship_advanced_mode.md`** — Operator checklist for Advanced
  Shipping (settings, checkout, drafts, confirm, Instant menu restore).
- **`docs/ONBOARDING.md` — AIV webhooks** — Full operator checklist (FedEx
  portal, WordPress settings, account vs per–tracking-number strategy, what is
  automatic vs not, optional `fedex_send_shipment_confirmation_mail` subscribe
  snippet, verification links). Documents that in-plugin auto-subscribe is not
  in core today.
- **AIV / Advanced Tracking documentation audit** — `docs/ARCHITECTURE.md` now
  documents outbound `HTTP\TrackingWebhook` (`trck-sub/v2`) vs inbound
  `TrackingWebhookReceiver`, including that subscribe is not auto-run on ship.
  `docs/TECH_SPEC.md` §10–11 updated with accurate subscribe payload, endpoint
  list, FedEx portal doc links, and portal verification notes. `docs/API_MAP.md`
  Notes expanded; `tests/manual/08_tracking_webhook.md` links FedEx docs +
  PHPUnit commands for receiver + subscription client.
- **Locations Search debug lines** — `HTTP\Locations::search()` now writes the
  JSON request payload and full decoded response to `error_log()` with prefix
  `[teamzlab-fedex][locations-search]` (usually `wp-content/debug.log` when
  `WP_DEBUG_LOG` is enabled in `wp-config.php`). Documented in
  `docs/ERROR_HANDBOOK.md`.
- Shipments admin list UX upgrades:
  - Search label updated to **"Search by Tracking ID"** with query execution on
    `_tracking_number` meta.
  - **Label Printed** toggle column with per-row AJAX save
    (`_fshipping_label_printed`).
  - Soft row highlighting: printed rows (green) and canceled rows (danger/red).
  - Bulk actions for printed state:
    `Mark as Label Printed` / `Mark as Label Not Printed`.
- New manual test recipe:
  `tests/manual/22_shipments_admin_workflow.md`.
- Documentation spine: root `CLAUDE.md`, `README.md`, per-module `CLAUDE.md`
  files, `docs/TECH_SPEC.md`, `docs/API_MAP.md`, `docs/ROADMAP.md`,
  `docs/MARKETING.md`, `docs/GLOSSARY.md`.
- `.env.example` documenting credential schema.
- `.gitignore` for standard WordPress plugin artefacts.
- **Address Validation API client** (`FSHIPPING\HTTP\AddressValidation`) —
  validates up to 100 addresses per request, classifies residential vs.
  commercial, returns standardized / corrected addresses.
- **Pickup History admin page** (`Fedex → Pickup History`) — shows
  previous pickup schedule events (single + consolidated), shipment counts,
  tracking lists, carrier/weight, and canceled status.
- **Cancel pickup from Pickup History** — `fshipping_cancel_pickup_by_confirmation`
  calls the same FedEx cancel path as the shipments list, then updates the
  history row and clears linked shipment pickup meta.

### Changed
- **FedEx Open Ship (order edit):** Removed the **International / customs (advanced)** JSON textarea from the **FedEx Open Ship** meta box. `_fshipping_openship_intl_customs` remains supported in `Draft` / Ajax when set outside the UI.
- **Fedex admin submenu order:** Settings uses an explicit `add_submenu_page`
  position (**999**) so it appears **last** under **Fedex**; other admin pages
  use positions **10–25**. Clicking the top-level **Fedex** menu opens the
  lowest-position submenu (Shipments), not Settings.
- **Locations Search URL** — `HTTP\Locations` now calls
  `POST /location/v1/locations` (FedEx catalog). The previous
  `/location/v1/locations/search` path returned `NOT.FOUND.ERROR` (“resource …
  no longer available”) from FedEx.
- `[fshipping_locations]` shortcode frontend now ships a richer customer UI:
  country + ZIP form fields, distance-unit selector (miles/km), result-count
  selector (up to 75), a **minimal one-row-per-location list**, client-side
  filter (search text), sort (distance / name), max-distance and phone-only
  filters, plus namespaced assets `assets/frontend/css/teamzzlab-fedex-locations.css`
  and `assets/frontend/js/teamzzlab-fedex-locations.js` (`teamzzlab-fedex-*`
  classes) to avoid style clashes. Results sit in a **nested panel** (boxed),
  toolbar is **side-by-side on ≥768px**, rows **hover** for feedback, **≤600px**
  stacks aside block under the address.
- Pickup workflow now supports consolidated daily scheduling from the
  Shipments list via a global **Schedule Pickup** action:
  one FedEx pickup request can link to multiple ready shipment rows,
  while row-level **Request pickup** remains available as fallback.
- Pickup cancellation now clears pickup metadata across all shipments
  sharing the same confirmation code (batch-safe cancel behavior).
- Pickup scheduling and cancellation now persist an admin audit trail in
  `fshipping_pickup_history` so historical pickup batches remain visible
  after row-level pickup meta is cleared.
- Postal AJAX validation now runs a country-aware Woo postcode format check
  before FedEx lookup, so clearly invalid ZIP/postal inputs no longer show
  "continue checkout" and instead return a field error.
- ZIP inline status now stays visible when FedEx postal API returns a
  non-error empty response: instead of disappearing, checkout shows a
  non-blocking confirmation that customers can continue.
- Checkout ZIP validation UX no longer shows the
  "Postal validation service returned no data..." warning when FedEx postal
  API returns an empty-but-non-error payload; explicit postal errors still show.
- Checkout shipment creation now treats FedEx postal-validation "no data"
  responses as non-blocking warnings (order note), preventing false negatives
  where Woo order succeeds but no `fedex_shipping` post is created.
- Checkout validation assets are no longer enqueued on the order-received page,
  preventing checkout-only inline guidance from appearing after successful order
  placement.
- Fixed checkout fatal on order submit caused by HTTP client singleton
  cross-class reuse in compatibility mode. `BaseClient::instance()` now
  guarantees the returned singleton is an instance of the called subclass.
- Removed Shipments admin **Charge Update** UI and AJAX endpoint.
- Documented FedEx limitation: post-creation shipment modifications are Open Ship
  workflow specific (before confirmation); confirmed shipments should use cancel
  + recreate flow for business value changes.
- **Postal Code Validation API client** (`FSHIPPING\HTTP\PostalCodeValidation`)
  — lightweight city / state / service-area lookup keyed on postal code.
- **Service Availability API client** (`FSHIPPING\HTTP\ServiceAvailability`)
  — returns the list of FedEx services allowed on a given origin→destination
  lane, for pre-checkout feasibility checks.
- **Pickup Request API client** (`FSHIPPING\HTTP\Pickup`) — check pickup
  availability, create pickups, cancel pickups.
- **Locations Search API client** (`FSHIPPING\HTTP\Locations`) — find nearby
  FedEx drop-off / pickup locations by address, lat-lng, or phone.
- **Rates wrapper** (`FSHIPPING\HTTP\Rates`) — convenience class that wraps
  the existing `HTTP\Shipping::get_shipping_rates` with a clean name and
  decoded transit-time metadata.
- **Advanced Integrated Visibility (webhook) subscription client**
  (`FSHIPPING\HTTP\TrackingWebhook`) — create / list / delete tracking-number
  and account-number subscriptions; payload shape matches FedEx v2.
- **AIV webhook receiver** (`FSHIPPING\Ajax\TrackingWebhookReceiver`) —
  REST endpoint at `/wp-json/fshipping/v1/aiv-webhook` with `fdx-signature`
  HMAC verification and event persistence.
- **Open Ship API client** (`FSHIPPING\HTTP\OpenShip`) — incremental
  multi-package (up to 999) shipments over a 5-day window.
- **Global Trade API client** (`FSHIPPING\HTTP\GlobalTrade`) — pre-ship
  customs / regulatory advisories for international shipments.
- **Trade Documents Upload API client** (`FSHIPPING\HTTP\TradeDocuments`) —
  electronically submits up to 5 customs documents per transaction.
- **Freight LTL API client** (`FSHIPPING\HTTP\FreightLTL`) — LTL rate
  quotes, shipment creation (with BOL), and pickup scheduling.
- **Return Tag / RMA client** (`FSHIPPING\HTTP\ReturnTag`) — creates a
  FedEx-hosted return label (PDF URL) for any WooCommerce order;
  persists `_fshipping_return_label_url` and `_fshipping_return_tracking`
  on the order, and adds an order note with the return tracking number.
- **AIV event router** (`FSHIPPING\Events\DeliveryUpdates`) — listens on
  `fshipping_aiv_event_received` and reacts to FedEx event codes:
  - `DL` / `DELIVERED` → transitions the WooCommerce order to `completed`.
  - `OD` / `OUT_FOR_DELIVERY` → adds a customer-visible order note.
  - `DE` / `EX` / `DELIVERY_EXCEPTION` → finds the 3 nearest FedEx
    Office locations via `HTTP\Locations` and emails the customer a
    Hold-at-Location redirect suggestion (the "loss-recovery" feature
    from Section 5.1 of the research brief).
- **Public rate-quote REST endpoint** (`FSHIPPING\Ajax\RateQuoteEndpoint`)
  — `GET /wp-json/fshipping/v1/rate-quote` for the embeddable rate
  calculator widget. Unauthenticated, CORS-open, 60 req/IP/hour,
  15-minute response cache keyed by payload hash.
- Return-label CPT column (**Return** → Create return / Return label).
- Ajax handler `fshipping_create_return` for the new column.
- **Customs-hold handling** (`FSHIPPING\Events\CustomsAlerts`) — catches
  `CH`, `CP`, `CD`, `CA`, `HL`, `CC` AIV event codes. Blocking codes
  trigger a merchant alert email with the tracking number, destination
  country, event code, and a one-click order-edit deeplink. Each event
  stamps `_fshipping_customs_state` / `_fshipping_customs_code` /
  `_fshipping_customs_at` post-meta for the Shipments list UI.
- **Pre-flight GlobalTrade guard** (`FSHIPPING\Events\ShipmentGuard`) —
  new `fshipping_pre_ship_check` filter runs before
  `HTTP\Shipment::create_shipment` on every order. For international
  shipments it calls `GlobalTrade::check_compliance` and blocks the
  Ship call if FedEx returns any `prohibitions[]`. Non-blocking
  `documentsRequired[]` results in a merchant order note.
- **Modern Tracking client** (`FSHIPPING\HTTP\Tracking`) — batches up
  to 30 tracking numbers per call, extracts Signature Proof of
  Delivery image URL + Estimated Delivery Time Window + scan event
  timeline, caches per tracking number for 10 min, retries once on
  `TRACK.TRACKINGNUMBER.NOTFOUND` after a 2-second backoff. Persists
  SPOD / EDTW to shipment post-meta.
- **Status badge column** on the Shipments CPT list — colored pills
  for customs hold (red) / in-progress (amber) / delivered (green) /
  out-for-delivery (blue) / in-transit (indigo) / exception (red) /
  label-created (gray).
- **Notifications settings tab** — `fshipping_customs_alerts_enabled`
  (checkbox, default on) + `fshipping_customs_alert_email` (falls back
  to admin_email).
- **Checkbox field type** in `Dashboard\Settings::render_field()`.
- **Frontend shortcodes**: `[fshipping_track]` (tracking lookup) and
  `[fshipping_locations]` (drop-off finder).
- **Admin dashboard widget** listing the 10 most recent shipments + statuses.
- **"Request pickup" row action** on the Shipments CPT list.
- **Ajax address validation** on block checkout (residential-surcharge shield).
- Manual test recipes under `tests/manual/` — one per API client.
- Marketing payload: `marketing/landing-copy.md`, `marketing/keywords.md`,
  `marketing/launch-checklist.md`, `marketing/outreach-templates.md`.

### Changed
- Address Validation is now actively wired into checkout UX (classic and
  block checkout): debounced field-change validation + final submit-time
  validation call through `fshipping_validate_address`, with inline
  classification feedback.
- Checkout validation UX now shows an in-flight **"Validating address..."**
  state and ignores stale responses when users type quickly.
- Checkout validation now enforces required Address Validation fields
  (street/city/postal/country + state for US/CA) and shows inline guidance
  when fields are incomplete instead of sending partial requests.
- Checkout pre-validation now checks contact fields (first/last/email/phone)
  and surfaces field-level inline warnings; AJAX validation also runs FedEx
  postal-code verification to catch ZIP/country/state mismatches earlier.
- Hardened checkout validation AJAX path with server-side `try/catch` fallback
  so transient runtime errors return inline field warnings instead of a hard
  request-failed state.
- Admin menu cleanup: removed dedicated **Shipments Trash** submenu; use the
  standard list-table Trash filter/button inside Shipments.
- Extended `Dashboard\Settings` with the "Webhook" tab (AIV subscription URL
  + shared secret) and the "Freight" tab (9-digit freight account number).
- `Ajax` class now routes AIV webhook events from the REST receiver into
  per-shipment post-meta updates, so customer-facing tracking reads cached
  push data first and falls back to Basic Track only on miss.

### Added — Sprint A/B/C/D (full API catalog coverage)
- **End-of-Day Close** (`FSHIPPING\HTTP\ShipmentClose`) — generates the daily Ground manifest PDF that FedEx drivers scan at pickup. Persists the last manifest URL to `wp_option fshipping_last_close_manifest`.
- **Pre-flight Ship validation** (`FSHIPPING\HTTP\ShipmentValidate`) — checks a Ship payload via `/ship/v1/shipments/packages/validate` without burning a label.
- **Special services injector** (`FSHIPPING\Events\SpecialServicesInjector`) — hooks `fshipping_ship_payload` to inject specialServicesRequested blocks. Supports Saturday delivery, Signature (direct/adult/indirect/none), Dangerous Goods / Hazmat, Alcohol (auto-forces adult signature), Dry Ice (with KG weight), COD (amount + collection type), Hold-at-Location as delivery destination, and third-party billing.
- **Services settings tab** — plugin-wide defaults for Saturday delivery, signature option, and third-party billing account.
- **Ship payload filter hook** — `apply_filters('fshipping_ship_payload', $payload, $order, $current_shipment)` added to `HTTP\Shipment::prepare_shipment_payload` (one-line additive touch to the grandfathered file).
- **Tracking by reference / TCN / door tag** — three new methods on `HTTP\Tracking`: `by_reference($ref, $account)`, `by_tcn($tcn)`, `by_door_tag($dt, $postal_code, $country)`.
- **SPOD PDF download** — `HTTP\Tracking::download_spod($tn)` hits the dedicated SPOD endpoint and saves the PDF to `wp-content/uploads/fedex-spod/`.
- **MPS (multi-piece shipment) metadata** — `mps_is_master`, `mps_piece_count`, `mps_piece_seq`, `mps_master_tn` now extracted in every track response.
- **AIV list / modify subscription** — `HTTP\TrackingWebhook::list_subscriptions()` + `modify_subscription($id, $event_types)`.
- **Retrieve-by-id endpoints**:
  - `HTTP\ShipmentRetrieve::by_transaction_id($id)` — fetch a historical shipment.
  - `HTTP\Pickup::retrieve($confirmation_code)` — look up a scheduled pickup's state.
  - `HTTP\TradeDocuments::retrieve($document_id)` — re-download a customs document.
- **Open Ship async** — `HTTP\OpenShip::start_async($args)` + `retrieve_async_status($job_id)` for batches > 40 packages.
- **ETD paperless orchestrator** (`FSHIPPING\Events\ETDOrchestrator`) — stitches GlobalTrade → TradeDocuments → Ship into a paperless customs workflow on `woocommerce_checkout_order_processed` (opt-in via `_fshipping_etd_invoice_path` order meta).

### Submodule
- **`kit/`** now points at
  [`Teamz-Lab-LTD/team_wp_mvp_kit`](https://github.com/Teamz-Lab-LTD/team_wp_mvp_kit) —
  the shared core that future Teamz Lab WP plugins will all consume.
  Autoloader wired in `feedex-shipping.php` so `use Teamz\Wp\Kit\*` is
  already available. Migration from local duplicates onto the kit's
  base classes is tracked in `kit/docs/MIGRATION_FROM_FEDEX.md`.

### Notes
- No existing API client (`Authorization`, `HTTP\Shipment`, `HTTP\Shipping`)
  was refactored. All additions are new files.
- Any field or value marked `// TODO: verify against live sandbox` in code
  should be validated against FedEx sandbox before promoting to production.
