<?php
namespace FSHIPPING\Admin;

use FSHIPPING\SingletonTrait;

/**
 * ETD (Electronic Trade Documents) invoice-upload meta-box on the
 * order edit screen. Saves the uploaded PDF path to
 * `_fshipping_etd_invoice_path` so Events\ETDOrchestrator can pick
 * it up on checkout.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class EtdInvoiceMetaBox {
    use SingletonTrait;

    public function init() {
        add_action('add_meta_boxes',                     [$this, 'register']);
        add_action('save_post_shop_order',                [$this, 'save'], 10, 2);
        add_action('woocommerce_process_shop_order_meta', [$this, 'save_hpos'], 10, 2);
    }

    public function register() {
        add_meta_box(
            'fshipping_etd_invoice',
            __('FedEx ETD commercial invoice', 'teamzlab-fedex'),
            [$this, 'render'],
            ['shop_order', 'woocommerce_page_wc-orders'],
            'side',
            'default'
        );
    }

    public function render($post_or_order) {
        $order_id = is_object($post_or_order) && method_exists($post_or_order, 'get_id')
            ? (int) $post_or_order->get_id()
            : (int) ($post_or_order->ID ?? 0);

        wp_nonce_field('fshipping_etd_invoice', '_fshipping_etd_invoice_nonce');
        $current_path = (string) get_post_meta($order_id, '_fshipping_etd_invoice_path', true);
        $current_exists = !empty($current_path) && file_exists($current_path);
        ?>
        <p>
            <?php esc_html_e('Upload a commercial invoice PDF for international orders. FedEx will clear customs paperlessly.', 'teamzlab-fedex'); ?>
        </p>

        <?php if ($current_exists) : ?>
            <p>
                <strong><?php esc_html_e('Current invoice:', 'teamzlab-fedex'); ?></strong><br/>
                <code><?php echo esc_html(basename($current_path)); ?></code>
                <br/>
                <label>
                    <input type="checkbox" name="fshipping_etd_invoice_clear" value="1" />
                    <?php esc_html_e('Remove current invoice', 'teamzlab-fedex'); ?>
                </label>
            </p>
        <?php endif; ?>

        <p>
            <label for="fshipping_etd_invoice_file"><?php esc_html_e('Replace / upload:', 'teamzlab-fedex'); ?></label><br/>
            <input type="file" id="fshipping_etd_invoice_file" name="fshipping_etd_invoice_file" accept="application/pdf" />
        </p>
        <?php
    }

    public function save($post_id, $post = null) {
        if (empty($_POST['_fshipping_etd_invoice_nonce']) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_fshipping_etd_invoice_nonce'])), 'fshipping_etd_invoice') ||
            !current_user_can('edit_post', $post_id)) {
            return;
        }
        $this->persist((int) $post_id);
    }

    public function save_hpos($order_id, $order = null) {
        if (empty($_POST['_fshipping_etd_invoice_nonce']) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_fshipping_etd_invoice_nonce'])), 'fshipping_etd_invoice')) {
            return;
        }
        $this->persist((int) $order_id);
    }

    private function persist(int $order_id): void {
        // save()/save_hpos() already verified this nonce; re-check it in this scope
        // so every superglobal read below is nonce-verified.
        check_admin_referer('fshipping_etd_invoice', '_fshipping_etd_invoice_nonce');
        if (!empty($_POST['fshipping_etd_invoice_clear'])) {
            $existing = (string) get_post_meta($order_id, '_fshipping_etd_invoice_path', true);
            if (!empty($existing) && file_exists($existing)) {
                wp_delete_file($existing);
            }
            delete_post_meta($order_id, '_fshipping_etd_invoice_path');
        }

        if (empty($_FILES['fshipping_etd_invoice_file']['tmp_name'])) {
            return;
        }

        // Use WP's sideload flow for security.
        if (!function_exists('wp_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Raw $_FILES array is required by wp_handle_upload(), which validates and sanitizes the upload; non-PDF files are rejected above.
        $file = wp_unslash($_FILES['fshipping_etd_invoice_file']);
        if (empty($file['name']) || strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)) !== 'pdf') {
            return; // silently reject non-PDFs
        }

        $upload = wp_handle_upload($file, [
            'test_form' => false,
            'mimes'     => ['pdf' => 'application/pdf'],
        ]);

        if (empty($upload['file'])) {
            return;
        }

        update_post_meta($order_id, '_fshipping_etd_invoice_path', sanitize_text_field($upload['file']));
    }
}
