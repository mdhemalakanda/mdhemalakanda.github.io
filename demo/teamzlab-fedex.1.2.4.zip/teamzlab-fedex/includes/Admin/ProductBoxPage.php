<?php
namespace FSHIPPING\Admin;

use FSHIPPING\Boxing\BoxCatalog;
use FSHIPPING\SingletonTrait;

/**
 * FedEx -> Product Box admin page.
 *
 * @since 1.9
 */
defined('ABSPATH') || exit;

class ProductBoxPage
{
    use SingletonTrait;

    public const PAGE_SLUG = 'fshipping_product_box';
    public const NONCE = 'fshipping_product_box';

    /**
     * @return void
     */
    public function init()
    {
        add_action('admin_menu', [$this, 'register_menu'], 24);
        add_action('admin_post_fshipping_save_product_box', [$this, 'handle_save']);
    }

    /**
     * @return void
     */
    public function register_menu()
    {
        add_submenu_page(
            'fedex_shipping',
            __('Product Box', 'teamzlab-fedex'),
            __('Product Box', 'teamzlab-fedex'),
            'manage_options',
            self::PAGE_SLUG,
            [$this, 'render'],
            24
        );
    }

    /**
     * @return void
     */
    public function render()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $catalog = BoxCatalog::instance()->get();
        $boxes = isset($catalog['boxes']) && is_array($catalog['boxes']) ? $catalog['boxes'] : [];
        $weight_output_unit = isset($catalog['weight_output_unit']) ? (string) $catalog['weight_output_unit'] : 'KG';
        $dimension_unit = isset($catalog['dimension_unit']) ? (string) $catalog['dimension_unit'] : 'CM';
        $products = $this->get_product_options();
        ?>
        <div class="wrap fshipping-product-box-wrap">
            <div class="fshipping-page-header">
                <div class="fshipping-page-header__main">
                    <h1 class="fshipping-page-title">
                        <span class="dashicons dashicons-archive" aria-hidden="true"></span>
                        <?php esc_html_e('Product Box', 'teamzlab-fedex'); ?>
                    </h1>
                    <p class="fshipping-page-subtitle"><?php esc_html_e('Create box templates and map products with per-box capacity. Shipment payload packages will use these rules first, then fallback to default package logic for unmatched products.', 'teamzlab-fedex'); ?></p>
                </div>
            </div>

            <?php // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only "saved" flag echoed by this plugin's own redirect after the nonce-verified save handler runs; display only. ?>
            <?php if (!empty($_GET['updated'])) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e('Product Box settings saved.', 'teamzlab-fedex'); ?></p></div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="fshipping_save_product_box" />
                <?php wp_nonce_field(self::NONCE, '_fshipping_product_box_nonce'); ?>

                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Weight output unit', 'teamzlab-fedex'); ?></th>
                        <td>
                            <select name="weight_output_unit">
                                <option value="KG" <?php selected($weight_output_unit, 'KG'); ?>><?php esc_html_e('KG', 'teamzlab-fedex'); ?></option>
                                <option value="LB" <?php selected($weight_output_unit, 'LB'); ?>><?php esc_html_e('LB', 'teamzlab-fedex'); ?></option>
                            </select>
                            <p class="description"><?php esc_html_e('Product and empty-box weights are converted to this unit before package payload is built.', 'teamzlab-fedex'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Dimension unit', 'teamzlab-fedex'); ?></th>
                        <td>
                            <select name="dimension_unit">
                                <option value="CM" <?php selected($dimension_unit, 'CM'); ?>><?php esc_html_e('CM', 'teamzlab-fedex'); ?></option>
                                <option value="IN" <?php selected($dimension_unit, 'IN'); ?>><?php esc_html_e('IN', 'teamzlab-fedex'); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>

                <hr />
                <h2><?php esc_html_e('Boxes', 'teamzlab-fedex'); ?></h2>
                <div id="fshipping-product-box-list">
                    <?php
                    if (empty($boxes)) {
                        $this->render_box_card(0, [], $products, $dimension_unit);
                    } else {
                        foreach ($boxes as $index => $box) {
                            $this->render_box_card((int) $index, $box, $products, $dimension_unit);
                        }
                    }
                    ?>
                </div>

                <p>
                    <button type="button" class="button" id="fshipping-add-box"><?php esc_html_e('Add box', 'teamzlab-fedex'); ?></button>
                </p>
                <?php submit_button(__('Save Product Box', 'teamzlab-fedex')); ?>
            </form>
        </div>

        <script type="text/html" id="tmpl-fshipping-box-card">
            <?php $this->render_box_card(999999, [], $products, $dimension_unit, true); ?>
        </script>
        <script type="text/html" id="tmpl-fshipping-box-rule-row">
            <?php $this->render_rule_row(999999, 999999, [], $products, true); ?>
        </script>
        <?php
    }

    /**
     * @return void
     */
    public function handle_save()
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Unauthorized.', 'teamzlab-fedex'));
        }
        if (
            empty($_POST['_fshipping_product_box_nonce'])
            || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_fshipping_product_box_nonce'])), self::NONCE)
        ) {
            wp_die(esc_html__('Invalid request.', 'teamzlab-fedex'));
        }

        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Deeply nested array; every leaf value is sanitized individually below (absint, sanitize_key, sanitize_text_field, numeric casts).
        $raw_boxes = isset($_POST['boxes']) && is_array($_POST['boxes']) ? wp_unslash($_POST['boxes']) : [];
        $rows = [];
        foreach ($raw_boxes as $row) {
            if (!is_array($row)) {
                continue;
            }
            $rules = [];
            if (!empty($row['rules']) && is_array($row['rules'])) {
                foreach ($row['rules'] as $rule) {
                    if (!is_array($rule)) {
                        continue;
                    }
                    $rules[] = [
                        'product_id' => isset($rule['product_id']) ? absint($rule['product_id']) : 0,
                        'capacity_qty' => isset($rule['capacity_qty']) ? absint($rule['capacity_qty']) : 0,
                    ];
                }
            }

            $rows[] = [
                'id' => isset($row['id']) ? sanitize_key((string) $row['id']) : '',
                'name' => isset($row['name']) ? sanitize_text_field((string) $row['name']) : '',
                'preset' => isset($row['preset']) ? (string) $row['preset'] : '',
                'dimensions' => [
                    'length' => isset($row['length']) ? (float) $row['length'] : 0,
                    'width' => isset($row['width']) ? (float) $row['width'] : 0,
                    'height' => isset($row['height']) ? (float) $row['height'] : 0,
                    'units' => isset($row['dimension_unit']) ? strtoupper(sanitize_text_field((string) $row['dimension_unit'])) : 'CM',
                ],
                'empty_weight' => [
                    'value' => isset($row['empty_weight']) ? (float) $row['empty_weight'] : 0,
                    'unit' => isset($row['empty_weight_unit']) ? strtoupper(sanitize_text_field((string) $row['empty_weight_unit'])) : 'KG',
                ],
                'product_rules' => $rules,
            ];
        }

        $payload = [
            'weight_output_unit' => isset($_POST['weight_output_unit']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['weight_output_unit']))) : 'KG',
            'dimension_unit' => isset($_POST['dimension_unit']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['dimension_unit']))) : 'CM',
            'boxes' => $rows,
        ];
        BoxCatalog::instance()->save($payload);

        wp_safe_redirect(admin_url('admin.php?page=' . self::PAGE_SLUG . '&updated=1'));
        exit;
    }

    /**
     * @return array<int,array<string,mixed>>
     */
    private function get_product_options(): array
    {
        $items = [];
        if (!function_exists('wc_get_products')) {
            return $items;
        }
        $products = wc_get_products([
            'limit' => 500,
            'status' => 'publish',
            'return' => 'objects',
            'orderby' => 'title',
            'order' => 'ASC',
        ]);
        foreach ($products as $product) {
            if (!is_object($product) || !method_exists($product, 'get_id')) {
                continue;
            }
            $items[] = [
                'id' => (int) $product->get_id(),
                'text' => sprintf('#%d %s', (int) $product->get_id(), (string) $product->get_name()),
            ];
        }
        return $items;
    }

    /**
     * @param int   $box_index
     * @param array $box
     * @param array $products
     * @param string $default_dimension_unit
     * @param bool  $is_template
     * @return void
     */
    private function render_box_card(int $box_index, array $box, array $products, string $default_dimension_unit, bool $is_template = false)
    {
        $box_id = !empty($box['id']) ? (string) $box['id'] : '';
        $name = !empty($box['name']) ? (string) $box['name'] : '';
        $dimensions = isset($box['dimensions']) && is_array($box['dimensions']) ? $box['dimensions'] : [];
        $length = !empty($dimensions['length']) ? (float) $dimensions['length'] : '';
        $width = !empty($dimensions['width']) ? (float) $dimensions['width'] : '';
        $height = !empty($dimensions['height']) ? (float) $dimensions['height'] : '';
        $dim_unit = !empty($dimensions['units']) ? (string) $dimensions['units'] : $default_dimension_unit;
        $empty_weight = isset($box['empty_weight']) && is_array($box['empty_weight']) ? $box['empty_weight'] : [];
        $empty_weight_value = isset($empty_weight['value']) ? (float) $empty_weight['value'] : '';
        $empty_weight_unit = isset($empty_weight['unit']) ? (string) $empty_weight['unit'] : 'KG';
        $rules = isset($box['product_rules']) && is_array($box['product_rules']) ? $box['product_rules'] : [];
        $preset = isset($box['preset']) ? (string) $box['preset'] : '';
        ?>
        <div class="fshipping-box-card fshipping-box-collapsed <?php echo $is_template ? 'fshipping-template' : ''; ?>">
            <div class="fshipping-box-head">
                <button type="button" class="fshipping-box-toggle" aria-expanded="false">
                    <span class="fshipping-box-toggle-label"><?php esc_html_e('Box', 'teamzlab-fedex'); ?></span>
                </button>
                <button type="button" class="button-link-delete fshipping-remove-box"><?php esc_html_e('Remove box', 'teamzlab-fedex'); ?></button>
            </div>
            <div class="fshipping-box-body">
                <input type="hidden" name="boxes[<?php echo esc_attr((string) $box_index); ?>][id]" value="<?php echo esc_attr($box_id); ?>" />
                <table class="form-table">
                    <tr>
                        <th><label for="fshipping-box-preset-<?php echo esc_attr((string) $box_index); ?>"><?php esc_html_e('FedEx packaging', 'teamzlab-fedex'); ?></label></th>
                        <td>
                            <select class="fedex-select2 fshipping-box-preset" id="fshipping-box-preset-<?php echo esc_attr((string) $box_index); ?>" name="boxes[<?php echo esc_attr((string) $box_index); ?>][preset]">
                                <option value=""><?php esc_html_e('Custom (enter dimensions)', 'teamzlab-fedex'); ?></option>
                                <?php foreach (BoxCatalog::packaging_presets() as $preset_key => $preset_data) : ?>
                                    <option
                                        value="<?php echo esc_attr($preset_key); ?>"
                                        data-length="<?php echo esc_attr((string) $preset_data['length']); ?>"
                                        data-width="<?php echo esc_attr((string) $preset_data['width']); ?>"
                                        data-height="<?php echo esc_attr((string) $preset_data['height']); ?>"
                                        data-name="<?php echo esc_attr((string) $preset_data['label']); ?>"
                                        <?php selected($preset, $preset_key); ?>
                                    ><?php echo esc_html((string) $preset_data['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php esc_html_e('Pick a FedEx supply to auto-fill the dimensions below (converted to the selected unit).', 'teamzlab-fedex'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Name', 'teamzlab-fedex'); ?></th>
                        <td><input type="text" name="boxes[<?php echo esc_attr((string) $box_index); ?>][name]" value="<?php echo esc_attr($name); ?>" class="regular-text fshipping-box-name-field" /></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Dimensions', 'teamzlab-fedex'); ?></th>
                        <td class="fshipping-box-dimensions">
                            <input type="number" step="0.01" min="0" name="boxes[<?php echo esc_attr((string) $box_index); ?>][length]" value="<?php echo esc_attr((string) $length); ?>" placeholder="<?php esc_attr_e('Length', 'teamzlab-fedex'); ?>" />
                            <input type="number" step="0.01" min="0" name="boxes[<?php echo esc_attr((string) $box_index); ?>][width]" value="<?php echo esc_attr((string) $width); ?>" placeholder="<?php esc_attr_e('Width', 'teamzlab-fedex'); ?>" />
                            <input type="number" step="0.01" min="0" name="boxes[<?php echo esc_attr((string) $box_index); ?>][height]" value="<?php echo esc_attr((string) $height); ?>" placeholder="<?php esc_attr_e('Height', 'teamzlab-fedex'); ?>" />
                            <select name="boxes[<?php echo esc_attr((string) $box_index); ?>][dimension_unit]">
                                <option value="CM" <?php selected($dim_unit, 'CM'); ?>>CM</option>
                                <option value="IN" <?php selected($dim_unit, 'IN'); ?>>IN</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Empty box weight', 'teamzlab-fedex'); ?></th>
                        <td class="fshipping-box-weight">
                            <input type="number" step="0.001" min="0" name="boxes[<?php echo esc_attr((string) $box_index); ?>][empty_weight]" value="<?php echo esc_attr((string) $empty_weight_value); ?>" />
                            <select name="boxes[<?php echo esc_attr((string) $box_index); ?>][empty_weight_unit]">
                                <option value="KG" <?php selected($empty_weight_unit, 'KG'); ?>>KG</option>
                                <option value="LB" <?php selected($empty_weight_unit, 'LB'); ?>>LB</option>
                                <option value="OZ" <?php selected($empty_weight_unit, 'OZ'); ?>>OZ</option>
                                <option value="G" <?php selected($empty_weight_unit, 'G'); ?>>G</option>
                            </select>
                        </td>
                    </tr>
                </table>
                <h4><?php esc_html_e('Products and capacity', 'teamzlab-fedex'); ?></h4>
                <table class="widefat striped fshipping-box-rules-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Product', 'teamzlab-fedex'); ?></th>
                            <th><?php esc_html_e('Qty this box can hold', 'teamzlab-fedex'); ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (empty($rules)) {
                            $this->render_rule_row($box_index, 0, [], $products);
                        } else {
                            foreach ($rules as $rule_index => $rule) {
                                $this->render_rule_row($box_index, (int) $rule_index, is_array($rule) ? $rule : [], $products);
                            }
                        }
                        ?>
                    </tbody>
                </table>
                <p><button type="button" class="button fshipping-add-rule"><?php esc_html_e('Add product row', 'teamzlab-fedex'); ?></button></p>
            </div>
        </div>
        <?php
    }

    /**
     * @param int   $box_index
     * @param int   $rule_index
     * @param array $rule
     * @param array $products
     * @param bool  $is_template
     * @return void
     */
    private function render_rule_row(int $box_index, int $rule_index, array $rule, array $products, bool $is_template = false)
    {
        $product_id = isset($rule['product_id']) ? absint($rule['product_id']) : 0;
        $capacity_qty = isset($rule['capacity_qty']) ? absint($rule['capacity_qty']) : 1;
        ?>
        <tr class="<?php echo $is_template ? 'fshipping-template' : ''; ?>">
            <td>
                <select class="fedex-select2 fshipping-rule-product" name="boxes[<?php echo esc_attr((string) $box_index); ?>][rules][<?php echo esc_attr((string) $rule_index); ?>][product_id]" data-width="100%">
                    <option value=""><?php esc_html_e('Select product', 'teamzlab-fedex'); ?></option>
                    <?php foreach ($products as $product) : ?>
                        <?php
                        $pid = isset($product['id']) ? (int) $product['id'] : 0;
                        $text = isset($product['text']) ? (string) $product['text'] : '';
                        ?>
                        <option value="<?php echo esc_attr((string) $pid); ?>" <?php selected($product_id, $pid); ?>><?php echo esc_html($text); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td>
                <input type="number" min="1" step="1" name="boxes[<?php echo esc_attr((string) $box_index); ?>][rules][<?php echo esc_attr((string) $rule_index); ?>][capacity_qty]" value="<?php echo esc_attr((string) $capacity_qty); ?>" />
            </td>
            <td><button type="button" class="button-link-delete fshipping-remove-rule"><?php esc_html_e('Remove', 'teamzlab-fedex'); ?></button></td>
        </tr>
        <?php
    }
}

