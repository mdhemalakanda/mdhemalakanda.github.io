<?php
namespace FSHIPPING\Admin;

use FSHIPPING\SingletonTrait;

/**
 * Freight LTL accessorial options (liftgate, inside delivery, residential,
 * appointment, protect-from-freezing, limited access).
 *
 * Addresses the explicit Woo feature-request gap:
 *   "Add liftgate option for FedEx Freight when delivering to residential
 *    addresses" — plus the full set of LTL accessorials competitors bury
 *   inside support tickets.
 *
 * Produces the FedEx-spec `specialServicesRequested.specialServiceTypes[]`
 * fragment that `HTTP\FreightLTL` can splice into its outbound payload.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class FreightLTLExtras {
    use SingletonTrait;

    /**
     * The subset of FedEx Freight accessorial codes we surface in the UI.
     * Keep this list short and merchant-friendly.
     *
     * @return array<string,array{code:string,label:string,residential_only:bool,requires_appointment:bool}>
     * @since 1.2
     */
    public function catalog(): array {
        return [
            'liftgate_pickup'       => ['code' => 'LIFTGATE_PICKUP',        'label' => 'Liftgate at pickup',        'residential_only' => false, 'requires_appointment' => false],
            'liftgate_delivery'     => ['code' => 'LIFTGATE_DELIVERY',      'label' => 'Liftgate at delivery',      'residential_only' => false, 'requires_appointment' => false],
            'inside_pickup'         => ['code' => 'INSIDE_PICKUP',          'label' => 'Inside pickup',             'residential_only' => false, 'requires_appointment' => false],
            'inside_delivery'       => ['code' => 'INSIDE_DELIVERY',        'label' => 'Inside delivery',           'residential_only' => false, 'requires_appointment' => false],
            'residential_pickup'    => ['code' => 'RESIDENTIAL_PICKUP',     'label' => 'Residential pickup',        'residential_only' => true,  'requires_appointment' => false],
            'residential_delivery' => ['code' => 'RESIDENTIAL_DELIVERY',    'label' => 'Residential delivery',      'residential_only' => true,  'requires_appointment' => false],
            'appointment'           => ['code' => 'APPOINTMENT',            'label' => 'Delivery appointment',      'residential_only' => false, 'requires_appointment' => true],
            'limited_access_delivery' => ['code' => 'LIMITED_ACCESS_DELIVERY', 'label' => 'Limited access delivery','residential_only' => false, 'requires_appointment' => false],
            'protect_from_freezing' => ['code' => 'PROTECTION_FROM_FREEZING','label' => 'Protect from freezing',    'residential_only' => false, 'requires_appointment' => false],
        ];
    }

    /**
     * Validate + normalize a merchant-selected set of options.
     *
     * @param array $input        Either a flat array of slug strings, or a
     *                            key/bool map where truthy values mean selected.
     * @param bool  $is_residential Whether the delivery address is residential.
     * @return array{codes:array<int,string>,warnings:array<int,string>}
     * @since 1.2
     */
    public function normalize(array $input, bool $is_residential = false): array {
        $catalog   = $this->catalog();
        $selected  = $this->coerce_selected_slugs($input);
        $codes     = [];
        $warnings  = [];

        foreach ($selected as $slug) {
            if (!isset($catalog[$slug])) {
                $warnings[] = sprintf('Unknown accessorial "%s" ignored.', $slug);
                continue;
            }
            $entry = $catalog[$slug];
            if ($entry['residential_only'] && !$is_residential) {
                $warnings[] = sprintf('"%s" only applies to residential deliveries — skipped.', $entry['label']);
                continue;
            }
            $codes[] = $entry['code'];
        }

        // If merchant selected inside_delivery OR liftgate_delivery on a
        // residential address, auto-add residential_delivery (FedEx requires it).
        $delivery_codes = ['INSIDE_DELIVERY', 'LIFTGATE_DELIVERY'];
        if ($is_residential && array_intersect($delivery_codes, $codes) && !in_array('RESIDENTIAL_DELIVERY', $codes, true)) {
            $codes[] = 'RESIDENTIAL_DELIVERY';
        }

        return [
            'codes'    => array_values(array_unique($codes)),
            'warnings' => $warnings,
        ];
    }

    /**
     * Build the payload fragment to splice into FreightLTL requests.
     *
     * @param array<int,string> $codes Return value of normalize()['codes'].
     * @return array{specialServicesRequested:array{specialServiceTypes:array<int,string>}}|array{}
     * @since 1.2
     */
    public function payload_fragment(array $codes): array {
        $codes = array_values(array_filter($codes, static fn($c) => is_string($c) && $c !== ''));
        if (empty($codes)) {
            return [];
        }
        return [
            'specialServicesRequested' => [
                'specialServiceTypes' => $codes,
            ],
        ];
    }

    /**
     * @param array $input
     * @return array<int,string>
     * @since 1.2
     */
    private function coerce_selected_slugs(array $input): array {
        $slugs = [];
        foreach ($input as $key => $value) {
            if (is_int($key) && is_string($value)) {
                $slugs[] = $value;
                continue;
            }
            if (is_string($key) && $value) {
                $slugs[] = $key;
            }
        }
        return array_values(array_unique(array_map(
            static fn($s) => strtolower(trim($s)),
            $slugs
        )));
    }
}
