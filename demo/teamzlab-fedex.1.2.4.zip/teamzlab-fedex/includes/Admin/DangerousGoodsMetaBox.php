<?php
namespace FSHIPPING\Admin;

use FSHIPPING\Shipping\DangerousGoods;
use FSHIPPING\SingletonTrait;

/**
 * Per-order Dangerous Goods metabox on the WC order edit screen.
 *
 * UI that writes to `_fshipping_dg_spec` — the validated DG declaration
 * that Events\AdvancedServicesInjector reads when building the Ship +
 * Rates payload. Closes the "DangerousGoods class exists but no UI"
 * gap flagged in docs/GAP_AUDIT_2026-04-18.md.
 *
 * Merchants pick a DG kind (hazmat / dry ice / alcohol / lithium
 * battery), fill the required fields for that kind, and the backend
 * validator rejects incomplete submissions before they persist.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class DangerousGoodsMetaBox {
    use SingletonTrait;

    public const NONCE_ACTION = 'fshipping_dg_metabox';
    public const NONCE_FIELD  = '_fshipping_dg_nonce';

    public function init() {
        add_action('add_meta_boxes',                     [$this, 'register']);
        add_action('save_post_shop_order',               [$this, 'save'], 10, 2);
        add_action('woocommerce_process_shop_order_meta', [$this, 'save_hpos'], 10, 2);
    }

    public function register() {
        add_meta_box(
            'fshipping_dg',
            __('FedEx dangerous goods', 'teamzlab-fedex'),
            [$this, 'render'],
            ['shop_order', 'woocommerce_page_wc-orders'],
            'side',
            'default'
        );
    }

    /**
     * @param \WP_Post|\WC_Order $post_or_order
     * @return void
     */
    public function render($post_or_order) {
        $order_id = is_object($post_or_order) && method_exists($post_or_order, 'get_id')
            ? (int) $post_or_order->get_id()
            : (int) ($post_or_order->ID ?? 0);

        wp_nonce_field(self::NONCE_ACTION, self::NONCE_FIELD);

        $spec = get_post_meta($order_id, '_fshipping_dg_spec', true);
        $spec = is_array($spec) ? $spec : [];

        $current_kind = (string) ($spec['kind'] ?? '');
        $un_number    = (string) ($spec['un_number'] ?? '');
        $proper_name  = (string) ($spec['proper_name'] ?? '');
        $hazard_class = (string) ($spec['hazard_class'] ?? '');
        $packing      = (string) ($spec['packing_group'] ?? '');
        $net_weight   = (string) ($spec['net_weight'] ?? '');
        $net_unit     = (string) ($spec['net_weight_unit'] ?? 'KG');
        $quantity     = (string) ($spec['quantity'] ?? '1');
        ?>
        <p>
            <label for="fshipping_dg_kind"><strong><?php esc_html_e('Dangerous goods kind', 'teamzlab-fedex'); ?></strong></label>
            <select id="fshipping_dg_kind" name="fshipping_dg[kind]">
                <option value=""<?php selected($current_kind, ''); ?>><?php esc_html_e('— none —', 'teamzlab-fedex'); ?></option>
                <?php foreach (DangerousGoods::instance()->kinds() as $slug => $label) : ?>
                    <option value="<?php echo esc_attr($slug); ?>"<?php selected($current_kind, $slug); ?>><?php echo esc_html($label); ?></option>
                <?php endforeach; ?>
            </select>
        </p>
        <p>
            <label for="fshipping_dg_un"><?php esc_html_e('UN number (e.g. UN3480)', 'teamzlab-fedex'); ?></label>
            <input type="text" id="fshipping_dg_un" name="fshipping_dg[un_number]" value="<?php echo esc_attr($un_number); ?>" class="widefat" />
        </p>
        <p>
            <label for="fshipping_dg_name"><?php esc_html_e('Proper shipping name', 'teamzlab-fedex'); ?></label>
            <input type="text" id="fshipping_dg_name" name="fshipping_dg[proper_name]" value="<?php echo esc_attr($proper_name); ?>" class="widefat" />
        </p>
        <p>
            <label for="fshipping_dg_class"><?php esc_html_e('Hazard class', 'teamzlab-fedex'); ?></label>
            <input type="text" id="fshipping_dg_class" name="fshipping_dg[hazard_class]" value="<?php echo esc_attr($hazard_class); ?>" class="widefat" />
        </p>
        <p>
            <label for="fshipping_dg_packing"><?php esc_html_e('Packing group', 'teamzlab-fedex'); ?></label>
            <select id="fshipping_dg_packing" name="fshipping_dg[packing_group]">
                <option value=""   <?php selected($packing, '');   ?>><?php esc_html_e('—', 'teamzlab-fedex'); ?></option>
                <option value="I"  <?php selected($packing, 'I');  ?>>I</option>
                <option value="II" <?php selected($packing, 'II'); ?>>II</option>
                <option value="III"<?php selected($packing, 'III');?>>III</option>
            </select>
        </p>
        <p>
            <label for="fshipping_dg_weight"><?php esc_html_e('Net weight', 'teamzlab-fedex'); ?></label>
            <input type="number" step="0.01" id="fshipping_dg_weight" name="fshipping_dg[net_weight]" value="<?php echo esc_attr($net_weight); ?>" style="width: 60%;" />
            <select name="fshipping_dg[net_weight_unit]">
                <option value="KG"<?php selected($net_unit, 'KG'); ?>>KG</option>
                <option value="LB"<?php selected($net_unit, 'LB'); ?>>LB</option>
            </select>
        </p>
        <p>
            <label for="fshipping_dg_qty"><?php esc_html_e('Quantity', 'teamzlab-fedex'); ?></label>
            <input type="number" id="fshipping_dg_qty" name="fshipping_dg[quantity]" value="<?php echo esc_attr($quantity); ?>" min="0" style="width: 80px;" />
        </p>
        <p class="description">
            <?php esc_html_e('Leaving "kind" empty clears the DG declaration from this order.', 'teamzlab-fedex'); ?>
        </p>
        <?php
    }

    public function save($post_id, $post = null) {
        if (!$this->authorize()) {
            return;
        }
        if (!current_user_can('edit_post', (int) $post_id)) {
            return;
        }
        $this->persist((int) $post_id);
    }

    public function save_hpos($order_id, $order = null) {
        if (!$this->authorize()) {
            return;
        }
        $this->persist((int) $order_id);
    }

    private function authorize(): bool {
        return !empty($_POST[self::NONCE_FIELD]) &&
               wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::NONCE_FIELD])), self::NONCE_ACTION);
    }

    private function persist(int $order_id): void {
        // save()/save_hpos() already verified this nonce via authorize(); re-check it
        // in this scope so every superglobal read below is nonce-verified.
        check_admin_referer(self::NONCE_ACTION, self::NONCE_FIELD);
        $raw = isset($_POST['fshipping_dg']) && is_array($_POST['fshipping_dg']) ? array_map('sanitize_text_field', wp_unslash($_POST['fshipping_dg'])) : [];
        if (empty($raw['kind'])) {
            delete_post_meta($order_id, '_fshipping_dg_spec');
            return;
        }

        $result = DangerousGoods::instance()->validate($raw);
        if (empty($result['ok'])) {
            // Keep the raw data so the merchant sees it next render, but
            // don't persist the validated spec — AdvancedServicesInjector
            // only fires on valid specs.
            delete_post_meta($order_id, '_fshipping_dg_spec');
            return;
        }
        update_post_meta($order_id, '_fshipping_dg_spec', $result['data']);
    }
}
