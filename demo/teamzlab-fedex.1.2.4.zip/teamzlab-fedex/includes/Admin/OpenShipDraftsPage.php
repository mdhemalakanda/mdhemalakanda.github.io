<?php
namespace FSHIPPING\Admin;

use FSHIPPING\OpenShip\Draft;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\Helper;

/**
 * Fedex → Open Shipments — list Advanced Open Ship orders (search, lifecycle + stage filters, bulk/row actions, confirm JSON detail view).
 *
 * @since 1.3
 */
defined('ABSPATH') || exit;

class OpenShipDraftsPage {
    use SingletonTrait;

    public const PAGE_SLUG = 'fshipping_openship_drafts';

    /** @var bool */
    private static $menu_registered = false;

    public function init() {
        if (self::$menu_registered) {
            return;
        }
        self::$menu_registered = true;
        add_action('admin_menu', [$this, 'register_menu'], 15);
        add_action('admin_init', [$this, 'guard_openship_admin_page'], 1);
        add_action('admin_init', [$this, 'handle_row_action']);
        // Assets (select2, style.css, main.js, fshipping-openship-shipments.css) are enqueued
        // centrally in FSHIPPING\Assets — nothing is enqueued from this class.
        add_filter('set_screen_option_fshipping_openship_drafts_per_page', [$this, 'set_per_page_screen_option'], 10, 3);
    }

    /**
     * Block direct access to Open Shipments URLs when Shipping mode is not Advanced (menu is hidden then).
     *
     * @return void
     */
    public function guard_openship_admin_page(): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page slug context check to decide whether this admin screen needs guarding; no state change.
        if (!is_admin() || empty($_GET['page']) || (string) $_GET['page'] !== self::PAGE_SLUG) {
            return;
        }
        if (Helper::instance()->get_shipping_mode() === 'advanced') {
            return;
        }
        if (!current_user_can('edit_shop_orders')) {
            return;
        }
        wp_die(
            wp_kses_post(
                sprintf(
                    /* translators: %s: URL to FedEx plugin settings (Shipping tab). */
                    __('Open Shipments is available only when <strong>Shipping mode</strong> is set to <strong>Advanced</strong> under FedEx settings. <a href="%s">Open FedEx settings</a>.', 'teamzlab-fedex'),
                    esc_url(admin_url('admin.php?page=fedex_shipping'))
                )
            ),
            esc_html__('Open Shipments unavailable', 'teamzlab-fedex'),
            ['response' => 403]
        );
    }

    /**
     * Per-page screen option + capability check.
     *
     * Registered on the real `load-{hook}` suffix returned by add_submenu_page()
     * (see register_menu()) — the previously hardcoded hook never fired.
     * Assets are enqueued centrally in FSHIPPING\Assets; nothing is enqueued here.
     *
     * @return void
     */
    public function on_load_screen() {
        if (Helper::instance()->get_shipping_mode() !== 'advanced') {
            return;
        }
        if (!current_user_can('edit_shop_orders')) {
            return;
        }
        add_screen_option('per_page', [
            'label'   => __('Orders per page', 'teamzlab-fedex'),
            'default' => 20,
            'option'  => 'fshipping_openship_drafts_per_page',
        ]);
    }

    /**
     * @param mixed $keep
     * @param string $option
     * @param int    $value
     * @return int
     */
    public function set_per_page_screen_option($keep, $option, $value) {
        if ('fshipping_openship_drafts_per_page' === $option) {
            return max(1, (int) $value);
        }
        return $keep;
    }

    /**
     * Single-order actions from row links (GET + nonce).
     *
     * @return void
     */
    public function handle_row_action() {
        if (empty($_GET['page']) || (string) $_GET['page'] !== self::PAGE_SLUG) {
            return;
        }
        if (Helper::instance()->get_shipping_mode() !== 'advanced') {
            return;
        }
        if (empty($_GET['fshipping_os_action']) || empty($_GET['order_id']) || empty($_GET['_wpnonce'])) {
            return;
        }
        if (!current_user_can('edit_shop_orders')) {
            return;
        }

        $action = sanitize_key(wp_unslash($_GET['fshipping_os_action']));
        $oid    = (int) $_GET['order_id'];
        if ($oid < 1 || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'fshipping_os_row_' . $oid)) {
            return;
        }

        if (!in_array($action, ['fedex_delete', 'trash', 'trash_fedex', 'restore', 'delete_permanent'], true)) {
            return;
        }

        if ($action === 'trash' || $action === 'trash_fedex' || $action === 'delete_permanent') {
            if (!current_user_can('delete_shop_orders')) {
                $this->redirect_with_notice(__('You do not have permission to trash orders.', 'teamzlab-fedex'));
                return;
            }
        }

        $order = wc_get_order($oid);
        if (!$order || !Draft::is_advanced_order($order)) {
            $this->redirect_with_notice(__('Invalid order.', 'teamzlab-fedex'));
            return;
        }

        // Trashed orders: restore / delete permanently (WC-style).
        if ($action === 'restore' || $action === 'delete_permanent') {
            if ($order->get_status() !== 'trash') {
                $this->redirect_with_notice(__('That order is not in the trash.', 'teamzlab-fedex'), true);
                return;
            }
            if ('yes' === (string) $order->get_meta(Draft::META_CONFIRMED, true)) {
                $this->redirect_with_notice(__('Invalid order.', 'teamzlab-fedex'), true);
                return;
            }
            if ($action === 'restore') {
                if ($order->untrash()) {
                    $this->redirect_with_notice(__('Order restored from the trash.', 'teamzlab-fedex'));
                } else {
                    $this->redirect_with_notice(__('Could not restore the order.', 'teamzlab-fedex'), true);
                }
                return;
            }
            // Cancel FedEx Open Ship session first (PUT …/openshipments/delete when index exists), same as FedEx cancel + trash.
            $r = Draft::cancel_fedex_open_shipment_and_clear($order);
            if (empty($r['ok'])) {
                $this->redirect_with_notice((string) ($r['error'] ?? __('FedEx delete failed; order not removed.', 'teamzlab-fedex')), true);
                return;
            }
            $order = wc_get_order($oid);
            if (!$order || !Draft::is_advanced_order($order)) {
                $this->redirect_with_notice(__('Invalid order.', 'teamzlab-fedex'));
                return;
            }
            if ($order->delete(true)) {
                $this->redirect_with_notice(__('Order deleted permanently.', 'teamzlab-fedex'));
            } else {
                $this->redirect_with_notice(__('Could not delete the order permanently.', 'teamzlab-fedex'), true);
            }
            return;
        }

        if (Draft::is_locked($order)) {
            $this->redirect_with_notice(__('Invalid or locked order.', 'teamzlab-fedex'));
            return;
        }

        if ($action === 'fedex_delete') {
            $r = Draft::cancel_fedex_open_shipment_and_clear($order);
            if (!empty($r['ok'])) {
                $this->redirect_with_notice(__('FedEx Open Ship session cancelled and local data cleared.', 'teamzlab-fedex'));
            } else {
                $this->redirect_with_notice((string) ($r['error'] ?? __('FedEx delete failed.', 'teamzlab-fedex')), true);
            }
            return;
        }

        if ($action === 'trash_fedex') {
            $r = Draft::cancel_fedex_open_shipment_and_clear($order);
            if (empty($r['ok'])) {
                $this->redirect_with_notice((string) ($r['error'] ?? __('FedEx delete failed; order not trashed.', 'teamzlab-fedex')), true);
                return;
            }
            $order = wc_get_order($oid);
            if ($order && $order->delete(false)) {
                $this->redirect_with_notice(__('Order moved to trash (FedEx session cancelled first).', 'teamzlab-fedex'));
            } else {
                $this->redirect_with_notice(__('FedEx session cleared but the order could not be trashed.', 'teamzlab-fedex'), true);
            }
            return;
        }

        // trash (local only).
        if ($order->delete(false)) {
            $this->redirect_with_notice(__('Order moved to trash.', 'teamzlab-fedex'));
        } else {
            $this->redirect_with_notice(__('Could not trash the order.', 'teamzlab-fedex'), true);
        }
    }

    /**
     * @param string $message
     * @param bool   $error
     * @return void
     */
    /**
     * List URL preserving Trash tab when operating from that view.
     *
     * @return string
     */
    public static function base_list_url(): string {
        $url = admin_url('admin.php?page=' . self::PAGE_SLUG);
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only trash view flag preserved when building the list URL for redirects/links; sanitized, display only.
        if (isset($_REQUEST['fshipping_os_status']) && sanitize_key(wp_unslash($_REQUEST['fshipping_os_status'])) === 'trash') {
            $url = add_query_arg('fshipping_os_status', 'trash', $url);
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only lifecycle filter preserved when building the list URL for redirects/links; sanitized, display only.
        if (!empty($_REQUEST['fshipping_os_lifecycle'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only lifecycle filter preserved when building the list URL for redirects/links; sanitized, display only.
            $url = add_query_arg('fshipping_os_lifecycle', sanitize_key(wp_unslash($_REQUEST['fshipping_os_lifecycle'])), $url);
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only stage filter preserved when building the list URL for redirects/links; sanitized, display only.
        if (!empty($_REQUEST['fshipping_os_stage'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only stage filter preserved when building the list URL for redirects/links; sanitized, display only.
            $url = add_query_arg('fshipping_os_stage', sanitize_key(wp_unslash($_REQUEST['fshipping_os_stage'])), $url);
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search term preserved when building the list URL for redirects/links; sanitized, display only.
        if (!empty($_REQUEST['s'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search term preserved when building the list URL for redirects/links; sanitized, display only.
            $url = add_query_arg('s', sanitize_text_field(wp_unslash($_REQUEST['s'])), $url);
        }

        return $url;
    }

    private function redirect_with_notice(string $message, bool $error = false) {
        set_transient(
            'fshipping_openship_drafts_notice_' . get_current_user_id(),
            ['message' => $message, 'error' => $error],
            60
        );
        wp_safe_redirect(self::base_list_url());
        exit;
    }

    /**
     * @return void
     */
    public function register_menu() {
        if (Helper::instance()->get_shipping_mode() !== 'advanced') {
            return;
        }
        $hook = add_submenu_page(
            'fedex_shipping',
            __('Open Shipments', 'teamzlab-fedex'),
            __('Open Shipments', 'teamzlab-fedex'),
            'edit_shop_orders',
            self::PAGE_SLUG,
            [$this, 'render'],
            10
        );
        // Hook the real page-load suffix (parent menu is a custom top-level menu,
        // so the prefix cannot be hardcoded); used only for the per-page screen option.
        if (is_string($hook) && $hook !== '') {
            add_action('load-' . $hook, [$this, 'on_load_screen']);
        }
    }

    /**
     * @return void
     */
    public function render() {
        if (!current_user_can('edit_shop_orders')) {
            wp_die(esc_html__('You do not have permission to access this page.', 'teamzlab-fedex'));
        }
        if (Helper::instance()->get_shipping_mode() !== 'advanced') {
            wp_die(esc_html__('Open Shipments is only available in Advanced shipping mode.', 'teamzlab-fedex'));
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only context check to decide whether to render the shipment detail view; display only, no state change.
        if (!empty($_GET['fshipping_os_detail']) && !empty($_GET['order_id'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only order id for the read-only detail view; display-only, sanitized with an absint() cast.
            $this->render_shipment_detail((int) $_GET['order_id']);

            return;
        }

        $uid = get_current_user_id();
        $n   = get_transient('fshipping_openship_drafts_notice_' . $uid);
        if (is_array($n) && !empty($n['message'])) {
            delete_transient('fshipping_openship_drafts_notice_' . $uid);
            $class = !empty($n['error']) ? 'notice-error' : 'notice-success';
            printf(
                '<div class="notice %1$s is-dismissible"><p>%2$s</p></div>',
                esc_attr($class),
                esc_html((string) $n['message'])
            );
        } elseif (is_string($n) && $n !== '') {
            delete_transient('fshipping_openship_drafts_notice_' . $uid);
            printf(
                '<div class="notice notice-success is-dismissible"><p>%s</p></div>',
                esc_html($n)
            );
        }

        $table = new OpenShipDraftsListTable();
        $table->prepare_items();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only trash view flag persisted as a hidden input in the admin filter form; sanitized, display only.
        $is_trash = isset($_GET['fshipping_os_status']) && sanitize_key(wp_unslash($_GET['fshipping_os_status'])) === 'trash';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only stage filter persisted as a hidden input in the admin filter form; sanitized, display only.
        $stage     = isset($_GET['fshipping_os_stage']) ? sanitize_key(wp_unslash($_GET['fshipping_os_stage'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only lifecycle filter persisted as a hidden input in the admin filter form; sanitized, display only.
        $life      = isset($_GET['fshipping_os_lifecycle']) ? sanitize_key(wp_unslash($_GET['fshipping_os_lifecycle'])) : '';
        ?>
        <div class="wrap fshipping-os-shipments-list">
            <h1 class="wp-heading-inline"><?php esc_html_e('FedEx Open Shipments', 'teamzlab-fedex'); ?></h1>
            <hr class="wp-header-end" />
            <p class="fshipping-os-shipments-intro"><?php esc_html_e('All Advanced (Open Ship) orders in one place. Filter by shipment stage or lifecycle, then open an order to edit packages or confirm. For confirmed shipments, use “View FedEx details” to inspect the stored FedEx confirm response.', 'teamzlab-fedex'); ?></p>
            <?php $table->views(); ?>
            <form method="get">
                <input type="hidden" name="page" value="<?php echo esc_attr(self::PAGE_SLUG); ?>" />
                <?php if ($is_trash) : ?>
                    <input type="hidden" name="fshipping_os_status" value="trash" />
                <?php endif; ?>
                <?php if ($stage !== '') : ?>
                    <input type="hidden" name="fshipping_os_stage" value="<?php echo esc_attr($stage); ?>" />
                <?php endif; ?>
                <?php if ($life !== '') : ?>
                    <input type="hidden" name="fshipping_os_lifecycle" value="<?php echo esc_attr($life); ?>" />
                <?php endif; ?>
                <?php $table->search_box(__('Search orders', 'teamzlab-fedex'), 'fshipping-os-drafts'); ?>
                <?php $table->display(); ?>
            </form>
        </div>
        <?php
    }

    /**
     * Read-only admin view: last Open Ship confirm JSON + order context.
     *
     * @param int $order_id
     * @return void
     */
    private function render_shipment_detail(int $order_id): void {
        if (Helper::instance()->get_shipping_mode() !== 'advanced') {
            wp_die(esc_html__('Open Shipments is only available in Advanced shipping mode.', 'teamzlab-fedex'));
        }
        if ($order_id < 1) {
            wp_die(esc_html__('Invalid order.', 'teamzlab-fedex'));
        }
        $order = wc_get_order($order_id);
        if (!$order || !Draft::is_advanced_order($order)) {
            wp_die(esc_html__('This order was not found or is not an Open Shipments (Advanced) order.', 'teamzlab-fedex'));
        }

        $list_url = self::base_list_url();
        $edit_url  = $order->get_edit_order_url();

        $confirm_raw = (string) $order->get_meta(Draft::META_CONFIRM_RESPONSE, true);
        $confirm_arr = $confirm_raw !== '' ? json_decode($confirm_raw, true) : null;
        if (!is_array($confirm_arr)) {
            $confirm_arr = null;
        }

        $pkgs_raw = (string) $order->get_meta(Draft::META_PACKAGES_JSON, true);
        $pkgs_dec = $pkgs_raw !== '' ? json_decode($pkgs_raw, true) : null;
        if (!is_array($pkgs_dec)) {
            $pkgs_dec = null;
        }

        $labels_raw = (string) $order->get_meta(Draft::META_PACKAGE_LABEL_FILES, true);
        $labels_dec = $labels_raw !== '' ? json_decode($labels_raw, true) : null;
        if (!is_array($labels_dec)) {
            $labels_dec = [];
        }

        $merged_label = (string) $order->get_meta(Draft::META_MERGED_LABEL_FILE, true);
        $fedex_track  = (string) $order->get_meta('_fedex_tracking', true);
        $label_url    = (string) $order->get_meta('_fedex_label_url', true);
        $session_idx  = (string) $order->get_meta(Draft::META_SHIPMENT_INDEX, true);
        $session_mst  = (string) $order->get_meta(Draft::META_SHIPMENT_ID_INDEX, true);
        $life         = (string) $order->get_meta(Draft::META_LIFECYCLE, true);
        $confirmed    = (string) $order->get_meta(Draft::META_CONFIRMED, true);

        $json_pretty = $confirm_arr !== null
            ? wp_json_encode($confirm_arr, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
            : '';
        if (false === $json_pretty) {
            $json_pretty = $confirm_raw;
        }

        $pkgs_pretty = $pkgs_dec !== null
            ? wp_json_encode($pkgs_dec, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
            : '';
        if (false === $pkgs_pretty) {
            $pkgs_pretty = '';
        }

        $dc = $order->get_date_created();

        ?>
        <div class="wrap fshipping-os-shipment-detail">
            <h1 class="wp-heading-inline"><?php esc_html_e('Open Ship — FedEx shipment details', 'teamzlab-fedex'); ?></h1>
            <hr class="wp-header-end" />
            <div class="fshipping-os-detail-nav">
                <a href="<?php echo esc_url($list_url); ?>" class="button"><?php esc_html_e('← Back to Open Shipments', 'teamzlab-fedex'); ?></a>
                <a href="<?php echo esc_url($edit_url); ?>" class="button button-primary"><?php esc_html_e('Edit order', 'teamzlab-fedex'); ?></a>
            </div>

            <div class="fshipping-os-detail-summary">
                <h2><?php esc_html_e('Order summary', 'teamzlab-fedex'); ?></h2>
                <table class="widefat striped">
                    <tbody>
                        <tr><th><?php esc_html_e('Order', 'teamzlab-fedex'); ?></th><td><strong>#<?php echo esc_html((string) $order->get_order_number()); ?></strong> (ID <?php echo esc_html((string) $order->get_id()); ?>)</td></tr>
                        <tr><th><?php esc_html_e('Customer', 'teamzlab-fedex'); ?></th><td><?php echo esc_html(trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name())); ?><br /><span class="description"><?php echo esc_html($order->get_billing_email()); ?></span></td></tr>
                        <tr><th><?php esc_html_e('Date', 'teamzlab-fedex'); ?></th><td><?php echo $dc ? esc_html($dc->date_i18n(get_option('date_format') . ' ' . get_option('time_format'))) : '—'; ?></td></tr>
                        <tr><th><?php esc_html_e('Order status', 'teamzlab-fedex'); ?></th><td><?php echo esc_html(wc_get_order_status_name($order->get_status())); ?></td></tr>
                        <tr><th><?php esc_html_e('Open Ship lifecycle', 'teamzlab-fedex'); ?></th><td><code><?php echo esc_html($life !== '' ? $life : '—'); ?></code></td></tr>
                        <tr><th><?php esc_html_e('Confirmed with FedEx', 'teamzlab-fedex'); ?></th><td><?php echo 'yes' === $confirmed ? esc_html__('Yes', 'teamzlab-fedex') : esc_html__('No', 'teamzlab-fedex'); ?></td></tr>
                        <tr><th><?php esc_html_e('Master tracking', 'teamzlab-fedex'); ?></th><td><?php echo $fedex_track !== '' ? '<code>' . esc_html($fedex_track) . '</code>' : '—'; ?></td></tr>
                        <tr><th><?php esc_html_e('Primary label file (order)', 'teamzlab-fedex'); ?></th><td><?php echo $label_url !== '' ? '<a href="' . esc_url($label_url) . '" target="_blank" rel="noopener noreferrer">' . esc_html($label_url) . '</a>' : '—'; ?></td></tr>
                        <?php
                        $all_labels_href = Draft::best_all_labels_pdf_url($order);
                        ?>
                        <tr><th><?php esc_html_e('All labels (PDF)', 'teamzlab-fedex'); ?></th><td><?php
                        if ($all_labels_href !== '') {
                            echo '<a href="' . esc_url($all_labels_href) . '" class="button button-primary" target="_blank" rel="noopener noreferrer">'
                                . esc_html__('Download / open all labels (one PDF)', 'teamzlab-fedex') . '</a>';
                        } elseif ($labels_dec !== []) {
                            echo '<span class="description">' . esc_html__(
                                'FedEx returned separate PDFs per package. Use the saved label files table below.',
                                'teamzlab-fedex'
                            ) . '</span> <a href="#fshipping-os-saved-label-files">' . esc_html__('Jump to files', 'teamzlab-fedex') . '</a>';
                        } else {
                            echo '—';
                        }
                            ?></td></tr>
                        <tr><th><?php esc_html_e('Open Ship index', 'teamzlab-fedex'); ?></th><td><?php echo $session_idx !== '' ? '<code>' . esc_html($session_idx) . '</code>' : '—'; ?></td></tr>
                        <tr><th><?php esc_html_e('Master id / shipmentIdIndex', 'teamzlab-fedex'); ?></th><td><?php echo $session_mst !== '' ? '<code>' . esc_html($session_mst) . '</code>' : '—'; ?></td></tr>
                    </tbody>
                </table>
            </div>

            <?php if ($merged_label !== '' || $labels_dec !== []) : ?>
                <div class="fshipping-os-label-files" id="fshipping-os-saved-label-files">
                    <h2><?php esc_html_e('Saved label files', 'teamzlab-fedex'); ?></h2>
                    <?php if ($merged_label !== '') : ?>
                        <p><strong><?php esc_html_e('Merged PDF', 'teamzlab-fedex'); ?>:</strong>
                            <a href="<?php echo esc_url($merged_label); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($merged_label); ?></a></p>
                    <?php endif; ?>
                    <?php if ($labels_dec !== []) : ?>
                        <table class="widefat striped">
                            <thead><tr>
                                <th><?php esc_html_e('Seq.', 'teamzlab-fedex'); ?></th>
                                <th><?php esc_html_e('Tracking', 'teamzlab-fedex'); ?></th>
                                <th><?php esc_html_e('File URL', 'teamzlab-fedex'); ?></th>
                            </tr></thead>
                            <tbody>
                                <?php foreach ($labels_dec as $row) : ?>
                                    <?php
                                    if (!is_array($row)) {
                                        continue;
                                    }
                                    $seq = isset($row['sequence']) ? (int) $row['sequence'] : 0;
                                    $tr  = isset($row['tracking']) ? (string) $row['tracking'] : '';
                                    $fu  = isset($row['file_url']) ? (string) $row['file_url'] : '';
                                    ?>
                                    <tr>
                                        <td><?php echo esc_html((string) $seq); ?></td>
                                        <td><code><?php echo esc_html($tr); ?></code></td>
                                        <td><?php echo $fu !== '' ? '<a href="' . esc_url($fu) . '" target="_blank" rel="noopener noreferrer">' . esc_html($fu) . '</a>' : '—'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <details class="fshipping-os-json-panel fshipping-os-json-toggle">
                <summary class="fshipping-os-json-toggle-summary">
                    <?php esc_html_e('Last FedEx confirm response (full JSON)', 'teamzlab-fedex'); ?>
                </summary>
                <div class="fshipping-os-json-toggle-content">
                    <?php if ($json_pretty !== '') : ?>
                        <pre class="fshipping-os-json-block" id="fshipping-os-confirm-json"><?php echo esc_html($json_pretty); ?></pre>
                    <?php else : ?>
                        <p class="fshipping-os-json-empty"><?php esc_html_e('No confirm response is stored on this order yet. Confirm shipment from the order screen to capture the FedEx JSON here.', 'teamzlab-fedex'); ?></p>
                    <?php endif; ?>
                </div>
            </details>

            <?php if ($pkgs_pretty !== '') : ?>
                <div class="fshipping-os-json-panel">
                    <h2><?php esc_html_e('Packages saved on the order (JSON)', 'teamzlab-fedex'); ?></h2>
                    <pre class="fshipping-os-json-block"><?php echo esc_html($pkgs_pretty); ?></pre>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}
