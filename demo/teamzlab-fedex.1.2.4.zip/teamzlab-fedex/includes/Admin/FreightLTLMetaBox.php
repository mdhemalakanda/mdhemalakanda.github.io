<?php
namespace FSHIPPING\Admin;

use FSHIPPING\SingletonTrait;

/**
 * Per-order FedEx Freight LTL accessorials metabox.
 *
 * Surfaces liftgate / inside-delivery / appointment / limited-access
 * checkboxes on the WC order edit screen. Writes to
 * `_fshipping_ltl_extras` — the normalized output that
 * AdvancedServicesInjector reads when building the Ship + Rates payload.
 *
 * Directly closes the public Woo feature-request gap on liftgate for
 * residential FedEx Freight deliveries.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class FreightLTLMetaBox {
    use SingletonTrait;

    public const NONCE_ACTION = 'fshipping_ltl_metabox';
    public const NONCE_FIELD  = '_fshipping_ltl_nonce';

    public function init() {
        add_action('add_meta_boxes',                     [$this, 'register']);
        add_action('save_post_shop_order',               [$this, 'save'], 10, 2);
        add_action('woocommerce_process_shop_order_meta', [$this, 'save_hpos'], 10, 2);
    }

    public function register() {
        add_meta_box(
            'fshipping_ltl_extras',
            __('FedEx Freight accessorials', 'teamzlab-fedex'),
            [$this, 'render'],
            ['shop_order', 'woocommerce_page_wc-orders'],
            'side',
            'default'
        );
    }

    public function render($post_or_order) {
        $order_id = is_object($post_or_order) && method_exists($post_or_order, 'get_id')
            ? (int) $post_or_order->get_id()
            : (int) ($post_or_order->ID ?? 0);

        wp_nonce_field(self::NONCE_ACTION, self::NONCE_FIELD);

        $saved       = get_post_meta($order_id, '_fshipping_ltl_extras', true);
        $saved       = is_array($saved) ? $saved : [];
        $active_codes = is_array($saved['codes'] ?? null) ? array_map('strtoupper', $saved['codes']) : [];
        $residential = (bool) get_post_meta($order_id, '_fshipping_ltl_residential', true);

        $catalog = FreightLTLExtras::instance()->catalog();

        ?>
        <p>
            <label>
                <input type="checkbox" name="fshipping_ltl_residential" value="1"
                       <?php checked($residential); ?> />
                <?php esc_html_e('Residential delivery address', 'teamzlab-fedex'); ?>
            </label>
        </p>
        <?php foreach ($catalog as $slug => $entry) : ?>
            <p>
                <label>
                    <input type="checkbox" name="fshipping_ltl[<?php echo esc_attr($slug); ?>]" value="1"
                        <?php checked(in_array(strtoupper($entry['code']), $active_codes, true)); ?> />
                    <?php echo esc_html($entry['label']); ?>
                </label>
            </p>
        <?php endforeach; ?>
        <p class="description">
            <?php esc_html_e('Unchecking everything removes the LTL accessorials for this order.', 'teamzlab-fedex'); ?>
        </p>
        <?php
    }

    public function save($post_id, $post = null) {
        if (!$this->authorize()) {
            return;
        }
        if (!current_user_can('edit_post', (int) $post_id)) {
            return;
        }
        $this->persist((int) $post_id);
    }

    public function save_hpos($order_id, $order = null) {
        if (!$this->authorize()) {
            return;
        }
        $this->persist((int) $order_id);
    }

    private function authorize(): bool {
        return !empty($_POST[self::NONCE_FIELD]) &&
               wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::NONCE_FIELD])), self::NONCE_ACTION);
    }

    private function persist(int $order_id): void {
        // save()/save_hpos() already verified this nonce via authorize(); re-check it
        // in this scope so every superglobal read below is nonce-verified.
        check_admin_referer(self::NONCE_ACTION, self::NONCE_FIELD);
        $raw         = isset($_POST['fshipping_ltl']) && is_array($_POST['fshipping_ltl']) ? array_map('sanitize_text_field', wp_unslash($_POST['fshipping_ltl'])) : [];
        $residential = !empty($_POST['fshipping_ltl_residential']);

        update_post_meta($order_id, '_fshipping_ltl_residential', $residential ? 1 : 0);

        if (empty($raw)) {
            delete_post_meta($order_id, '_fshipping_ltl_extras');
            return;
        }

        $normalized = FreightLTLExtras::instance()->normalize($raw, $residential);
        if (empty($normalized['codes'])) {
            delete_post_meta($order_id, '_fshipping_ltl_extras');
            return;
        }
        update_post_meta($order_id, '_fshipping_ltl_extras', $normalized);
    }
}
