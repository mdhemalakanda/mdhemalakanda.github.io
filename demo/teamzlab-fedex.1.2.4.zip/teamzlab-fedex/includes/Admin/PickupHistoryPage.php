<?php
namespace FSHIPPING\Admin;

use FSHIPPING\SingletonTrait;

/**
 * Fedex -> Pickup history grouped event log.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class PickupHistoryPage {
    use SingletonTrait;

    public const PAGE_SLUG = 'fshipping_pickup_history';

    public function init() {
        add_action('admin_menu', [$this, 'register_menu']);
    }

    public function register_menu() {
        add_submenu_page(
            'fedex_shipping',
            __('Pickup History', 'teamzlab-fedex'),
            __('Pickup History', 'teamzlab-fedex'),
            'manage_options',
            self::PAGE_SLUG,
            [$this, 'render'],
            21
        );
    }

    public function render() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $records = get_option('fshipping_pickup_history', []);
        if (!is_array($records)) {
            $records = [];
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin filter form (search term); value is sanitized and only affects which rows are displayed, no state change.
        $search = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only admin filter form (status filter); value is sanitized and only affects which rows are displayed, no state change.
        $status = isset($_GET['status']) ? sanitize_key(wp_unslash($_GET['status'])) : '';
        $total_records = count($records);
        $records = $this->filter_records($records, $search, $status);
        $default_pickup_date = $this->default_pickup_date();
        ?>
        <div class="wrap fshipping-pickup-page">
            <div class="fshipping-page-header">
                <div class="fshipping-page-header__main">
                    <h1 class="fshipping-page-title">
                        <span class="dashicons dashicons-airplane" aria-hidden="true"></span>
                        <?php esc_html_e('FedEx Pickup History', 'teamzlab-fedex'); ?>
                    </h1>
                    <p class="fshipping-page-subtitle"><?php esc_html_e('Schedule FedEx pickups and review every request sent for this store (single + consolidated). Use it to audit which pickup covered which shipments and when.', 'teamzlab-fedex'); ?></p>
                </div>
                <div class="fshipping-page-header__aside">
                    <span class="fshipping-badge fshipping-badge--purple">
                        <?php
                        echo esc_html(sprintf(
                            /* translators: %s: number of pickup requests stored for this store. */
                            _n('%s pickup on record', '%s pickups on record', $total_records, 'teamzlab-fedex'),
                            number_format_i18n($total_records)
                        ));
                        ?>
                    </span>
                </div>
            </div>

            <div class="fshipping-card fshipping-pickup-card">
                <div class="fshipping-card__header">
                    <div>
                        <h2 class="fshipping-card__title"><?php esc_html_e('Schedule Global Pickup', 'teamzlab-fedex'); ?></h2>
                        <p class="fshipping-card__desc"><?php esc_html_e('Create one consolidated FedEx pickup for all ready shipments (published, has tracking, not canceled, no existing pickup confirmation).', 'teamzlab-fedex'); ?></p>
                    </div>
                </div>
                <div class="fshipping-card__body">
                    <div class="fshipping-pickup-card__row">
                        <div class="fshipping-pickup-card__field">
                            <label for="fshipping-pickup-date"><?php esc_html_e('Pickup date', 'teamzlab-fedex'); ?></label>
                            <input
                                type="date"
                                id="fshipping-pickup-date"
                                value="<?php echo esc_attr($default_pickup_date); ?>"
                                min="<?php echo esc_attr(gmdate('Y-m-d')); ?>"
                            />
                        </div>
                        <button type="button" class="button button-primary" id="fshipping-schedule-global-pickup">
                            <?php esc_html_e('Schedule pickup', 'teamzlab-fedex'); ?>
                        </button>
                        <span id="fshipping-pickup-schedule-status" class="description"></span>
                    </div>
                </div>
            </div>

            <form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>" class="fshipping-pickup-toolbar">
                <?php // Never send post_type= here: admin.php + post_type breaks get_plugin_page_hook() (Cannot load page). ?>
                <label class="screen-reader-text" for="fshipping-pickup-search"><?php esc_html_e('Search pickup history by confirmation or tracking number', 'teamzlab-fedex'); ?></label>
                <input
                    type="search"
                    id="fshipping-pickup-search"
                    name="s"
                    class="regular-text"
                    value="<?php echo esc_attr($search); ?>"
                    placeholder="<?php echo esc_attr(__('Confirmation/Tracking', 'teamzlab-fedex')); ?>"
                />
                <select name="status">
                    <option value=""><?php esc_html_e('All statuses', 'teamzlab-fedex'); ?></option>
                    <option value="scheduled" <?php selected($status, 'scheduled'); ?>><?php esc_html_e('Scheduled', 'teamzlab-fedex'); ?></option>
                    <option value="canceled" <?php selected($status, 'canceled'); ?>><?php esc_html_e('Canceled', 'teamzlab-fedex'); ?></option>
                </select>
                <button type="submit" class="button"><?php esc_html_e('Filter', 'teamzlab-fedex'); ?></button>
            </form>

            <?php if (empty($records)) : ?>
                <div class="fshipping-card">
                    <div class="fshipping-card__body">
                        <p class="fshipping-pickup-empty"><?php esc_html_e('No pickup history found yet.', 'teamzlab-fedex'); ?></p>
                    </div>
                </div>
            <?php else : ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Created (UTC)', 'teamzlab-fedex'); ?></th>
                            <th><?php esc_html_e('Confirmation', 'teamzlab-fedex'); ?></th>
                            <th><?php esc_html_e('Status', 'teamzlab-fedex'); ?></th>
                            <th><?php esc_html_e('Scope', 'teamzlab-fedex'); ?></th>
                            <th><?php esc_html_e('Shipments', 'teamzlab-fedex'); ?></th>
                            <th><?php esc_html_e('Tracking', 'teamzlab-fedex'); ?></th>
                            <th><?php esc_html_e('Ready', 'teamzlab-fedex'); ?></th>
                            <th><?php esc_html_e('Carrier', 'teamzlab-fedex'); ?></th>
                            <th><?php esc_html_e('Weight', 'teamzlab-fedex'); ?></th>
                            <th><?php esc_html_e('Actions', 'teamzlab-fedex'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($records as $row) : ?>
                            <?php
                            $history_row_id = (string) ($row['id'] ?? '');
                            $created_at = (string) ($row['created_at'] ?? '');
                            $confirmation = (string) ($row['confirmation'] ?? '');
                            $scope = (string) ($row['scope'] ?? '');
                            $status_label = (string) ($row['status'] ?? 'scheduled');
                            $shipment_ids = array_values(array_filter(array_map('intval', (array) ($row['shipment_ids'] ?? []))));
                            $tracking_numbers = array_values(array_filter(array_map('sanitize_text_field', (array) ($row['tracking_numbers'] ?? []))));
                            $count = (int) ($row['shipment_count'] ?? count($shipment_ids));
                            $ready = (string) ($row['ready'] ?? '');
                            $carrier = (string) ($row['carrier_code'] ?? '');
                            $weight = (float) ($row['weight'] ?? 0);
                            $weight_unit = (string) ($row['weight_unit'] ?? '');
                            $status_text = 'canceled' === strtolower($status_label)
                                ? sprintf(
                                    /* translators: %s is canceled date */
                                    __('Canceled (%s)', 'teamzlab-fedex'),
                                    (string) ($row['canceled_at'] ?? '')
                                )
                                : __('Scheduled', 'teamzlab-fedex');
                            $status_modifier = $this->status_badge_modifier($status_label);
                            ?>
                            <tr>
                                <td><?php echo esc_html($created_at); ?></td>
                                <td>
                                    <?php if ('' !== $confirmation) : ?>
                                        <span class="fshipping-pickup-confirmation"><?php echo esc_html($confirmation); ?></span>
                                    <?php else : ?>
                                        <span class="description">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="fshipping-status-badge<?php echo '' !== $status_modifier ? ' fshipping-status-badge--' . esc_attr($status_modifier) : ''; ?>">
                                        <?php echo esc_html($status_text); ?>
                                    </span>
                                </td>
                                <td><?php echo esc_html(strtoupper($scope ?: 'single')); ?></td>
                                <td>
                                    <?php echo esc_html((string) $count); ?>
                                    <?php if (!empty($shipment_ids)) : ?>
                                        <span class="fshipping-track-muted"><?php echo esc_html(implode(', ', $shipment_ids)); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html(!empty($tracking_numbers) ? implode(', ', $tracking_numbers) : '—'); ?></td>
                                <td><?php echo esc_html($ready ?: '—'); ?></td>
                                <td><?php echo esc_html($carrier ?: '—'); ?></td>
                                <td><?php echo esc_html($weight > 0 ? ((string) $weight . ' ' . $weight_unit) : '—'); ?></td>
                                <td>
                                    <?php if ('scheduled' === strtolower($status_label) && '' !== $confirmation && '' !== $history_row_id) : ?>
                                        <button
                                            type="button"
                                            class="button button-small button-danger fshipping-pickup-history-cancel"
                                            data-confirmation="<?php echo esc_attr($confirmation); ?>"
                                            data-history-id="<?php echo esc_attr($history_row_id); ?>"
                                        ><?php esc_html_e('Cancel pickup', 'teamzlab-fedex'); ?></button>
                                    <?php elseif ('canceled' === strtolower($status_label)) : ?>
                                        <span class="description"><?php esc_html_e('Canceled', 'teamzlab-fedex'); ?></span>
                                    <?php else : ?>
                                        <span class="description">—</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            <script>
            (function () {
                var ajaxUrl = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
                var nonce = <?php echo wp_json_encode(wp_create_nonce('fshipping_nonce')); ?>;
                var scheduleBtn = document.getElementById('fshipping-schedule-global-pickup');
                var pickupDateInput = document.getElementById('fshipping-pickup-date');
                var statusNode = document.getElementById('fshipping-pickup-schedule-status');

                function setStatus(msg) {
                    if (!statusNode) return;
                    statusNode.textContent = msg || '';
                }

                function postAjax(action, payload) {
                    var data = new FormData();
                    data.append('action', action);
                    data.append('nonce', nonce);
                    Object.keys(payload || {}).forEach(function (key) {
                        var value = payload[key];
                        if (Array.isArray(value)) {
                            value.forEach(function (v) { data.append(key + '[]', String(v)); });
                        } else if (value !== undefined && value !== null) {
                            data.append(key, String(value));
                        }
                    });
                    return fetch(ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' })
                        .then(function (r) { return r.json(); });
                }

                if (scheduleBtn) {
                    scheduleBtn.addEventListener('click', function () {
                        var pickupDate = pickupDateInput ? (pickupDateInput.value || '') : '';
                        if (!pickupDate) {
                            window.alert(<?php echo wp_json_encode(__('Select a pickup date first.', 'teamzlab-fedex')); ?>);
                            return;
                        }
                        scheduleBtn.disabled = true;
                        setStatus(<?php echo wp_json_encode(__('Loading ready shipments...', 'teamzlab-fedex')); ?>);

                        postAjax('fshipping_get_ready_pickups', {})
                            .then(function (res) {
                                if (!res || !res.success) {
                                    throw new Error((res && res.data && (res.data.fedex_error || res.data.message || res.data.error)) || 'ready_load_failed');
                                }
                                var shipments = (res.data && res.data.shipments) ? res.data.shipments : [];
                                if (!shipments.length) {
                                    throw new Error(<?php echo wp_json_encode(__('No ready shipments available for pickup.', 'teamzlab-fedex')); ?>);
                                }
                                var count = shipments.length;
                                var lines = shipments.slice(0, 12).map(function (row, idx) {
                                    var tracking = row && row.tracking_number ? row.tracking_number : 'N/A';
                                    return (idx + 1) + '. ' + tracking;
                                });
                                var summary = <?php echo wp_json_encode(__('Ready shipments:', 'teamzlab-fedex')); ?> + ' ' + count + '\n'
                                    + lines.join('\n')
                                    + (count > 12 ? '\n…' : '')
                                    + '\n\n<?php echo esc_js(__('Pickup date:', 'teamzlab-fedex')); ?> ' + pickupDate
                                    + '\n\n<?php echo esc_js(__('Create one consolidated FedEx pickup now?', 'teamzlab-fedex')); ?>';
                                if (!window.confirm(summary)) {
                                    throw new Error('__aborted__');
                                }
                                setStatus(<?php echo wp_json_encode(__('Scheduling pickup...', 'teamzlab-fedex')); ?>);
                                return postAjax('fshipping_request_pickup_batch', {
                                    shipment_ids: shipments.map(function (row) { return row.shipment_id; }),
                                    pickup_date: pickupDate
                                });
                            })
                            .then(function (res) {
                                if (!res || !res.success) {
                                    throw new Error((res && res.data && (res.data.fedex_error || res.data.message || res.data.error)) || 'pickup_failed');
                                }
                                var code = res && res.data ? (res.data.confirmation || '') : '';
                                setStatus('');
                                window.alert(code
                                    ? <?php echo wp_json_encode(__('Pickup scheduled. Confirmation:', 'teamzlab-fedex')); ?> + ' ' + code
                                    : <?php echo wp_json_encode(__('Pickup scheduled successfully.', 'teamzlab-fedex')); ?>);
                                window.location.reload();
                            })
                            .catch(function (err) {
                                if (err && err.message === '__aborted__') {
                                    setStatus('');
                                    return;
                                }
                                setStatus('');
                                window.alert((err && err.message) ? String(err.message) : 'Request failed');
                            })
                            .finally(function () {
                                scheduleBtn.disabled = false;
                            });
                    });
                }

                document.addEventListener('click', function (e) {
                    var btn = e.target.closest('.fshipping-pickup-history-cancel');
                    if (!btn) return;
                    e.preventDefault();
                    var confirmation = btn.getAttribute('data-confirmation') || '';
                    var historyId = btn.getAttribute('data-history-id') || '';
                    if (!confirmation || !historyId) return;
                    if (!window.confirm(<?php echo wp_json_encode(__('Cancel this scheduled FedEx pickup? This calls FedEx cancel and clears pickup data on linked shipments.', 'teamzlab-fedex')); ?>)) {
                        return;
                    }
                    btn.disabled = true;
                    var data = new FormData();
                    data.append('action', 'fshipping_cancel_pickup_by_confirmation');
                    data.append('nonce', nonce);
                    data.append('confirmation', confirmation);
                    data.append('history_id', historyId);
                    fetch(ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' })
                        .then(function (r) { return r.json(); })
                        .then(function (res) {
                            if (res && res.success) {
                                window.location.reload();
                                return;
                            }
                            var msg = (res && res.data && (res.data.fedex_error || res.data.message)) ? res.data.fedex_error || res.data.message : (res && res.data && res.data.error) || 'Cancel failed';
                            window.alert(String(msg));
                            btn.disabled = false;
                        })
                        .catch(function () {
                            window.alert('Request failed');
                            btn.disabled = false;
                        });
                });
            })();
            </script>
        </div>
        <?php
    }

    /**
     * Next business date (Mon-Fri) in UTC date format.
     *
     * @return string
     */
    private function default_pickup_date() {
        $timestamp = strtotime('+1 day');
        if (false === $timestamp) {
            return gmdate('Y-m-d');
        }
        while (in_array((int) gmdate('N', $timestamp), [6, 7], true)) {
            $timestamp = strtotime('+1 day', $timestamp);
            if (false === $timestamp) {
                return gmdate('Y-m-d');
            }
        }

        return gmdate('Y-m-d', $timestamp);
    }

    /**
     * Map a raw pickup history status string to a status badge modifier.
     *
     * Statuses are raw DB strings ('scheduled' / 'canceled' today); anything
     * unrecognized falls back to the neutral (unmodified) badge.
     *
     * @param string $status Raw status value.
     * @return string '' (neutral), 'ok', 'warn' or 'danger'.
     */
    private function status_badge_modifier($status) {
        $status = strtolower(trim((string) $status));

        if (in_array($status, ['completed', 'confirmed', 'success', 'succeeded'], true)) {
            return 'ok';
        }

        if (in_array($status, ['pending', 'queued', 'in-progress', 'in_progress', 'warning'], true)) {
            return 'warn';
        }

        if (in_array($status, ['canceled', 'cancelled', 'failed', 'error'], true)) {
            return 'danger';
        }

        return '';
    }

    /**
     * @param array  $records
     * @param string $search
     * @param string $status  '', 'scheduled', or 'canceled'
     * @return array
     */
    private function filter_records(array $records, $search, $status) {
        $out = [];
        $search = strtolower(trim((string) $search));
        $status = strtolower((string) $status);
        $tokens = $search !== '' ? preg_split('/[\s,]+/', $search, -1, PREG_SPLIT_NO_EMPTY) : [];

        foreach ($records as $row) {
            $row_status = strtolower((string) ($row['status'] ?? 'scheduled'));
            if ('' !== $status && $row_status !== $status) {
                continue;
            }

            if (!empty($tokens)) {
                $haystack = $this->row_search_haystack($row);
                foreach ($tokens as $token) {
                    if ('' === $token || false === strpos($haystack, $token)) {
                        continue 2;
                    }
                }
            }

            $out[] = $row;
        }

        return $out;
    }

    /**
     * Lowercased string for substring search: confirmation, tracking, shipment CPT ids,
     * linked WooCommerce order ids and order numbers.
     *
     * @param array $row Pickup history row.
     * @return string
     */
    private function row_search_haystack(array $row): string {
        $parts = [
            (string) ($row['confirmation'] ?? ''),
            implode(' ', (array) ($row['tracking_numbers'] ?? [])),
            implode(' ', array_map('strval', (array) ($row['shipment_ids'] ?? []))),
        ];

        foreach ((array) ($row['shipment_ids'] ?? []) as $shipment_id) {
            $shipment_id = (int) $shipment_id;
            if ($shipment_id <= 0) {
                continue;
            }
            $order_id = (int) get_post_meta($shipment_id, '_fedex_shipment_order_id', true);
            if ($order_id > 0) {
                $parts[] = (string) $order_id;
                if (function_exists('wc_get_order')) {
                    $order = wc_get_order($order_id);
                    if ($order) {
                        $parts[] = (string) $order->get_order_number();
                    }
                }
            }
        }

        return strtolower(implode(' ', array_filter(array_map('strval', $parts))));
    }
}
