<?php
namespace FSHIPPING\Admin;

use FSHIPPING\OpenShip\PackageLineExtras;

/**
 * Markup for optional FedEx RequestedPackageLineItem fields (accordion "Other information").
 */
defined('ABSPATH') || exit;

class OpenShipPackageExtrasMarkup {
    /**
     * @param array<string, mixed> $extras Sanitized `package_line_extras` or raw from DB.
     */
    public static function render_accordion(array $extras, int $box_index, string $default_currency): void {
        $e    = $extras;
        $bid  = 'fshipping-os-extras-' . $box_index;
        $pss  = isset($e['packageSpecialServices']) && is_array($e['packageSpecialServices']) ? $e['packageSpecialServices'] : [];
        $hasA = !empty($pss['specialServiceTypes']) && is_array($pss['specialServiceTypes'])
            && in_array('ALCOHOL', $pss['specialServiceTypes'], true);

        echo '<div class="fshipping-os-extras-accordion" data-box-index="' . esc_attr((string) $box_index) . '">';
        echo '<button type="button" class="button fshipping-os-extras-toggle" aria-expanded="false" aria-controls="' . esc_attr($bid) . '">';
        echo esc_html__('Other information', 'teamzlab-fedex');
        echo ' <span class="fshipping-os-extras-caret" aria-hidden="true">▸</span>';
        echo '</button>';
        echo '<div class="fshipping-os-package-extras" id="' . esc_attr($bid) . '" hidden>';

        echo '<p class="description fshipping-os-extras-intro">' . esc_html__('Optional FedEx Open Ship package fields. Leave blank to omit from the API request.', 'teamzlab-fedex') . '</p>';
        echo '<p class="description fshipping-os-extras-intro">' . esc_html__('“Sequence number” here is optional line-item data. FedEx assigns its own package sequence in the Add Package response — see “FedEx package sequence” above after a successful push.', 'teamzlab-fedex') . '</p>';

        // --- Identifiers
        self::extra_card_open(esc_html__('Identifiers', 'teamzlab-fedex'));
        $seq = isset($e['sequenceNumber']) ? (string) $e['sequenceNumber'] : '';
        self::field_row_inline(
            esc_html__('Sequence number (optional)', 'teamzlab-fedex'),
            '<input type="text" class="small-text fshipping-x-field" data-json-key="sequenceNumber" value="' . esc_attr($seq) . '" placeholder="' . esc_attr__('Auto if empty', 'teamzlab-fedex') . '" />'
        );
        $sub = isset($e['subPackagingType']) ? (string) $e['subPackagingType'] : '';
        ob_start();
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-x-field" data-json-key="subPackagingType" data-placeholder="' . esc_attr__('Select…', 'teamzlab-fedex') . '">';
        echo '<option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::SUBPACKAGING_TYPES as $opt) {
            echo '<option value="' . esc_attr($opt) . '"' . selected($sub, $opt, false) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select>';
        self::field_row_inline(esc_html__('Sub-packaging type', 'teamzlab-fedex'), ob_get_clean());

        $gpc = isset($e['groupPackageCount']) ? (int) $e['groupPackageCount'] : 0;
        self::field_row_inline(
            esc_html__('Group package count', 'teamzlab-fedex'),
            '<input type="number" min="1" class="small-text fshipping-x-field" data-json-key="groupPackageCount" value="' . esc_attr($gpc > 0 ? (string) $gpc : '') . '" />'
        );
        echo '<p class="description fshipping-os-field-hint">' . esc_html__('FedEx expects identical weight, dimensions, and commodities when using a group count.', 'teamzlab-fedex') . '</p>';
        self::extra_card_close();

        // --- Clearance
        self::extra_card_open(esc_html__('Clearance & descriptions', 'teamzlab-fedex'));
        $ifc = isset($e['itemDescriptionForClearance']) ? (string) $e['itemDescriptionForClearance'] : '';
        self::field_row_stack(
            esc_html__('Item description for clearance', 'teamzlab-fedex'),
            '<textarea class="widefat fshipping-x-field" data-json-key="itemDescriptionForClearance" rows="2">' . esc_textarea($ifc) . '</textarea>'
        );
        $idesc = isset($e['itemDescription']) ? (string) $e['itemDescription'] : '';
        self::field_row_stack(
            esc_html__('Item description (package)', 'teamzlab-fedex'),
            '<textarea class="widefat fshipping-x-field" data-json-key="itemDescription" rows="2">' . esc_textarea($idesc) . '</textarea>'
        );
        self::extra_card_close();

        // Content record
        self::extra_card_open(esc_html__('Content record', 'teamzlab-fedex'));
        $crs = isset($e['contentRecord']) && is_array($e['contentRecord']) ? $e['contentRecord'] : [];
        if ($crs === []) {
            $crs = [['itemNumber' => '', 'receivedQuantity' => '', 'partNumber' => '']];
        }
        echo '<table class="widefat fshipping-cr-table"><thead><tr>';
        echo '<th>' . esc_html__('Item / SKU', 'teamzlab-fedex') . '</th><th>' . esc_html__('Qty', 'teamzlab-fedex') . '</th>';
        echo '<th>' . esc_html__('Part #', 'teamzlab-fedex') . '</th><th class="fshipping-cr-actions"></th>';
        echo '</tr></thead><tbody class="fshipping-cr-tbody">';
        foreach ($crs as $cr) {
            if (!is_array($cr)) {
                $cr = [];
            }
            self::render_content_record_row(
                isset($cr['itemNumber']) ? (string) $cr['itemNumber'] : '',
                isset($cr['receivedQuantity']) ? (string) $cr['receivedQuantity'] : '',
                isset($cr['partNumber']) ? (string) $cr['partNumber'] : ''
            );
        }
        echo '<tr class="fshipping-cr-row fshipping-cr-template" hidden>';
        echo '<td><input type="text" class="small-text fshipping-cr-inum" value="" placeholder="' . esc_attr__('SKU or item id', 'teamzlab-fedex') . '" /></td>';
        echo '<td><input type="number" min="0" class="small-text fshipping-cr-qty" value="" /></td>';
        echo '<td><input type="text" class="regular-text fshipping-cr-part" value="" /></td>';
        echo '<td><button type="button" class="button-link fshipping-cr-remove" aria-label="' . esc_attr__('Remove row', 'teamzlab-fedex') . '">' . esc_html__('×', 'teamzlab-fedex') . '</button></td>';
        echo '</tr>';
        echo '</tbody></table>';
        echo '<p class="fshipping-os-card-actions"><button type="button" class="button button-small fshipping-cr-add">' . esc_html__('Add content row', 'teamzlab-fedex') . '</button></p>';
        self::extra_card_close();

        $vh = isset($e['variableHandlingChargeDetail']) && is_array($e['variableHandlingChargeDetail']) ? $e['variableHandlingChargeDetail'] : [];
        self::extra_card_open(esc_html__('Variable handling charge', 'teamzlab-fedex'));
        self::render_variable_handling($vh, $default_currency);
        self::extra_card_close();

        self::extra_card_open(esc_html__('Package special services', 'teamzlab-fedex'));
        self::render_package_special_services($pss, $hasA, $default_currency);
        self::extra_card_close();

        echo '</div></div>';
    }

    /**
     * @param array<string, mixed> $vh
     */
    private static function render_variable_handling(array $vh, string $default_currency): void {
        $rt = isset($vh['rateType']) ? (string) $vh['rateType'] : '';
        ob_start();
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-x-field" data-json-key="variableHandlingChargeDetail.rateType">';
        echo '<option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::VARIABLE_RATE_TYPES as $opt) {
            echo '<option value="' . esc_attr($opt) . '"' . selected($rt, $opt, false) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select>';
        self::field_row_inline(esc_html__('Rate type', 'teamzlab-fedex'), ob_get_clean());

        $pv = isset($vh['percentValue']) ? (float) $vh['percentValue'] : 0;
        self::field_row_inline(
            esc_html__('Percent value', 'teamzlab-fedex'),
            '<input type="number" step="0.01" class="small-text fshipping-x-field" data-json-key="variableHandlingChargeDetail.percentValue" value="' . esc_attr($pv > 0 ? (string) $pv : '') . '" />'
        );

        $rlt = isset($vh['rateLevelType']) ? (string) $vh['rateLevelType'] : '';
        ob_start();
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-x-field" data-json-key="variableHandlingChargeDetail.rateLevelType">';
        echo '<option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::VARIABLE_RATE_LEVEL_TYPES as $opt) {
            echo '<option value="' . esc_attr($opt) . '"' . selected($rlt, $opt, false) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select>';
        self::field_row_inline(esc_html__('Rate level type', 'teamzlab-fedex'), ob_get_clean());

        $fa = isset($vh['fixedValue']['amount']) ? (string) $vh['fixedValue']['amount'] : '';
        $fc = isset($vh['fixedValue']['currency']) ? (string) $vh['fixedValue']['currency'] : $default_currency;
        ob_start();
        echo '<span class="fshipping-os-inline-cluster">';
        echo '<input type="number" step="0.01" class="small-text fshipping-x-field" data-json-key="variableHandlingChargeDetail.fixedValue.amount" value="' . esc_attr($fa) . '" /> ';
        self::render_currency_select('variableHandlingChargeDetail.fixedValue.currency', $fc);
        echo '</span>';
        self::field_row_inline(esc_html__('Fixed amount', 'teamzlab-fedex'), ob_get_clean());

        $reb = isset($vh['rateElementBasis']) ? (string) $vh['rateElementBasis'] : '';
        ob_start();
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-x-field" data-json-key="variableHandlingChargeDetail.rateElementBasis">';
        echo '<option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::RATE_ELEMENT_BASIS as $opt) {
            echo '<option value="' . esc_attr($opt) . '"' . selected($reb, $opt, false) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select>';
        self::field_row_inline(esc_html__('Rate element basis', 'teamzlab-fedex'), ob_get_clean());
    }

    private static function render_currency_select(string $data_key, string $current): void {
        $codes = PackageLineExtras::get_currency_options();
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-os-s2-currency fshipping-x-field" data-json-key="' . esc_attr($data_key) . '">';
        foreach ($codes as $code => $label) {
            echo '<option value="' . esc_attr($code) . '"' . selected($current, $code, false) . '>' . esc_html($code . ' — ' . $label) . '</option>';
        }
        echo '</select>';
    }

    /**
     * @param array<string, mixed> $pss
     */
    private static function render_package_special_services(array $pss, bool $has_alcohol, string $default_currency): void {
        $sel = !empty($pss['specialServiceTypes']) && is_array($pss['specialServiceTypes']) ? $pss['specialServiceTypes'] : [];
        ob_start();
        echo '<select class="fedex-select2 fshipping-os-s2-wide fshipping-x-field" multiple="multiple" data-json-key="packageSpecialServices.specialServiceTypes" data-placeholder="' . esc_attr__('Select one or more', 'teamzlab-fedex') . '">';
        foreach (apply_filters('fshipping_openship_special_service_type_options', PackageLineExtras::SPECIAL_SERVICE_TYPES) as $opt) {
            $iss = in_array($opt, $sel, true);
            echo '<option value="' . esc_attr($opt) . '"' . ( $iss ? ' selected="selected"' : '' ) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select>';
        self::field_row_stack(esc_html__('Special service types', 'teamzlab-fedex'), ob_get_clean());

        $sig = isset($pss['signatureOptionType']) ? (string) $pss['signatureOptionType'] : '';
        ob_start();
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-x-field" data-json-key="packageSpecialServices.signatureOptionType">';
        echo '<option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::SIGNATURE_OPTION_TYPES as $opt) {
            echo '<option value="' . esc_attr($opt) . '"' . selected($sig, $opt, false) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select>';
        self::field_row_inline(esc_html__('Signature option', 'teamzlab-fedex'), ob_get_clean());

        self::inner_card_open(esc_html__('Priority alert', 'teamzlab-fedex'));
        $pad = isset($pss['priorityAlertDetail']) && is_array($pss['priorityAlertDetail']) ? $pss['priorityAlertDetail'] : [];
        $ets = !empty($pad['enhancementTypes']) && is_array($pad['enhancementTypes']) ? $pad['enhancementTypes'] : [''];
        echo '<p class="fshipping-os-inner-label">' . esc_html__('Enhancement types', 'teamzlab-fedex') . '</p>';
        echo '<ul class="fshipping-str-list" data-json-parent="packageSpecialServices.priorityAlertDetail.enhancementTypes">';
        foreach ($ets as $et) {
            echo '<li><input type="text" class="regular-text fshipping-x-str" value="' . esc_attr((string) $et) . '" placeholder="PRIORITY_ALERT_PLUS" /> ';
            echo '<button type="button" class="button button-small fshipping-str-remove">' . esc_html__('Remove', 'teamzlab-fedex') . '</button></li>';
        }
        echo '</ul><p class="fshipping-os-card-actions"><button type="button" class="button button-small fshipping-str-add" data-parent="packageSpecialServices.priorityAlertDetail.enhancementTypes">' . esc_html__('Add value', 'teamzlab-fedex') . '</button></p>';

        $cts = !empty($pad['content']) && is_array($pad['content']) ? $pad['content'] : [''];
        echo '<p class="fshipping-os-inner-label">' . esc_html__('Content strings', 'teamzlab-fedex') . '</p>';
        echo '<ul class="fshipping-str-list" data-json-parent="packageSpecialServices.priorityAlertDetail.content">';
        foreach ($cts as $c) {
            echo '<li><input type="text" class="large-text fshipping-x-str" value="' . esc_attr((string) $c) . '" /> ';
            echo '<button type="button" class="button button-small fshipping-str-remove">' . esc_html__('Remove', 'teamzlab-fedex') . '</button></li>';
        }
        echo '</ul><p class="fshipping-os-card-actions"><button type="button" class="button button-small fshipping-str-add" data-parent="packageSpecialServices.priorityAlertDetail.content">' . esc_html__('Add value', 'teamzlab-fedex') . '</button></p>';
        self::inner_card_close();

        $srn = isset($pss['signatureOptionDetail']['signatureReleaseNumber']) ? (string) $pss['signatureOptionDetail']['signatureReleaseNumber'] : '';
        self::field_row_inline(
            esc_html__('Signature release number', 'teamzlab-fedex'),
            '<input type="text" class="regular-text fshipping-x-field" data-json-key="packageSpecialServices.signatureOptionDetail.signatureReleaseNumber" value="' . esc_attr($srn) . '" />'
        );

        $ad = isset($pss['alcoholDetail']) && is_array($pss['alcoholDetail']) ? $pss['alcoholDetail'] : [];
        $art = isset($ad['alcoholRecipientType']) ? (string) $ad['alcoholRecipientType'] : '';
        $sat = isset($ad['shipperAgreementType']) ? (string) $ad['shipperAgreementType'] : '';
        echo '<div class="fshipping-pss-alcohol" ' . ( $has_alcohol ? '' : 'hidden' ) . '>';
        self::inner_card_open(esc_html__('Alcohol', 'teamzlab-fedex'));
        ob_start();
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-x-field" data-json-key="packageSpecialServices.alcoholDetail.alcoholRecipientType">';
        echo '<option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::ALCOHOL_RECIPIENT_TYPES as $opt) {
            echo '<option value="' . esc_attr($opt) . '"' . selected($art, $opt, false) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select>';
        self::field_row_inline(esc_html__('Alcohol recipient type', 'teamzlab-fedex'), ob_get_clean());
        self::field_row_inline(
            esc_html__('Shipper agreement type', 'teamzlab-fedex'),
            '<input type="text" class="regular-text fshipping-x-field" data-json-key="packageSpecialServices.alcoholDetail.shipperAgreementType" value="' . esc_attr($sat) . '" placeholder="' . esc_attr__('e.g. Retailer', 'teamzlab-fedex') . '" />'
        );
        self::inner_card_close();
        echo '</div>';

        $dg = isset($pss['dangerousGoodsDetail']) && is_array($pss['dangerousGoodsDetail']) ? $pss['dangerousGoodsDetail'] : [];
        $acc = isset($dg['accessibility']) ? (string) $dg['accessibility'] : '';
        $cao = isset($dg['cargoAircraftOnly']) ? (bool) $dg['cargoAircraftOnly'] : false;
        $reg = isset($dg['regulation']) ? (string) $dg['regulation'] : '';
        $dgo = !empty($dg['options']) && is_array($dg['options']) ? $dg['options'] : [];

        self::inner_card_open(esc_html__('Dangerous goods', 'teamzlab-fedex'));
        ob_start();
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-x-field" data-json-key="packageSpecialServices.dangerousGoodsDetail.accessibility">';
        echo '<option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::DG_ACCESSIBILITY as $opt) {
            echo '<option value="' . esc_attr($opt) . '"' . selected($acc, $opt, false) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select>';
        self::field_row_inline(esc_html__('Accessibility', 'teamzlab-fedex'), ob_get_clean());

        self::field_row_inline(
            esc_html__('Cargo aircraft only', 'teamzlab-fedex'),
            '<label class="fshipping-os-check"><input type="checkbox" class="fshipping-x-field" data-json-key="packageSpecialServices.dangerousGoodsDetail.cargoAircraftOnly" value="1" ' . checked($cao, true, false) . ' /> ' . esc_html__('Yes', 'teamzlab-fedex') . '</label>'
        );

        ob_start();
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-x-field" data-json-key="packageSpecialServices.dangerousGoodsDetail.regulation">';
        echo '<option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::DG_REGULATIONS as $opt) {
            echo '<option value="' . esc_attr($opt) . '"' . selected($reg, $opt, false) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select>';
        self::field_row_inline(esc_html__('Regulation', 'teamzlab-fedex'), ob_get_clean());

        ob_start();
        echo '<select class="fedex-select2 fshipping-os-s2-wide fshipping-x-field" multiple="multiple" data-json-key="packageSpecialServices.dangerousGoodsDetail.options" data-placeholder="' . esc_attr__('Select…', 'teamzlab-fedex') . '">';
        foreach (PackageLineExtras::DG_OPTIONS as $opt) {
            $idg = in_array($opt, $dgo, true);
            echo '<option value="' . esc_attr($opt) . '"' . ( $idg ? ' selected="selected"' : '' ) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select>';
        self::field_row_stack(esc_html__('DG options', 'teamzlab-fedex'), ob_get_clean());
        self::inner_card_close();

        $cod = isset($pss['packageCODDetail']['codCollectionAmount']) && is_array($pss['packageCODDetail']['codCollectionAmount'])
            ? $pss['packageCODDetail']['codCollectionAmount'] : [];
        $cAmt = isset($cod['amount']) ? (string) $cod['amount'] : '';
        $cCur = isset($cod['currency']) ? (string) $cod['currency'] : $default_currency;

        self::inner_card_open(esc_html__('COD', 'teamzlab-fedex'));
        ob_start();
        echo '<span class="fshipping-os-inline-cluster">';
        echo '<input type="number" step="0.01" class="small-text fshipping-x-field" data-json-key="packageSpecialServices.packageCODDetail.codCollectionAmount.amount" value="' . esc_attr($cAmt) . '" /> ';
        self::render_currency_select('packageSpecialServices.packageCODDetail.codCollectionAmount.currency', $cCur);
        echo '</span>';
        self::field_row_inline(esc_html__('Collection amount', 'teamzlab-fedex'), ob_get_clean());
        self::inner_card_close();

        $pcv = isset($pss['pieceCountVerificationBoxCount']) ? (int) $pss['pieceCountVerificationBoxCount'] : 0;
        self::field_row_inline(
            esc_html__('Piece count verification (boxes)', 'teamzlab-fedex'),
            '<input type="number" min="0" class="small-text fshipping-x-field" data-json-key="packageSpecialServices.pieceCountVerificationBoxCount" value="' . esc_attr((string) $pcv) . '" />'
        );

        $bds = !empty($pss['batteryDetails']) && is_array($pss['batteryDetails']) ? $pss['batteryDetails'] : [['batteryPackingType' => '', 'batteryRegulatoryType' => '', 'batteryMaterialType' => '']];
        self::inner_card_open(esc_html__('Battery details', 'teamzlab-fedex'));
        echo '<div class="fshipping-battery-rows">';
        foreach ($bds as $bd) {
            if (!is_array($bd)) {
                $bd = [];
            }
            self::render_battery_row(
                isset($bd['batteryPackingType']) ? (string) $bd['batteryPackingType'] : '',
                isset($bd['batteryRegulatoryType']) ? (string) $bd['batteryRegulatoryType'] : '',
                isset($bd['batteryMaterialType']) ? (string) $bd['batteryMaterialType'] : ''
            );
        }
        echo '<div class="fshipping-battery-row fshipping-battery-template fshipping-os-battery-card" hidden>';
        echo '<div class="fshipping-os-battery-card__head">';
        echo '<span class="fshipping-os-battery-card__title">' . esc_html__('Battery', 'teamzlab-fedex') . '</span>';
        echo '<button type="button" class="button button-small fshipping-battery-remove">' . esc_html__('Remove', 'teamzlab-fedex') . '</button>';
        echo '</div><div class="fshipping-os-battery-card__body">';
        self::render_battery_fields_inner();
        echo '</div></div>';
        echo '</div>';
        echo '<p class="fshipping-os-card-actions"><button type="button" class="button button-small fshipping-battery-add">' . esc_html__('Add battery row', 'teamzlab-fedex') . '</button></p>';
        self::inner_card_close();

        $di = isset($pss['dryIceWeight']) && is_array($pss['dryIceWeight']) ? $pss['dryIceWeight'] : [];
        $diu = isset($di['units']) ? (string) $di['units'] : 'KG';
        $div = isset($di['value']) ? (float) $di['value'] : 0;
        self::inner_card_open(esc_html__('Dry ice weight', 'teamzlab-fedex'));
        ob_start();
        echo '<span class="fshipping-os-inline-cluster">';
        echo '<select class="fshipping-x-field fshipping-os-select-native" data-json-key="packageSpecialServices.dryIceWeight.units">';
        foreach (PackageLineExtras::WEIGHT_UNITS as $u) {
            echo '<option value="' . esc_attr($u) . '"' . selected($diu, $u, false) . '>' . esc_html($u) . '</option>';
        }
        echo '</select> ';
        echo '<input type="number" step="0.01" class="small-text fshipping-x-field" data-json-key="packageSpecialServices.dryIceWeight.value" value="' . esc_attr($div > 0 ? (string) $div : '') . '" />';
        echo '</span>';
        self::field_row_inline(esc_html__('Units & value', 'teamzlab-fedex'), ob_get_clean());
        self::inner_card_close();

        $sbd = !empty($pss['standaloneBatteryDetails']) && is_array($pss['standaloneBatteryDetails']) ? $pss['standaloneBatteryDetails'] : [['batteryMaterialType' => '']];
        self::inner_card_open(esc_html__('Standalone batteries', 'teamzlab-fedex'));
        echo '<div class="fshipping-sbatt-rows">';
        foreach ($sbd as $sb) {
            if (!is_array($sb)) {
                $sb = [];
            }
            $bmt = isset($sb['batteryMaterialType']) ? (string) $sb['batteryMaterialType'] : '';
            echo '<div class="fshipping-sbatt-row fshipping-os-sbatt-card">';
            echo '<div class="fshipping-os-sbatt-card__body">';
            echo '<select class="fedex-select2 fshipping-os-s2 fshipping-sbatt-mt">';
            echo '<option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
            foreach (PackageLineExtras::BATTERY_MATERIAL_TYPES as $opt) {
                echo '<option value="' . esc_attr($opt) . '"' . selected($bmt, $opt, false) . '>' . esc_html($opt) . '</option>';
            }
            echo '</select>';
            echo '</div>';
            echo '<button type="button" class="button button-small fshipping-sbatt-remove">' . esc_html__('Remove', 'teamzlab-fedex') . '</button>';
            echo '</div>';
        }
        echo '</div>';
        echo '<p class="fshipping-os-card-actions"><button type="button" class="button button-small fshipping-sbatt-add">' . esc_html__('Add standalone battery', 'teamzlab-fedex') . '</button></p>';
        self::inner_card_close();
    }

    private static function render_battery_fields_inner(): void {
        echo '<div class="fshipping-os-battery-card__grid">';
        echo '<div class="fshipping-os-field fshipping-os-field--battery">';
        echo '<span class="fshipping-os-field__label">' . esc_html__('Packing type', 'teamzlab-fedex') . '</span>';
        echo '<span class="fshipping-os-field__control">';
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-b-bpt"><option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::BATTERY_PACKING_TYPES as $opt) {
            echo '<option value="' . esc_attr($opt) . '">' . esc_html($opt) . '</option>';
        }
        echo '</select></span></div>';
        echo '<div class="fshipping-os-field fshipping-os-field--battery">';
        echo '<span class="fshipping-os-field__label">' . esc_html__('Regulatory type', 'teamzlab-fedex') . '</span>';
        echo '<span class="fshipping-os-field__control"><input type="text" class="regular-text fshipping-b-brt" placeholder="IATA_SECTION_II" /></span></div>';
        echo '<div class="fshipping-os-field fshipping-os-field--battery">';
        echo '<span class="fshipping-os-field__label">' . esc_html__('Material type', 'teamzlab-fedex') . '</span>';
        echo '<span class="fshipping-os-field__control">';
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-b-bmt"><option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::BATTERY_MATERIAL_TYPES as $opt) {
            echo '<option value="' . esc_attr($opt) . '">' . esc_html($opt) . '</option>';
        }
        echo '</select></span></div>';
        echo '</div>';
    }

    private static function render_battery_row(string $bpt, string $brt, string $bmt): void {
        echo '<div class="fshipping-battery-row fshipping-os-battery-card">';
        echo '<div class="fshipping-os-battery-card__head">';
        echo '<span class="fshipping-os-battery-card__title">' . esc_html__('Battery', 'teamzlab-fedex') . '</span>';
        echo '<button type="button" class="button button-small fshipping-battery-remove">' . esc_html__('Remove', 'teamzlab-fedex') . '</button>';
        echo '</div>';
        echo '<div class="fshipping-os-battery-card__body">';
        echo '<div class="fshipping-os-battery-card__grid">';
        echo '<div class="fshipping-os-field fshipping-os-field--battery">';
        echo '<span class="fshipping-os-field__label">' . esc_html__('Packing type', 'teamzlab-fedex') . '</span>';
        echo '<span class="fshipping-os-field__control">';
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-b-bpt">';
        echo '<option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::BATTERY_PACKING_TYPES as $opt) {
            echo '<option value="' . esc_attr($opt) . '"' . selected($bpt, $opt, false) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select></span></div>';
        echo '<div class="fshipping-os-field fshipping-os-field--battery">';
        echo '<span class="fshipping-os-field__label">' . esc_html__('Regulatory type', 'teamzlab-fedex') . '</span>';
        echo '<span class="fshipping-os-field__control"><input type="text" class="regular-text fshipping-b-brt" value="' . esc_attr($brt) . '" placeholder="IATA_SECTION_II" /></span></div>';
        echo '<div class="fshipping-os-field fshipping-os-field--battery">';
        echo '<span class="fshipping-os-field__label">' . esc_html__('Material type', 'teamzlab-fedex') . '</span>';
        echo '<span class="fshipping-os-field__control">';
        echo '<select class="fedex-select2 fshipping-os-s2 fshipping-b-bmt">';
        echo '<option value="">' . esc_html__('—', 'teamzlab-fedex') . '</option>';
        foreach (PackageLineExtras::BATTERY_MATERIAL_TYPES as $opt) {
            echo '<option value="' . esc_attr($opt) . '"' . selected($bmt, $opt, false) . '>' . esc_html($opt) . '</option>';
        }
        echo '</select></span></div>';
        echo '</div></div></div>';
    }

    private static function render_content_record_row(string $inum, string $rqty, string $pnum): void {
        echo '<tr class="fshipping-cr-row">';
        echo '<td><input type="text" class="small-text fshipping-cr-inum" value="' . esc_attr($inum) . '" placeholder="' . esc_attr__('SKU or item id', 'teamzlab-fedex') . '" /></td>';
        echo '<td><input type="number" min="0" class="small-text fshipping-cr-qty" value="' . esc_attr($rqty) . '" /></td>';
        echo '<td><input type="text" class="regular-text fshipping-cr-part" value="' . esc_attr($pnum) . '" /></td>';
        echo '<td class="fshipping-cr-actions"><button type="button" class="button-link fshipping-cr-remove" aria-label="' . esc_attr__('Remove row', 'teamzlab-fedex') . '">' . esc_html__('×', 'teamzlab-fedex') . '</button></td>';
        echo '</tr>';
    }

    /**
     * @param string $title_html Already-escaped title markup (callers pass esc_html__() text).
     */
    private static function extra_card_open(string $title_html): void {
        echo '<section class="fshipping-os-extra-card">';
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $title_html is pre-escaped by every caller via esc_html__(); escaping again would double-encode entities like &amp;.
        echo '<h4 class="fshipping-os-extra-card__title">' . $title_html . '</h4>';
        echo '<div class="fshipping-os-extra-card__body">';
    }

    private static function extra_card_close(): void {
        echo '</div></section>';
    }

    /**
     * @param string $title_html Already-escaped title markup (callers pass esc_html__() text).
     */
    private static function inner_card_open(string $title_html): void {
        echo '<div class="fshipping-os-inner-card">';
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $title_html is pre-escaped by every caller via esc_html__(); escaping again would double-encode entities like &amp;.
        echo '<h5 class="fshipping-os-inner-card__title">' . $title_html . '</h5>';
        echo '<div class="fshipping-os-inner-card__body">';
    }

    private static function inner_card_close(): void {
        echo '</div></div>';
    }

    /**
     * @param string $label_html   Already-escaped label text (callers pass esc_html__() text).
     * @param string $control_html Already-escaped form-control markup built by this class (esc_attr/esc_textarea values).
     */
    private static function field_row_inline(string $label_html, string $control_html): void {
        echo '<div class="fshipping-os-field">';
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $label_html is pre-escaped by every caller via esc_html__(); escaping again would double-encode entities like &amp;.
        echo '<span class="fshipping-os-field__label">' . $label_html . '</span>';
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $control_html is fully escaped form markup (inputs/selects/textareas) built in this class; esc_html()/wp_kses_post() would break the controls and drop required data-* attributes.
        echo '<span class="fshipping-os-field__control">' . $control_html . '</span>';
        echo '</div>';
    }

    /**
     * @param string $label_html   Already-escaped label text (callers pass esc_html__() text).
     * @param string $control_html Already-escaped form-control markup built by this class (esc_attr/esc_textarea values).
     */
    private static function field_row_stack(string $label_html, string $control_html): void {
        echo '<div class="fshipping-os-field fshipping-os-field--stack">';
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $label_html is pre-escaped by every caller via esc_html__(); escaping again would double-encode entities like &amp;.
        echo '<span class="fshipping-os-field__label">' . $label_html . '</span>';
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $control_html is fully escaped form markup (inputs/selects/textareas) built in this class; esc_html()/wp_kses_post() would break the controls and drop required data-* attributes.
        echo '<div class="fshipping-os-field__control">' . $control_html . '</div>';
        echo '</div>';
    }
}
