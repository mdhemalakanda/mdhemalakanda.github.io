<?php
namespace FSHIPPING\Admin;

use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\OrderMeta;

/**
 * Per-order special-services meta box on the WC order edit screen.
 *
 * Checkboxes + fields that write to the `_fshipping_*` post-meta keys
 * that Events\SpecialServicesInjector already reads when building the
 * Ship payload. Closes the "no UI for per-order hazmat / alcohol /
 * COD" gap.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class SpecialServicesMetaBox {
    use SingletonTrait;

    public function init() {
        add_action('add_meta_boxes',     [$this, 'register']);
        add_action('save_post_shop_order', [$this, 'save'], 10, 2);
        // HPOS compatibility: the 'save_post_shop_order' also fires on
        // HPOS order CPT screens for legacy storage; for the real
        // HPOS order-edit screen we also hook on the WC-specific action.
        add_action('woocommerce_process_shop_order_meta', [$this, 'save_hpos'], 10, 2);
    }

    public function register() {
        add_meta_box(
            'fshipping_special_services',
            __('FedEx special services', 'teamzlab-fedex'),
            [$this, 'render'],
            ['shop_order', 'woocommerce_page_wc-orders'],
            'side',
            'default'
        );
    }

    /**
     * @param \WP_Post|\WC_Order $post_or_order
     * @return void
     */
    public function render($post_or_order) {
        $order_id = is_object($post_or_order) && method_exists($post_or_order, 'get_id')
            ? (int) $post_or_order->get_id()
            : (int) ($post_or_order->ID ?? 0);

        wp_nonce_field('fshipping_special_services', '_fshipping_special_services_nonce');

        $hazmat   = (string) OrderMeta::get($order_id, '_fshipping_hazmat');
        $alcohol  = (string) OrderMeta::get($order_id, '_fshipping_alcohol');
        $dry_ice  = (string) OrderMeta::get($order_id, '_fshipping_dry_ice');
        $di_weight = (string) OrderMeta::get($order_id, '_fshipping_dry_ice_weight');
        $cod_amt  = (string) OrderMeta::get($order_id, '_fshipping_cod_amount');
        $cod_type = (string) OrderMeta::get($order_id, '_fshipping_cod_type');
        $sig_opt  = (string) OrderMeta::get($order_id, '_fshipping_signature_option');
        $saturday = (string) OrderMeta::get($order_id, '_fshipping_saturday_delivery');
        $hal_id   = (string) OrderMeta::get($order_id, '_fshipping_hold_at_location_id');
        ?>
        <p>
            <label>
                <input type="checkbox" name="fshipping_saturday_delivery" value="1" <?php checked(!empty($saturday)); ?> />
                <?php esc_html_e('Saturday delivery', 'teamzlab-fedex'); ?>
            </label>
        </p>

        <p>
            <label for="fshipping_signature_option"><strong><?php esc_html_e('Signature option', 'teamzlab-fedex'); ?></strong></label><br/>
            <select id="fshipping_signature_option" name="fshipping_signature_option">
                <option value=""         <?php selected($sig_opt, '');         ?>><?php esc_html_e('Use default', 'teamzlab-fedex'); ?></option>
                <option value="NONE"     <?php selected($sig_opt, 'NONE');     ?>><?php esc_html_e('No signature', 'teamzlab-fedex'); ?></option>
                <option value="INDIRECT" <?php selected($sig_opt, 'INDIRECT'); ?>><?php esc_html_e('Indirect', 'teamzlab-fedex'); ?></option>
                <option value="DIRECT"   <?php selected($sig_opt, 'DIRECT');   ?>><?php esc_html_e('Direct', 'teamzlab-fedex'); ?></option>
                <option value="ADULT"    <?php selected($sig_opt, 'ADULT');    ?>><?php esc_html_e('Adult', 'teamzlab-fedex'); ?></option>
            </select>
        </p>

        <p>
            <label>
                <input type="checkbox" name="fshipping_hazmat" value="1" <?php checked(!empty($hazmat)); ?> />
                <?php esc_html_e('Hazardous materials (lithium batteries, chemicals, etc.)', 'teamzlab-fedex'); ?>
            </label>
        </p>

        <p>
            <label>
                <input type="checkbox" name="fshipping_alcohol" value="1" <?php checked(!empty($alcohol)); ?> />
                <?php esc_html_e('Alcohol (auto-forces adult signature)', 'teamzlab-fedex'); ?>
            </label>
        </p>

        <p>
            <label>
                <input type="checkbox" name="fshipping_dry_ice" value="1" <?php checked(!empty($dry_ice)); ?> />
                <?php esc_html_e('Dry ice', 'teamzlab-fedex'); ?>
            </label>
            <br/>
            <input type="number" step="0.1" min="0" name="fshipping_dry_ice_weight"
                   value="<?php echo esc_attr($di_weight); ?>" placeholder="<?php esc_attr_e('KG', 'teamzlab-fedex'); ?>"
                   style="width:7em;" />
            <small><?php esc_html_e('KG of dry ice', 'teamzlab-fedex'); ?></small>
        </p>

        <p>
            <label for="fshipping_cod_amount"><strong><?php esc_html_e('COD amount', 'teamzlab-fedex'); ?></strong></label><br/>
            <input type="number" step="0.01" min="0" id="fshipping_cod_amount" name="fshipping_cod_amount"
                   value="<?php echo esc_attr($cod_amt); ?>" placeholder="0.00" style="width:9em;" />
            <br/>
            <select name="fshipping_cod_type">
                <option value="ANY"               <?php selected($cod_type, 'ANY');               ?>><?php esc_html_e('Any payment', 'teamzlab-fedex'); ?></option>
                <option value="GUARANTEED_FUNDS"  <?php selected($cod_type, 'GUARANTEED_FUNDS');  ?>><?php esc_html_e('Guaranteed funds', 'teamzlab-fedex'); ?></option>
                <option value="CASH"              <?php selected($cod_type, 'CASH');              ?>><?php esc_html_e('Cash only', 'teamzlab-fedex'); ?></option>
            </select>
        </p>

        <p>
            <label for="fshipping_hold_at_location_id"><strong><?php esc_html_e('Hold at Location ID', 'teamzlab-fedex'); ?></strong></label><br/>
            <input type="text" id="fshipping_hold_at_location_id" name="fshipping_hold_at_location_id"
                   value="<?php echo esc_attr($hal_id); ?>" placeholder="<?php esc_attr_e('FedEx location id', 'teamzlab-fedex'); ?>" />
            <br/>
            <small><?php esc_html_e('Leave blank unless shipping to a FedEx Office for pickup.', 'teamzlab-fedex'); ?></small>
        </p>
        <?php
    }

    /**
     * @param int      $post_id
     * @param \WP_Post $post
     * @return void
     */
    public function save($post_id, $post = null) {
        if (empty($_POST['_fshipping_special_services_nonce']) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_fshipping_special_services_nonce'])), 'fshipping_special_services') ||
            !current_user_can('edit_post', $post_id)) {
            return;
        }
        $this->persist_meta((int) $post_id);
    }

    /**
     * @param int       $order_id
     * @param \WC_Order $order
     * @return void
     */
    public function save_hpos($order_id, $order = null) {
        if (empty($_POST['_fshipping_special_services_nonce']) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_fshipping_special_services_nonce'])), 'fshipping_special_services')) {
            return;
        }
        $this->persist_meta((int) $order_id);
    }

    private function persist_meta(int $order_id): void {
        // save()/save_hpos() already verified this nonce; re-check it in this scope
        // so every superglobal read below is nonce-verified.
        check_admin_referer('fshipping_special_services', '_fshipping_special_services_nonce');
        // HPOS-safe writes: Events\SpecialServicesInjector reads these keys via
        // WC_Order::get_meta(), so legacy post-meta writes were invisible to the
        // Ship payload on custom-order-table stores.
        $bool_fields = ['fshipping_saturday_delivery', 'fshipping_hazmat', 'fshipping_alcohol', 'fshipping_dry_ice'];
        foreach ($bool_fields as $key) {
            $val = !empty($_POST[$key]) ? '1' : '';
            OrderMeta::update($order_id, '_' . $key, $val);
        }
        OrderMeta::update($order_id, '_fshipping_signature_option',      sanitize_text_field(wp_unslash($_POST['fshipping_signature_option']      ?? '')));
        OrderMeta::update($order_id, '_fshipping_dry_ice_weight',        isset($_POST['fshipping_dry_ice_weight']) ? (float) sanitize_text_field(wp_unslash($_POST['fshipping_dry_ice_weight'])) : 0.0);
        OrderMeta::update($order_id, '_fshipping_cod_amount',            isset($_POST['fshipping_cod_amount']) ? (float) sanitize_text_field(wp_unslash($_POST['fshipping_cod_amount'])) : 0.0);
        OrderMeta::update($order_id, '_fshipping_cod_type',              sanitize_text_field(wp_unslash($_POST['fshipping_cod_type']              ?? '')));
        OrderMeta::update($order_id, '_fshipping_hold_at_location_id',   sanitize_text_field(wp_unslash($_POST['fshipping_hold_at_location_id']   ?? '')));
    }
}
