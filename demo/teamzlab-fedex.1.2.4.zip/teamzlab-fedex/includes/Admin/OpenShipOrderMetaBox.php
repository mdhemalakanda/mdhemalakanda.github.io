<?php
namespace FSHIPPING\Admin;

use FSHIPPING\OpenShip\Draft;
use FSHIPPING\OpenShip\PackageLineExtras;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\Helper;

/**
 * WooCommerce order — Open Ship draft packages + confirm (full admin UI).
 *
 * @since 1.3
 */
defined('ABSPATH') || exit;

class OpenShipOrderMetaBox {
    use SingletonTrait;

    public function init() {
        if (Helper::instance()->get_shipping_mode() !== 'advanced') {
            return;
        }
        add_action('add_meta_boxes', [$this, 'register'], 30);
        add_action('add_meta_boxes', [$this, 'maybe_remove_box'], 40);
        add_action('admin_enqueue_scripts', [$this, 'enqueue'], 10, 1);
    }

    /**
     * @return void
     */
    public function maybe_remove_box() {
        $order_id = 0;
        global $post;
        if ($post && isset($post->ID) && 'shop_order' === $post->post_type) {
            $order_id = (int) $post->ID;
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Context detection (order id) to decide whether to remove the meta box on this admin screen; display-only, sanitized with absint().
        } elseif (isset($_GET['id'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Context detection (order id) to decide whether to remove the meta box on this admin screen; display-only, sanitized with absint().
            $order_id = (int) $_GET['id'];
        }
        if ($order_id <= 0) {
            return;
        }
        $order = wc_get_order($order_id);
        if (!$order || !Draft::is_advanced_order($order)) {
            remove_meta_box('fshipping_openship_order', 'shop_order', 'normal');
            remove_meta_box('fshipping_openship_order', 'woocommerce_page_wc-orders', 'normal');
        }
    }

    /**
     * @param string $hook
     * @return void
     */
    public function enqueue($hook) {
        $order_id = 0;
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Context detection (order id) to decide which admin screen assets to enqueue; display-only, sanitized with absint().
        if ('post.php' === $hook && isset($_GET['post'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Context detection (order id) to decide which admin screen assets to enqueue; display-only, sanitized with absint().
            $order_id = (int) $_GET['post'];
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Context detection (page + order id) to decide which admin screen assets to enqueue; display-only, sanitized with absint().
        } elseif (isset($_GET['page'], $_GET['id']) && 'wc-orders' === $_GET['page']) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Context detection (order id) to decide which admin screen assets to enqueue; display-only, sanitized with absint().
            $order_id = (int) $_GET['id'];
        }
        if ($order_id <= 0) {
            return;
        }
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($screen && 'shop_order' !== $screen->id && 'woocommerce_page_wc-orders' !== $screen->id) {
            return;
        }
        $order = wc_get_order($order_id);
        if (!$order || !Draft::is_advanced_order($order)) {
            return;
        }
        wp_enqueue_style(
            'fshipping-select2',
            plugins_url('assets/admin/css/select2.css', FSHIPPING_FILE),
            [],
            '1.0.0'
        );
        wp_enqueue_script(
            'fshipping-select2-script',
            plugins_url('assets/admin/js/select2.js', FSHIPPING_FILE),
            ['jquery'],
            '1.0.0',
            true
        );
        wp_enqueue_style(
            'fshipping-openship-order',
            plugins_url('assets/admin/css/fshipping-openship-order.css', FSHIPPING_FILE),
            ['fshipping-select2'],
            '1.7.4'
        );
        wp_enqueue_script(
            'fshipping-openship-order',
            plugins_url('assets/admin/js/fshipping-openship-order.js', FSHIPPING_FILE),
            ['jquery', 'fshipping-select2-script'],
            '1.7.4',
            true
        );

        $h = Helper::instance();
        $currency_codes = PackageLineExtras::get_currency_options();
        $last_push_rows_raw = (string) $order->get_meta(Draft::META_LAST_PUSH_ROWS, true);
        $last_push_rows = $last_push_rows_raw !== '' ? json_decode($last_push_rows_raw, true) : [];
        if (!is_array($last_push_rows)) {
            $last_push_rows = [];
        }
        wp_localize_script('fshipping-openship-order', 'fshippingOpenShip', [
            'ajaxUrl'    => admin_url('admin-ajax.php'),
            'restUrl'    => esc_url_raw(rest_url('fshipping/v1/orders/' . (int) $order->get_id() . '/openship/push')),
            'restNonce'  => wp_create_nonce('wp_rest'),
            'nonce'      => wp_create_nonce('fshipping_openship'),
            'orderId'    => (int) $order->get_id(),
            'currencyCodes' => array_keys($currency_codes),
            'confirmed'  => Draft::is_locked($order),
            'lastPushRows' => $last_push_rows,
            'i18n'       => [
                'confirmFinalize'   => __('Finalize this Open Ship session and create labels?', 'teamzlab-fedex'),
                'confirmRestart'    => __('Start a new FedEx session with current settings and packages? A new session index will be created on FedEx.', 'teamzlab-fedex'),
                'confirmDeletePkg'  => __('Delete this package on FedEx? This cannot be undone.', 'teamzlab-fedex'),
                'confirmClearAll'   => __('Cancel the entire FedEx Open Ship session and clear package tracking on this order?', 'teamzlab-fedex'),
                'needOneBox'        => __('Add at least one package.', 'teamzlab-fedex'),
                'boxPrefix'         => __('Box', 'teamzlab-fedex'),
                'totalWeightPrefix' => __('Total weight (est. lb)', 'teamzlab-fedex') . ': ',
                'requestFailed'     => __('Request failed', 'teamzlab-fedex'),
                'success'           => __('Success', 'teamzlab-fedex'),
                'failed'            => __('Failed', 'teamzlab-fedex'),
                'saveRow'           => __('Save', 'teamzlab-fedex'),
                'editRow'           => __('Edit', 'teamzlab-fedex'),
                'deleteRow'         => __('Delete', 'teamzlab-fedex'),
                'lockedActions'     => __('Shipment confirmed — package actions disabled.', 'teamzlab-fedex'),
                'copyTxnId'         => __('Copy transaction ID', 'teamzlab-fedex'),
                'copiedTxn'         => __('Copied.', 'teamzlab-fedex'),
                'noTrackingActions' => __('No FedEx tracking number on this row yet. Run Save & push first.', 'teamzlab-fedex'),
            ],
        ]);
    }

    /**
     * @return void
     */
    public function register() {
        add_meta_box(
            'fshipping_openship_order',
            __('FedEx Open Ship', 'teamzlab-fedex'),
            [$this, 'render'],
            ['shop_order', 'woocommerce_page_wc-orders'],
            'normal',
            'high'
        );
    }

    /**
     * @param \WP_Post|\WC_Order $post_or_order
     * @return void
     */
    public function render($post_or_order) {
        $order = $post_or_order instanceof \WC_Order
            ? $post_or_order
            : (isset($post_or_order->ID) ? wc_get_order($post_or_order->ID) : null);
        if (!$order || !Draft::is_advanced_order($order)) {
            echo '<p class="description">' . esc_html__('Not an Advanced (Open Ship) order.', 'teamzlab-fedex') . '</p>';
            return;
        }

        $h            = Helper::instance();
        $index        = (string) $order->get_meta(Draft::META_SHIPMENT_INDEX, true);
        $id_index     = (string) $order->get_meta(Draft::META_SHIPMENT_ID_INDEX, true);
        $life         = (string) $order->get_meta(Draft::META_LIFECYCLE, true);
        $locked       = Draft::is_locked($order);
        $pkgs         = Draft::get_packages($order);
        $overrides = Draft::get_shipment_overrides($order);
        $fedex_line = Draft::get_fedex_shipping_line($order);
        if (empty($overrides['serviceType']) && $fedex_line && !empty($fedex_line['meta']['service_type'])) {
            $overrides['serviceType'] = (string) $fedex_line['meta']['service_type'];
        }
        $settings_opts = get_option('fshipping_options', []);
        if (empty($overrides['pickupType']) && !empty($settings_opts['fshipping_labeling_pickup_type'])) {
            $overrides['pickupType'] = (string) $settings_opts['fshipping_labeling_pickup_type'];
        }
        if (empty($overrides['packagingType']) && !empty($settings_opts['fshipping_labeling_packaging_type'])) {
            $overrides['packagingType'] = (string) $settings_opts['fshipping_labeling_packaging_type'];
        }
        if (empty($overrides['paymentType']) && !empty($settings_opts['fshipping_labeling_payment_type'])) {
            $overrides['paymentType'] = (string) $settings_opts['fshipping_labeling_payment_type'];
        }
        $wc_status    = $order->get_status();
        $tracking     = (string) $order->get_meta('_fedex_tracking', true);
        $label_order  = (string) $order->get_meta('_fedex_label_url', true);
        $ship_post_id = Draft::find_shipment_post_id_for_order($order->get_id());
        $label_cpt    = $ship_post_id ? (string) get_post_meta($ship_post_id, '_shipping_label', true) : '';

        if (empty($pkgs)) {
            $pkgs = Draft::packages_from_requested_shipment([]);
        }

        $service_opts   = $h->get_field_options('service_type');
        $pickup_opts    = $h->get_field_options('pickup_type');
        $packaging_opts = $h->get_field_options('packaging_type');
        $payment_opts   = $h->get_field_options('payment_type');
        $curr           = $order->get_currency() ?: 'USD';

        echo '<div class="fshipping-os-wrap">';

        $this->render_status_row($life, $locked, $wc_status, $tracking);
        echo '<div class="fshipping-os-alerts" id="fshipping-os-alerts" hidden></div>';

        if ($locked) {
            $this->render_locked_summary($order, $tracking, $label_order, $label_cpt, $ship_post_id);
            echo '</div>';

            return;
        }

        echo '<h4>' . esc_html__('Shipment settings', 'teamzlab-fedex') . '</h4>';
        echo '<p class="description">' . esc_html__('Changing service or pickup after checkout requires restarting the FedEx Open Ship session (new session index). Use “Restart FedEx session” after saving settings.', 'teamzlab-fedex') . '</p>';
        echo '<div class="fshipping-os-grid">';

        echo '<div><label for="fshipping-os-service">' . esc_html__('Service type', 'teamzlab-fedex') . '</label>';
        echo '<select id="fshipping-os-service" class="widefat">';
        foreach ($service_opts as $code => $lbl) {
            $sel = (!empty($overrides['serviceType']) ? $overrides['serviceType'] : '') === $code ? ' selected' : '';
            echo '<option value="' . esc_attr($code) . '"' . esc_attr($sel) . '>' . esc_html($lbl) . '</option>';
        }
        echo '</select></div>';

        echo '<div><label for="fshipping-os-pickup">' . esc_html__('Pickup type', 'teamzlab-fedex') . '</label>';
        echo '<select id="fshipping-os-pickup" class="widefat">';
        foreach ($pickup_opts as $code => $lbl) {
            $sel = (!empty($overrides['pickupType']) ? $overrides['pickupType'] : '') === $code ? ' selected' : '';
            echo '<option value="' . esc_attr($code) . '"' . esc_attr($sel) . '>' . esc_html($lbl . ' (' . $code . ')') . '</option>';
        }
        echo '</select></div>';

        echo '<div><label for="fshipping-os-packaging">' . esc_html__('Packaging type', 'teamzlab-fedex') . '</label>';
        echo '<select id="fshipping-os-packaging" class="widefat">';
        foreach ($packaging_opts as $code => $lbl) {
            $sel = (!empty($overrides['packagingType']) ? $overrides['packagingType'] : '') === $code ? ' selected' : '';
            echo '<option value="' . esc_attr($code) . '"' . esc_attr($sel) . '>' . esc_html($lbl) . '</option>';
        }
        echo '</select></div>';

        echo '<div><label for="fshipping-os-payment">' . esc_html__('Shipping charges (payor)', 'teamzlab-fedex') . '</label>';
        echo '<select id="fshipping-os-payment" class="widefat">';
        foreach ($payment_opts as $code => $lbl) {
            $sel = (!empty($overrides['paymentType']) ? $overrides['paymentType'] : '') === $code ? ' selected' : '';
            echo '<option value="' . esc_attr($code) . '"' . esc_attr($sel) . '>' . esc_html($lbl) . '</option>';
        }
        echo '</select></div>';

        echo '</div>';

        echo '<p><button type="button" class="button" id="fshipping-os-save-settings">' . esc_html__('Save shipment settings', 'teamzlab-fedex') . '</button></p>';

        echo '<h4>' . esc_html__('Session', 'teamzlab-fedex') . '</h4>';
        echo '<p><strong>' . esc_html__('Open Ship index (shipmentIndex)', 'teamzlab-fedex') . ':</strong> '
            . esc_html($index !== '' ? $index : '—');
        echo '<br /><strong>' . esc_html__('Master tracking (shipmentIdIndex)', 'teamzlab-fedex') . ':</strong> '
            . esc_html($id_index !== '' ? $id_index : '—');
        echo '<br /><strong>' . esc_html__('Lifecycle', 'teamzlab-fedex') . ':</strong> ' . esc_html($life !== '' ? $life : '—') . '</p>';

        echo '<h4>' . esc_html__('Packages', 'teamzlab-fedex') . '</h4>';
        echo '<div id="fshipping-os-boxes">';
        $bi = 0;
        foreach ($pkgs as $pkg) {
            $this->render_package_box($order, is_array($pkg) ? $pkg : [], $bi, $curr, $pkgs);
            ++$bi;
        }
        echo '</div>';
        echo '<p><button type="button" class="button" id="fshipping-os-add-box">' . esc_html__('Add box', 'teamzlab-fedex') . '</button>';
        echo ' <span class="fshipping-os-total-w" id="fshipping-os-total-w"></span></p>';

        echo '<div class="fshipping-os-actions">';
        echo '<button type="button" class="button button-primary" id="fshipping-os-save-push">' . esc_html__('Save & push to FedEx', 'teamzlab-fedex') . '</button> ';
        echo '<button type="button" class="button" id="fshipping-os-recalc">' . esc_html__('Recalculate total weight', 'teamzlab-fedex') . '</button> ';
        echo '<button type="button" class="button" id="fshipping-os-restart">' . esc_html__('Restart FedEx session', 'teamzlab-fedex') . '</button> ';
        echo '<button type="button" class="button" id="fshipping-os-clear-all-pkgs">' . esc_html__('Clear all packages (FedEx session)', 'teamzlab-fedex') . '</button> ';
        echo '<button type="button" class="button button-primary" id="fshipping-openship-confirm">' . esc_html__('Confirm shipment', 'teamzlab-fedex') . '</button>';
        echo '</div>';

        echo '<p class="description">' . esc_html__('Save & push updates the open shipment (PUT), then modifies or adds each package on FedEx. Clear all cancels the FedEx session (PUT delete). Confirm finalizes the session and creates labels.', 'teamzlab-fedex') . '</p>';

        echo '<div class="fshipping-os-push-results-wrap" id="fshipping-os-push-results-wrap" hidden>';
        echo '<h4>' . esc_html__('Last FedEx response (packages)', 'teamzlab-fedex') . '</h4>';
        echo '<table class="widefat striped fshipping-os-push-results" id="fshipping-os-push-results"><thead><tr>';
        echo '<th>' . esc_html__('Package #', 'teamzlab-fedex') . '</th>';
        echo '<th>' . esc_html__('Tracking #', 'teamzlab-fedex') . '</th>';
        echo '<th>' . esc_html__('Sequence', 'teamzlab-fedex') . '</th>';
        echo '<th>' . esc_html__('Status', 'teamzlab-fedex') . '</th>';
        echo '<th>' . esc_html__('Message', 'teamzlab-fedex') . '</th>';
        echo '<th>' . esc_html__('Transaction ID', 'teamzlab-fedex') . '</th>';
        echo '<th>' . esc_html__('Actions', 'teamzlab-fedex') . '</th>';
        echo '</tr></thead><tbody id="fshipping-os-push-results-body"></tbody></table>';
        echo '</div>';

        $pkg_meta_preview = (string) $order->get_meta(Draft::META_PACKAGE_LABEL_FILES, true);
        $merged_preview   = (string) $order->get_meta(Draft::META_MERGED_LABEL_FILE, true);
        if ($tracking || $label_order || $label_cpt || $pkg_meta_preview !== '' || $merged_preview !== '') {
            $this->render_label_block($order, $tracking, $label_order, $label_cpt, $ship_post_id, false);
        }

        $items_payload = [];
        foreach ($order->get_items() as $iid => $item) {
            if (!is_object($item) || !method_exists($item, 'get_quantity')) {
                continue;
            }
            $items_payload[] = [
                'order_item_id' => (int) $iid,
                'name'          => $item->get_name(),
                'max'           => (int) $item->get_quantity(),
            ];
        }
        echo '<script type="application/json" id="fshipping-os-order-items">' . wp_json_encode($items_payload) . '</script>';

        echo '</div>';
    }

    /**
     * @param \WC_Order $order
     * @param array<string, mixed> $pkg
     * @param int|string $box_index
     * @param string $currency
     * @param array<int, mixed> $all_pkgs All package rows (for per-box qty remaining).
     * @return void
     */
    private function render_package_box($order, array $pkg, $box_index, string $currency, array $all_pkgs = []): void {
        $name = isset($pkg['box_name']) ? (string) $pkg['box_name'] : sprintf(/* translators: %s: index */ __('Box %s', 'teamzlab-fedex'), (string) ((int) $box_index + 1));
        $w    = isset($pkg['weight']) ? (float) $pkg['weight'] : 1.0;
        $wu   = !empty($pkg['weight_unit']) && strtoupper((string) $pkg['weight_unit']) === 'KG' ? 'KG' : 'LB';
        $l    = isset($pkg['length']) ? (int) $pkg['length'] : 10;
        $wi   = isset($pkg['width']) ? (int) $pkg['width'] : 10;
        $h    = isset($pkg['height']) ? (int) $pkg['height'] : 10;
        $du   = !empty($pkg['dimension_unit']) && strtoupper((string) $pkg['dimension_unit']) === 'CM' ? 'CM' : 'IN';
        $dv   = isset($pkg['declared_value_amount']) ? (float) $pkg['declared_value_amount'] : 0.0;
        $dvc  = !empty($pkg['declared_value_currency']) ? (string) $pkg['declared_value_currency'] : $currency;
        $fedex = isset($pkg['fedex_package_id']) ? (string) $pkg['fedex_package_id'] : '';
        $fdel  = isset($pkg['fedex_delete_id']) ? (string) $pkg['fedex_delete_id'] : '';
        $fseq  = isset($pkg['fedex_sequence']) ? (string) $pkg['fedex_sequence'] : '';

        $idx = is_numeric($box_index) ? (int) $box_index : 0;
        echo '<div class="fshipping-os-box postbox" data-box-index="' . esc_attr((string) $idx) . '">';
        echo '<input type="hidden" class="fshipping-pkg-fedex-id" value="' . esc_attr($fedex) . '" />';
        echo '<input type="hidden" class="fshipping-pkg-fedex-del" value="' . esc_attr($fdel) . '" />';
        echo '<input type="hidden" class="fshipping-pkg-fedex-seq" value="' . esc_attr($fseq) . '" />';
        echo '<p class="fshipping-os-box-head"><strong>' . esc_html__('Package', 'teamzlab-fedex') . '</strong> ';
        echo '<button type="button" class="button-link fshipping-os-remove-box">' . esc_html__('Remove box', 'teamzlab-fedex') . '</button></p>';

        echo '<table class="widefat fshipping-os-pkg-table"><tbody>';
        echo '<tr><th>' . esc_html__('Name', 'teamzlab-fedex') . '</th><td><input type="text" class="widefat fshipping-pkg-name" value="' . esc_attr($name) . '" /></td></tr>';
        echo '<tr><th>' . esc_html__('Weight', 'teamzlab-fedex') . '</th><td>';
        echo '<input type="number" step="0.01" class="small-text fshipping-pkg-weight" value="' . esc_attr((string) $w) . '" /> ';
        echo '<select class="fshipping-pkg-wu">';
        echo '<option value="LB"' . selected($wu, 'LB', false) . '>LB</option>';
        echo '<option value="KG"' . selected($wu, 'KG', false) . '>KG</option>';
        echo '</select></td></tr>';
        echo '<tr><th>' . esc_html__('Dimensions (L×W×H)', 'teamzlab-fedex') . '</th><td>';
        echo '<input type="number" class="small-text fshipping-pkg-l" value="' . esc_attr((string) $l) . '" />×';
        echo '<input type="number" class="small-text fshipping-pkg-w" value="' . esc_attr((string) $wi) . '" />×';
        echo '<input type="number" class="small-text fshipping-pkg-h" value="' . esc_attr((string) $h) . '" /> ';
        echo '<select class="fshipping-pkg-du">';
        echo '<option value="IN"' . selected($du, 'IN', false) . '>IN</option>';
        echo '<option value="CM"' . selected($du, 'CM', false) . '>CM</option>';
        echo '</select></td></tr>';
        echo '<tr><th>' . esc_html__('Declared value (optional)', 'teamzlab-fedex') . '</th><td>';
        echo '<input type="number" step="0.01" class="small-text fshipping-pkg-dv" value="' . esc_attr($dv > 0 ? (string) $dv : '') . '" placeholder="0" /> ';
        echo '<input type="text" class="small-text fshipping-pkg-dvc" value="' . esc_attr($dvc) . '" maxlength="3" /> ';
        echo '</td></tr>';
        echo '<tr><th>' . esc_html__('FedEx package id', 'teamzlab-fedex') . '</th><td>';
        if ($fedex !== '') {
            $track_url = Draft::fedex_public_tracking_url($fedex);
            if ($track_url !== '') {
                echo '<a href="' . esc_url($track_url) . '" target="_blank" rel="noopener noreferrer" class="fshipping-pkg-fedex-link">';
                echo '<code class="fshipping-pkg-fedex">' . esc_html($fedex) . '</code></a>';
                echo ' <span class="description">' . esc_html__('Track on FedEx (new tab).', 'teamzlab-fedex') . '</span>';
            } else {
                echo '<code class="fshipping-pkg-fedex">' . esc_html($fedex) . '</code>';
            }
        } else {
            echo '<code class="fshipping-pkg-fedex">—</code>';
        }
        echo '</td></tr>';
        echo '<tr><th>' . esc_html__('FedEx package sequence', 'teamzlab-fedex') . '</th><td>';
        if ($fseq !== '') {
            echo '<code>' . esc_html($fseq) . '</code>';
            echo ' <span class="description">' . esc_html__('From Add Package response (packageSequenceNumber). Not the same as optional “Sequence number” in Other information.', 'teamzlab-fedex') . '</span>';
        } else {
            echo '<span class="description">—</span>';
        }
        echo '</td></tr>';
        echo '</tbody></table>';

        echo '<p class="fshipping-os-items"><strong>' . esc_html__('Products in this box', 'teamzlab-fedex') . '</strong></p>';
        echo '<table class="widefat striped fshipping-os-items-table"><thead><tr><th>' . esc_html__('Product', 'teamzlab-fedex') . '</th><th>' . esc_html__('Qty', 'teamzlab-fedex') . '</th></tr></thead><tbody>';
        $map = [];
        if (!empty($pkg['items']) && is_array($pkg['items'])) {
            foreach ($pkg['items'] as $it) {
                if (!empty($it['order_item_id'])) {
                    $map[(int) $it['order_item_id']] = (int) ($it['qty'] ?? 0);
                }
            }
        }
        $bi = is_numeric($box_index) ? (int) $box_index : 0;
        foreach ($order->get_items() as $iid => $item) {
            if (!is_object($item) || !method_exists($item, 'get_quantity')) {
                continue;
            }
            $line_max        = (int) $item->get_quantity();
            $used_elsewhere  = $this->sum_item_qty_in_other_boxes($all_pkgs, $bi, (int) $iid);
            $max_for_box     = max(0, $line_max - $used_elsewhere);
            $q               = (int) ($map[(int) $iid] ?? 0);
            if ($q > $max_for_box) {
                $q = $max_for_box;
            }
            echo '<tr><td>' . esc_html($item->get_name()) . '</td><td>';
            echo '<input type="number" min="0" max="' . esc_attr((string) $max_for_box) . '" class="small-text fshipping-box-item-qty" data-order-item-id="' . esc_attr((string) $iid) . '" data-order-line-qty="' . esc_attr((string) $line_max) . '" value="' . esc_attr((string) $q) . '" /> ';
            echo '<span class="fshipping-box-item-qty-hint">/ ' . esc_html((string) $line_max) . '</span>';
            echo '</td></tr>';
        }
        echo '</tbody></table>';

        $extras = isset($pkg['package_line_extras']) && is_array($pkg['package_line_extras']) ? $pkg['package_line_extras'] : [];
        OpenShipPackageExtrasMarkup::render_accordion($extras, $idx, $dvc);

        echo '</div>';
    }

    /**
     * Sum qty for an order line item across all package rows except the current box index.
     *
     * @param array<int, mixed> $all_pkgs
     */
    private function sum_item_qty_in_other_boxes(array $all_pkgs, int $current_box_index, int $order_item_id): int {
        $sum = 0;
        foreach ($all_pkgs as $idx => $op) {
            if ((int) $idx === $current_box_index || !is_array($op)) {
                continue;
            }
            if (empty($op['items']) || !is_array($op['items'])) {
                continue;
            }
            foreach ($op['items'] as $oit) {
                if (!is_array($oit) || empty($oit['order_item_id'])) {
                    continue;
                }
                if ((int) $oit['order_item_id'] !== $order_item_id) {
                    continue;
                }
                $sum += (int) ($oit['qty'] ?? 0);
            }
        }

        return $sum;
    }

    /**
     * @param string $life
     * @param bool   $locked
     * @param string $wc_status
     * @param string $tracking
     * @return void
     */
    private function render_status_row(string $life, bool $locked, string $wc_status, string $tracking): void {
        $labels = [
            __('Draft', 'teamzlab-fedex'),
            __('In progress', 'teamzlab-fedex'),
            __('Confirmed', 'teamzlab-fedex'),
            __('Shipped', 'teamzlab-fedex'),
            __('Delivered', 'teamzlab-fedex'),
        ];
        $step = 0;
        if ($life === Draft::LIFE_IN_PROGRESS) {
            $step = 1;
        }
        if ($locked || $life === Draft::LIFE_CONFIRMED) {
            $step = 2;
        }
        if ($tracking !== '' && in_array($wc_status, ['processing', 'on-hold'], true)) {
            $step = max($step, 3);
        }
        if ($wc_status === 'completed') {
            $step = 4;
        }

        echo '<ul class="fshipping-os-status">';
        foreach ($labels as $i => $label) {
            $cls = '';
            if ($i < $step) {
                $cls = 'is-done';
            } elseif ($i === $step) {
                $cls = 'is-active';
            }
            echo '<li class="' . esc_attr($cls) . '">' . esc_html($label) . '</li>';
        }
        echo '</ul>';
    }

    /**
     * @param \WC_Order $order
     * @param string $tracking
     * @param string $label_order
     * @param string $label_cpt
     * @param int $ship_post_id
     * @return void
     */
    private function render_locked_summary($order, string $tracking, string $label_order, string $label_cpt, int $ship_post_id): void {
        echo '<p class="description">' . esc_html__('Shipment confirmed — labels generated. Editing is locked.', 'teamzlab-fedex') . '</p>';
        $this->render_label_block($order, $tracking, $label_order, $label_cpt, $ship_post_id, true);
    }

    /**
     * @param \WC_Order $order
     * @param string    $tracking
     * @param string    $label_order
     * @param string    $label_cpt
     * @param int       $ship_post_id
     * @param bool      $locked
     * @return void
     */
    private function render_label_block(\WC_Order $order, string $tracking, string $label_order, string $label_cpt, int $ship_post_id, bool $locked): void {
        $pkg_raw = (string) $order->get_meta(Draft::META_PACKAGE_LABEL_FILES, true);
        $decoded = $pkg_raw !== '' ? json_decode($pkg_raw, true) : [];
        $pkg_list = is_array($decoded) ? $decoded : [];
        $merged_local = (string) $order->get_meta(Draft::META_MERGED_LABEL_FILE, true);

        echo '<div class="fshipping-os-label-row"><h4>' . esc_html__('Label & tracking', 'teamzlab-fedex') . '</h4>';
        if ($tracking !== '') {
            echo '<p><strong>' . esc_html__('Master tracking', 'teamzlab-fedex') . ':</strong> ';
            $turl = Draft::fedex_public_tracking_url($tracking);
            if ($turl !== '') {
                echo '<a href="' . esc_url($turl) . '" target="_blank" rel="noopener noreferrer"><code>' . esc_html($tracking) . '</code></a>';
            } else {
                echo '<code>' . esc_html($tracking) . '</code>';
            }
            echo '</p>';
        }

        $primary = $label_order !== '' ? $label_order : $label_cpt;

        if ($merged_local !== '') {
            echo '<p><a href="' . esc_url($merged_local) . '" class="button button-primary" target="_blank" rel="noopener noreferrer">'
                . esc_html__('Download merged labels (all packages, one PDF)', 'teamzlab-fedex') . '</a></p>';
        }

        if (count($pkg_list) > 1) {
            echo '<h5>' . esc_html__('Labels by package', 'teamzlab-fedex') . '</h5>';
            echo '<ul class="fshipping-os-per-piece-labels">';
            foreach ($pkg_list as $i => $row) {
                if (!is_array($row)) {
                    continue;
                }
                $t = isset($row['tracking']) ? (string) $row['tracking'] : '';
                $u = isset($row['file_url']) ? (string) $row['file_url'] : '';
                $seq = isset($row['sequence']) ? (int) $row['sequence'] : 0;
                if ($u === '') {
                    continue;
                }
                $box_label = $seq > 0
                    ? sprintf(/* translators: %d: FedEx package sequence */ esc_html__('Package %d', 'teamzlab-fedex'), $seq)
                    : sprintf(/* translators: %d: 1-based index */ esc_html__('Package %d', 'teamzlab-fedex'), (int) $i + 1);
                echo '<li><strong>' . esc_html($box_label) . '</strong>';
                if ($t !== '') {
                    echo ' — <code>' . esc_html($t) . '</code>';
                }
                echo ' <a href="' . esc_url($u) . '" class="button button-small" target="_blank" rel="noopener noreferrer">'
                    . esc_html__('PDF', 'teamzlab-fedex') . '</a></li>';
            }
            echo '</ul>';
        } elseif ($primary !== '' && count($pkg_list) <= 1 && ($merged_local === '' || $primary !== $merged_local)) {
            echo '<p><a href="' . esc_url($primary) . '" class="button" target="_blank" rel="noopener noreferrer">'
                . esc_html__('Download / open label (PDF)', 'teamzlab-fedex') . '</a></p>';
        }

        if ($ship_post_id > 0) {
            $shipment_view_url = add_query_arg(
                [
                    'page'                => OpenShipDraftsPage::PAGE_SLUG,
                    'fshipping_os_detail' => '1',
                    'order_id'            => (int) $order->get_id(),
                ],
                admin_url('admin.php')
            );
            echo '<p><a href="' . esc_url($shipment_view_url) . '" class="button">'
                . esc_html__('View shipment record', 'teamzlab-fedex') . '</a></p>';
        }

        if ($locked && ($primary !== '' || $merged_local !== '' || $pkg_list !== [])) {
            $is_local = ($primary !== '' && strpos($primary, '/fedex-labels/') !== false)
                || $merged_local !== ''
                || $pkg_list !== [];
            if ($is_local || $merged_local !== '' || $pkg_list !== []) {
                echo '<p class="description">' . esc_html__(
                    'Label PDFs above are stored under Media → Uploads (fedex-labels). Reprint anytime from this screen.',
                    'teamzlab-fedex'
                ) . '</p>';
            } else {
                echo '<p class="description">' . esc_html__(
                    'Reprint: use the download link while the FedEx label URL is valid. If it expired, use FedEx tools or contact support.',
                    'teamzlab-fedex'
                ) . '</p>';
            }
        }
        echo '</div>';
    }
}
