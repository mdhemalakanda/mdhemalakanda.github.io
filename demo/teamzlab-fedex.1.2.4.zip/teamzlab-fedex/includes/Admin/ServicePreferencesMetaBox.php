<?php
namespace FSHIPPING\Admin;

use FSHIPPING\Shipping\ServicePreferences;
use FSHIPPING\SingletonTrait;

/**
 * Per-order FedEx service-preferences metabox.
 *
 * Surfaces Saturday delivery, Evening delivery, adult-signature, and
 * date-certain toggles on the WC order edit screen. Writes to
 * `_fshipping_svc_preferences` — the normalized output that
 * AdvancedServicesInjector reads when building the Ship + Rates payload.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class ServicePreferencesMetaBox {
    use SingletonTrait;

    public const NONCE_ACTION = 'fshipping_svc_prefs';
    public const NONCE_FIELD  = '_fshipping_svc_prefs_nonce';

    public function init() {
        add_action('add_meta_boxes',                     [$this, 'register']);
        add_action('save_post_shop_order',               [$this, 'save'], 10, 2);
        add_action('woocommerce_process_shop_order_meta', [$this, 'save_hpos'], 10, 2);
    }

    public function register() {
        add_meta_box(
            'fshipping_svc_prefs',
            __('FedEx service preferences', 'teamzlab-fedex'),
            [$this, 'render'],
            ['shop_order', 'woocommerce_page_wc-orders'],
            'side',
            'default'
        );
    }

    public function render($post_or_order) {
        $order_id = is_object($post_or_order) && method_exists($post_or_order, 'get_id')
            ? (int) $post_or_order->get_id()
            : (int) ($post_or_order->ID ?? 0);

        wp_nonce_field(self::NONCE_ACTION, self::NONCE_FIELD);

        $saved    = get_post_meta($order_id, '_fshipping_svc_preferences', true);
        $saved    = is_array($saved) ? $saved : [];
        $codes    = is_array($saved['codes'] ?? null) ? $saved['codes'] : [];
        $deliver_by = (string) ($saved['specific_delivery_date'] ?? '');

        $catalog = ServicePreferences::instance()->catalog();
        $active_set = array_flip(array_map('strtoupper', $codes));

        foreach ($catalog as $slug => $entry) {
            $is_active = isset($active_set[strtoupper($entry['code'])]);
            ?>
            <p>
                <label>
                    <input type="checkbox" name="fshipping_svc[<?php echo esc_attr($slug); ?>]" value="1"
                        <?php checked($is_active); ?> />
                    <?php echo esc_html($entry['label']); ?>
                </label>
            </p>
            <?php
        }
        ?>
        <p>
            <label for="fshipping_svc_deliver_by"><?php esc_html_e('Specific delivery date (for date-certain)', 'teamzlab-fedex'); ?></label>
            <input type="date" id="fshipping_svc_deliver_by" name="fshipping_svc_deliver_by"
                   value="<?php echo esc_attr($deliver_by); ?>" class="widefat" />
        </p>
        <?php
    }

    public function save($post_id, $post = null) {
        if (!$this->authorize()) {
            return;
        }
        if (!current_user_can('edit_post', (int) $post_id)) {
            return;
        }
        $this->persist((int) $post_id);
    }

    public function save_hpos($order_id, $order = null) {
        if (!$this->authorize()) {
            return;
        }
        $this->persist((int) $order_id);
    }

    private function authorize(): bool {
        return !empty($_POST[self::NONCE_FIELD]) &&
               wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::NONCE_FIELD])), self::NONCE_ACTION);
    }

    private function persist(int $order_id): void {
        // save()/save_hpos() already verified this nonce via authorize(); re-check it
        // in this scope so every superglobal read below is nonce-verified.
        check_admin_referer(self::NONCE_ACTION, self::NONCE_FIELD);
        $raw   = isset($_POST['fshipping_svc']) && is_array($_POST['fshipping_svc']) ? array_map('sanitize_text_field', wp_unslash($_POST['fshipping_svc'])) : [];
        $delivery_by = isset($_POST['fshipping_svc_deliver_by']) ? sanitize_text_field((string) wp_unslash($_POST['fshipping_svc_deliver_by'])) : '';

        if (empty($raw)) {
            delete_post_meta($order_id, '_fshipping_svc_preferences');
            return;
        }

        // ServicePreferences::normalize returns warnings that we'd ideally
        // surface in an admin notice — leaving the hook out here keeps the
        // metabox self-contained; a future enhancement can translate
        // $normalized['warnings'] into transient-stashed admin notices.
        $normalized = ServicePreferences::instance()->normalize($raw, '', $delivery_by);
        if (empty($normalized['codes'])) {
            delete_post_meta($order_id, '_fshipping_svc_preferences');
            return;
        }
        update_post_meta($order_id, '_fshipping_svc_preferences', $normalized);
    }
}
