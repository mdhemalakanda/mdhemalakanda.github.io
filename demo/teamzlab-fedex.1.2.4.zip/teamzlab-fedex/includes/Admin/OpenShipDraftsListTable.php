<?php
namespace FSHIPPING\Admin;

use FSHIPPING\HTTP\OpenShip;
use FSHIPPING\OpenShip\Draft;

/**
 * WP_List_Table for Fedex → Open Shipments (Advanced orders: awaiting confirm through shipped).
 *
 * @since 1.4
 */
defined('ABSPATH') || exit;

if (!class_exists('\WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class OpenShipDraftsListTable extends \WP_List_Table {
    /**
     * GET/POST name for bulk-selected order IDs (must not be `order` — that is a
     * reserved WordPress query var for sort direction and breaks `order[]` arrays).
     */
    private const BULK_ORDER_IDS_PARAM = 'fshipping_os_ids';

    /** @var array<int, \WC_Order> */
    private $items_data = [];

    /** @var int */
    public $count_active = 0;

    /** @var int */
    public $count_trash = 0;

    public function __construct() {
        parent::__construct([
            'singular' => 'order',
            'plural'   => 'orders',
            'ajax'     => false,
        ]);
    }

    /**
     * Whether the Trash tab is active (WooCommerce-style).
     *
     * @return bool
     */
    private function is_trash_view(): bool {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only list-table filter (trash view flag); value is sanitized and only affects which rows are displayed, no state change.
        return isset($_REQUEST['fshipping_os_status']) && sanitize_key(wp_unslash($_REQUEST['fshipping_os_status'])) === 'trash';
    }

    /**
     * Base admin URL for row links, preserving the Trash tab.
     *
     * @return string
     */
    private function admin_base_url(): string {
        $url = admin_url('admin.php?page=' . OpenShipDraftsPage::PAGE_SLUG);
        if ($this->is_trash_view()) {
            $url = add_query_arg('fshipping_os_status', 'trash', $url);
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only lifecycle filter preserved when building list-table row/action links; sanitized, display only.
        if (!empty($_REQUEST['fshipping_os_lifecycle'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only lifecycle filter preserved when building list-table row/action links; sanitized, display only.
            $url = add_query_arg('fshipping_os_lifecycle', sanitize_key(wp_unslash($_REQUEST['fshipping_os_lifecycle'])), $url);
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only stage filter preserved when building list-table row/action links; sanitized, display only.
        if (!empty($_REQUEST['fshipping_os_stage'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only stage filter preserved when building list-table row/action links; sanitized, display only.
            $url = add_query_arg('fshipping_os_stage', sanitize_key(wp_unslash($_REQUEST['fshipping_os_stage'])), $url);
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search term preserved when building list-table row/action links; sanitized, display only.
        if (!empty($_REQUEST['s'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search term preserved when building list-table row/action links; sanitized, display only.
            $url = add_query_arg('s', sanitize_text_field(wp_unslash($_REQUEST['s'])), $url);
        }

        return $url;
    }

    /**
     * @return void
     */
    public function prepare_items() {
        $this->process_bulk_action();

        $per_page     = $this->get_items_per_page('fshipping_openship_drafts_per_page', 20);
        $current_page = $this->get_pagenum();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search filter for the list table; value is sanitized and only affects which rows are displayed, no state change.
        $search       = isset($_REQUEST['s']) ? sanitize_text_field(wp_unslash($_REQUEST['s'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only lifecycle filter for the list table; value is sanitized and only affects which rows are displayed, no state change.
        $lifecycle    = isset($_REQUEST['fshipping_os_lifecycle']) ? sanitize_key(wp_unslash($_REQUEST['fshipping_os_lifecycle'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only stage filter for the list table; value is sanitized and only affects which rows are displayed, no state change.
        $stage        = isset($_REQUEST['fshipping_os_stage']) ? sanitize_key(wp_unslash($_REQUEST['fshipping_os_stage'])) : '';

        $this->count_active = 0;
        $this->count_trash  = 0;

        // `status => any` does NOT include trashed orders: HPOS maps `any` to `wc_get_order_statuses()`
        // only; CPT/WP_Query `any` excludes trash-like stati. Include `trash` so the Trash tab matches
        // WooCommerce → Orders (see WC `OrdersTableQuery::sanitize_status()`).
        $statuses = array_values( array_unique( array_merge( array_keys( wc_get_order_statuses() ), [ 'trash' ] ) ) );

        $query = wc_get_orders([
            'limit'      => 500,
            'status'     => $statuses,
            'paginate'   => false,
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Scoped wc_get_orders() lookup on orders using a fixed meta key constant and a hard limit of 500; no unbounded meta scan.
            'meta_key'   => Draft::META_FULFILLMENT_MODE,
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Scoped wc_get_orders() lookup on orders using a fixed meta key constant and a hard limit of 500; no unbounded meta scan.
            'meta_value' => 'advanced',
            'orderby'    => 'date',
            'order'      => 'DESC',
        ]);

        $candidates = [];
        foreach ($query as $order) {
            if (!is_object($order) || !method_exists($order, 'get_id')) {
                continue;
            }
            $confirmed = 'yes' === (string) $order->get_meta(Draft::META_CONFIRMED, true);
            $wc_status = $order->get_status();

            if ($stage === 'awaiting') {
                if ($confirmed) {
                    continue;
                }
            } elseif ($stage === 'shipped') {
                if (!$confirmed) {
                    continue;
                }
                if ($wc_status === 'completed') {
                    continue;
                }
            } elseif ($stage === 'delivered') {
                if (!$confirmed) {
                    continue;
                }
                if ($wc_status !== 'completed') {
                    continue;
                }
            }

            if ($lifecycle !== '') {
                $life = (string) $order->get_meta(Draft::META_LIFECYCLE, true);
                if ($life !== $lifecycle) {
                    continue;
                }
            }
            if ($search !== '') {
                $sid = (string) $order->get_id();
                $em  = (string) $order->get_billing_email();
                $fn  = (string) $order->get_billing_first_name() . ' ' . (string) $order->get_billing_last_name();
                $hay = strtolower($sid . ' ' . $em . ' ' . $fn . ' ' . $order->get_order_number());
                if (stripos($hay, strtolower($search)) === false) {
                    continue;
                }
            }
            $candidates[] = $order;
            if ($order->get_status() === 'trash') {
                ++$this->count_trash;
            } else {
                ++$this->count_active;
            }
        }

        $filtered = [];
        foreach ($candidates as $order) {
            if ($this->is_trash_view()) {
                if ($order->get_status() === 'trash') {
                    $filtered[] = $order;
                }
            } elseif ($order->get_status() !== 'trash') {
                $filtered[] = $order;
            }
        }

        $total          = count($filtered);
        $offset         = ($current_page - 1) * $per_page;
        $this->items_data = array_slice($filtered, $offset, $per_page);

        $this->items = $this->items_data;
        $this->set_pagination_args([
            'total_items' => $total,
            'per_page'    => $per_page,
            'total_pages' => (int) ceil(max(1, $total) / $per_page),
        ]);

        $this->_column_headers = [
            $this->get_columns(),
            [],
            $this->get_sortable_columns(),
        ];
    }

    /**
     * All | Trash (same idea as WooCommerce → Orders).
     *
     * @return array<string, string>
     */
    protected function get_views() {
        $page = OpenShipDraftsPage::PAGE_SLUG;
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search term echoed into the All/Trash view links; sanitized, display only.
        $s    = isset($_REQUEST['s']) ? sanitize_text_field(wp_unslash($_REQUEST['s'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only lifecycle filter echoed into the All/Trash view links; sanitized, display only.
        $life = isset($_REQUEST['fshipping_os_lifecycle']) ? sanitize_key(wp_unslash($_REQUEST['fshipping_os_lifecycle'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only stage filter echoed into the All/Trash view links; sanitized, display only.
        $stg  = isset($_REQUEST['fshipping_os_stage']) ? sanitize_key(wp_unslash($_REQUEST['fshipping_os_stage'])) : '';

        $all_url = remove_query_arg(
            ['paged', 'fshipping_os_status', 'action', 'action2', self::BULK_ORDER_IDS_PARAM, '_wpnonce'],
            admin_url('admin.php?page=' . $page)
        );
        if ($s !== '') {
            $all_url = add_query_arg('s', $s, $all_url);
        }
        if ($life !== '') {
            $all_url = add_query_arg('fshipping_os_lifecycle', $life, $all_url);
        }
        if ($stg !== '') {
            $all_url = add_query_arg('fshipping_os_stage', $stg, $all_url);
        }

        $trash_url = remove_query_arg(
            ['paged', 'action', 'action2', self::BULK_ORDER_IDS_PARAM, '_wpnonce'],
            admin_url('admin.php?page=' . $page)
        );
        $trash_url = add_query_arg('fshipping_os_status', 'trash', $trash_url);
        if ($s !== '') {
            $trash_url = add_query_arg('s', $s, $trash_url);
        }
        if ($life !== '') {
            $trash_url = add_query_arg('fshipping_os_lifecycle', $life, $trash_url);
        }
        if ($stg !== '') {
            $trash_url = add_query_arg('fshipping_os_stage', $stg, $trash_url);
        }

        $current = $this->is_trash_view() ? 'trash' : 'all';

        return [
            'all' => sprintf(
                '<a href="%s"%s>%s</a>',
                esc_url($all_url),
                'all' === $current ? ' class="current" aria-current="page"' : '',
                sprintf(
                    /* translators: %d: order count */
                    __('All <span class="count">(%d)</span>', 'teamzlab-fedex'),
                    (int) $this->count_active
                )
            ),
            'trash' => sprintf(
                '<a href="%s"%s>%s</a>',
                esc_url($trash_url),
                'trash' === $current ? ' class="current" aria-current="page"' : '',
                sprintf(
                    /* translators: %d: order count */
                    __('Trash <span class="count">(%d)</span>', 'teamzlab-fedex'),
                    (int) $this->count_trash
                )
            ),
        ];
    }

    /**
     * @return void
     */
    public function no_items() {
        if ($this->is_trash_view()) {
            esc_html_e('No Open Shipments orders in the trash.', 'teamzlab-fedex');
        } else {
            esc_html_e('No Open Shipments orders match the current filters.', 'teamzlab-fedex');
        }
    }

    /**
     * @return array<string, string>
     */
    public function get_columns() {
        return [
            'cb'          => '<input type="checkbox" />',
            'order'       => __('Order', 'teamzlab-fedex'),
            'customer'    => __('Customer', 'teamzlab-fedex'),
            'date'        => __('Date', 'teamzlab-fedex'),
            'status'      => __('Order status', 'teamzlab-fedex'),
            'lifecycle'   => __('Lifecycle', 'teamzlab-fedex'),
            'shipment'    => __('Shipment', 'teamzlab-fedex'),
            'label_printed' => __('Label Printed', 'teamzlab-fedex'),
            'all_labels_pdf' => __('All labels PDF', 'teamzlab-fedex'),
            'session'     => __('FedEx session', 'teamzlab-fedex'),
            'packages'    => __('Boxes', 'teamzlab-fedex'),
            'cancel_shipment' => __('Cancel', 'teamzlab-fedex'),
            'trade_documents' => __('Trade docs', 'teamzlab-fedex'),
        ];
    }

    /**
     * @return array<string, array<int, bool>>
     */
    protected function get_sortable_columns() {
        return [];
    }

    /**
     * @return array<string, string>
     */
    protected function get_bulk_actions() {
        if ($this->is_trash_view()) {
            $actions = [
                'restore'           => __('Restore', 'teamzlab-fedex'),
                'delete_permanent'  => __('Delete permanently', 'teamzlab-fedex'),
            ];
            if (!current_user_can('delete_shop_orders')) {
                unset($actions['delete_permanent']);
            }
            return $actions;
        }

        $actions = [
            'trash' => __('Move to trash (WooCommerce only)', 'teamzlab-fedex'),
        ];
        if (!current_user_can('delete_shop_orders')) {
            unset($actions['trash']);
        }
        return $actions;
    }

    /**
     * @return array<string, string>
     */
    public function get_row_actions_for_order(\WC_Order $order): array {
        $id        = $order->get_id();
        $base      = $this->admin_base_url();
        $can_trash = current_user_can('delete_shop_orders');

        if ($order->get_status() === 'trash') {
            $actions = [
                'edit' => sprintf(
                    '<a href="%s">%s</a>',
                    esc_url($order->get_edit_order_url()),
                    esc_html__('Edit order', 'teamzlab-fedex')
                ),
                'restore' => sprintf(
                    '<a href="%s">%s</a>',
                    esc_url(wp_nonce_url(add_query_arg([
                        'fshipping_os_action' => 'restore',
                        'order_id'            => $id,
                    ], $base), 'fshipping_os_row_' . $id)),
                    esc_html__('Restore', 'teamzlab-fedex')
                ),
            ];
            if ($can_trash) {
                $delete_url = esc_url(wp_nonce_url(add_query_arg([
                    'fshipping_os_action' => 'delete_permanent',
                    'order_id'            => $id,
                ], $base), 'fshipping_os_row_' . $id));
                $confirm_js = esc_js(
                    __('Are you sure you want to delete?', 'teamzlab-fedex')
                );
                $actions['delete'] = sprintf(
                    '<a href="%s" class="submitdelete fshipping-os-row-delete-confirm" onclick="return confirm(\'%s\');">%s</a>',
                    $delete_url,
                    $confirm_js,
                    esc_html__('Delete permanently', 'teamzlab-fedex')
                );
            }
            return $actions;
        }

        $detail_url = add_query_arg(
            [
                'page'                => OpenShipDraftsPage::PAGE_SLUG,
                'fshipping_os_detail' => '1',
                'order_id'            => $id,
            ],
            admin_url('admin.php')
        );

        $actions = [
            'edit' => sprintf(
                '<a href="%s">%s</a>',
                esc_url($order->get_edit_order_url()),
                esc_html__('Edit order', 'teamzlab-fedex')
            ),
        ];

        $has_confirm_json = (string) $order->get_meta(Draft::META_CONFIRM_RESPONSE, true) !== '';
        if (Draft::is_locked($order) || $has_confirm_json) {
            $actions['view_shipment'] = sprintf(
                '<a href="%s">%s</a>',
                esc_url($detail_url),
                esc_html__('View FedEx details', 'teamzlab-fedex')
            );
        }

        if (!Draft::is_locked($order)) {
            $actions['fedex_del'] = sprintf(
                '<a href="%s" class="fshipping-os-fedex-cancel">%s</a>',
                esc_url(wp_nonce_url(add_query_arg([
                    'fshipping_os_action' => 'fedex_delete',
                    'order_id'            => $id,
                ], $base), 'fshipping_os_row_' . $id)),
                esc_html__('Cancel on FedEx', 'teamzlab-fedex')
            );
            $actions['trash'] = sprintf(
                '<a href="%s" class="submitdelete">%s</a>',
                esc_url(wp_nonce_url(add_query_arg([
                    'fshipping_os_action' => 'trash',
                    'order_id'            => $id,
                ], $base), 'fshipping_os_row_' . $id)),
                esc_html__('Move to trash (local)', 'teamzlab-fedex')
            );
            $actions['trash_fedex'] = sprintf(
                '<a href="%s" class="submitdelete">%s</a>',
                esc_url(wp_nonce_url(add_query_arg([
                    'fshipping_os_action' => 'trash_fedex',
                    'order_id'            => $id,
                ], $base), 'fshipping_os_row_' . $id)),
                esc_html__('Trash after FedEx cancel', 'teamzlab-fedex')
            );
        }

        if (!$can_trash) {
            unset($actions['trash'], $actions['trash_fedex']);
        }

        return $actions;
    }

    /**
     * @param \WC_Order $item
     * @return string
     */
    protected function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="%s[]" value="%d" />',
            esc_attr(self::BULK_ORDER_IDS_PARAM),
            $item->get_id()
        );
    }

    /**
     * @param \WC_Order $item
     * @return string
     */
    protected function column_order($item) {
        $actions = $this->get_row_actions_for_order($item);
        return sprintf(
            '<strong><a href="%s">#%s</a></strong>%s',
            esc_url($item->get_edit_order_url()),
            esc_html((string) $item->get_order_number()),
            $this->row_actions($actions)
        );
    }

    /**
     * @param \WC_Order $item
     * @return string
     */
    protected function column_customer($item) {
        return esc_html(trim($item->get_billing_first_name() . ' ' . $item->get_billing_last_name()))
            . '<br /><small>' . esc_html($item->get_billing_email()) . '</small>';
    }

    /**
     * @param \WC_Order $item
     * @return string
     */
    protected function column_date($item) {
        $d = $item->get_date_created();
        return $d ? esc_html($d->date_i18n(get_option('date_format') . ' ' . get_option('time_format'))) : '—';
    }

    /**
     * @param \WC_Order $item
     * @return string
     */
    protected function column_status($item) {
        return esc_html(wc_get_order_status_name($item->get_status()));
    }

    /**
     * @param \WC_Order $item
     * @return string
     */
    protected function column_lifecycle($item) {
        return esc_html((string) $item->get_meta(Draft::META_LIFECYCLE, true) ?: '—');
    }

    /**
     * @param \WC_Order $item
     * @return string
     */
    protected function column_shipment($item) {
        $confirmed = 'yes' === (string) $item->get_meta(Draft::META_CONFIRMED, true);
        $st        = $item->get_status();
        if ($confirmed) {
            if ($st === 'completed') {
                $badge   = __('Delivered', 'teamzlab-fedex');
                $variant = ' fshipping-status-badge--ok';
            } else {
                $badge   = __('Shipped', 'teamzlab-fedex');
                $variant = ' fshipping-status-badge--info';
            }
        } else {
            $badge   = __('Open', 'teamzlab-fedex');
            $variant = '';
        }

        return '<span class="fshipping-os-ship-badge fshipping-status-badge' . $variant . '">'
            . esc_html($badge) . '</span>';
    }

    /**
     * @param \WC_Order $item
     * @return string
     */
    protected function column_label_printed($item) {
        if ($item->get_status() === 'trash') {
            return '—';
        }
        $printed = (string) $item->get_meta('_fshipping_label_printed', true);
        $checked = ('yes' === $printed);
        $is_canceled = in_array(strtolower((string) $item->get_status()), ['cancelled', 'canceled'], true);
        $disabled_attr = $is_canceled ? ' disabled="disabled"' : '';

        $html  = '<label class="fshipping-toggle-switch" title="' . esc_attr__('Mark label as printed', 'teamzlab-fedex') . '">';
        $html .= '<input type="checkbox" class="fshipping-label-printed-toggle" data-order_id="' . esc_attr((string) $item->get_id()) . '"'
            . checked($checked, true, false) . $disabled_attr . ' />';
        $html .= '<span class="fshipping-toggle-slider" aria-hidden="true"></span>';
        $html .= '</label>';
        $html .= '<span class="fshipping-toggle-text">' . esc_html(
            $is_canceled ? __('Canceled', 'teamzlab-fedex') : ($checked ? __('Printed', 'teamzlab-fedex') : __('Not printed', 'teamzlab-fedex'))
        ) . '</span>';

        return $html;
    }

    /**
     * One-click merged/single label PDF, or link to per-package files on the FedEx detail view.
     *
     * @param \WC_Order $item
     * @return string
     */
    protected function column_all_labels_pdf($item) {
        if ($item->get_status() === 'trash') {
            return '—';
        }

        $all_url = Draft::best_all_labels_pdf_url($item);
        if ($all_url !== '') {
            return '<a href="' . esc_url($all_url) . '" class="button button-small" target="_blank" rel="noopener noreferrer">'
                . esc_html__('Open PDF', 'teamzlab-fedex') . '</a>';
        }

        $raw = (string) $item->get_meta(Draft::META_PACKAGE_LABEL_FILES, true);
        $decoded = $raw !== '' ? json_decode($raw, true) : [];
        $piece_urls = 0;
        if (is_array($decoded)) {
            foreach ($decoded as $row) {
                if (is_array($row) && !empty($row['file_url'])) {
                    ++$piece_urls;
                }
            }
        }
        if ($piece_urls < 2) {
            return '—';
        }

        $detail_url = add_query_arg(
            [
                'page'                => OpenShipDraftsPage::PAGE_SLUG,
                'fshipping_os_detail' => '1',
                'order_id'            => (int) $item->get_id(),
            ],
            admin_url('admin.php')
        );

        return '<a href="' . esc_url($detail_url) . '#fshipping-os-saved-label-files" class="button button-small">'
            . esc_html__('Per-package PDFs', 'teamzlab-fedex') . '</a>';
    }

    /**
     * @param \WC_Order $item
     * @return string
     */
    protected function column_session($item) {
        $idx = (string) $item->get_meta(Draft::META_SHIPMENT_INDEX, true);
        return $idx !== '' ? '<code>' . esc_html($idx) . '</code>' : '—';
    }

    /**
     * @param \WC_Order $item
     * @return string
     */
    protected function column_packages($item) {
        $pk = Draft::get_packages($item);
        return (string) count($pk);
    }

    /**
     * Render row with the same visual state classes used by Ship API list table:
     * - fshipping-row-canceled => soft danger background
     * - fshipping-row-printed  => soft green background
     *
     * @param \WC_Order $item
     * @return void
     */
    public function single_row($item) {
        $classes = ['iedit'];
        $status = strtolower((string) $item->get_status());
        if (in_array($status, ['cancelled', 'canceled'], true)) {
            $classes[] = 'fshipping-row-canceled';
        } elseif ((string) $item->get_meta('_fshipping_label_printed', true) === 'yes') {
            $classes[] = 'fshipping-row-printed';
        }

        echo '<tr class="' . esc_attr(implode(' ', $classes)) . '">';
        $this->single_row_columns($item);
        echo '</tr>';
    }

    /**
     * Ship-API style cancel action for Open Ship list rows.
     * Enabled only after tracking exists (confirmed/shipped flows).
     *
     * @param \WC_Order $item
     * @return string
     */
    protected function column_cancel_shipment($item) {
        if ($item->get_status() === 'trash') {
            return '—';
        }

        $tracking = (string) $item->get_meta('_fedex_tracking', true);
        if ($tracking === '') {
            $tracking = (string) $item->get_meta(Draft::META_SHIPMENT_ID_INDEX, true);
        }
        if ($tracking === '') {
            return '<span class="description">' . esc_html__('Not available', 'teamzlab-fedex') . '</span>';
        }

        $order_status = strtolower((string) $item->get_status());
        if (in_array($order_status, ['cancelled', 'canceled'], true)) {
            return '<button type="button" class="button button-small button-danger disabled" disabled>'
                . esc_html__('Canceled', 'teamzlab-fedex') . '</button>';
        }

        return '<button type="button" class="button button-small button-danger fedex-cancel-shipment" data-tracking_id="'
            . esc_attr($tracking) . '">' . esc_html__('Cancel', 'teamzlab-fedex') . '</button>';
    }

    /**
     * @param \WC_Order $item
     * @return string
     */
    protected function column_trade_documents($item) {
        $order_id = (int) $item->get_id();
        $session_tracking = (string) $item->get_meta(Draft::META_SHIPMENT_ID_INDEX, true);
        $tracking = (string) $item->get_meta('_fedex_tracking', true);
        if ($tracking === '') {
            $tracking = $session_tracking;
        }
        $uploads = $this->get_trade_document_upload_rows_for_order($item);
        $last_error = (string) $item->get_meta('_fshipping_trade_doc_last_error', true);
        $disabled = $tracking === '' ? ' disabled' : '';
        $btn = '<button type="button" class="button button-small fshipping-toggle-trade-docs" data-order_id="'
            . esc_attr($order_id) . '" data-tracking="' . esc_attr($tracking) . '"' . $disabled . '>'
            . esc_html__('Upload docs', 'teamzlab-fedex') . '</button>';

        if ($uploads !== []) {
            $state = '<span class="fshipping-trade-docs-state fshipping-trade-docs-state-ok">'
                . esc_html(sprintf(
                    /* translators: %d: number of uploaded trade documents. */
                    __('Uploaded: %d', 'teamzlab-fedex'),
                    count($uploads)
                )) . '</span>';
        } elseif ($last_error !== '') {
            $state = '<span class="fshipping-trade-docs-state fshipping-trade-docs-state-err">'
                . esc_html__('Failed', 'teamzlab-fedex') . '</span>';
        } else {
            $state = '<span class="fshipping-trade-docs-state">' . esc_html__('Not uploaded', 'teamzlab-fedex') . '</span>';
        }

        $html = $btn . ' ' . $state;
        if ($last_error !== '') {
            $html .= '<div class="fshipping-trade-docs-inline-error">' . esc_html($last_error) . '</div>';
        }

        return $html;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function get_trade_document_upload_rows_for_order(\WC_Order $order): array {
        $raw = $order->get_meta('_fshipping_trade_doc_upload_ids', true);
        if (is_array($raw)) {
            return $raw;
        }
        if (!is_string($raw) || $raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);

        return is_array($decoded) ? $decoded : [];
    }

    /**
     * @return void
     */
    protected function process_bulk_action() {
        if (!current_user_can('edit_shop_orders')) {
            return;
        }
        $action = $this->current_action();
        if (
            !$action
            || !in_array(
                $action,
                [
                    'trash',
                    'restore',
                    'delete_permanent',
                ],
                true
            )
        ) {
            return;
        }
        check_admin_referer('bulk-' . $this->_args['plural']);

        $ids = [];
        if (!empty($_REQUEST[self::BULK_ORDER_IDS_PARAM])) {
            $ids = array_map('intval', (array) $_REQUEST[self::BULK_ORDER_IDS_PARAM]);
        } elseif (!empty($_REQUEST['order']) && is_array($_REQUEST['order'])) {
            // Legacy `order[]` only when it is a real array (never use WP sort string `order=asc|desc`).
            $ids = array_map('intval', $_REQUEST['order']);
        }
        $ids = array_values(array_unique(array_filter($ids)));
        if ($ids === []) {
            return;
        }

        $needs_delete_cap = in_array($action, ['trash', 'delete_permanent'], true);
        if ($needs_delete_cap && !current_user_can('delete_shop_orders')) {
            set_transient(
                'fshipping_openship_drafts_notice_' . get_current_user_id(),
                ['message' => __('You do not have permission for that action.', 'teamzlab-fedex'), 'error' => true],
                60
            );
            wp_safe_redirect(OpenShipDraftsPage::base_list_url());
            exit;
        }

        $done               = 0;
        $errs               = [];
        $bulk_fedex_puts    = 0;
        $bulk_fedex_no_sess = 0;
        foreach ($ids as $oid) {
            $order = wc_get_order($oid);
            if (!$order || !Draft::is_advanced_order($order)) {
                continue;
            }
            if ('yes' === (string) $order->get_meta(Draft::META_CONFIRMED, true)) {
                continue;
            }

            if ($action === 'restore' || $action === 'delete_permanent') {
                if ($order->get_status() !== 'trash') {
                    continue;
                }
                if ($action === 'restore') {
                    if ($order->untrash()) {
                        ++$done;
                    }
                } else {
                    $had_fedex_session = (string) $order->get_meta(Draft::META_SHIPMENT_INDEX, true) !== '';
                    // Force full FedEx delete URL / payload / response into debug.log for every row (bulk path),
                    // or a matching block when no FedEx session (PUT not sent — WC delete still runs).
                    $r = Draft::cancel_fedex_open_shipment_and_clear($order, true);
                    if ($had_fedex_session) {
                        ++$bulk_fedex_puts;
                    } else {
                        ++$bulk_fedex_no_sess;
                    }
                    if (empty($r['ok'])) {
                        if (!empty($r['error'])) {
                            $errs[] = '#' . $oid . ': ' . $r['error'];
                        }
                        continue;
                    }
                    $order = wc_get_order($oid);
                    if (!$order) {
                        OpenShip::debug_log_push_message(
                            '[teamzlab-fedex Open Ship] bulk_audit: WooCommerce wc_get_order() failed after FedEx cancel; permanent delete not run order_id=' . $oid,
                            true
                        );
                    } else {
                        $wc_deleted = (bool) $order->delete(true);
                        if ($wc_deleted) {
                            ++$done;
                            OpenShip::debug_log_push_message(
                                '[teamzlab-fedex Open Ship] bulk_audit: WooCommerce permanent delete succeeded order_id=' . $oid,
                                true
                            );
                        } else {
                            OpenShip::debug_log_push_message(
                                '[teamzlab-fedex Open Ship] bulk_audit: WooCommerce permanent delete FAILED order_id=' . $oid,
                                true
                            );
                        }
                    }
                }
                continue;
            }

            if (Draft::is_locked($order)) {
                continue;
            }
            if ($action === 'trash') {
                if ($order->delete(false)) {
                    ++$done;
                }
            }
        }

        if ($action === 'delete_permanent' && $ids !== []) {
            OpenShip::debug_log_push_message(
                sprintf(
                    '[teamzlab-fedex Open Ship] bulk delete_permanent summary: selected_order_ids=%s orders_removed_in_wc=%d rows_with_fedex_put=%d rows_without_fedex_session=%d',
                    implode(',', $ids),
                    $done,
                    $bulk_fedex_puts,
                    $bulk_fedex_no_sess
                )
                . (empty($errs) ? '' : ' errors=' . implode('; ', array_slice($errs, 0, 10))),
                true
            );
        }

        $msg = sprintf(
            /* translators: %d: count */
            _n('%d order updated.', '%d orders updated.', $done, 'teamzlab-fedex'),
            $done
        );
        if (!empty($errs)) {
            $msg .= ' ' . implode(' ', array_slice($errs, 0, 5));
        }
        $notice = ['message' => $msg, 'error' => !empty($errs)];
        set_transient('fshipping_openship_drafts_notice_' . get_current_user_id(), $notice, 60);
        wp_safe_redirect(OpenShipDraftsPage::base_list_url());
        exit;
    }

    /**
     * Extra controls (search + lifecycle filter).
     *
     * @param string $which
     * @return void
     */
    protected function extra_tablenav($which) {
        if ($which !== 'top') {
            return;
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only lifecycle filter used to pre-select the dropdown in the filter form; sanitized, display only.
        $sel  = isset($_REQUEST['fshipping_os_lifecycle']) ? sanitize_key(wp_unslash($_REQUEST['fshipping_os_lifecycle'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only stage filter used to pre-select the dropdown in the filter form; sanitized, display only.
        $stg  = isset($_REQUEST['fshipping_os_stage']) ? sanitize_key(wp_unslash($_REQUEST['fshipping_os_stage'])) : '';
        $trash = $this->is_trash_view();
        ?>
        <div class="alignleft actions">
            <label class="screen-reader-text" for="fshipping_os_stage"><?php esc_html_e('Filter by shipment stage', 'teamzlab-fedex'); ?></label>
            <select name="fshipping_os_stage" id="fshipping_os_stage">
                <option value=""><?php esc_html_e('All stages', 'teamzlab-fedex'); ?></option>
                <option value="awaiting" <?php selected($stg, 'awaiting'); ?>><?php esc_html_e('Awaiting confirm', 'teamzlab-fedex'); ?></option>
                <option value="shipped" <?php selected($stg, 'shipped'); ?>><?php esc_html_e('Shipped (confirmed, not completed)', 'teamzlab-fedex'); ?></option>
                <option value="delivered" <?php selected($stg, 'delivered'); ?>><?php esc_html_e('Delivered (completed)', 'teamzlab-fedex'); ?></option>
            </select>
            <?php if (!$trash) : ?>
            <label class="screen-reader-text" for="fshipping_os_lifecycle"><?php esc_html_e('Filter by lifecycle', 'teamzlab-fedex'); ?></label>
            <select name="fshipping_os_lifecycle" id="fshipping_os_lifecycle">
                <option value=""><?php esc_html_e('All lifecycles', 'teamzlab-fedex'); ?></option>
                <option value="draft" <?php selected($sel, 'draft'); ?>><?php esc_html_e('draft', 'teamzlab-fedex'); ?></option>
                <option value="in_progress" <?php selected($sel, 'in_progress'); ?>><?php esc_html_e('in_progress', 'teamzlab-fedex'); ?></option>
                <option value="confirmed" <?php selected($sel, 'confirmed'); ?>><?php esc_html_e('confirmed', 'teamzlab-fedex'); ?></option>
            </select>
            <?php endif; ?>
            <?php submit_button(__('Filter', 'teamzlab-fedex'), '', 'filter_action', false); ?>
        </div>
        <?php
    }

    /**
     * @param string $text
     * @return string|bool
     */
    public function search_box($text, $input_id) {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search term used to decide whether to render the search box; display only, no state change.
        if (empty($_REQUEST['s']) && !$this->has_items() && !$this->is_trash_view()) {
            return '';
        }
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only search term used to pre-fill the search box value; sanitized, display only.
        $search = isset($_REQUEST['s']) ? sanitize_text_field(wp_unslash($_REQUEST['s'])) : '';
        ?>
        <p class="search-box">
            <label class="screen-reader-text" for="<?php echo esc_attr($input_id); ?>"><?php echo esc_html($text); ?>:</label>
            <input type="search" id="<?php echo esc_attr($input_id); ?>" name="s" value="<?php echo esc_attr($search); ?>" />
            <?php submit_button($text, '', '', false, ['id' => 'search-submit']); ?>
        </p>
        <?php
        return '';
    }
}
