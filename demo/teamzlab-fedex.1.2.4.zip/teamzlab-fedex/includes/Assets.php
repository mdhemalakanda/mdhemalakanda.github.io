<?php
namespace FSHIPPING;
/**
 * This file will enqueue all required assets.
 * 
 * @since 1.0
 */
class Assets {
    use SingletonTrait;

    public function init() {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_asets'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
    }

    public function enqueue_admin_asets($screen) {
        $screen = (string) $screen;
        $is_openship_drafts_screen = strpos($screen, 'fshipping_openship_drafts') !== false;
        $is_product_box_screen = strpos($screen, 'fshipping_product_box') !== false;
        $is_pickup_history_screen = strpos($screen, 'fshipping_pickup_history') !== false;
        if(
            $screen === 'toplevel_page_fedex_shipping'
            || $screen === 'edit.php'
            || $is_openship_drafts_screen
            || $is_product_box_screen
            || $is_pickup_history_screen
        ) {
            wp_enqueue_style(
                'fshipping-select2',
                plugins_url('assets/admin/css/select2.css', FSHIPPING_FILE),
                [],
                '1.1.0',
                'all'
            );
            wp_enqueue_style(
                'fshipping-admin',
                plugins_url('assets/admin/css/style.css', FSHIPPING_FILE),
                [],
                '1.1.3',
                'all'
            );

            if ( $is_openship_drafts_screen ) {
                // Styles for the Open Ship drafts list (hook prefix varies with
                // the parent menu title, so this is keyed off the substring above).
                wp_enqueue_style(
                    'fshipping-openship-shipments',
                    plugins_url('assets/admin/css/fshipping-openship-shipments.css', FSHIPPING_FILE),
                    ['fshipping-admin'],
                    '1.1.0',
                    'all'
                );
            }

            wp_enqueue_script(
                'fshipping-select2-script',
                plugins_url('assets/admin/js/select2.js', FSHIPPING_FILE),
                array('jquery'),
                time(),
                true
            );

            wp_enqueue_script(
                'fshipping-fedex',
                plugins_url('assets/admin/js/main.js', FSHIPPING_FILE),
                array('jquery', 'fshipping-select2-script'),
                time(),
                true
            );

            $args = array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('fshipping_nonce')
            );
            wp_localize_script('fshipping-fedex', 'fshipping_params', $args);
        }

        if ($is_product_box_screen) {
            wp_enqueue_style(
                'fshipping-product-box',
                plugins_url('assets/admin/css/fshipping-product-box.css', FSHIPPING_FILE),
                [],
                '1.1.1',
                'all'
            );
            wp_enqueue_script(
                'fshipping-product-box',
                plugins_url('assets/admin/js/fshipping-product-box.js', FSHIPPING_FILE),
                ['jquery', 'fshipping-select2-script'],
                time(),
                true
            );
        }
    }

    /**
     * Enqueue checkout-side assets for address validation feedback.
     *
     * @return void
     */
    public function enqueue_frontend_assets() {
        if (!function_exists('is_checkout') || !is_checkout()) {
            return;
        }
        if (function_exists('is_order_received_page') && is_order_received_page()) {
            return;
        }

        $options = get_option('fshipping_options');
        $is_enabled = !isset($options['fshipping_enable_checkout_address_validation'])
            || !empty($options['fshipping_enable_checkout_address_validation']);
        if (!$is_enabled) {
            return;
        }

        wp_enqueue_style(
            'fshipping-checkout',
            plugins_url('assets/frontend/css/checkout-validation.css', FSHIPPING_FILE),
            [],
            '1.0.0',
            'all'
        );

        wp_enqueue_script(
            'fshipping-checkout',
            plugins_url('assets/frontend/js/checkout-validation.js', FSHIPPING_FILE),
            array('jquery'),
            time(),
            true
        );

        $args = array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('fshipping_nonce'),
            'messages' => array(
                'validating' => __('Validating address...', 'teamzlab-fedex'),
                'business' => __('Business address detected.', 'teamzlab-fedex'),
                'residential' => __('Residential address detected. Carrier surcharge may apply.', 'teamzlab-fedex'),
                'mixed' => __('Mixed address type detected. Please verify shipping details.', 'teamzlab-fedex'),
                'incomplete' => __('Complete street, city, state/province, ZIP/postal code, and country to validate address.', 'teamzlab-fedex'),
                'invalid_fields' => __('Please fix highlighted checkout fields before placing the order.', 'teamzlab-fedex'),
                'validating_zip' => __('Validating ZIP code...', 'teamzlab-fedex'),
                'zip_valid' => __('ZIP / postal code validated.', 'teamzlab-fedex'),
                'zip_unknown' => __('ZIP validation unavailable right now.', 'teamzlab-fedex'),
                'zip_unknown_continue' => __('ZIP check finished. You can continue checkout.', 'teamzlab-fedex'),
                'zip_error' => __('ZIP validation request failed. Please continue or retry.', 'teamzlab-fedex'),
                'unknown' => __('Address classification unavailable right now. Rates may still be calculated.', 'teamzlab-fedex'),
                'error' => __('Address validation request failed. Please continue or retry.', 'teamzlab-fedex'),
            ),
        );
        wp_localize_script('fshipping-checkout', 'fshipping_checkout_params', $args);
    }
}