<?php
namespace FSHIPPING\Email;
use FSHIPPING\SingletonTrait;
/**
 * This class will use for send mail for shipment confirmation.
 * 
 * @since 1.0
 */
defined('ABSPATH') || exit;
class ShipmentConfirmation {
    use SingletonTrait;

    public function init() {
        add_action('fshipping_send_shipment_email', array($this, 'send_mail'), 10, 2);
    }

   public function send_mail($post_id, $api_data) {

        if ( empty($post_id) ) {
            return false;
        }

        // Send-level idempotency: WP-Cron can deliver this event more than
        // once (option read/write races resurrect overdue events), and each
        // fire must not re-email the customer. The first send attempt marks
        // the shipment; later fires exit here.
        if ( get_post_meta($post_id, '_fshipping_confirmation_sent', true) ) {
            return false;
        }

        $tracking_number = get_post_meta($post_id, '_tracking_number', true);
        $order_id        = get_post_meta($post_id, '_fedex_shipment_order_id', true);
        $label_url       = get_post_meta($post_id, '_shipping_label', true);

        if ( ! $order_id ) {
            return false;
        }

        $order = wc_get_order($order_id);

        if ( ! $order ) {
            return false;
        }

        $customer_email = $order->get_billing_email();
        $customer_name  = $order->get_billing_first_name();
        $order_number   = $order->get_order_number();
        $order_total    = $order->get_formatted_order_total();

        $tracking_number = $tracking_number ? $tracking_number : 'N/A';
        $label_url       = $label_url ? $label_url : '#';

        $subject         = sprintf(
            /* translators: %s: WooCommerce order number. */
            __('Your Shipment Has Been Created - Order #%s', 'teamzlab-fedex'),
            $order_number
        );
        $hello_text      = sprintf(
            /* translators: %s: customer billing first name. */
            __('Hello %s, Your shipment has been created successfully.', 'teamzlab-fedex'),
            $customer_name
        );
        $name_label      = __('Name', 'teamzlab-fedex');
        $value_label     = __('Value', 'teamzlab-fedex');
        $shipping_label  = __('Shipping Cost', 'teamzlab-fedex');
        $tracking_label  = __('Tracking Number', 'teamzlab-fedex');
        $label_text      = __('Shipping Label', 'teamzlab-fedex');
        $download_label  = __('Download Label', 'teamzlab-fedex');
        $email_label     = __('Customer Email', 'teamzlab-fedex');
        $print_label     = __('Printable Order Copy', 'teamzlab-fedex');
        $download_text   = __('Download', 'teamzlab-fedex');

        $message = 
        '<table cellpadding="10" cellspacing="0" border="0" style="width:100%;max-width:650px;border-collapse:collapse;font-family:Arial,sans-serif;">
        <tr style="background:#4d148c;color:#ffffff;">
            <td colspan="2" style="padding:15px;text-align:center;font-size:18px;font-weight:bold;">📦 ' . $this->escape_html($subject) . '</td>
        </tr>
        <tr>
            <td colspan="2" style="border:1px solid #e6e1f0;">' . $this->escape_html($hello_text) . '</td>
        </tr>
        <tr style="background:#f6f2fc;font-weight:bold;">
            <td style="border:1px solid #e6e1f0;">' . $this->escape_html($name_label) . '</td>
            <td style="border:1px solid #e6e1f0;">' . $this->escape_html($value_label) . '</td>
        </tr>
        <tr>
            <td style="border:1px solid #e6e1f0;">' . $this->escape_html($shipping_label) . '</td>
            <td style="border:1px solid #e6e1f0;">' . $order_total . '</td>
        </tr>
        <tr style="background:#fbfaff;">
            <td style="border:1px solid #e6e1f0;">' . $this->escape_html($tracking_label) . '</td>
            <td style="border:1px solid #e6e1f0;">' . $this->escape_html($tracking_number) . '</td>
        </tr>
        <tr>
            <td style="border:1px solid #e6e1f0;">' . $this->escape_html($label_text) . '</td>
            <td style="border:1px solid #e6e1f0;"><a href="' . $this->escape_url($label_url) . '" style="color:#4d148c;font-weight:bold;">' . $this->escape_html($download_label) . '</a></td>
        </tr>
        <tr style="background:#fbfaff;">
            <td style="border:1px solid #e6e1f0;">' . $this->escape_html($email_label) . '</td>
            <td style="border:1px solid #e6e1f0;">' . $this->escape_html($customer_email) . '</td>
        </tr>
        <tr>
            <td style="border:1px solid #e6e1f0;">' . $this->escape_html($print_label) . '</td>
            <td style="border:1px solid #e6e1f0;"><a href="' . $this->escape_url($label_url) . '" style="color:#4d148c;font-weight:bold;">' . $this->escape_html($download_text) . '</a></td>
        </tr>
        </table>';

        $headers = array('Content-Type: text/html; charset=UTF-8');

        $sent = wp_mail(
            sanitize_email($customer_email),
            esc_html($subject),
            $message,
            $headers
        );

        // Mark regardless of wp_mail()'s boolean (some transports return
        // false after accepting) so a flaky mail layer can never cause a
        // resend loop; reported failures are logged for the merchant.
        update_post_meta($post_id, '_fshipping_confirmation_sent', time());

        if ( ! $sent ) {
            $logger = function_exists( 'wc_get_logger' ) ? wc_get_logger() : null;
            if ( $logger ) {
                $logger->warning(
                    sprintf(
                        /* translators: 1: shipment post id, 2: customer email. */
                        __( 'Shipment confirmation email for shipment #%1$s to %2$s reported a send failure.', 'teamzlab-fedex' ),
                        $post_id,
                        sanitize_email($customer_email)
                    ),
                    array( 'source' => 'teamz_fedex_email' )
                );
            }
        }

        return true;
    }

    /**
     * Escape helper for HTML output
     */
    private function escape_html($value) {
        return esc_html($value);
    }

    /**
     * Escape helper for URLs
     */
    private function escape_url($value) {
        return esc_url($value);
    }
}