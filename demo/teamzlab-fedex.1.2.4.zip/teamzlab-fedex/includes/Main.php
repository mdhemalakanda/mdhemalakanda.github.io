<?php
namespace FSHIPPING;

use FSHIPPING\Admin\OpenShipDraftsPage;
use FSHIPPING\Admin\OpenShipOrderMetaBox;
use FSHIPPING\Admin\PickupHistoryPage;
use FSHIPPING\Admin\ProductBoxPage;
use FSHIPPING\OpenShip\AjaxHandler as OpenShipAjaxHandler;
use FSHIPPING\OpenShip\OrderStatuses;
use FSHIPPING\Ajax\RateQuoteEndpoint;
use FSHIPPING\Ajax\TrackingWebhookReceiver;
use FSHIPPING\CPT\Shipments;
use FSHIPPING\Dashboard\Settings;
use FSHIPPING\Dashboard\Widget;
use FSHIPPING\Events\AdvancedServicesInjector;
use FSHIPPING\Events\CustomsAlerts;
use FSHIPPING\Events\DeliveryUpdates;
use FSHIPPING\Events\ETDOrchestrator;
use FSHIPPING\Events\ProductBoxPayloadInjector;
use FSHIPPING\Events\RuntimeIntegrator;
use FSHIPPING\Events\ShipmentGuard;
use FSHIPPING\Events\SpecialServicesInjector;
use FSHIPPING\Events\TrackingTimelineRecorder;
use FSHIPPING\Frontend\Checkout;
use FSHIPPING\Frontend\ReturnPortalHandler;
use FSHIPPING\Frontend\Shortcodes;
use FSHIPPING\Licensing\Freemius;
use FSHIPPING\Shipping\OneRateComparator;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Trade\CommercialInvoiceBuilder;
/**
 * This is main plugin file.
 * 
 * @since 1.0
 */
defined('ABSPATH') || exit;

class Main {
    use SingletonTrait;

    /**
     * Get token.
     * 
     * @return void
     */
    public function init() {
        // Licensing first — Freemius needs to register its admin hooks
        // before Menu / Settings run, so the opt-in + account pages
        // slot into the right place. No-ops when FSHIPPING_DISTRO is
        // 'codecanyon' or the Freemius keys/SDK aren't present.
        Freemius::instance()->init();

        Menu::instance()->init();
        OrderStatuses::instance()->init();
        OpenShipDraftsPage::instance()->init();
        OpenShipOrderMetaBox::instance()->init();
        OpenShipAjaxHandler::instance()->init();
        Settings::instance()->init();
        Email\ShipmentConfirmation::instance()->init();
        Schedule\Shipment::instance()->init();
        Checkout::instance()->init();
        Assets::instance()->init();
        Shipments::instance()->init();
        Ajax::instance()->init();
        Order::instance()->init();

        // New in 1.1: shortcodes, dashboard widget, AIV webhook receiver,
        // AIV → order-status event handler, and public rate-quote REST
        // endpoint (for the embeddable calculator widget).
        Shortcodes::instance()->init();
        Widget::instance()->init();
        TrackingWebhookReceiver::instance()->init();
        DeliveryUpdates::instance()->init();
        CustomsAlerts::instance()->init();
        ShipmentGuard::instance()->init();
        SpecialServicesInjector::instance()->init();
        ETDOrchestrator::instance()->init();
        RateQuoteEndpoint::instance()->init();

        // v1.2 admin UIs (fedex-specific, consume kit helpers).
        PickupHistoryPage::instance()->init();
        ProductBoxPage::instance()->init();
        // Per-order FedEx sidebar meta boxes (special services, ETD invoice upload,
        // dangerous goods, service preferences, Freight accessorials) are not
        // registered — classes remain under includes/Admin/ for reference; injectors
        // still read _fshipping_* meta when set programmatically.

        // v1.2 Wave 2 — features nobody else ships.
        TrackingTimelineRecorder::instance()->init();
        AdvancedServicesInjector::instance()->init();
        ProductBoxPayloadInjector::instance()->init();

        // v1.2 runtime glue — Staging/SafetyNet, SavingsMeter reclassification
        // on the checkout path. See docs/GAP_AUDIT_2026-04-18.md §1.3.
        RuntimeIntegrator::instance()->init();

        // v1.2 gap-fills — let FedEx auto-generate commercial invoices,
        // surface One Rate flat-rate pricing alongside standard rates.
        CommercialInvoiceBuilder::instance()->init();
        OneRateComparator::instance()->init();

        // Return-tag portal POST handler (template_redirect).
        ReturnPortalHandler::instance()->init();
    }
}