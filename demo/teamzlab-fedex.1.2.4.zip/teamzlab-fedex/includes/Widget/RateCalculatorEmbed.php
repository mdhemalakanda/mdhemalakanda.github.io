<?php
namespace FSHIPPING\Widget;

use FSHIPPING\SingletonTrait;

/**
 * Embeddable FedEx rate calculator widget.
 *
 * Renders a public "quote your FedEx shipping in 10 seconds" widget that
 * any site can drop in via a `<script>` tag. Every embed earns a
 * branded "Powered by teamzlab-fedex" backlink — the viral loop.
 *
 * This class owns:
 * - Formatting raw Rates-API responses into widget-friendly rows.
 * - Building the copy-paste embed snippet.
 * - IP-bucket rate-limit helpers so the public endpoint can't be abused.
 *
 * The actual REST route wiring + Rates API orchestration live in a thin
 * companion class that depends on a live WP install (to be wired during
 * Wave 3 launch).
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class RateCalculatorEmbed {
    use SingletonTrait;

    public const DEFAULT_RATE_LIMIT_PER_HOUR = 30;

    /**
     * Format a raw Rates API response into widget-friendly rows.
     *
     * @param array $raw Response body from /rate/v1/rates/quotes.
     * @param string $currency ISO 4217 hint for display fallback.
     * @return array<int,array{service:string,label:string,total:float,currency:string,eta:string}>
     * @since 1.2
     */
    public function format_quotes(array $raw, string $currency = 'USD'): array {
        $rates = $raw['output']['rateReplyDetails'] ?? [];
        if (!is_array($rates)) {
            return [];
        }

        $rows = [];
        foreach ($rates as $rate) {
            if (!is_array($rate)) {
                continue;
            }
            $first = $rate['ratedShipmentDetails'][0] ?? [];
            $total = (float) ($first['totalNetCharge'] ?? ($first['totalBaseCharge'] ?? 0));
            $cur   = (string) ($first['currency']     ?? $currency);
            $rows[] = [
                'service'  => (string) ($rate['serviceType'] ?? ''),
                'label'    => (string) ($rate['serviceName'] ?? ($rate['serviceType'] ?? 'FedEx service')),
                'total'    => round($total, 2),
                'currency' => $cur,
                'eta'      => (string) ($rate['commit']['dateDetail']['dayFormat'] ?? ($rate['commit']['derivedDeliveryDate'] ?? '')),
            ];
        }

        usort($rows, static fn($a, $b) => $a['total'] <=> $b['total']);
        return $rows;
    }

    /**
     * Build the copy-paste embed snippet for the merchant's site.
     *
     * @param string $site_url Tool domain (e.g. `https://tool.teamzlab.com`).
     * @param array<string,string> $overrides Optional data-* defaults.
     * @return string Valid HTML snippet.
     * @since 1.2
     */
    public function build_embed_snippet(string $site_url, array $overrides = []): string {
        $site_url = rtrim($site_url, '/');
        if ($site_url === '') {
            return '';
        }

        $data_attrs = '';
        foreach ($overrides as $key => $value) {
            $slug = preg_replace('/[^a-z0-9_-]/', '', strtolower((string) $key));
            if ($slug === '') {
                continue;
            }
            $data_attrs .= sprintf(' data-%s="%s"', $slug, htmlspecialchars((string) $value, ENT_QUOTES));
        }

        $script = $site_url . '/widget/fedex-rates.js';
        return sprintf(
            '<div class="fshipping-rate-widget"%s></div>' . "\n" .
            '%s' .
            '<!-- Powered by teamzlab-fedex: %s -->',
            $data_attrs,
            wp_get_script_tag([
                'async' => true,
                'src'   => $script,
            ]),
            htmlspecialchars($site_url, ENT_QUOTES)
        );
    }

    /**
     * Rate-limit bucket key for a given IP + hour.
     *
     * @param string $ip          Requestor IP (any format).
     * @param int    $hour_bucket UTC hour bucket, e.g. (int) floor(time() / 3600).
     * @return string
     * @since 1.2
     */
    public function rate_limit_key(string $ip, int $hour_bucket): string {
        // Hash the IP so the transient key never contains PII in plain text.
        $ip_hash = substr(hash('sha256', trim($ip)), 0, 16);
        return 'fshipping_rlw_' . $ip_hash . '_' . $hour_bucket;
    }

    /**
     * @param int $count Current bucket count.
     * @param int $limit Max per hour.
     * @return bool
     * @since 1.2
     */
    public function is_rate_limited(int $count, int $limit = self::DEFAULT_RATE_LIMIT_PER_HOUR): bool {
        return $count >= max(1, $limit);
    }

    /**
     * Normalize a raw widget input payload.
     *
     * @param array $input
     * @return array{origin:string,destination:string,weight:float,weight_unit:string,length:float,width:float,height:float,dim_unit:string,country:string}
     * @since 1.2
     */
    public function normalize_input(array $input): array {
        return [
            'origin'      => sanitize_text_field((string) ($input['origin']      ?? '')),
            'destination' => sanitize_text_field((string) ($input['destination'] ?? '')),
            'weight'      => (float)  ($input['weight']       ?? 0),
            'weight_unit' => strtoupper(sanitize_text_field((string) ($input['weight_unit'] ?? 'LB'))),
            'length'      => (float)  ($input['length']  ?? 0),
            'width'       => (float)  ($input['width']   ?? 0),
            'height'      => (float)  ($input['height']  ?? 0),
            'dim_unit'    => strtoupper(sanitize_text_field((string) ($input['dim_unit'] ?? 'IN'))),
            'country'     => strtoupper(sanitize_text_field((string) ($input['country']  ?? 'US'))),
        ];
    }
}
