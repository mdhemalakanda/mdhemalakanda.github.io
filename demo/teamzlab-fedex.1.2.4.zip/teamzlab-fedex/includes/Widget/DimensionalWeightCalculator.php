<?php
namespace FSHIPPING\Widget;

use FSHIPPING\SingletonTrait;

/**
 * Pure-client-side FedEx dimensional-weight calculator.
 *
 * Renders a form + inline JS that applies FedEx's official dim divisors
 * (139 imperial / 5000 metric) to L×W×H and compares against the actual
 * weight. No API calls — this is a landing-page tool built for the
 * `fedex dimensional weight` keyword (147 Bing searches/mo per
 * docs/SEO_AUDIT_2026-04-18.md).
 *
 * Registered as `[fshipping_dim_weight]` via Frontend\Shortcodes.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class DimensionalWeightCalculator {
    use SingletonTrait;

    /** FedEx US-domestic imperial dim divisor (in → lb). */
    public const DIM_DIVISOR_IMPERIAL = 139;

    /** FedEx international metric dim divisor (cm → kg). */
    public const DIM_DIVISOR_METRIC = 5000;

    /**
     * Compute dim weight given L×W×H and a unit system.
     *
     * @param float  $l
     * @param float  $w
     * @param float  $h
     * @param string $unit 'IN' (default) or 'CM'.
     * @return float Dimensional weight rounded to 2 decimals. Returns 0.0
     *               if any dimension is <= 0.
     * @since 1.2
     */
    public function dim_weight(float $l, float $w, float $h, string $unit = 'IN'): float {
        if ($l <= 0 || $w <= 0 || $h <= 0) {
            return 0.0;
        }
        $divisor = strtoupper($unit) === 'CM' ? self::DIM_DIVISOR_METRIC : self::DIM_DIVISOR_IMPERIAL;
        return round(($l * $w * $h) / $divisor, 2);
    }

    /**
     * FedEx bills the greater of actual vs. dim weight.
     *
     * @param float $actual
     * @param float $dim
     * @return float
     * @since 1.2
     */
    public function billed_weight(float $actual, float $dim): float {
        return max($actual, $dim);
    }

    /**
     * Render the calculator HTML + inline JS. Safe to embed on any page
     * via the `[fshipping_dim_weight]` shortcode.
     *
     * @param array $atts Supported: `unit` ('IN'|'CM', default 'IN').
     * @return string
     * @since 1.2
     */
    public function render(array $atts = []): string {
        $default_unit = isset($atts['unit']) && in_array(strtoupper((string) $atts['unit']), ['IN', 'CM'], true)
            ? strtoupper((string) $atts['unit'])
            : 'IN';
        $divisor_in = self::DIM_DIVISOR_IMPERIAL;
        $divisor_cm = self::DIM_DIVISOR_METRIC;

        ob_start();

        $id_length = wp_unique_id('fshipping-dim-length-');
        $id_width  = wp_unique_id('fshipping-dim-width-');
        $id_height = wp_unique_id('fshipping-dim-height-');
        $id_unit   = wp_unique_id('fshipping-dim-unit-');
        $id_actual = wp_unique_id('fshipping-dim-actual-');
        ?>
        <div class="fshipping-dim-calc" data-default-unit="<?php echo esc_attr($default_unit); ?>">
            <form class="fshipping-dim-calc-form">
                <header class="fshipping-dim-calc-head">
                    <span class="fshipping-dim-calc-chip" aria-hidden="true">Fed<span class="fshipping-dim-calc-chip-ex">Ex</span></span>
                    <div>
                        <h3 class="fshipping-dim-calc-title"><?php esc_html_e('FedEx dimensional weight calculator', 'teamzlab-fedex'); ?></h3>
                        <p class="fshipping-dim-calc-sub"><?php esc_html_e('Carriers bill the greater of actual or dimensional weight — see which one applies to your package.', 'teamzlab-fedex'); ?></p>
                    </div>
                </header>
                <div class="fshipping-dim-calc-grid">
                    <div class="fshipping-dim-calc-field">
                        <label for="<?php echo esc_attr($id_length); ?>"><?php esc_html_e('Length', 'teamzlab-fedex'); ?></label>
                        <div class="fshipping-dim-calc-control">
                            <input type="number" id="<?php echo esc_attr($id_length); ?>" name="length" inputmode="decimal" min="0" step="0.01" required>
                            <span class="fshipping-dim-calc-suffix" data-fshipping-suffix="dim">in</span>
                        </div>
                    </div>
                    <div class="fshipping-dim-calc-field">
                        <label for="<?php echo esc_attr($id_width); ?>"><?php esc_html_e('Width', 'teamzlab-fedex'); ?></label>
                        <div class="fshipping-dim-calc-control">
                            <input type="number" id="<?php echo esc_attr($id_width); ?>" name="width" inputmode="decimal" min="0" step="0.01" required>
                            <span class="fshipping-dim-calc-suffix" data-fshipping-suffix="dim">in</span>
                        </div>
                    </div>
                    <div class="fshipping-dim-calc-field">
                        <label for="<?php echo esc_attr($id_height); ?>"><?php esc_html_e('Height', 'teamzlab-fedex'); ?></label>
                        <div class="fshipping-dim-calc-control">
                            <input type="number" id="<?php echo esc_attr($id_height); ?>" name="height" inputmode="decimal" min="0" step="0.01" required>
                            <span class="fshipping-dim-calc-suffix" data-fshipping-suffix="dim">in</span>
                        </div>
                    </div>
                    <div class="fshipping-dim-calc-field">
                        <label for="<?php echo esc_attr($id_unit); ?>"><?php esc_html_e('Units', 'teamzlab-fedex'); ?></label>
                        <div class="fshipping-dim-calc-control">
                            <select id="<?php echo esc_attr($id_unit); ?>" name="unit">
                                <option value="IN"<?php echo $default_unit === 'IN' ? ' selected' : ''; ?>><?php esc_html_e('Inches (lb)', 'teamzlab-fedex'); ?></option>
                                <option value="CM"<?php echo $default_unit === 'CM' ? ' selected' : ''; ?>><?php esc_html_e('Centimeters (kg)', 'teamzlab-fedex'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="fshipping-dim-calc-field">
                        <label for="<?php echo esc_attr($id_actual); ?>"><?php esc_html_e('Actual weight', 'teamzlab-fedex'); ?> <span class="fshipping-dim-calc-optional">(<?php esc_html_e('optional', 'teamzlab-fedex'); ?>)</span></label>
                        <div class="fshipping-dim-calc-control">
                            <input type="number" id="<?php echo esc_attr($id_actual); ?>" name="actual_weight" inputmode="decimal" min="0" step="0.01">
                            <span class="fshipping-dim-calc-suffix" data-fshipping-suffix="weight">lb</span>
                        </div>
                    </div>
                </div>
                <button type="submit" class="fshipping-dim-calc-submit"><?php esc_html_e('Calculate dimensional weight', 'teamzlab-fedex'); ?></button>
                <p class="fshipping-dim-calc-formula" data-fshipping-formula><?php
                    echo esc_html(sprintf(
                        /* translators: %d: imperial dim divisor. */
                        __('Formula: (L × W × H) ÷ %d — inches to pounds.', 'teamzlab-fedex'),
                        (int) $divisor_in
                    ));
                ?></p>
            </form>
            <div class="fshipping-dim-calc-output" aria-live="polite"></div>
        </div>
        <script>
        (function () {
            var SUFFIX_DIM    = { IN: 'in', CM: 'cm' };
            var SUFFIX_WEIGHT = { IN: 'lb', CM: 'kg' };
            var FORMULA = {
                IN: '<?php echo esc_js(sprintf(
                    /* translators: %d: imperial dim divisor. */
                    __('Formula: (L × W × H) ÷ %d — inches to pounds.', 'teamzlab-fedex'),
                    (int) $divisor_in
                )); ?>',
                CM: '<?php echo esc_js(sprintf(
                    /* translators: %d: metric dim divisor. */
                    __('Formula: (L × W × H) ÷ %d — centimeters to kilograms.', 'teamzlab-fedex'),
                    (int) $divisor_cm
                )); ?>'
            };
            var LBL_DIM    = '<?php echo esc_js(__('Dimensional weight', 'teamzlab-fedex')); ?>';
            var LBL_ACTUAL = '<?php echo esc_js(__('Actual weight', 'teamzlab-fedex')); ?>';
            var LBL_BILLED = '<?php echo esc_js(__('Billable weight', 'teamzlab-fedex')); ?>';
            var NOTE       = '<?php echo esc_js(__('FedEx bills the greater of actual and dimensional weight.', 'teamzlab-fedex')); ?>';
            var ERR        = '<?php echo esc_js(__('Enter length, width, and height greater than zero.', 'teamzlab-fedex')); ?>';

            function fmt(n) {
                return String(Math.round(n * 100) / 100);
            }

            function tile(label, value, suffix, primary) {
                return '<div class="fshipping-dim-calc-tile' + (primary ? ' is-primary' : '') + '">' +
                    '<span class="fshipping-dim-calc-tilelabel">' + label + '</span>' +
                    '<span class="fshipping-dim-calc-tilevalue">' + value +
                    '<small>' + suffix + '</small></span></div>';
            }

            var roots = document.querySelectorAll('.fshipping-dim-calc:not([data-bound])');
            roots.forEach(function (root) {
                root.setAttribute('data-bound', '1');
                var form = root.querySelector('.fshipping-dim-calc-form');
                var out  = root.querySelector('.fshipping-dim-calc-output');
                var els  = form.elements;

                function syncUnits() {
                    var unit = els.namedItem('unit').value;
                    root.querySelectorAll('[data-fshipping-suffix="dim"]').forEach(function (el) {
                        el.textContent = SUFFIX_DIM[unit];
                    });
                    root.querySelectorAll('[data-fshipping-suffix="weight"]').forEach(function (el) {
                        el.textContent = SUFFIX_WEIGHT[unit];
                    });
                    var formula = root.querySelector('[data-fshipping-formula]');
                    if (formula) {
                        formula.textContent = FORMULA[unit];
                    }
                }

                function calculate() {
                    var L = parseFloat(els.namedItem('length').value || 0);
                    var W = parseFloat(els.namedItem('width').value || 0);
                    var H = parseFloat(els.namedItem('height').value || 0);
                    var A = parseFloat(els.namedItem('actual_weight').value || 0);
                    var unit = els.namedItem('unit').value;
                    var div  = unit === 'CM' ? <?php echo (int) $divisor_cm; ?> : <?php echo (int) $divisor_in; ?>;
                    if (!(L > 0 && W > 0 && H > 0)) {
                        root.classList.remove('is-calculated');
                        out.innerHTML = '<p class="fshipping-dim-calc-error">' + ERR + '</p>';
                        return;
                    }
                    var dim    = Math.round(((L * W * H) / div) * 100) / 100;
                    var billed = Math.max(A, dim);
                    var wSuf   = SUFFIX_WEIGHT[unit];
                    root.classList.add('is-calculated');
                    out.innerHTML =
                        '<div class="fshipping-dim-calc-results">' +
                            tile(LBL_DIM, fmt(dim), wSuf, false) +
                            tile(LBL_ACTUAL, A > 0 ? fmt(A) : '—', A > 0 ? wSuf : '', false) +
                            tile(LBL_BILLED, fmt(billed), wSuf, true) +
                        '</div>' +
                        '<p class="fshipping-dim-calc-note">' + NOTE + '</p>';
                }

                form.addEventListener('submit', function (ev) {
                    ev.preventDefault();
                    calculate();
                });

                // Once a result is on screen, keep it live as the user tweaks values.
                ['input', 'change'].forEach(function (evt) {
                    form.addEventListener(evt, function () {
                        syncUnits();
                        if (root.classList.contains('is-calculated')) {
                            calculate();
                        }
                    });
                });
            });
        })();
        </script>
        <?php
        return (string) ob_get_clean();
    }
}
