<?php
namespace FSHIPPING\OpenShip;

use FSHIPPING\HTTP\OpenShip;
use FSHIPPING\HTTP\Shipment;
use FSHIPPING\OpenShip\PackageLineExtras;
use FSHIPPING\Utils\Helper;

/**
 * Order meta keys and helpers for Advanced (Open Ship) fulfillment.
 *
 * @since 1.3
 */
defined('ABSPATH') || exit;

class Draft {
    public const META_FULFILLMENT_MODE   = '_fshipping_fulfillment_mode';
    /** FedEx **`shipmentIndex`** (open-shipment key; root **`index`** on create, e.g. `wc_order_{order_id}_{suffix}`). */
    public const META_SHIPMENT_INDEX     = '_fshipping_openship_shipment_index';
    /** Alias for {@see META_SHIPMENT_INDEX} (some integrations store `_fshipping_openship_index`). */
    public const META_OPENSHIP_INDEX_ALIAS = '_fshipping_openship_index';
    /** FedEx **`shipmentIdIndex`** (master tracking number from create). */
    public const META_SHIPMENT_ID_INDEX  = '_fshipping_openship_shipment_id_index';
    public const META_LIFECYCLE          = '_fshipping_openship_lifecycle';
    public const META_PACKAGES_JSON      = '_fshipping_openship_packages_json';
    public const META_CONFIRMED          = '_fshipping_openship_confirmed';
    public const META_CONFIRM_RESPONSE   = '_fshipping_openship_last_confirm_json';
    /** JSON array persisted for admin "Last FedEx response (packages)" table rows. */
    public const META_LAST_PUSH_ROWS     = '_fshipping_openship_last_push_rows';
    /** JSON array: per-piece saved label PDFs after Ship / Open Ship confirm — `[{"sequence":1,"tracking":"…","file_url":"…"},…]`. */
    public const META_PACKAGE_LABEL_FILES  = '_fshipping_package_label_files';
    /** JSON object map: package sequence => configured Product Box name (`{"1":"Large","2":"Large"}`) for label UI naming. */
    public const META_PACKAGE_BOX_NAME_MAP = '_fshipping_package_box_name_map';
    /** JSON array of packed boxes for admin list “Box info” column: `[{"box":"Large Box 1","products":[{"name":"Belt","qty":4}]},…]`. */
    public const META_PRODUCT_BOX_DISPLAY = '_fshipping_product_box_display_json';
    /** Local uploads URL for merged multi-piece label PDF when FedEx returns `shipmentDocuments` (MERGED_LABEL_DOCUMENTS). */
    public const META_MERGED_LABEL_FILE    = '_fshipping_merged_label_url';
    /** JSON: serviceType, pickupType, packagingType, paymentType (shippingChargesPayment) */
    public const META_SHIPMENT_OVERRIDES = '_fshipping_openship_shipment_overrides';
    /** JSON: international / customs patch (merged into requestedShipment at start — verify in FedEx portal). */
    public const META_INTL_CUSTOMS       = '_fshipping_openship_intl_customs';

    /**
     * FedEx Open Ship session state (create → add packages → confirm).
     * Distinct from {@see META_LIFECYCLE} (draft / in_progress / confirmed workflow).
     */
    public const META_SESSION_STATUS = '_fshipping_openship_session_status';

    public const SESSION_OPEN      = 'open';
    public const SESSION_ACTIVE    = 'active';
    public const SESSION_CLOSED    = 'closed';
    public const SESSION_ABANDONED = 'abandoned';

    public const LIFE_DRAFT       = 'draft';
    public const LIFE_IN_PROGRESS = 'in_progress';
    public const LIFE_CONFIRMED  = 'confirmed';

    /**
     * @param \WC_Order $order
     * @return bool
     */
    public static function is_advanced_order($order): bool {
        return 'advanced' === (string) $order->get_meta(self::META_FULFILLMENT_MODE, true);
    }

    /**
     * @param \WC_Order $order
     * @return bool
     */
    public static function is_locked($order): bool {
        return 'yes' === (string) $order->get_meta(self::META_CONFIRMED, true);
    }

    /**
     * Best URL to open/download “all” shipping-label PDFs in one file when FedEx provided one.
     *
     * Prefers merged multi-piece PDF (`_fshipping_merged_label_url`), else a single saved per-piece
     * file, else the order’s primary `_fedex_label_url` when no per-piece list exists. Returns
     * empty string when only multiple per-piece PDFs exist (no single combined file).
     *
     * @param \WC_Order $order
     * @return string Uploads URL or empty.
     */
    public static function best_all_labels_pdf_url($order): string {
        if (!is_object($order) || !method_exists($order, 'get_meta')) {
            return '';
        }
        $merged = (string) $order->get_meta(self::META_MERGED_LABEL_FILE, true);
        if ($merged !== '') {
            return $merged;
        }
        $raw = (string) $order->get_meta(self::META_PACKAGE_LABEL_FILES, true);
        $decoded = $raw !== '' ? json_decode($raw, true) : [];
        $urls    = [];
        if (is_array($decoded)) {
            foreach ($decoded as $row) {
                if (is_array($row) && !empty($row['file_url'])) {
                    $urls[] = (string) $row['file_url'];
                }
            }
        }
        if (count($urls) === 1) {
            return $urls[0];
        }
        if (count($urls) > 1) {
            return '';
        }

        return (string) $order->get_meta('_fedex_label_url', true);
    }

    /**
     * FedEx shipping method line as used by Shipment::prepare_shipment_payload.
     *
     * @param \WC_Order $order
     * @return array<string, mixed>|null
     */
    public static function get_fedex_shipping_line($order): ?array {
        if (!is_object($order) || !method_exists($order, 'get_shipping_methods')) {
            return null;
        }
        foreach ($order->get_shipping_methods() as $item) {
            if ($item->get_method_id() === 'fshipping_custom') {
                return [
                    'id'    => $item->get_method_id(),
                    'name'  => $item->get_name(),
                    'total' => $item->get_total(),
                    'meta'  => [
                        'service_type' => $item->get_meta('service_type'),
                        'currency'     => $item->get_meta('currency'),
                        'package'      => $item->get_meta('package'),
                    ],
                ];
            }
        }
        return null;
    }

    /**
     * @param \WC_Order $order
     * @return array<string, string>
     */
    public static function get_shipment_overrides($order): array {
        $raw = (string) $order->get_meta(self::META_SHIPMENT_OVERRIDES, true);
        if ($raw === '') {
            return [];
        }
        $d = json_decode($raw, true);
        return is_array($d) ? $d : [];
    }

    /**
     * @param \WC_Order            $order
     * @param array<string, mixed> $overrides
     * @return void
     */
    public static function set_shipment_overrides($order, array $overrides): void {
        $order->update_meta_data(self::META_SHIPMENT_OVERRIDES, wp_json_encode($overrides));
    }

    /**
     * Seed admin shipment controls from the first successful Ship-style payload (checkout).
     *
     * @param \WC_Order            $order
     * @param array<string, mixed> $requested_shipment From prepare_shipment_payload requestedShipment.
     * @return void
     */
    public static function seed_shipment_overrides_from_payload($order, array $requested_shipment): void {
        if ((string) $order->get_meta(self::META_SHIPMENT_OVERRIDES, true) !== '') {
            return;
        }
        $pay = isset($requested_shipment['shippingChargesPayment']) && is_array($requested_shipment['shippingChargesPayment'])
            ? $requested_shipment['shippingChargesPayment']
            : [];
        $payment_type = isset($pay['paymentType']) ? (string) $pay['paymentType'] : '';
        self::set_shipment_overrides($order, array_filter([
            'serviceType'   => isset($requested_shipment['serviceType']) ? (string) $requested_shipment['serviceType'] : '',
            'pickupType'    => isset($requested_shipment['pickupType']) ? (string) $requested_shipment['pickupType'] : '',
            'packagingType' => isset($requested_shipment['packagingType']) ? (string) $requested_shipment['packagingType'] : '',
            'paymentType'   => $payment_type,
        ]));
    }

    /**
     * Merge admin overrides + intl patch into requestedShipment fragment (Open Ship start).
     *
     * @param \WC_Order            $order
     * @param array<string, mixed> $requested_shipment
     * @return array<string, mixed>
     */
    public static function merge_overrides_into_requested_shipment($order, array $requested_shipment): array {
        $o = self::get_shipment_overrides($order);
        if (!empty($o['serviceType'])) {
            $requested_shipment['serviceType'] = sanitize_text_field((string) $o['serviceType']);
        }
        if (!empty($o['pickupType'])) {
            $requested_shipment['pickupType'] = sanitize_text_field((string) $o['pickupType']);
        }
        if (!empty($o['packagingType'])) {
            $requested_shipment['packagingType'] = sanitize_text_field((string) $o['packagingType']);
        }
        if (!empty($o['paymentType']) && isset($requested_shipment['shippingChargesPayment']) && is_array($requested_shipment['shippingChargesPayment'])) {
            $requested_shipment['shippingChargesPayment']['paymentType'] = sanitize_text_field((string) $o['paymentType']);
        }

        $intl_raw = (string) $order->get_meta(self::META_INTL_CUSTOMS, true);
        if ($intl_raw !== '') {
            $intl = json_decode($intl_raw, true);
            if (is_array($intl) && !empty($intl['requestedShipment_patch']) && is_array($intl['requestedShipment_patch'])) {
                $requested_shipment = array_replace_recursive($requested_shipment, $intl['requestedShipment_patch']);
            }
        }

        /**
         * Last-mile patch for Open Ship start requestedShipment (Advanced mode).
         *
         * @param array<string, mixed> $requested_shipment
         * @param \WC_Order            $order
         */
        return apply_filters('fshipping_openship_requested_shipment', $requested_shipment, $order);
    }

    /**
     * @param \WC_Order $order
     * @return array<int, array<string, mixed>>
     */
    public static function get_packages($order): array {
        $raw = (string) $order->get_meta(self::META_PACKAGES_JSON, true);
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * @param \WC_Order $order
     * @param array<int, array<string, mixed>> $packages
     * @return void
     */
    public static function set_packages($order, array $packages): void {
        $order->update_meta_data(self::META_PACKAGES_JSON, wp_json_encode($packages));
        $order->save();
    }

    /**
     * Normalize one package row from admin JSON.
     *
     * @param array<string, mixed> $row
     * @param int                  $index 1-based
     * @return array<string, mixed>
     */
    public static function normalize_package_row(array $row, int $index): array {
        $wunit = !empty($row['weight_unit']) && strtoupper((string) $row['weight_unit']) === 'KG' ? 'KG' : 'LB';
        $dunit = !empty($row['dimension_unit']) && strtoupper((string) $row['dimension_unit']) === 'CM' ? 'CM' : 'IN';
        $items = [];
        if (!empty($row['items']) && is_array($row['items'])) {
            foreach ($row['items'] as $it) {
                if (!is_array($it)) {
                    continue;
                }
                $oid = isset($it['order_item_id']) ? (int) $it['order_item_id'] : 0;
                $qty = isset($it['qty']) ? (int) $it['qty'] : 0;
                if ($oid > 0 && $qty > 0) {
                    $items[] = ['order_item_id' => $oid, 'qty' => $qty];
                }
            }
        }

        return [
            'local_id'              => isset($row['local_id']) ? (string) $row['local_id'] : (string) $index,
            'box_name'              => isset($row['box_name']) ? sanitize_text_field((string) $row['box_name']) : sprintf(/* translators: %d: box number */ __('Box %d', 'teamzlab-fedex'), $index),
            'fedex_package_id'      => isset($row['fedex_package_id']) ? sanitize_text_field((string) $row['fedex_package_id']) : '',
            'fedex_delete_id'       => isset($row['fedex_delete_id']) ? sanitize_text_field((string) $row['fedex_delete_id']) : '',
            'fedex_sequence'        => isset($row['fedex_sequence']) ? sanitize_text_field((string) $row['fedex_sequence']) : '',
            'weight'                => isset($row['weight']) ? (float) $row['weight'] : 1.0,
            'weight_unit'           => $wunit,
            'length'                => isset($row['length']) ? (int) $row['length'] : 10,
            'width'                 => isset($row['width']) ? (int) $row['width'] : 10,
            'height'                => isset($row['height']) ? (int) $row['height'] : 10,
            'dimension_unit'        => $dunit,
            'declared_value_amount' => isset($row['declared_value_amount']) ? (float) $row['declared_value_amount'] : 0.0,
            'declared_value_currency' => !empty($row['declared_value_currency']) ? sanitize_text_field((string) $row['declared_value_currency']) : 'USD',
            'items'                 => $items,
            'package_line_extras'   => PackageLineExtras::sanitize(
                isset($row['package_line_extras']) && is_array($row['package_line_extras']) ? $row['package_line_extras'] : []
            ),
        ];
    }

    /**
     * Cap each line's per-box qty so total allocated per order line never exceeds the line quantity.
     * Packages are processed in order (first boxes get priority).
     *
     * @param array<int, array<string, mixed>> $packages
     * @param \WC_Order                        $order
     * @return array<int, array<string, mixed>>
     */
    public static function clamp_package_line_items_to_order_quantities(array $packages, $order): array {
        $remaining = [];
        foreach ($order->get_items() as $iid => $item) {
            if (!is_object($item) || !method_exists($item, 'get_quantity')) {
                continue;
            }
            $remaining[(int) $iid] = max(0, (int) $item->get_quantity());
        }

        $out = [];
        foreach ($packages as $pkg) {
            if (!is_array($pkg)) {
                $out[] = $pkg;
                continue;
            }
            $items = [];
            if (!empty($pkg['items']) && is_array($pkg['items'])) {
                foreach ($pkg['items'] as $it) {
                    if (!is_array($it)) {
                        continue;
                    }
                    $oid = isset($it['order_item_id']) ? (int) $it['order_item_id'] : 0;
                    $qty = isset($it['qty']) ? (int) $it['qty'] : 0;
                    if ($oid < 1 || $qty < 1) {
                        continue;
                    }
                    $cap = $remaining[ $oid ] ?? 0;
                    $take = min($qty, $cap);
                    if ($take > 0) {
                        $items[] = ['order_item_id' => $oid, 'qty' => $take];
                        $remaining[ $oid ] = $cap - $take;
                    }
                }
            }
            $pkg['items'] = $items;
            $out[]        = $pkg;
        }

        return $out;
    }

    /**
     * Auto-fill each package row weight from assigned order-item quantities.
     *
     * Keeps the existing row weight when a package has no assigned items or when
     * all assigned products are weightless.
     *
     * @param array<int, array<string, mixed>> $packages
     * @param \WC_Order                        $order
     * @return array<int, array<string, mixed>>
     */
    public static function hydrate_package_weights_from_order_items(array $packages, $order): array {
        if (!is_object($order) || !method_exists($order, 'get_items')) {
            return $packages;
        }

        $order_items = [];
        foreach ($order->get_items() as $item_id => $item) {
            $order_items[(int) $item_id] = $item;
        }

        foreach ($packages as $idx => $pkg) {
            if (!is_array($pkg) || empty($pkg['items']) || !is_array($pkg['items'])) {
                continue;
            }

            $target_weight_unit = !empty($pkg['weight_unit']) && strtoupper((string) $pkg['weight_unit']) === 'KG'
                ? 'KG'
                : 'LB';
            $calculated_weight = 0.0;

            foreach ($pkg['items'] as $assigned) {
                if (!is_array($assigned)) {
                    continue;
                }
                $order_item_id = isset($assigned['order_item_id']) ? (int) $assigned['order_item_id'] : 0;
                $qty           = isset($assigned['qty']) ? (int) $assigned['qty'] : 0;
                if ($order_item_id <= 0 || $qty <= 0 || empty($order_items[$order_item_id])) {
                    continue;
                }

                $item    = $order_items[$order_item_id];
                $product = is_object($item) && method_exists($item, 'get_product') ? $item->get_product() : null;
                if (!is_object($product) || !method_exists($product, 'has_weight') || !$product->has_weight()) {
                    continue;
                }

                $product_weight = Helper::instance()->normalize_store_weight($product->get_weight(), $target_weight_unit);
                if ($product_weight > 0) {
                    $calculated_weight += ((float) $product_weight * $qty);
                }
            }

            if ($calculated_weight > 0) {
                $pkg['weight'] = round($calculated_weight, 3);
                $packages[$idx] = $pkg;
            }
        }

        return $packages;
    }

    /**
     * @param array<int, array<string, mixed>> $packages
     * @param \WC_Order                        $order
     * @return array{errors: array<int, string>, warnings: array<int, string>}
     */
    public static function validate_packages_for_admin(array $packages, $order): array {
        $errors   = [];
        $warnings = [];
        if (empty($packages)) {
            $errors[] = __('Add at least one package before saving or confirming.', 'teamzlab-fedex');
        }
        $currency = $order->get_currency() ?: 'USD';
        foreach ($packages as $i => $pkg) {
            $n = $i + 1;
            if (empty($pkg['weight']) || (float) $pkg['weight'] <= 0) {
                $errors[] = sprintf(
                    /* translators: %d: box index */
                    __('Box %d: weight must be greater than zero.', 'teamzlab-fedex'),
                    $n
                );
            }
            if (((float) ($pkg['weight'] ?? 0)) > 150 && ($pkg['weight_unit'] ?? 'LB') === 'LB') {
                $warnings[] = sprintf(
                    /* translators: %d: box index */
                    __('Box %d: weight over 150 lb — verify service limits.', 'teamzlab-fedex'),
                    $n
                );
            }
            foreach (['length', 'width', 'height'] as $dim) {
                if (!isset($pkg[$dim]) || (int) $pkg[$dim] <= 0) {
                    $errors[] = sprintf(
                        /* translators: %d: box index */
                        __('Box %d: all dimensions (L × W × H) must be greater than zero.', 'teamzlab-fedex'),
                        $n
                    );
                    break;
                }
            }
            if (!empty($pkg['declared_value_amount']) && (float) $pkg['declared_value_amount'] < 0) {
                $errors[] = sprintf(
                    /* translators: %d: box index */
                    __('Box %d: declared value cannot be negative.', 'teamzlab-fedex'),
                    $n
                );
            }
        }

        $street = (string) ($order->get_shipping_address_1() ?: $order->get_billing_address_1());
        if ($street === '') {
            $errors[] = __('Shipping/billing address is incomplete (street required).', 'teamzlab-fedex');
        }

        $allocated = [];
        foreach ($packages as $pkg) {
            if (empty($pkg['items']) || !is_array($pkg['items'])) {
                continue;
            }
            foreach ($pkg['items'] as $it) {
                if (!is_array($it) || empty($it['order_item_id']) || empty($it['qty'])) {
                    continue;
                }
                $oid = (int) $it['order_item_id'];
                $allocated[$oid] = ($allocated[$oid] ?? 0) + (int) $it['qty'];
            }
        }
        foreach ($order->get_items() as $item_id => $item) {
            if (!is_object($item) || !method_exists($item, 'get_quantity')) {
                continue;
            }
            $oid = (int) $item_id;
            $max = (int) $item->get_quantity();
            if ($max <= 0) {
                continue;
            }
            $used = $allocated[$oid] ?? 0;
            if ($used > $max) {
                $warnings[] = sprintf(
                    /* translators: 1: product name, 2: allocated qty, 3: max qty */
                    __('Product "%1$s": allocated %2$d in boxes exceeds order quantity (%3$d).', 'teamzlab-fedex'),
                    $item->get_name(),
                    $used,
                    $max
                );
            }
        }

        return ['errors' => $errors, 'warnings' => $warnings];
    }

    /**
     * Public FedEx Track URL for a package tracking number (Add Package / piece response).
     *
     * @param string $tracking_number
     * @return string Empty if unusable.
     */
    public static function fedex_public_tracking_url(string $tracking_number): string {
        $t = preg_replace('/\s+/', '', trim($tracking_number));
        if ($t === '' || strlen($t) < 4) {
            return '';
        }
        $url = 'https://www.fedex.com/fedextrack/?trknbr=' . rawurlencode($t);
        return apply_filters('fshipping_openship_public_tracking_url', $url, $t);
    }

    /**
     * First piece object from Add Open Shipment Packages response `output` (FedEx Ship API shapes vary).
     *
     * @param array<string, mixed> $output
     * @return array<string, mixed>
     */
    private static function first_piece_from_openship_add_output(array $output): array {
        if (!empty($output['pieceResponses'][0]) && is_array($output['pieceResponses'][0])) {
            return $output['pieceResponses'][0];
        }
        if (!empty($output['transactionShipments'][0]['pieceResponses'][0]) && is_array($output['transactionShipments'][0]['pieceResponses'][0])) {
            return $output['transactionShipments'][0]['pieceResponses'][0];
        }
        return [];
    }

    /**
     * @param array<string, mixed> $piece
     */
    private static function tracking_from_piece(array $piece): string {
        foreach (['trackingNumber', 'trackNumber'] as $key) {
            if (!empty($piece[$key]) && is_scalar($piece[$key])) {
                return sanitize_text_field((string) $piece[$key]);
            }
        }
        if (!empty($piece['trackingIds']) && is_array($piece['trackingIds'])) {
            foreach ($piece['trackingIds'] as $tid) {
                if (!is_array($tid)) {
                    continue;
                }
                foreach (['trackingNumber', 'trackingId'] as $k) {
                    if (!empty($tid[$k]) && is_scalar($tid[$k])) {
                        return sanitize_text_field((string) $tid[$k]);
                    }
                }
            }
        }
        return '';
    }

    /**
     * @param array<string, mixed> $piece
     */
    private static function package_sequence_from_piece(array $piece): string {
        foreach (['packageSequenceNumber', 'sequenceNumber', 'sequence'] as $key) {
            if (!isset($piece[$key]) || $piece[$key] === '') {
                continue;
            }
            return sanitize_text_field((string) $piece[$key]);
        }
        return '';
    }

    /**
     * Remove previously pushed Open Ship packages from the FedEx session before re-adding (avoids duplicates).
     *
     * PUT `/ship/v1/openshipments/packages/delete` uses `trackingIds[].trackingNumber`
     * from the package identifier FedEx returns; prefer `fedex_package_id` (tracking) over sequence when both exist.
     *
     * @param string                             $shipment_index
     * @param array<int, array<string, mixed>>   $packages
     * @return array<int, array<string, mixed>>
     */
    /**
     * @param array{shipmentIndex: string, shipmentIdIndex: string} $session
     */
    public static function remove_existing_packages_from_fedex_session(array $session, array $packages): array {
        $shipment_index    = sanitize_text_field($session['shipmentIndex'] ?? '');
        $shipment_id_index = sanitize_text_field($session['shipmentIdIndex'] ?? '');
        if ($shipment_id_index === '') {
            $shipment_id_index = $shipment_index;
        }
        if ($shipment_index === '') {
            return $packages;
        }
        $os = OpenShip::instance();
        foreach ($packages as $i => $pkg) {
            if (!is_array($pkg)) {
                continue;
            }
            $del = (string) ($pkg['fedex_package_id'] ?? $pkg['fedex_delete_id'] ?? '');
            if ($del !== '') {
                $os->delete_package($shipment_index, $del, $shipment_id_index);
            }
            unset(
                $packages[$i]['fedex_package_id'],
                $packages[$i]['fedex_delete_id'],
                $packages[$i]['fedex_sequence']
            );
        }
        return $packages;
    }

    /**
     * Pair of FedEx Open Ship identifiers for Add/Confirm/Delete (see `OpenShip::extract_openship_session_from_create_output()`).
     *
     * @param \WC_Order $order
     * @return array{shipmentIndex: string, shipmentIdIndex: string}
     */
    public static function get_openship_session_for_fedex($order): array {
        if (!is_object($order) || !method_exists($order, 'get_meta')) {
            return ['shipmentIndex' => '', 'shipmentIdIndex' => ''];
        }
        $sidx = (string) $order->get_meta(self::META_SHIPMENT_INDEX, true);
        if ($sidx === '') {
            $sidx = (string) $order->get_meta(self::META_OPENSHIP_INDEX_ALIAS, true);
        }
        $sid  = (string) $order->get_meta(self::META_SHIPMENT_ID_INDEX, true);
        if ($sidx !== '' && $sid === '') {
            $sid = $sidx;
        }

        return [
            'shipmentIndex'   => $sidx,
            'shipmentIdIndex' => $sid !== '' ? $sid : $sidx,
        ];
    }

    /**
     * Persist both **`shipmentIndex`** and **`shipmentIdIndex`** after **`openshipments/create`**.
     *
     * @param array{shipmentIndex: string, shipmentIdIndex: string} $session
     */
    public static function set_openship_session_meta($order, array $session): void {
        if (!is_object($order) || !method_exists($order, 'update_meta_data')) {
            return;
        }
        $order->update_meta_data(self::META_SHIPMENT_INDEX, sanitize_text_field($session['shipmentIndex'] ?? ''));
        $order->update_meta_data(self::META_SHIPMENT_ID_INDEX, sanitize_text_field($session['shipmentIdIndex'] ?? ''));
        $order->update_meta_data(self::META_SESSION_STATUS, self::SESSION_OPEN);
    }

    /**
     * New root `index` for POST openshipments/create (FedEx rejects duplicate active indexes — use a fresh string per create).
     *
     * @param \WC_Order $order
     */
    public static function allocate_unique_openship_index($order): string {
        $id = (is_object($order) && method_exists($order, 'get_id')) ? (int) $order->get_id() : 0;

        return self::allocate_unique_openship_index_for_order_id($id);
    }

    /**
     * Same unique pattern as {@see allocate_unique_openship_index()} without a full order object (HTTP layer, filters).
     *
     * Format: `wc_order_{order_id}_{6 hex}` (or `wc_order_{8 hex}` when **order_id** is 0) — short, readable, and never
     * reused across calls (entropy in the suffix avoids FedEx **`SHIPMENT.INDEX.INUSE`** on retries).
     */
    public static function allocate_unique_openship_index_for_order_id(int $order_id): string {
        $order_id = max(0, $order_id);
        $suffix   = substr(bin2hex(random_bytes(3)), 0, 6);
        if ($order_id > 0) {
            return sprintf('wc_order_%d_%s', $order_id, $suffix);
        }

        return 'wc_order_' . substr(bin2hex(random_bytes(4)), 0, 8);
    }

    /**
     * @param \WC_Order $order
     */
    public static function get_openship_session_status($order): string {
        if (!is_object($order) || !method_exists($order, 'get_meta')) {
            return '';
        }
        if (self::is_locked($order)) {
            return self::SESSION_CLOSED;
        }
        $explicit = (string) $order->get_meta(self::META_SESSION_STATUS, true);
        if ($explicit !== '') {
            return $explicit;
        }
        $idx = (string) $order->get_meta(self::META_SHIPMENT_INDEX, true);

        return $idx !== '' ? self::SESSION_OPEN : '';
    }

    /**
     * Whether "Restart FedEx session" should skip openshipments/create and reuse stored indices (OPEN / ACTIVE).
     *
     * @param \WC_Order $order
     */
    public static function should_reuse_openship_session_for_restart($order): bool {
        if (!self::is_advanced_order($order) || self::is_locked($order)) {
            return false;
        }
        $session = self::get_openship_session_for_fedex($order);
        if ($session['shipmentIndex'] === '' || $session['shipmentIdIndex'] === '') {
            return false;
        }
        $st = self::get_openship_session_status($order);
        if ($st === self::SESSION_ABANDONED || $st === self::SESSION_CLOSED) {
            return false;
        }

        return true;
    }

    /**
     * After a successful Add Package push, mark session ACTIVE when at least one box has a FedEx package id.
     *
     * @param \WC_Order                             $order
     * @param array<int, array<string, mixed>> $packages
     */
    public static function sync_openship_session_status_after_packages_pushed($order, array $packages): void {
        if (!is_object($order) || !method_exists($order, 'update_meta_data')) {
            return;
        }
        foreach ($packages as $pkg) {
            if (is_array($pkg) && !empty($pkg['fedex_package_id'])) {
                $order->update_meta_data(self::META_SESSION_STATUS, self::SESSION_ACTIVE);

                return;
            }
        }
    }

    /**
     * Whether a stored **`fedex_package_id`** is a plausible **piece** tracking id for **PUT …/packages** (not the
     * session master **`shipmentIdIndex`** or open-shipment **`shipmentIndex`**, which are often mistaken for piece ids).
     *
     * @param string               $local_id Trimmed package row id.
     * @param array{shipmentIndex: string, shipmentIdIndex: string} $session
     */
    private static function fedex_local_id_is_piece_tracking_for_modify(string $local_id, array $session): bool {
        if ($local_id === '') {
            return false;
        }
        $sid  = isset($session['shipmentIdIndex']) ? trim((string) $session['shipmentIdIndex']) : '';
        $sidx = isset($session['shipmentIndex']) ? trim((string) $session['shipmentIndex']) : '';
        if ($sid !== '' && $local_id === $sid) {
            return false;
        }
        if ($sidx !== '' && $local_id === $sidx) {
            return false;
        }

        return true;
    }

    /**
     * Best-effort: PUT update shipment (optional), then PUT modify or POST add per row (FedEx session must exist).
     *
     * @param \WC_Order $order
     * @param array     $packages
     * @param array<int, array<string, mixed>>|null $previous_packages Snapshot before this push (for deleting removed boxes on FedEx). Omit to skip orphan deletes.
     * @return array Updated rows with FedEx ids when returned.
     */
    public static function push_packages_to_fedex($order, array $packages, ?array $previous_packages = null): array {
        $d = self::push_packages_to_fedex_detailed($order, $packages, $previous_packages);

        return $d['packages'];
    }

    /**
     * Same as {@see push_packages_to_fedex()} plus per-step rows for the order admin UI + REST.
     *
     * @return array{packages: array<int, array<string, mixed>>, rows: array<int, array<string, mixed>>, update_shipment: array<string, mixed>}
     */
    public static function push_packages_to_fedex_detailed($order, array $packages, ?array $previous_packages = null): array {
        $rows              = [];
        $update_decoded    = [];
        $ran_update        = false;
        $session           = self::get_openship_session_for_fedex($order);
        if ($session['shipmentIndex'] === '') {
            return [
                'packages'         => $packages,
                'rows'             => [],
                'update_shipment'  => [],
            ];
        }
        $os = OpenShip::instance();

        $new_ids = [];
        foreach ($packages as $pkg) {
            if (is_array($pkg) && !empty($pkg['fedex_package_id'])) {
                $new_ids[] = (string) $pkg['fedex_package_id'];
            }
        }
        if (is_array($previous_packages) && $previous_packages !== []) {
            foreach ($previous_packages as $op) {
                if (!is_array($op)) {
                    continue;
                }
                $fid = (string) ($op['fedex_package_id'] ?? '');
                if ($fid === '' || in_array($fid, $new_ids, true)) {
                    continue;
                }
                $os->delete_package($session['shipmentIndex'], $fid, $session['shipmentIdIndex']);
            }
        }

        $ran_update = (bool) apply_filters('fshipping_openship_put_update_shipment_before_packages', true, $order, $packages, $session);
        if ($ran_update) {
            $update_decoded = $os->put_update_open_shipment_from_order(
                $order,
                $session['shipmentIndex'],
                $session['shipmentIdIndex'],
                max(1, count($packages))
            );
            self::delete_orphaned_remote_pieces_after_update($os, $session, $packages, $update_decoded);
        }

        $n = 0;
        foreach ($packages as $i => $pkg) {
            if (!is_array($pkg)) {
                continue;
            }
            ++$n;
            $local_track = isset($pkg['fedex_package_id']) ? trim((string) $pkg['fedex_package_id']) : '';
            $has_piece_id = $local_track !== '' && self::fedex_local_id_is_piece_tracking_for_modify($local_track, $session);
            $used_put     = $has_piece_id && apply_filters('fshipping_openship_use_put_modify_for_existing', true, $pkg, $order, $n);
            $retried_add  = false;
            if ($used_put) {
                $decoded = $os->put_modify_package_full(
                    $session['shipmentIndex'],
                    $pkg,
                    $session['shipmentIdIndex'],
                    $order,
                    $n
                );
                $put_err = OpenShip::first_fedex_error_message($decoded);
                if ($put_err !== ''
                    && OpenShip::is_likely_invalid_piece_tracking_for_modify($put_err)
                    && apply_filters('fshipping_openship_retry_add_after_modify_tracking_error', true, $put_err, $pkg, $order, $n)
                ) {
                    unset(
                        $packages[$i]['fedex_package_id'],
                        $packages[$i]['fedex_delete_id'],
                        $packages[$i]['fedex_sequence']
                    );
                    $pkg         = $packages[$i];
                    $used_put    = false;
                    $retried_add = true;
                    $decoded     = $os->add_package_full(
                        $session['shipmentIndex'],
                        $pkg,
                        $session['shipmentIdIndex'],
                        $order,
                        $n
                    );
                }
            } else {
                $decoded = $os->add_package_full(
                    $session['shipmentIndex'],
                    $pkg,
                    $session['shipmentIdIndex'],
                    $order,
                    $n
                );
            }
            $err_msg = OpenShip::first_fedex_error_message($decoded);
            $ok      = $decoded !== []
                && $err_msg === ''
                && (!isset($decoded['errors']) || !is_array($decoded['errors']) || $decoded['errors'] === []);
            $meta    = OpenShip::extract_transaction_and_packages_from_response($decoded);
            $out     = $decoded['output'] ?? [];
            if (!is_array($out)) {
                $out = [];
            }
            $piece = self::first_piece_from_openship_add_output($out);
            if ($piece === [] && $decoded !== []) {
                $piece = self::first_piece_from_openship_add_output($decoded);
            }
            $track = '';
            $seq   = '';
            if (!empty($piece)) {
                $track = self::tracking_from_piece($piece);
                $seq   = self::package_sequence_from_piece($piece);
                if ($track !== '') {
                    $packages[$i]['fedex_package_id'] = $track;
                }
                if ($seq !== '') {
                    $packages[$i]['fedex_delete_id'] = $seq;
                    $packages[$i]['fedex_sequence']  = $seq;
                }
            }
            if ($track === '' && !empty($meta['packages'][0]['trackingNumber'])) {
                $track = $meta['packages'][0]['trackingNumber'];
            }
            if ($seq === '' && !empty($meta['packages'][0]['sequenceNumber'])) {
                $seq = $meta['packages'][0]['sequenceNumber'];
            }
            $tid = $meta['transaction_id'];
            if ($tid === '' && !empty($decoded['output']['transactionId'])) {
                $tid = (string) $decoded['output']['transactionId'];
            }
            $rows[] = [
                'package_number'   => $n,
                'action'           => $used_put ? 'modify' : 'add',
                'success'          => $ok,
                'message'          => $ok
                    ? ($used_put
                        ? __('Package updated on FedEx.', 'teamzlab-fedex')
                        : ($retried_add
                            ? __('Package added on FedEx. (Previous piece id was not valid for update; saved as a new package.)', 'teamzlab-fedex')
                            : __('Package added on FedEx.', 'teamzlab-fedex')))
                    : ($err_msg !== '' ? $err_msg : __('FedEx returned an error for this package.', 'teamzlab-fedex')),
                'tracking_number'  => $track,
                'sequence_number'  => $seq,
                'transaction_id'   => $tid,
            ];
        }

        $upd_err = OpenShip::first_fedex_error_message($update_decoded);
        $upd_ok  = $ran_update && $upd_err === ''
            && (!isset($update_decoded['errors']) || !is_array($update_decoded['errors']) || $update_decoded['errors'] === []);
        array_unshift(
            $rows,
            [
                'package_number'  => 0,
                'action'          => 'update_shipment',
                'success'         => !$ran_update || $upd_ok,
                'message'         => !$ran_update
                    ? __('Update shipment step skipped (filter).', 'teamzlab-fedex')
                    : ($upd_ok
                        ? __('Open shipment updated at FedEx.', 'teamzlab-fedex')
                        : ($upd_err !== '' ? $upd_err : __('FedEx rejected shipment update.', 'teamzlab-fedex'))),
                'tracking_number' => '',
                'sequence_number' => '',
                'transaction_id'  => OpenShip::extract_transaction_and_packages_from_response($update_decoded)['transaction_id'],
            ]
        );

        return [
            'packages'        => $packages,
            'rows'            => $rows,
            'update_shipment' => $update_decoded,
        ];
    }

    /**
     * FedEx can retain old piece rows in an existing Open Ship session. If those stale rows have
     * declared/carriage values, confirm may fail even when current local boxes are valid.
     * After shipment-level PUT update, remove remote pieces not represented by current local rows.
     *
     * @param array{shipmentIndex: string, shipmentIdIndex: string} $session
     * @param array<int, array<string, mixed>>                      $packages
     * @param array<string, mixed>                                  $update_decoded
     */
    private static function delete_orphaned_remote_pieces_after_update(
        OpenShip $os,
        array $session,
        array $packages,
        array $update_decoded
    ): void {
        $shipment_index = sanitize_text_field((string) ($session['shipmentIndex'] ?? ''));
        $shipment_id_index = sanitize_text_field((string) ($session['shipmentIdIndex'] ?? ''));
        if ($shipment_index === '') {
            return;
        }
        if ($shipment_id_index === '') {
            $shipment_id_index = $shipment_index;
        }

        $keep_ids = [];
        foreach ($packages as $pkg) {
            if (!is_array($pkg) || empty($pkg['fedex_package_id'])) {
                continue;
            }
            $id = sanitize_text_field((string) $pkg['fedex_package_id']);
            if ($id !== '') {
                $keep_ids[$id] = true;
            }
        }
        $keep_ids[$shipment_id_index] = true;

        $remote_ids = self::extract_remote_piece_tracking_ids_from_update($update_decoded);
        foreach ($remote_ids as $remote_id) {
            if ($remote_id === '' || isset($keep_ids[$remote_id])) {
                continue;
            }
            $os->delete_package($shipment_index, $remote_id, $shipment_id_index);
        }
    }

    /**
     * @param array<string, mixed> $decoded
     * @return array<int, string>
     */
    private static function extract_remote_piece_tracking_ids_from_update(array $decoded): array {
        $ids = [];
        $out = isset($decoded['output']) && is_array($decoded['output']) ? $decoded['output'] : [];
        $tx0 = isset($out['transactionShipments'][0]) && is_array($out['transactionShipments'][0])
            ? $out['transactionShipments'][0]
            : [];

        if (!empty($tx0['pieceResponses']) && is_array($tx0['pieceResponses'])) {
            foreach ($tx0['pieceResponses'] as $piece) {
                if (!is_array($piece)) {
                    continue;
                }
                $tn = sanitize_text_field((string) ($piece['trackingNumber'] ?? ''));
                if ($tn !== '') {
                    $ids[] = $tn;
                }
            }
        }

        $csd = isset($tx0['completedShipmentDetail']) && is_array($tx0['completedShipmentDetail'])
            ? $tx0['completedShipmentDetail']
            : [];
        if (!empty($csd['completedPackageDetails']) && is_array($csd['completedPackageDetails'])) {
            foreach ($csd['completedPackageDetails'] as $cpd) {
                if (!is_array($cpd) || empty($cpd['trackingIds']) || !is_array($cpd['trackingIds'])) {
                    continue;
                }
                foreach ($cpd['trackingIds'] as $tid) {
                    if (!is_array($tid)) {
                        continue;
                    }
                    $tn = sanitize_text_field((string) ($tid['trackingNumber'] ?? ''));
                    if ($tn !== '') {
                        $ids[] = $tn;
                    }
                }
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * Store per–order-line FedEx piece tracking for the package row that contains the line (last write wins).
     * Call before {@see WC_Order::save()} so line-item meta persists with the order.
     *
     * @param array<int, array<string, mixed>> $packages
     */
    public static function sync_order_item_piece_tracking_meta($order, array $packages): void {
        if (!is_object($order) || !method_exists($order, 'get_items')) {
            return;
        }
        foreach ($order->get_items() as $item) {
            if (is_object($item) && method_exists($item, 'delete_meta_data')) {
                $item->delete_meta_data('_fshipping_openship_piece_tracking');
            }
        }
        foreach ($packages as $pkg) {
            if (!is_array($pkg) || empty($pkg['fedex_package_id'])) {
                continue;
            }
            $tr = sanitize_text_field((string) $pkg['fedex_package_id']);
            if ($tr === '' || empty($pkg['items']) || !is_array($pkg['items'])) {
                continue;
            }
            foreach ($pkg['items'] as $it) {
                if (!is_array($it) || empty($it['order_item_id'])) {
                    continue;
                }
                $oi = $order->get_item((int) $it['order_item_id']);
                if ($oi && method_exists($oi, 'update_meta_data')) {
                    $oi->update_meta_data('_fshipping_openship_piece_tracking', $tr);
                }
            }
        }
    }

    /**
     * Remove FedEx package identifiers from stored package rows (after session cancelled on FedEx).
     *
     * @param array<int, array<string, mixed>> $packages
     * @return array<int, array<string, mixed>>
     */
    public static function strip_fedex_package_identifiers_from_packages(array $packages): array {
        foreach ($packages as $i => $pkg) {
            if (!is_array($pkg)) {
                continue;
            }
            unset(
                $packages[$i]['fedex_package_id'],
                $packages[$i]['fedex_delete_id'],
                $packages[$i]['fedex_sequence']
            );
        }
        return $packages;
    }

    /**
     * Call FedEx **Delete Open Shipment** for the session index, then clear local session meta and package FedEx ids.
     *
     * If there is no session index, succeeds and strips any orphaned FedEx ids on package rows.
     *
     * @param \WC_Order $order
     * @param bool      $force_delete_api_audit_log When true, each FedEx **PUT …/openshipments/delete** writes full
     *                    URL / request / response to `wp-content/debug.log` even without `WP_DEBUG_LOG` (bulk delete).
     * @return array{ok:bool, error?:string}
     * @since 1.4
     */
    public static function cancel_fedex_open_shipment_and_clear($order, bool $force_delete_api_audit_log = false): array {
        if (!is_object($order) || !method_exists($order, 'get_id')) {
            return ['ok' => false, 'error' => __('Invalid order.', 'teamzlab-fedex')];
        }

        $session = self::get_openship_session_for_fedex($order);
        if ($session['shipmentIndex'] === '') {
            if ($force_delete_api_audit_log) {
                OpenShip::instance()->log_bulk_audit_openship_delete_not_applicable((int) $order->get_id());
            }
            $pk       = self::get_packages($order);
            $stripped = self::strip_fedex_package_identifiers_from_packages($pk);
            if (wp_json_encode($stripped) !== wp_json_encode($pk)) {
                $order->update_meta_data(self::META_PACKAGES_JSON, wp_json_encode(array_values($stripped)));
                $order->save();
            }
            return ['ok' => true];
        }

        $resp = OpenShip::instance()->delete_open_shipment(
            $session['shipmentIndex'],
            (int) $order->get_id(),
            $force_delete_api_audit_log
        );
        if ($resp === []) {
            return ['ok' => false, 'error' => __('FedEx delete returned no data (check connection and OAuth).', 'teamzlab-fedex')];
        }
        if (!empty($resp['errors']) && is_array($resp['errors'])) {
            $err = reset($resp['errors']);
            $msg = is_array($err) && !empty($err['message'])
                ? (string) $err['message']
                : __('FedEx delete failed.', 'teamzlab-fedex');
            return ['ok' => false, 'error' => $msg];
        }

        $order->update_meta_data(self::META_SHIPMENT_INDEX, '');
        $order->update_meta_data(self::META_SHIPMENT_ID_INDEX, '');
        $order->update_meta_data(self::META_SESSION_STATUS, self::SESSION_ABANDONED);
        $order->update_meta_data(self::META_LIFECYCLE, self::LIFE_DRAFT);
        $pk = self::get_packages($order);
        $pk = self::strip_fedex_package_identifiers_from_packages($pk);
        $order->update_meta_data(self::META_PACKAGES_JSON, wp_json_encode(array_values($pk)));
        $order->add_order_note(
            __('FedEx Open Ship: session cancelled on FedEx; local session and package FedEx ids cleared.', 'teamzlab-fedex'),
            false
        );
        $order->save();

        return ['ok' => true];
    }

    /**
     * Build local package rows from Ship-style requestedPackageLineItems (checkout snapshot).
     *
     * @param array<string, mixed> $requested_shipment
     * @return array<int, array<string, mixed>>
     */
    public static function packages_from_requested_shipment(array $requested_shipment): array {
        $lines = isset($requested_shipment['requestedPackageLineItems']) && is_array($requested_shipment['requestedPackageLineItems'])
            ? $requested_shipment['requestedPackageLineItems']
            : [];
        $out   = [];
        $n     = 0;
        foreach ($lines as $line) {
            if (!is_array($line)) {
                continue;
            }
            ++$n;
            $w = isset($line['weight']) && is_array($line['weight']) ? $line['weight'] : [];
            $d = isset($line['dimensions']) && is_array($line['dimensions']) ? $line['dimensions'] : [];
            $out[] = [
                'local_id'              => (string) $n,
                'box_name'              => sprintf(/* translators: %d: box number */ __('Box %d', 'teamzlab-fedex'), $n),
                'fedex_package_id'      => '',
                'fedex_delete_id'       => '',
                'weight'                => isset($w['value']) ? (float) $w['value'] : 1.0,
                'weight_unit'           => !empty($w['units']) ? (string) $w['units'] : 'LB',
                'length'                => isset($d['length']) ? (int) $d['length'] : 10,
                'width'                 => isset($d['width']) ? (int) $d['width'] : 10,
                'height'                => isset($d['height']) ? (int) $d['height'] : 10,
                'dimension_unit'        => !empty($d['units']) ? (string) $d['units'] : 'IN',
                'declared_value_amount' => 0.0,
                'declared_value_currency' => 'USD',
                'items'                 => [],
            ];
        }
        if (empty($out)) {
            $out[] = [
                'local_id'              => '1',
                'box_name'              => __('Box 1', 'teamzlab-fedex'),
                'fedex_package_id'      => '',
                'fedex_delete_id'       => '',
                'weight'                => 1.0,
                'weight_unit'           => 'LB',
                'length'                => 10,
                'width'                 => 10,
                'height'                => 10,
                'dimension_unit'        => 'IN',
                'declared_value_amount' => 0.0,
                'declared_value_currency' => 'USD',
                'items'                 => [],
            ];
        }
        return $out;
    }

    /**
     * Find fedex_shipping post linked to this order (after confirm).
     *
     * @param int $order_id
     * @return int 0 if none
     */
    public static function find_shipment_post_id_for_order(int $order_id): int {
        $q = new \WP_Query([
            'post_type'      => 'fedex_shipping',
            'post_status'    => 'any',
            'posts_per_page' => 1,
            'no_found_rows'  => true,
            'fields'         => 'ids',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Exact-match lookup on this plugin's fedex_shipping CPT by its _fedex_shipment_order_id meta after order confirm; single post, hard-limited to 1.
            'meta_query'     => [
                [
                    'key'   => '_fedex_shipment_order_id',
                    'value' => (string) $order_id,
                ],
            ],
        ]);
        if (empty($q->posts[0])) {
            return 0;
        }
        return (int) $q->posts[0];
    }
}
