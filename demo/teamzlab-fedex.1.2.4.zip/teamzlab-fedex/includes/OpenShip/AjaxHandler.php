<?php
namespace FSHIPPING\OpenShip;

use FSHIPPING\HTTP\OpenShip as OpenShipClient;
use FSHIPPING\HTTP\Shipment;
use FSHIPPING\OpenShip\OpenShipPushValidator;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\Helper;

/**
 * Admin Ajax for Open Ship draft orders.
 *
 * @since 1.3
 */
defined('ABSPATH') || exit;

class AjaxHandler {
    use SingletonTrait;

    public function init() {
        if (Helper::instance()->get_shipping_mode() !== 'advanced') {
            return;
        }
        add_action('wp_ajax_fshipping_openship_save_packages', [$this, 'save_packages']);
        add_action('wp_ajax_fshipping_openship_save_shipment_settings', [$this, 'save_shipment_settings']);
        add_action('wp_ajax_fshipping_openship_restart_session', [$this, 'restart_session']);
        add_action('wp_ajax_fshipping_openship_confirm', [$this, 'confirm']);
        add_action('wp_ajax_fshipping_openship_modify_package', [$this, 'modify_package']);
        add_action('wp_ajax_fshipping_openship_delete_package', [$this, 'delete_package_row']);
        add_action('wp_ajax_fshipping_openship_clear_all_packages', [$this, 'clear_all_packages']);
        add_action('rest_api_init', [$this, 'register_rest_routes']);
    }

    /**
     * @return void
     */
    public function register_rest_routes() {
        register_rest_route(
            'fshipping/v1',
            '/orders/(?P<order_id>\d+)/openship/push',
            [
                'methods'             => 'POST',
                'callback'            => [$this, 'rest_openship_push'],
                'permission_callback' => [$this, 'rest_permission_edit_orders'],
            ]
        );
    }

    /**
     * @return bool|\WP_Error
     */
    public function rest_permission_edit_orders() {
        if (!current_user_can('edit_shop_orders')) {
            return new \WP_Error('fshipping_forbidden', __('Forbidden.', 'teamzlab-fedex'), ['status' => 403]);
        }

        return true;
    }

    /**
     * POST `/wp-json/fshipping/v1/orders/{order_id}/openship/push` — same behavior as Ajax `fshipping_openship_save_packages`.
     * Send `X-WP-Nonce` (wp-api-fetch) and JSON body `{ "packages": [ ... ] }`.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response|\WP_Error
     */
    public function rest_openship_push(\WP_REST_Request $request) {
        $nonce = $request->get_header('X-WP-Nonce');
        if (!is_string($nonce) || !wp_verify_nonce($nonce, 'wp_rest')) {
            return new \WP_Error('fshipping_rest_nonce', __('Invalid REST nonce.', 'teamzlab-fedex'), ['status' => 403]);
        }

        $order_id = (int) $request['order_id'];
        $order    = wc_get_order($order_id);
        if (!$order || !Draft::is_advanced_order($order) || Draft::is_locked($order)) {
            return new \WP_Error('fshipping_bad_order', __('Invalid order.', 'teamzlab-fedex'), ['status' => 400]);
        }

        $body = $request->get_json_params();
        if (!is_array($body) || !isset($body['packages']) || !is_array($body['packages'])) {
            return new \WP_Error('fshipping_bad_body', __('JSON body must include a packages array.', 'teamzlab-fedex'), ['status' => 400]);
        }

        $indexed = $this->parse_packages_from_decoded($order, $body['packages']);
        if (null === $indexed) {
            return new \WP_Error('fshipping_bad_packages', __('Invalid packages data.', 'teamzlab-fedex'), ['status' => 400]);
        }

        $validation = Draft::validate_packages_for_admin($indexed, $order);
        $push_val   = OpenShipPushValidator::validate($indexed, $order);
        $validation['errors']   = array_merge($validation['errors'], $push_val['errors']);
        $validation['warnings'] = array_merge($validation['warnings'], $push_val['warnings']);
        if (!empty($validation['errors'])) {
            return new \WP_Error(
                'fshipping_validation',
                implode("\n\n", $validation['errors']),
                [
                    'status'   => 400,
                    'errors'   => $validation['errors'],
                    'warnings' => $validation['warnings'],
                ]
            );
        }

        $result = $this->run_save_packages_push($order_id, $order, $indexed, $validation['warnings']);
        if (is_wp_error($result)) {
            $data = $result->get_error_data();
            $msg  = $result->get_error_message();
            $code = 400;
            if (is_array($data) && isset($data['status'])) {
                $code = (int) $data['status'];
            }

            return new \WP_Error($result->get_error_code(), $msg, is_array($data) ? $data : []);
        }

        return new \WP_REST_Response($result, 200);
    }

    /**
     * @param array<int, mixed> $decoded
     * @return array<int, array<string, mixed>>|null
     */
    private function parse_packages_from_decoded(\WC_Order $order, array $decoded): ?array {
        $indexed = [];
        $n       = 0;
        foreach ($decoded as $row) {
            if (!is_array($row)) {
                continue;
            }
            ++$n;
            $indexed[] = Draft::normalize_package_row($row, $n);
        }

        $indexed = Draft::clamp_package_line_items_to_order_quantities($indexed, $order);
        return Draft::hydrate_package_weights_from_order_items($indexed, $order);
    }

    /**
     * FedEx /openshipments/create returned no usable output — surface API errors when present.
     *
     * @param string|null $extra_note Appended to the summary (e.g. missing session index after HTTP 200).
     */
    private function json_error_openship_start_failed(?string $extra_note = null): void {
        $e = $this->wp_error_openship_start_failed($extra_note);
        $data = $e->get_error_data();
        if (!is_array($data)) {
            wp_send_json_error(['message' => $e->get_error_message()], 400);

            return;
        }
        $code = isset($data['status']) ? (int) $data['status'] : 400;
        unset($data['status']);
        wp_send_json_error($data, $code);
    }

    /**
     * Parse packages JSON and normalize rows.
     *
     * @return array<int, array<string, mixed>>|null
     */
    private function parse_packages_from_request(\WC_Order $order): ?array {
        check_ajax_referer('fshipping_openship', 'nonce');

        // Raw JSON string: validated by json_decode() below, every field is
        // sanitized downstream in Draft::normalize_package_row(). FILTER_DEFAULT
        // keeps the payload byte-for-byte intact.
        $raw = isset($_POST['packages']) ? filter_var(wp_unslash($_POST['packages']), FILTER_DEFAULT) : '[]';
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return null;
        }
        $indexed = [];
        $n       = 0;
        foreach ($decoded as $row) {
            if (!is_array($row)) {
                continue;
            }
            ++$n;
            $indexed[] = Draft::normalize_package_row($row, $n);
        }

        $indexed = Draft::clamp_package_line_items_to_order_quantities($indexed, $order);
        return Draft::hydrate_package_weights_from_order_items($indexed, $order);
    }

    /**
     * Save packages and push to FedEx (Add Package / auto-start session when index is empty).
     *
     * @return void
     */
    public function save_packages() {
        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(['message' => __('Forbidden.', 'teamzlab-fedex')], 403);
        }
        check_ajax_referer('fshipping_openship', 'nonce');

        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        $order    = wc_get_order($order_id);
        if (!$order || !Draft::is_advanced_order($order) || Draft::is_locked($order)) {
            wp_send_json_error(['message' => __('Invalid order.', 'teamzlab-fedex')], 400);
        }

        $indexed = $this->parse_packages_from_request($order);
        if (null === $indexed) {
            wp_send_json_error(['message' => __('Invalid packages JSON.', 'teamzlab-fedex')], 400);
        }

        $validation = Draft::validate_packages_for_admin($indexed, $order);
        $push_val   = OpenShipPushValidator::validate($indexed, $order);
        $validation['errors']   = array_merge($validation['errors'], $push_val['errors']);
        $validation['warnings'] = array_merge($validation['warnings'], $push_val['warnings']);
        if (!empty($validation['errors'])) {
            wp_send_json_error([
                'message'  => implode("\n\n", $validation['errors']),
                'errors'   => $validation['errors'],
                'warnings' => $validation['warnings'],
            ], 400);
        }

        $result = $this->run_save_packages_push($order_id, $order, $indexed, $validation['warnings']);
        if (is_wp_error($result)) {
            $data = $result->get_error_data();
            if (!is_array($data)) {
                wp_send_json_error(['message' => $result->get_error_message()], 400);

                return;
            }
            $code = isset($data['status']) ? (int) $data['status'] : 400;
            unset($data['status']);
            wp_send_json_error($data, $code);

            return;
        }

        wp_send_json_success($result);
    }

    /**
     * Shared implementation for Save & push (Ajax + REST).
     *
     * @param array<int, string> $warnings
     * @return array<string, mixed>|\WP_Error
     */
    private function run_save_packages_push(int $order_id, \WC_Order $order, array $indexed, array $warnings) {
        $previous_packages_snapshot = Draft::get_packages($order);
        $index_at_start             = (string) $order->get_meta(Draft::META_SHIPMENT_INDEX, true);
        $index                      = $index_at_start;
        $session_auto_started       = false;

        if ($index === '') {
            $line = Draft::get_fedex_shipping_line($order);
            if (null === $line) {
                return new \WP_Error(
                    'fshipping_no_fedex_line',
                    __('No FedEx shipping method on this order. Cannot start an Open Ship session.', 'teamzlab-fedex'),
                    ['status' => 400]
                );
            }
            Draft::set_packages($order, $indexed);
            $out = OpenShipClient::instance()->start_from_order($order, $line);
            if ([] === $out || !OpenShipClient::openship_create_response_body_indicates_success($out)) {
                return $this->wp_error_openship_start_failed();
            }
            $session = OpenShipClient::instance()->extract_openship_session_from_create_output($out);
            if ($session['shipmentIndex'] === '' || $session['shipmentIdIndex'] === '') {
                return $this->wp_error_openship_start_failed(
                    __('FedEx returned a body without a usable Open Ship session index / master id. See openship_create_response in the browser console or wp-content/debug.log.', 'teamzlab-fedex')
                );
            }
            Draft::set_openship_session_meta($order, $session);
            $index = $session['shipmentIndex'];
            $order->update_meta_data(Draft::META_CONFIRMED, 'no');
            $session_auto_started = true;
        }

        if (OpenShipClient::should_log_openship_push_debug()) {
            $ctx = wp_json_encode($indexed, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (false === $ctx) {
                $ctx = '[]';
            }
            $suffix = $session_auto_started ? ' (session auto-started for this save)' : '';
            OpenShipClient::debug_log_push_message(
                '[teamzlab-fedex Open Ship save_packages push] order_id=' . $order_id
                . ' shipment_index=' . ($index !== '' ? $index : '(empty)') . $suffix
                . ' normalized_packages=' . $ctx
            );
        }

        $fedex_push_ran = false;
        $push_detail    = [
            'rows'             => [],
            'update_shipment'  => [],
            'packages'         => $indexed,
        ];
        if ($index !== '') {
            $push_detail = Draft::push_packages_to_fedex_detailed($order, $indexed, $previous_packages_snapshot);
            $indexed     = $push_detail['packages'];
            Draft::sync_openship_session_status_after_packages_pushed($order, $indexed);
            $fedex_push_ran = true;
        }

        Draft::sync_order_item_piece_tracking_meta($order, $indexed);
        Draft::set_packages($order, $indexed);
        $order->update_meta_data(Draft::META_LAST_PUSH_ROWS, wp_json_encode($push_detail['rows']));
        $order->update_meta_data(Draft::META_LIFECYCLE, Draft::LIFE_IN_PROGRESS);
        if ($fedex_push_ran) {
            if ($session_auto_started) {
                $order->add_order_note(
                    __('FedEx Open Ship: session started automatically; packages pushed to FedEx (Add Package).', 'teamzlab-fedex'),
                    false
                );
            } else {
                $order->add_order_note(__('FedEx Open Ship: packages saved and pushed to FedEx.', 'teamzlab-fedex'), false);
            }
        } else {
            $order->add_order_note(
                __('FedEx Open Ship: packages saved locally only — no session index. Use Restart FedEx session or ensure checkout created an Open Ship session.', 'teamzlab-fedex'),
                false
            );
        }
        $order->save();

        if ($fedex_push_ran) {
            $notice = $session_auto_started
                ? __('Open Ship session started and packages sent to FedEx (Add Package). See order notes / debug log.', 'teamzlab-fedex')
                : __('Packages saved. FedEx Add Package was called for each box (see order notes / debug log).', 'teamzlab-fedex');
        } else {
            $notice = __('Packages saved locally. FedEx was not called — missing Open Ship session index.', 'teamzlab-fedex');
        }

        $this->log_admin_action_debug(
            'save_push',
            $order_id,
            [
                'packages_before_push' => $indexed,
                'session_auto_started' => $session_auto_started,
                'had_session_index'    => $index_at_start !== '',
            ],
            [
                'push_rows'       => $push_detail['rows'],
                'update_shipment' => $push_detail['update_shipment'],
            ],
            true
        );

        return [
            'ok'                   => true,
            'warnings'             => $warnings,
            'notice'               => $notice,
            'fedex_push_ran'       => $fedex_push_ran,
            'had_session_index'    => $index_at_start !== '',
            'session_auto_started' => $session_auto_started,
            'push_rows'            => $push_detail['rows'],
            'shipment_index'       => (string) $order->get_meta(Draft::META_SHIPMENT_INDEX, true),
            'confirmed'            => Draft::is_locked($order),
        ];
    }

    /**
     * @return \WP_Error
     */
    private function wp_error_openship_start_failed(?string $extra_note = null): \WP_Error {
        $client = OpenShipClient::instance();
        $full   = $client->get_last_openship_start_full();
        $req    = $client->get_last_openship_create_request_payload();
        $msg    = OpenShipClient::summarize_fedex_start_failure($full);
        if ($extra_note !== null && $extra_note !== '') {
            $msg .= "\n\n" . $extra_note;
        }
        $base_url   = rtrim(Helper::instance()->get_base_url(), '/');
        $create_url = $base_url . '/ship/v1/openshipments/create';
        $api_line   = OpenShipClient::format_openship_debug_api_line('POST', $create_url);
        OpenShipClient::debug_log_push_json_blocks(
            'openshipments/create (admin — start failed)',
            [
                'FedEx REST URL'       => $create_url,
                'API (requested)'      => $api_line,
                'request (JSON body)'  => is_array($req) ? $req : [],
                'response (full body)' => is_array($full) ? $full : [],
            ],
            true
        );
        $enc = static function ($v): string {
            if (!is_array($v)) {
                return '';
            }
            $j = wp_json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

            return is_string($j) ? $j : '';
        };
        $data = [
            'message'                  => $msg,
            'openship_create_request'  => $enc(is_array($req) ? $req : []),
            'openship_create_response' => $enc(is_array($full) ? $full : []),
            'status'                   => 400,
        ];
        if (is_array($full) && !empty($full['errors'])) {
            $data['fedex_errors'] = $full['errors'];
        }

        return new \WP_Error('fshipping_openship_start_failed', $msg, $data);
    }

    /**
     * Persist service / pickup / payment overrides and optional international JSON.
     *
     * @return void
     */
    public function save_shipment_settings() {
        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(['message' => __('Forbidden.', 'teamzlab-fedex')], 403);
        }
        check_ajax_referer('fshipping_openship', 'nonce');

        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        $order    = wc_get_order($order_id);
        if (!$order || !Draft::is_advanced_order($order) || Draft::is_locked($order)) {
            wp_send_json_error(['message' => __('Invalid order.', 'teamzlab-fedex')], 400);
        }

        $overrides = [];
        if (isset($_POST['shipment_overrides'])) {
            // Raw JSON string: only whitelisted keys survive, sanitized below. FILTER_DEFAULT keeps the payload intact.
            $raw = filter_var(wp_unslash($_POST['shipment_overrides']), FILTER_DEFAULT);
            $d   = is_string($raw) ? json_decode($raw, true) : [];
            if (is_array($d)) {
                $overrides = [
                    'serviceType'   => isset($d['serviceType']) ? sanitize_text_field((string) $d['serviceType']) : '',
                    'pickupType'    => isset($d['pickupType']) ? sanitize_text_field((string) $d['pickupType']) : '',
                    'packagingType' => isset($d['packagingType']) ? sanitize_text_field((string) $d['packagingType']) : '',
                    'paymentType'   => isset($d['paymentType']) ? sanitize_text_field((string) $d['paymentType']) : '',
                ];
            }
        }
        $merged = array_merge(Draft::get_shipment_overrides($order), array_filter($overrides));
        Draft::set_shipment_overrides($order, $merged);

        if (isset($_POST['intl_customs'])) {
            // Raw JSON string: validated by json_decode() below and re-encoded for storage. FILTER_DEFAULT keeps the payload intact.
            $intl_raw = filter_var(wp_unslash($_POST['intl_customs']), FILTER_DEFAULT);
            if ($intl_raw === '' || $intl_raw === '{}') {
                $order->delete_meta_data(Draft::META_INTL_CUSTOMS);
            } else {
                $test = json_decode($intl_raw, true);
                $order->update_meta_data(Draft::META_INTL_CUSTOMS, is_array($test) ? wp_json_encode($test) : '{}');
            }
        }

        $order->save();
        $order->add_order_note(__('FedEx Open Ship: shipment settings updated.', 'teamzlab-fedex'), false);
        wp_send_json_success(['ok' => true]);
    }

    /**
     * Sync packages to FedEx: reuses an open or active session (no duplicate create), or runs openshipments/create with a new unique index when session was cleared on FedEx, closed, or missing.
     *
     * @return void
     */
    public function restart_session() {
        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(['message' => __('Forbidden.', 'teamzlab-fedex')], 403);
        }
        check_ajax_referer('fshipping_openship', 'nonce');

        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        $order    = wc_get_order($order_id);
        if (!$order || !Draft::is_advanced_order($order) || Draft::is_locked($order)) {
            wp_send_json_error(['message' => __('Invalid order.', 'teamzlab-fedex')], 400);
        }

        $line = Draft::get_fedex_shipping_line($order);
        if (null === $line) {
            wp_send_json_error(['message' => __('No FedEx shipping method on order.', 'teamzlab-fedex')], 400);
        }

        if (isset($_POST['shipment_overrides'])) {
            // Raw JSON string: only whitelisted keys survive, sanitized below. FILTER_DEFAULT keeps the payload intact.
            $raw = filter_var(wp_unslash($_POST['shipment_overrides']), FILTER_DEFAULT);
            $d   = is_string($raw) ? json_decode($raw, true) : [];
            if (is_array($d)) {
                $overrides = [
                    'serviceType'   => isset($d['serviceType']) ? sanitize_text_field((string) $d['serviceType']) : '',
                    'pickupType'    => isset($d['pickupType']) ? sanitize_text_field((string) $d['pickupType']) : '',
                    'packagingType' => isset($d['packagingType']) ? sanitize_text_field((string) $d['packagingType']) : '',
                    'paymentType'   => isset($d['paymentType']) ? sanitize_text_field((string) $d['paymentType']) : '',
                ];
                $merged = array_merge(Draft::get_shipment_overrides($order), array_filter($overrides));
                Draft::set_shipment_overrides($order, $merged);
            }
        }
        if (isset($_POST['intl_customs'])) {
            // Raw JSON string: validated by json_decode() below and re-encoded for storage. FILTER_DEFAULT keeps the payload intact.
            $intl_raw = filter_var(wp_unslash($_POST['intl_customs']), FILTER_DEFAULT);
            if ($intl_raw === '' || $intl_raw === '{}') {
                $order->delete_meta_data(Draft::META_INTL_CUSTOMS);
            } else {
                $test = json_decode($intl_raw, true);
                $order->update_meta_data(Draft::META_INTL_CUSTOMS, is_array($test) ? wp_json_encode($test) : '{}');
            }
        }
        $order->save();

        $indexed = $this->parse_packages_from_request($order);
        if (null === $indexed) {
            wp_send_json_error(['message' => __('Invalid packages JSON.', 'teamzlab-fedex')], 400);
        }

        $validation = Draft::validate_packages_for_admin($indexed, $order);
        $push_val   = OpenShipPushValidator::validate($indexed, $order);
        $validation['errors']   = array_merge($validation['errors'], $push_val['errors']);
        $validation['warnings'] = array_merge($validation['warnings'], $push_val['warnings']);
        if (!empty($validation['errors'])) {
            wp_send_json_error([
                'message'  => implode("\n\n", $validation['errors']),
                'errors'   => $validation['errors'],
                'warnings' => $validation['warnings'],
            ], 400);
        }

        if (Draft::should_reuse_openship_session_for_restart($order)) {
            Draft::set_packages($order, $indexed);
            $pkgs      = Draft::get_packages($order);
            $new_index = (string) $order->get_meta(Draft::META_SHIPMENT_INDEX, true);
            if ($new_index !== '') {
                $pkgs = Draft::push_packages_to_fedex($order, $pkgs);
            }
            Draft::sync_openship_session_status_after_packages_pushed($order, $pkgs);
            Draft::set_packages($order, $pkgs);
            $order->update_meta_data(Draft::META_LIFECYCLE, Draft::LIFE_DRAFT);
            $order->update_meta_data(Draft::META_CONFIRMED, 'no');
            $order->add_order_note(
                sprintf(
                    /* translators: %s: Open Ship index */
                    __('FedEx Open Ship: session restarted — reusing existing FedEx index %s (no duplicate openshipments/create). Packages re-synced.', 'teamzlab-fedex'),
                    $new_index !== '' ? $new_index : '—'
                ),
                false
            );
            $order->save();

            wp_send_json_success([
                'ok'               => true,
                'shipment_index'   => $new_index,
                'session_reused'   => true,
            ]);

            return;
        }

        Draft::set_packages($order, $indexed);

        $out = OpenShipClient::instance()->start_from_order($order, $line);
        if ([] === $out || !OpenShipClient::openship_create_response_body_indicates_success($out)) {
            $this->json_error_openship_start_failed();
        }

        $session = OpenShipClient::instance()->extract_openship_session_from_create_output($out);
        if ($session['shipmentIndex'] === '' || $session['shipmentIdIndex'] === '') {
            $this->json_error_openship_start_failed(
                __('FedEx returned a body without a usable Open Ship session index / master id. See openship_create_response in the browser console or wp-content/debug.log.', 'teamzlab-fedex')
            );
        }
        Draft::set_openship_session_meta($order, $session);
        $new_index = $session['shipmentIndex'];
        $order->update_meta_data(Draft::META_LIFECYCLE, Draft::LIFE_DRAFT);
        $order->update_meta_data(Draft::META_CONFIRMED, 'no');

        $pkgs = Draft::get_packages($order);
        if ($new_index !== '') {
            $pkgs = Draft::push_packages_to_fedex($order, $pkgs);
        }
        Draft::set_packages($order, $pkgs);

        $order->add_order_note(
            sprintf(
                /* translators: %s: new session id */
                __('FedEx Open Ship: new session started (%s).', 'teamzlab-fedex'),
                $new_index !== '' ? $new_index : '—'
            ),
            false
        );
        $order->save();

        wp_send_json_success(['ok' => true, 'shipment_index' => $new_index]);
    }

    /**
     * @return void
     */
    public function confirm() {
        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(['message' => __('Forbidden.', 'teamzlab-fedex')], 403);
        }
        check_ajax_referer('fshipping_openship', 'nonce');

        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        $order    = wc_get_order($order_id);
        if (!$order || !Draft::is_advanced_order($order) || Draft::is_locked($order)) {
            wp_send_json_error(['message' => __('Invalid order.', 'teamzlab-fedex')], 400);
        }

        $indexed = Draft::get_packages($order);
        $validation = Draft::validate_packages_for_admin($indexed, $order);
        if (!empty($validation['errors'])) {
            wp_send_json_error([
                'message' => implode(' ', $validation['errors']),
                'errors'  => $validation['errors'],
            ], 400);
        }

        $session = Draft::get_openship_session_for_fedex($order);
        if ($session['shipmentIndex'] === '') {
            wp_send_json_error(['message' => __('Missing Open Ship session index. Save packages or restart session.', 'teamzlab-fedex')], 400);
        }

        // Ensure FedEx session-level shipment totals/customs are refreshed from latest package rows
        // before confirm. Without this, stale session values can trigger carriage/customs mismatch errors.
        OpenShipClient::instance()->put_update_open_shipment_from_order(
            $order,
            $session['shipmentIndex'],
            $session['shipmentIdIndex'],
            max(1, count($indexed))
        );

        $full = OpenShipClient::instance()->confirm_full($session['shipmentIndex'], $session['shipmentIdIndex'], $order);
        if (empty($full)) {
            wp_send_json_error(['message' => __('FedEx confirm returned no data.', 'teamzlab-fedex')], 500);
        }
        if (!empty($full['errors'])) {
            $err = reset($full['errors']);
            $msg = is_array($err) && !empty($err['message']) ? (string) $err['message'] : __('FedEx confirm failed.', 'teamzlab-fedex');
            wp_send_json_error(['message' => $msg], 400);
        }

        $mapped = OpenShipClient::instance()->normalize_confirm_body_for_persist($full);
        Shipment::instance()->persist_shipment_from_api_response($order, $mapped);

        $order->update_meta_data(Draft::META_CONFIRMED, 'yes');
        $order->update_meta_data(Draft::META_LIFECYCLE, Draft::LIFE_CONFIRMED);
        $order->update_meta_data(Draft::META_SESSION_STATUS, Draft::SESSION_CLOSED);
        $order->update_meta_data(Draft::META_CONFIRM_RESPONSE, wp_json_encode($full));
        $order->save();

        $order->update_status('processing', __('FedEx Open Ship confirmed; label created.', 'teamzlab-fedex'));
        $order->add_order_note(__('FedEx Open Ship: shipment confirmed and labels stored.', 'teamzlab-fedex'), false);

        wp_send_json_success(['ok' => true]);
    }

    /**
     * PUT modify one package (inline save from results table).
     *
     * @return void
     */
    public function modify_package() {
        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(['message' => __('Forbidden.', 'teamzlab-fedex')], 403);
        }
        check_ajax_referer('fshipping_openship', 'nonce');

        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        $order    = wc_get_order($order_id);
        if (!$order || !Draft::is_advanced_order($order) || Draft::is_locked($order)) {
            wp_send_json_error(['message' => __('Invalid order or shipment confirmed.', 'teamzlab-fedex')], 400);
        }

        $package_index = isset($_POST['package_index']) ? (int) $_POST['package_index'] : -1;
        // Raw JSON string: validated by json_decode() below, fields normalized via Draft::normalize_package_row(). FILTER_DEFAULT keeps the payload intact.
        $raw           = isset($_POST['package']) ? filter_var(wp_unslash($_POST['package']), FILTER_DEFAULT) : '';
        $row_in        = json_decode($raw, true);
        if (!is_array($row_in) || $package_index < 0) {
            wp_send_json_error(['message' => __('Invalid package data.', 'teamzlab-fedex')], 400);
        }

        $session = Draft::get_openship_session_for_fedex($order);
        if ($session['shipmentIndex'] === '') {
            wp_send_json_error(['message' => __('Missing Open Ship session index.', 'teamzlab-fedex')], 400);
        }

        $pkgs = Draft::get_packages($order);
        if (!isset($pkgs[$package_index]) || !is_array($pkgs[$package_index])) {
            wp_send_json_error(['message' => __('Package row not found.', 'teamzlab-fedex')], 400);
        }

        $merged = array_merge($pkgs[$package_index], $row_in);
        $merged = Draft::normalize_package_row($merged, $package_index + 1);
        if (empty($merged['fedex_package_id'])) {
            wp_send_json_error(['message' => __('No FedEx tracking on this row — use Save & push first.', 'teamzlab-fedex')], 400);
        }

        $decoded = OpenShipClient::instance()->put_modify_package_full(
            $session['shipmentIndex'],
            $merged,
            $session['shipmentIdIndex'],
            $order,
            $package_index + 1
        );
        $err = OpenShipClient::first_fedex_error_message($decoded);
        $this->log_admin_action_debug(
            'modify_package',
            $order_id,
            [
                'package_index' => $package_index,
                'request_row'   => $merged,
            ],
            $decoded,
            true
        );
        if ($err !== '' || (!empty($decoded['errors']) && is_array($decoded['errors']) && $decoded['errors'] !== [])) {
            OpenShipClient::debug_log_push_json_blocks(
                'openship admin modify_package (Ajax error)',
                [
                    'request (package row)' => $merged,
                    'response (full body)'   => $decoded,
                ],
                true
            );
            wp_send_json_error(['message' => $err !== '' ? $err : __('FedEx modify failed.', 'teamzlab-fedex')], 400);
        }

        $out = $decoded['output'] ?? [];
        if (!is_array($out)) {
            $out = [];
        }
        $piece = self::draft_first_piece_from_output($out);
        if ($piece !== []) {
            $tr = self::draft_tracking_from_piece($piece);
            $sq = self::draft_sequence_from_piece($piece);
            if ($tr !== '') {
                $merged['fedex_package_id'] = $tr;
            }
            if ($sq !== '') {
                $merged['fedex_delete_id'] = $sq;
                $merged['fedex_sequence']  = $sq;
            }
        }
        $pkgs[$package_index] = $merged;
        Draft::sync_order_item_piece_tracking_meta($order, $pkgs);
        Draft::set_packages($order, $pkgs);

        wp_send_json_success([
            'ok'              => true,
            'package'         => $merged,
            'transaction_id'  => OpenShipClient::extract_transaction_and_packages_from_response($decoded)['transaction_id'],
        ]);
    }

    /**
     * DELETE one package on FedEx and remove the local package row from the order.
     *
     * @return void
     */
    public function delete_package_row() {
        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(['message' => __('Forbidden.', 'teamzlab-fedex')], 403);
        }
        check_ajax_referer('fshipping_openship', 'nonce');

        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        $order    = wc_get_order($order_id);
        if (!$order || !Draft::is_advanced_order($order) || Draft::is_locked($order)) {
            wp_send_json_error(['message' => __('Invalid order or shipment confirmed.', 'teamzlab-fedex')], 400);
        }

        $package_index = isset($_POST['package_index']) ? (int) $_POST['package_index'] : -1;
        $fedex_id      = isset($_POST['fedex_package_id']) ? sanitize_text_field(wp_unslash((string) $_POST['fedex_package_id'])) : '';
        if ($package_index < 0 || $fedex_id === '') {
            wp_send_json_error(['message' => __('Missing package index or FedEx id.', 'teamzlab-fedex')], 400);
        }

        $session = Draft::get_openship_session_for_fedex($order);
        if ($session['shipmentIndex'] === '') {
            wp_send_json_error(['message' => __('Missing Open Ship session index.', 'teamzlab-fedex')], 400);
        }

        $decoded = OpenShipClient::instance()->delete_package_with_response(
            $session['shipmentIndex'],
            $fedex_id,
            $session['shipmentIdIndex']
        );
        $this->log_admin_action_debug(
            'delete_package',
            $order_id,
            [
                'package_index'     => $package_index,
                'fedex_package_id'  => $fedex_id,
                'shipment_index'    => $session['shipmentIndex'],
                'shipment_id_index' => $session['shipmentIdIndex'],
            ],
            $decoded,
            true
        );
        $err = OpenShipClient::first_fedex_error_message($decoded);
        if ($err !== '' || (!empty($decoded['errors']) && is_array($decoded['errors']) && $decoded['errors'] !== [])) {
            wp_send_json_error(['message' => $err !== '' ? $err : __('FedEx delete package failed.', 'teamzlab-fedex')], 400);
        }

        $pkgs = Draft::get_packages($order);
        if (isset($pkgs[$package_index])) {
            unset($pkgs[$package_index]);
            $pkgs = array_values($pkgs);
            Draft::sync_order_item_piece_tracking_meta($order, $pkgs);
            Draft::set_packages($order, $pkgs);
        }

        $rows_raw = (string) $order->get_meta(Draft::META_LAST_PUSH_ROWS, true);
        $rows = $rows_raw !== '' ? json_decode($rows_raw, true) : [];
        if (is_array($rows) && $rows !== []) {
            $target_num = $package_index + 1;
            $rows = array_values(array_filter($rows, static function ($row) use ($target_num, $fedex_id): bool {
                if (!is_array($row)) {
                    return false;
                }
                $pkg_no = isset($row['package_number']) ? (int) $row['package_number'] : 0;
                $trk = isset($row['tracking_number']) ? (string) $row['tracking_number'] : '';
                if ($pkg_no === $target_num) {
                    return false;
                }
                if ($fedex_id !== '' && $trk !== '' && $trk === $fedex_id) {
                    return false;
                }

                return true;
            }));
            $order->update_meta_data(Draft::META_LAST_PUSH_ROWS, wp_json_encode($rows));
            $order->save();
        }

        wp_send_json_success([
            'ok'       => true,
            'packages' => $pkgs,
            'push_rows' => is_array($rows) ? $rows : [],
        ]);
    }

    /**
     * PUT delete whole Open Ship session (Clear all packages) and clear local package rows/results.
     *
     * @return void
     */
    public function clear_all_packages() {
        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(['message' => __('Forbidden.', 'teamzlab-fedex')], 403);
        }
        check_ajax_referer('fshipping_openship', 'nonce');

        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        $order    = wc_get_order($order_id);
        if (!$order || !Draft::is_advanced_order($order) || Draft::is_locked($order)) {
            wp_send_json_error(['message' => __('Invalid order or shipment confirmed.', 'teamzlab-fedex')], 400);
        }

        $result = Draft::cancel_fedex_open_shipment_and_clear($order, false);
        if (empty($result['ok'])) {
            wp_send_json_error([
                'message' => isset($result['error']) ? (string) $result['error'] : __('Could not clear FedEx session.', 'teamzlab-fedex'),
            ], 400);
        }

        Draft::sync_order_item_piece_tracking_meta($order, []);
        $order->update_meta_data(Draft::META_PACKAGES_JSON, wp_json_encode([]));
        $order->update_meta_data(Draft::META_LAST_PUSH_ROWS, wp_json_encode([]));
        $order->save();

        wp_send_json_success([
            'ok'       => true,
            'packages' => [],
            'push_rows' => [],
        ]);
    }

    /**
     * @param array<string, mixed> $output
     * @return array<string, mixed>
     */
    private static function draft_first_piece_from_output(array $output): array {
        if (!empty($output['pieceResponses'][0]) && is_array($output['pieceResponses'][0])) {
            return $output['pieceResponses'][0];
        }
        if (!empty($output['transactionShipments'][0]['pieceResponses'][0]) && is_array($output['transactionShipments'][0]['pieceResponses'][0])) {
            return $output['transactionShipments'][0]['pieceResponses'][0];
        }

        return [];
    }

    /**
     * @param array<string, mixed> $piece
     */
    private static function draft_tracking_from_piece(array $piece): string {
        foreach (['trackingNumber', 'trackNumber'] as $key) {
            if (!empty($piece[$key]) && is_scalar($piece[$key])) {
                return sanitize_text_field((string) $piece[$key]);
            }
        }

        return '';
    }

    /**
     * @param array<string, mixed> $piece
     */
    private static function draft_sequence_from_piece(array $piece): string {
        foreach (['packageSequenceNumber', 'sequenceNumber', 'sequence'] as $key) {
            if (isset($piece[$key]) && $piece[$key] !== '') {
                return sanitize_text_field((string) $piece[$key]);
            }
        }

        return '';
    }

    /**
     * Write one admin action payload/response block to debug.log for Open Ship order actions.
     *
     * @param array<string, mixed> $request_payload
     * @param array<string, mixed> $response_payload
     */
    private function log_admin_action_debug(
        string $action,
        int $order_id,
        array $request_payload,
        array $response_payload,
        bool $force = false
    ): void {
        OpenShipClient::debug_log_push_json_blocks(
            'openship admin action=' . $action . ' order_id=' . max(0, $order_id),
            [
                'request (JSON body)'  => $request_payload,
                'response (full body)' => $response_payload,
            ],
            $force
        );
    }
}
