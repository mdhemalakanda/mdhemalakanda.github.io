<?php
namespace FSHIPPING\OpenShip;

use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\Helper;

/**
 * WooCommerce order statuses for Advanced Open Ship lifecycle (optional display).
 *
 * @since 1.3
 */
defined('ABSPATH') || exit;

class OrderStatuses {
    use SingletonTrait;

    public function init() {
        add_action('init', [$this, 'register']);
        add_filter('wc_order_statuses', [$this, 'register_labels']);
    }

    /**
     * @return void
     */
    public function register() {
        register_post_status('wc-fedex-draft', [
            'label'                     => _x('FedEx draft (Open Ship)', 'Order status', 'teamzlab-fedex'),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            /* translators: %s: number of orders with this status. */
            'label_count'               => _n_noop(
                'FedEx draft <span class="count">(%s)</span>',
                'FedEx draft <span class="count">(%s)</span>',
                'teamzlab-fedex'
            ),
        ]);
        register_post_status('wc-fedex-openship', [
            'label'                     => _x('FedEx Open Ship (in progress)', 'Order status', 'teamzlab-fedex'),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            /* translators: %s: number of orders with this status. */
            'label_count'               => _n_noop(
                'FedEx Open Ship <span class="count">(%s)</span>',
                'FedEx Open Ship <span class="count">(%s)</span>',
                'teamzlab-fedex'
            ),
        ]);
    }

    /**
     * @param array<string, string> $statuses
     * @return array<string, string>
     */
    public function register_labels($statuses) {
        if (Helper::instance()->get_shipping_mode() !== 'advanced') {
            return $statuses;
        }
        $statuses['wc-fedex-draft']    = _x('FedEx draft (Open Ship)', 'Order status label', 'teamzlab-fedex');
        $statuses['wc-fedex-openship'] = _x('FedEx Open Ship (in progress)', 'Order status label', 'teamzlab-fedex');
        return $statuses;
    }
}
