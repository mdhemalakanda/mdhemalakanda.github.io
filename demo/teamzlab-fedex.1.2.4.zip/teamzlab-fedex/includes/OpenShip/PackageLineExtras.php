<?php
namespace FSHIPPING\OpenShip;

/**
 * Optional FedEx Open Ship RequestedPackageLineItem fields (Add Open Shipment Packages).
 *
 * @see https://developer.fedex.com/api/en-us/catalog/open-ship/v1/docs.html
 */
defined('ABSPATH') || exit;

class PackageLineExtras {
    /** @var list<string> */
    public const SUBPACKAGING_TYPES = [
        'BAG', 'BARREL', 'BASKET', 'BOX', 'BUCKET', 'BUNDLE', 'CAGE', 'CARTON', 'CASE', 'CHEST',
        'CONTAINER', 'CRATE', 'CYLINDER', 'DRUM', 'ENVELOPE', 'HAMPER', 'OTHER', 'PACKAGE', 'PAIL',
        'PALLET', 'PARCEL', 'PIECE', 'REEL', 'ROLL', 'SACK', 'SHRINKWRAPPED', 'SKID', 'TANK',
        'TOTEBIN', 'TUBE', 'UNIT',
    ];

    /** @var list<string> */
    public const VARIABLE_RATE_TYPES = [
        'ACCOUNT', 'ACTUAL', 'CURRENT', 'CUSTOM', 'LIST', 'INCENTIVE', 'PREFERRED',
        'PREFERRED_INCENTIVE', 'PREFERRED_CURRENCY',
    ];

    /** @var list<string> */
    public const VARIABLE_RATE_LEVEL_TYPES = ['BUNDLED_RATE', 'INDIVIDUAL_PACKAGE_RATE'];

    /** @var list<string> */
    public const RATE_ELEMENT_BASIS = ['NET_CHARGE', 'NET_FREIGHT', 'BASE_CHARGE', 'NET_CHARGE_EXCLUDING_TAXES'];

    /** @var list<string> */
    public const SIGNATURE_OPTION_TYPES = [
        'SERVICE_DEFAULT', 'NO_SIGNATURE_REQUIRED', 'INDIRECT', 'DIRECT', 'ADULT',
    ];

    /** @var list<string> FedEx package-level special services (extend via filter on enqueue). */
    public const SPECIAL_SERVICE_TYPES = [
        'ALCOHOL', 'APPOINTMENT', 'BATTERY', 'COD', 'CUT_FLOWERS', 'DANGEROUS_GOODS',
        'DRY_ICE', 'NON_STANDARD_CONTAINER', 'PRIORITY_ALERT', 'SIGNATURE_OPTION',
        'LITHIUM_BATTERY', 'PERISHABLE', 'PIECE_COUNT_VERIFICATION', 'PROTECTIVE_FROST',
        'RETURNS_CLEARANCE', 'SATURDAY_DELIVERY', 'EVENT_NOTIFICATION', 'EXTREME_LENGTH',
    ];

    /** @var list<string> */
    public const ALCOHOL_RECIPIENT_TYPES = ['LICENSEE', 'CONSUMER'];

    /** @var list<string> */
    public const DG_ACCESSIBILITY = ['ACCESSIBLE', 'INACCESSIBLE'];

    /** @var list<string> */
    public const DG_REGULATIONS = ['ADR', 'DOT', 'IATA', 'ORMD'];

    /** @var list<string> */
    public const DG_OPTIONS = [
        'HAZARDOUS_MATERIALS', 'BATTERY', 'ORM_D', 'REPORTABLE_QUANTITIES',
        'SMALL_QUANTITY_EXCEPTION', 'LIMITED_QUANTITIES_COMMODITIES',
    ];

    /** @var list<string> */
    public const BATTERY_PACKING_TYPES = ['CONTAINED_IN_EQUIPMENT', 'PACKED_WITH_EQUIPMENT'];

    /** @var list<string> */
    public const BATTERY_MATERIAL_TYPES = ['LITHIUM_METAL', 'LITHIUM_ION'];

    /** @var list<string> */
    public const WEIGHT_UNITS = ['KG', 'LB'];

    /**
     * FedEx `customerReferenceType` on `RequestedPackageLineItem.customerReferences`.
     *
     * @var list<string>
     */
    public const CUSTOMER_REFERENCE_TYPES = [
        'CUSTOMER_REFERENCE',
        'DEPARTMENT_NUMBER',
        'INVOICE_NUMBER',
        'P_O_NUMBER',
        'INTRACOUNTRY_REGULATORY_REFERENCE',
        'RMA_ASSOCIATION',
    ];

    /**
     * Whether the Open Ship session **`serviceType`** is Ground-like (FedEx prints **30** chars max for
     * **`CUSTOMER_REFERENCE`** on Ground vs **40** on Express).
     */
    public static function is_ground_like_service_type(string $service_type): bool {
        $t = strtoupper(trim($service_type));
        if ($t === '') {
            return false;
        }
        if (false !== strpos($t, 'GROUND')) {
            return true;
        }
        if (false !== strpos($t, 'HOME_DELIVERY')) {
            return true;
        }
        if ($t === 'SMART_POST' || false !== strpos($t, 'SMARTPOST')) {
            return true;
        }

        return false;
    }

    /**
     * Max length for `value` by type (FedEx Ship API — label/invoice print limits).
     * `CUSTOMER_REFERENCE` uses **40** (Express) unless **`$service_type`** is Ground-like (**30**).
     * Sanitize-time calls pass no service type (stores up to 40); Add Package applies service-aware truncation.
     *
     * @param string      $type          Enum `customerReferenceType`.
     * @param string|null $service_type  Open Ship `requestedShipment.serviceType` (from order shipment overrides).
     *
     * @see self::truncate_customer_reference_value()
     */
    public static function customer_reference_value_max_length(string $type, ?string $service_type = null): int {
        $defaults = [
            'CUSTOMER_REFERENCE'               => 40,
            'DEPARTMENT_NUMBER'                => 30,
            'INVOICE_NUMBER'                   => 30,
            'P_O_NUMBER'                       => 30,
            'INTRACOUNTRY_REGULATORY_REFERENCE' => 30,
            'RMA_ASSOCIATION'                  => 20,
        ];
        $base = $defaults[ $type ] ?? 30;

        if ('CUSTOMER_REFERENCE' === $type && null !== $service_type && $service_type !== '' && self::is_ground_like_service_type($service_type)) {
            $base = 30;
        }

        return (int) apply_filters('fshipping_openship_customer_reference_value_max_length', $base, $type, $service_type ?? '');
    }

    /**
     * Truncate a single reference value to FedEx limits (mbstring when available).
     *
     * @param string|null $service_type Passed on Add Package when known (Ground vs Express for `CUSTOMER_REFERENCE`).
     */
    public static function truncate_customer_reference_value(string $type, string $value, ?string $service_type = null): string {
        $max = self::customer_reference_value_max_length($type, $service_type);
        if ($max < 1) {
            return '';
        }
        $value = (string) $value;

        return function_exists('mb_substr') ? mb_substr($value, 0, $max) : substr($value, 0, $max);
    }

    /**
     * @param array<string, mixed> $raw
     * @return array<string, mixed>
     */
    public static function sanitize(array $raw): array {
        if (empty($raw) || !is_array($raw)) {
            return [];
        }
        $out = [];

        $seq = isset($raw['sequenceNumber']) ? trim((string) $raw['sequenceNumber']) : '';
        if ($seq !== '') {
            $out['sequenceNumber'] = sanitize_text_field($seq);
        }

        $sub = isset($raw['subPackagingType']) ? strtoupper(sanitize_text_field((string) $raw['subPackagingType'])) : '';
        if ($sub !== '' && in_array($sub, self::SUBPACKAGING_TYPES, true)) {
            $out['subPackagingType'] = $sub;
        }

        $gpc = isset($raw['groupPackageCount']) ? (int) $raw['groupPackageCount'] : 0;
        if ($gpc > 0) {
            $out['groupPackageCount'] = $gpc;
        }

        $ifc = isset($raw['itemDescriptionForClearance']) ? trim((string) $raw['itemDescriptionForClearance']) : '';
        if ($ifc !== '') {
            $out['itemDescriptionForClearance'] = sanitize_textarea_field($ifc);
        }

        $idesc = isset($raw['itemDescription']) ? trim((string) $raw['itemDescription']) : '';
        if ($idesc !== '') {
            $out['itemDescription'] = sanitize_textarea_field($idesc);
        }

        if (!empty($raw['contentRecord']) && is_array($raw['contentRecord'])) {
            $cr = [];
            foreach ($raw['contentRecord'] as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $entry = [];
                if (isset($row['itemNumber'])) {
                    $entry['itemNumber'] = sanitize_text_field((string) $row['itemNumber']);
                }
                if (isset($row['receivedQuantity'])) {
                    $entry['receivedQuantity'] = (int) $row['receivedQuantity'];
                }
                if (isset($row['partNumber'])) {
                    $entry['partNumber'] = sanitize_text_field((string) $row['partNumber']);
                }
                if ($entry !== []) {
                    $cr[] = $entry;
                }
            }
            if ($cr !== []) {
                $out['contentRecord'] = $cr;
            }
        }

        $vh = self::sanitize_variable_handling(isset($raw['variableHandlingChargeDetail']) && is_array($raw['variableHandlingChargeDetail'])
            ? $raw['variableHandlingChargeDetail'] : []);
        if ($vh !== []) {
            $out['variableHandlingChargeDetail'] = $vh;
        }

        $pss = self::sanitize_package_special_services(isset($raw['packageSpecialServices']) && is_array($raw['packageSpecialServices'])
            ? $raw['packageSpecialServices'] : []);
        if ($pss !== []) {
            $out['packageSpecialServices'] = $pss;
        }

        if (!empty($raw['extraCustomerReferences']) && is_array($raw['extraCustomerReferences'])) {
            $refs = [];
            foreach ($raw['extraCustomerReferences'] as $ref) {
                if (!is_array($ref)) {
                    continue;
                }
                $t = isset($ref['customerReferenceType']) ? strtoupper(sanitize_text_field((string) $ref['customerReferenceType'])) : '';
                $v = isset($ref['value']) ? sanitize_text_field((string) $ref['value']) : '';
                if ($t === '' || $v === '' || ! in_array($t, self::CUSTOMER_REFERENCE_TYPES, true)) {
                    continue;
                }
                $refs[] = [
                    'customerReferenceType' => $t,
                    'value'                 => self::truncate_customer_reference_value($t, $v),
                ];
            }
            if ($refs !== []) {
                $out['extraCustomerReferences'] = $refs;
            }
        }

        return $out;
    }

    /**
     * @param array<string, mixed> $in
     * @return array<string, mixed>
     */
    private static function sanitize_variable_handling(array $in): array {
        if ($in === []) {
            return [];
        }
        $out = [];
        $rt = isset($in['rateType']) ? strtoupper(sanitize_text_field((string) $in['rateType'])) : '';
        if ($rt !== '' && in_array($rt, self::VARIABLE_RATE_TYPES, true)) {
            $out['rateType'] = $rt;
        }
        if (isset($in['percentValue'])) {
            $pv = (float) $in['percentValue'];
            if ($pv > 0) {
                $out['percentValue'] = $pv;
            }
        }
        $rlt = isset($in['rateLevelType']) ? strtoupper(sanitize_text_field((string) $in['rateLevelType'])) : '';
        if ($rlt !== '' && in_array($rlt, self::VARIABLE_RATE_LEVEL_TYPES, true)) {
            $out['rateLevelType'] = $rlt;
        }
        if (!empty($in['fixedValue']) && is_array($in['fixedValue'])) {
            $fv = $in['fixedValue'];
            $amt = isset($fv['amount']) ? (float) $fv['amount'] : 0.0;
            $cur = isset($fv['currency']) ? strtoupper(sanitize_text_field((string) $fv['currency'])) : '';
            if ($amt > 0 && strlen($cur) === 3) {
                $out['fixedValue'] = [
                    'amount'   => (string) $amt,
                    'currency' => $cur,
                ];
            }
        }
        $reb = isset($in['rateElementBasis']) ? strtoupper(sanitize_text_field((string) $in['rateElementBasis'])) : '';
        if ($reb !== '' && in_array($reb, self::RATE_ELEMENT_BASIS, true)) {
            $out['rateElementBasis'] = $reb;
        }

        return $out;
    }

    /**
     * @param array<string, mixed> $in
     * @return array<string, mixed>
     */
    private static function sanitize_package_special_services(array $in): array {
        if ($in === []) {
            return [];
        }
        $out = [];

        if (!empty($in['specialServiceTypes']) && is_array($in['specialServiceTypes'])) {
            $sts = [];
            foreach ($in['specialServiceTypes'] as $s) {
                $u = strtoupper(sanitize_text_field((string) $s));
                if ($u !== '' && in_array($u, self::SPECIAL_SERVICE_TYPES, true)) {
                    $sts[] = $u;
                }
            }
            $sts = array_values(array_unique($sts));
            if ($sts !== []) {
                $out['specialServiceTypes'] = $sts;
            }
        }

        $sig = isset($in['signatureOptionType']) ? strtoupper(sanitize_text_field((string) $in['signatureOptionType'])) : '';
        if ($sig !== '' && in_array($sig, self::SIGNATURE_OPTION_TYPES, true)) {
            $out['signatureOptionType'] = $sig;
        }

        if (!empty($in['priorityAlertDetail']) && is_array($in['priorityAlertDetail'])) {
            $pad = $in['priorityAlertDetail'];
            $ped = [];
            if (!empty($pad['enhancementTypes']) && is_array($pad['enhancementTypes'])) {
                $et = [];
                foreach ($pad['enhancementTypes'] as $e) {
                    $x = strtoupper(sanitize_text_field((string) $e));
                    if ($x !== '') {
                        $et[] = $x;
                    }
                }
                if ($et !== []) {
                    $ped['enhancementTypes'] = $et;
                }
            }
            if (!empty($pad['content']) && is_array($pad['content'])) {
                $cc = [];
                foreach ($pad['content'] as $c) {
                    $x = sanitize_text_field((string) $c);
                    if ($x !== '') {
                        $cc[] = $x;
                    }
                }
                if ($cc !== []) {
                    $ped['content'] = $cc;
                }
            }
            if ($ped !== []) {
                $out['priorityAlertDetail'] = $ped;
            }
        }

        if (!empty($in['signatureOptionDetail']) && is_array($in['signatureOptionDetail'])) {
            $sd = $in['signatureOptionDetail'];
            $srn = isset($sd['signatureReleaseNumber']) ? sanitize_text_field((string) $sd['signatureReleaseNumber']) : '';
            if ($srn !== '') {
                $out['signatureOptionDetail'] = ['signatureReleaseNumber' => $srn];
            }
        }

        $has_alcohol = !empty($out['specialServiceTypes']) && in_array('ALCOHOL', $out['specialServiceTypes'], true);
        if ($has_alcohol && !empty($in['alcoholDetail']) && is_array($in['alcoholDetail'])) {
            $ad = $in['alcoholDetail'];
            $art = isset($ad['alcoholRecipientType']) ? strtoupper(sanitize_text_field((string) $ad['alcoholRecipientType'])) : '';
            if ($art !== '' && in_array($art, self::ALCOHOL_RECIPIENT_TYPES, true)) {
                $out['alcoholDetail'] = [
                    'alcoholRecipientType' => $art,
                    'shipperAgreementType' => isset($ad['shipperAgreementType'])
                        ? sanitize_text_field((string) $ad['shipperAgreementType']) : '',
                ];
            }
        }

        if (!empty($in['dangerousGoodsDetail']) && is_array($in['dangerousGoodsDetail'])) {
            $dg = $in['dangerousGoodsDetail'];
            $dgo = [];
            $acc = isset($dg['accessibility']) ? strtoupper(sanitize_text_field((string) $dg['accessibility'])) : '';
            if ($acc !== '' && in_array($acc, self::DG_ACCESSIBILITY, true)) {
                $dgo['accessibility'] = $acc;
            }
            if (isset($dg['cargoAircraftOnly'])) {
                $dgo['cargoAircraftOnly'] = (bool) $dg['cargoAircraftOnly'];
            }
            $reg = isset($dg['regulation']) ? strtoupper(sanitize_text_field((string) $dg['regulation'])) : '';
            if ($reg !== '' && in_array($reg, self::DG_REGULATIONS, true)) {
                $dgo['regulation'] = $reg;
            }
            if (!empty($dg['options']) && is_array($dg['options'])) {
                $opts = [];
                foreach ($dg['options'] as $o) {
                    $u = strtoupper(sanitize_text_field((string) $o));
                    if ($u !== '' && in_array($u, self::DG_OPTIONS, true)) {
                        $opts[] = $u;
                    }
                }
                if ($opts !== []) {
                    $dgo['options'] = array_values(array_unique($opts));
                }
            }
            if ($dgo !== []) {
                $out['dangerousGoodsDetail'] = $dgo;
            }
        }

        if (!empty($in['packageCODDetail']) && is_array($in['packageCODDetail'])) {
            $cod = $in['packageCODDetail'];
            if (!empty($cod['codCollectionAmount']) && is_array($cod['codCollectionAmount'])) {
                $ca = $cod['codCollectionAmount'];
                $amt = isset($ca['amount']) ? (float) $ca['amount'] : 0.0;
                $cur = isset($ca['currency']) ? strtoupper(sanitize_text_field((string) $ca['currency'])) : '';
                if ($amt > 0 && strlen($cur) === 3) {
                    $out['packageCODDetail'] = [
                        'codCollectionAmount' => [
                            'amount'   => (string) $amt,
                            'currency' => $cur,
                        ],
                    ];
                }
            }
        }

        if (isset($in['pieceCountVerificationBoxCount'])) {
            $pc = (int) $in['pieceCountVerificationBoxCount'];
            if ($pc >= 0) {
                $out['pieceCountVerificationBoxCount'] = $pc;
            }
        }

        if (!empty($in['batteryDetails']) && is_array($in['batteryDetails'])) {
            $bds = [];
            foreach ($in['batteryDetails'] as $bd) {
                if (!is_array($bd)) {
                    continue;
                }
                $bpt = isset($bd['batteryPackingType']) ? strtoupper(sanitize_text_field((string) $bd['batteryPackingType'])) : '';
                $bmt = isset($bd['batteryMaterialType']) ? strtoupper(sanitize_text_field((string) $bd['batteryMaterialType'])) : '';
                $row = [];
                if ($bpt !== '' && in_array($bpt, self::BATTERY_PACKING_TYPES, true)) {
                    $row['batteryPackingType'] = $bpt;
                }
                $brt = isset($bd['batteryRegulatoryType']) ? strtoupper(sanitize_text_field((string) $bd['batteryRegulatoryType'])) : '';
                if ($brt !== '') {
                    $row['batteryRegulatoryType'] = $brt;
                }
                if ($bmt !== '' && in_array($bmt, self::BATTERY_MATERIAL_TYPES, true)) {
                    $row['batteryMaterialType'] = $bmt;
                }
                if (isset($row['batteryPackingType'], $row['batteryMaterialType'])) {
                    $bds[] = $row;
                }
            }
            if ($bds !== []) {
                $out['batteryDetails'] = $bds;
            }
        }

        if (!empty($in['dryIceWeight']) && is_array($in['dryIceWeight'])) {
            $di = $in['dryIceWeight'];
            $u = isset($di['units']) ? strtoupper(sanitize_text_field((string) $di['units'])) : '';
            $v = isset($di['value']) ? (float) $di['value'] : 0.0;
            if ($u !== '' && in_array($u, self::WEIGHT_UNITS, true) && $v > 0) {
                $out['dryIceWeight'] = ['units' => $u, 'value' => $v];
            }
        }

        if (!empty($in['standaloneBatteryDetails']) && is_array($in['standaloneBatteryDetails'])) {
            $sbd = [];
            foreach ($in['standaloneBatteryDetails'] as $sb) {
                if (!is_array($sb)) {
                    continue;
                }
                $bmt = isset($sb['batteryMaterialType']) ? strtoupper(sanitize_text_field((string) $sb['batteryMaterialType'])) : '';
                if ($bmt !== '' && in_array($bmt, self::BATTERY_MATERIAL_TYPES, true)) {
                    $sbd[] = ['batteryMaterialType' => $bmt];
                }
            }
            if ($sbd !== []) {
                $out['standaloneBatteryDetails'] = $sbd;
            }
        }

        return $out;
    }

    /**
     * WooCommerce currency codes for select2 (ISO codes).
     *
     * @return array<string, string> code => label
     */
    public static function get_currency_options(): array {
        if (!function_exists('get_woocommerce_currencies')) {
            return ['USD' => 'USD'];
        }
        return get_woocommerce_currencies();
    }
}
