<?php
namespace FSHIPPING\OpenShip;

/**
 * Server-side validation for Open Ship **Save & push** / restart push (not draft).
 *
 * Validates `package_line_extras` after {@see PackageLineExtras::sanitize()} / {@see Draft::normalize_package_row()}.
 */
defined('ABSPATH') || exit;

class OpenShipPushValidator {
    /**
     * @param array<int, array<string, mixed>> $packages Normalized package rows.
     * @param \WC_Order                        $order
     * @return array{errors: array<int, string>, warnings: array<int, string>}
     */
    public static function validate(array $packages, $order): array {
        $errors   = [];
        $warnings = [];

        foreach ($packages as $i => $pkg) {
            if (!is_array($pkg)) {
                continue;
            }
            $n      = $i + 1;
            $extras = isset($pkg['package_line_extras']) && is_array($pkg['package_line_extras']) ? $pkg['package_line_extras'] : [];

            if (!empty($extras['groupPackageCount']) && (int) $extras['groupPackageCount'] > 1) {
                if (!apply_filters('fshipping_openship_allow_group_package_count', false, $extras, $pkg, $n)) {
                    $errors[] = sprintf(
                        /* translators: %d: box index */
                        __(
                            'Box %d: “Group package count” greater than 1 tells FedEx this line represents multiple identical pieces. Clear it unless weight, dimensions, and commodities truly match FedEx grouped-packaging rules, or a developer may allow this via filter `fshipping_openship_allow_group_package_count`.',
                            'teamzlab-fedex'
                        ),
                        $n
                    );
                }
            }

            $pss = isset($extras['packageSpecialServices']) && is_array($extras['packageSpecialServices'])
                ? $extras['packageSpecialServices'] : [];
            $sts = isset($pss['specialServiceTypes']) && is_array($pss['specialServiceTypes'])
                ? $pss['specialServiceTypes'] : [];

            if (apply_filters('fshipping_openship_validate_blocking_combos', true, $sts, $pss, $extras, $n, $pkg)) {
                $has_cod  = in_array('COD', $sts, true);
                $has_dg   = in_array('DANGEROUS_GOODS', $sts, true);
                $has_batt = in_array('BATTERY', $sts, true) || in_array('LITHIUM_BATTERY', $sts, true);
                $has_pa   = in_array('PRIORITY_ALERT', $sts, true);
                if ($has_cod && $has_dg && $has_batt && $has_pa) {
                    $errors[] = sprintf(
                        /* translators: %d: box index */
                        __(
                            'Box %d: Combining COD, Dangerous goods, battery, and Priority Alert on one package often fails in production. Remove one or more special services.',
                            'teamzlab-fedex'
                        ),
                        $n
                    );
                }
            }

            if (in_array('COD', $sts, true)) {
                $cod = isset($pss['packageCODDetail']['codCollectionAmount']) && is_array($pss['packageCODDetail']['codCollectionAmount'])
                    ? $pss['packageCODDetail']['codCollectionAmount'] : [];
                $amt = isset($cod['amount']) ? (float) $cod['amount'] : 0.0;
                $cur = isset($cod['currency']) ? strtoupper((string) $cod['currency']) : '';
                if ($amt <= 0 || strlen($cur) !== 3) {
                    $errors[] = sprintf(
                        /* translators: %d: box index */
                        __('Box %d: COD is selected — enter a COD collection amount greater than zero and a 3-letter currency code.', 'teamzlab-fedex'),
                        $n
                    );
                }
            }

            if (in_array('ALCOHOL', $sts, true)) {
                $ad  = isset($pss['alcoholDetail']) && is_array($pss['alcoholDetail']) ? $pss['alcoholDetail'] : [];
                $art = isset($ad['alcoholRecipientType']) ? strtoupper((string) $ad['alcoholRecipientType']) : '';
                if ($art === '' || !in_array($art, PackageLineExtras::ALCOHOL_RECIPIENT_TYPES, true)) {
                    $errors[] = sprintf(
                        /* translators: %d: box index */
                        __('Box %d: Alcohol is selected — choose a valid alcohol recipient type.', 'teamzlab-fedex'),
                        $n
                    );
                }
            }

            if (in_array('DANGEROUS_GOODS', $sts, true)) {
                $dg  = isset($pss['dangerousGoodsDetail']) && is_array($pss['dangerousGoodsDetail']) ? $pss['dangerousGoodsDetail'] : [];
                $acc = isset($dg['accessibility']) ? strtoupper((string) $dg['accessibility']) : '';
                $reg = isset($dg['regulation']) ? strtoupper((string) $dg['regulation']) : '';
                if ($acc === '' || !in_array($acc, PackageLineExtras::DG_ACCESSIBILITY, true)) {
                    $errors[] = sprintf(
                        /* translators: %d: box index */
                        __('Box %d: Dangerous goods is selected — set accessibility (Accessible or Inaccessible).', 'teamzlab-fedex'),
                        $n
                    );
                }
                if ($reg === '' || !in_array($reg, PackageLineExtras::DG_REGULATIONS, true)) {
                    $errors[] = sprintf(
                        /* translators: %d: box index */
                        __('Box %d: Dangerous goods is selected — set regulation (e.g. ADR, DOT, IATA).', 'teamzlab-fedex'),
                        $n
                    );
                }
            }

            if (in_array('BATTERY', $sts, true) || in_array('LITHIUM_BATTERY', $sts, true)) {
                $has_bd = !empty($pss['batteryDetails']) && is_array($pss['batteryDetails']) && $pss['batteryDetails'] !== [];
                $has_sb = !empty($pss['standaloneBatteryDetails']) && is_array($pss['standaloneBatteryDetails']) && $pss['standaloneBatteryDetails'] !== [];
                if (!$has_bd && !$has_sb) {
                    $errors[] = sprintf(
                        /* translators: %d: box index */
                        __('Box %d: Battery service is selected — add at least one complete battery detail row or standalone battery.', 'teamzlab-fedex'),
                        $n
                    );
                }
            }

            if (in_array('PRIORITY_ALERT', $sts, true)) {
                $pad = isset($pss['priorityAlertDetail']) && is_array($pss['priorityAlertDetail']) ? $pss['priorityAlertDetail'] : [];
                $et  = !empty($pad['enhancementTypes']) && is_array($pad['enhancementTypes']) ? $pad['enhancementTypes'] : [];
                $cc  = !empty($pad['content']) && is_array($pad['content']) ? $pad['content'] : [];
                if ($et === [] && $cc === []) {
                    $errors[] = sprintf(
                        /* translators: %d: box index */
                        __('Box %d: Priority Alert is selected — add at least one enhancement type or content string.', 'teamzlab-fedex'),
                        $n
                    );
                }
            }

            if (in_array('DRY_ICE', $sts, true)) {
                $di = isset($pss['dryIceWeight']) && is_array($pss['dryIceWeight']) ? $pss['dryIceWeight'] : [];
                $v  = isset($di['value']) ? (float) $di['value'] : 0.0;
                if ($v <= 0) {
                    $errors[] = sprintf(
                        /* translators: %d: box index */
                        __('Box %d: Dry ice is selected — enter a dry ice weight greater than zero.', 'teamzlab-fedex'),
                        $n
                    );
                }
            }

            $vh = isset($extras['variableHandlingChargeDetail']) && is_array($extras['variableHandlingChargeDetail'])
                ? $extras['variableHandlingChargeDetail'] : [];
            if ($vh !== []) {
                $rt = isset($vh['rateType']) ? strtoupper((string) $vh['rateType']) : '';
                if ($rt === '' || !in_array($rt, PackageLineExtras::VARIABLE_RATE_TYPES, true)) {
                    $errors[] = sprintf(
                        /* translators: %d: box index */
                        __('Box %d: Variable handling — select a valid rate type or clear variable handling fields.', 'teamzlab-fedex'),
                        $n
                    );
                } else {
                    $rlt = isset($vh['rateLevelType']) ? strtoupper((string) $vh['rateLevelType']) : '';
                    if ($rlt !== '' && !in_array($rlt, PackageLineExtras::VARIABLE_RATE_LEVEL_TYPES, true)) {
                        $errors[] = sprintf(
                            /* translators: %d: box index */
                            __('Box %d: Variable handling — invalid rate level type.', 'teamzlab-fedex'),
                            $n
                        );
                    }
                    $reb = isset($vh['rateElementBasis']) ? strtoupper((string) $vh['rateElementBasis']) : '';
                    if ($reb !== '' && !in_array($reb, PackageLineExtras::RATE_ELEMENT_BASIS, true)) {
                        $errors[] = sprintf(
                            /* translators: %d: box index */
                            __('Box %d: Variable handling — invalid rate element basis.', 'teamzlab-fedex'),
                            $n
                        );
                    }
                    $has_pct = isset($vh['percentValue']) && (float) $vh['percentValue'] > 0;
                    $fv      = isset($vh['fixedValue']) && is_array($vh['fixedValue']) ? $vh['fixedValue'] : [];
                    $has_fv  = isset($fv['amount']) && (float) $fv['amount'] > 0
                        && isset($fv['currency']) && strlen((string) $fv['currency']) === 3;
                    if ($rt === 'CUSTOM' && !$has_pct && !$has_fv) {
                        $errors[] = sprintf(
                            /* translators: %d: box index */
                            __('Box %d: Variable handling — rate type CUSTOM requires a percent value and/or a fixed amount with currency.', 'teamzlab-fedex'),
                            $n
                        );
                    }
                }
            }

            if (!empty($extras['contentRecord']) && is_array($extras['contentRecord'])) {
                foreach ($extras['contentRecord'] as $row) {
                    if (!is_array($row)) {
                        continue;
                    }
                    $inum = isset($row['itemNumber']) ? trim((string) $row['itemNumber']) : '';
                    $rqty = isset($row['receivedQuantity']) ? (int) $row['receivedQuantity'] : 0;
                    $pnum = isset($row['partNumber']) ? trim((string) $row['partNumber']) : '';
                    if (($rqty > 0 || $pnum !== '') && $inum === '') {
                        $warnings[] = sprintf(
                            /* translators: %d: box index */
                            __('Box %d: A content record row has quantity or part number but no item number / SKU.', 'teamzlab-fedex'),
                            $n
                        );
                        break;
                    }
                }
            }
        }

        $out = ['errors' => $errors, 'warnings' => $warnings];

        return apply_filters('fshipping_openship_push_validation', $out, $packages);
    }
}
