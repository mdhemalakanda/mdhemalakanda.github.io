<?php
namespace FSHIPPING\Ajax;

use FSHIPPING\SingletonTrait;

/**
 * AIV webhook receiver.
 *
 * Registers a REST endpoint at /wp-json/fshipping/v1/aiv-webhook that
 * FedEx posts events to. Verifies the fdx-signature HMAC header, drops
 * replays (body-hash + event-id dedup + staleness guard) and persists
 * the latest event per tracking number into post-meta on the matching
 * `fedex_shipping` CPT row.
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class TrackingWebhookReceiver {
    use SingletonTrait;

    /**
     * Attach REST route registration.
     *
     * @return void
     * @since 1.1
     */
    public function init() {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    /**
     * Register the webhook endpoint.
     *
     * @return void
     * @since 1.1
     */
    public function register_routes() {
        register_rest_route('fshipping/v1', '/aiv-webhook', [
            'methods'             => 'POST',
            'callback'            => [$this, 'handle'],
            'permission_callback' => '__return_true', // auth happens via HMAC below
        ]);
    }

    /**
     * Handle an incoming webhook delivery.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     * @since 1.1
     */
    public function handle($request) {
        $raw_body  = $request->get_body();
        $signature = (string) $request->get_header('fdx-signature');

        if (!$this->verify_signature($raw_body, $signature)) {
            return new \WP_REST_Response(['ok' => false, 'error' => 'invalid_signature'], 401);
        }

        $payload = json_decode($raw_body, true);
        if (!is_array($payload)) {
            return new \WP_REST_Response(['ok' => false, 'error' => 'invalid_payload'], 400);
        }

        // Replay protection (SEC-03). The HMAC proves the body came from
        // FedEx, not that it is new — a captured valid POST would otherwise
        // replay forever and re-fire fshipping_aiv_event_received (duplicate
        // timeline entries, re-completed orders, repeat customer emails).
        if ($this->is_replayed_delivery($raw_body, $payload)) {
            // Idempotent success so FedEx stops retrying a delivery it
            // already processed; nothing is re-dispatched.
            return new \WP_REST_Response(['ok' => true, 'duplicate' => true], 200);
        }

        $event_time = $this->extract_event_time($payload);
        if (!empty($event_time) && !$this->is_fresh_event_time($event_time)) {
            $this->log_info('AIV webhook stale event skipped: ' . sanitize_text_field((string) $event_time));
            return new \WP_REST_Response(['ok' => false, 'error' => 'stale_event'], 200);
        }

        $events = $this->extract_events($payload);
        foreach ($events as $event) {
            $tn = isset($event['trackingNumber']) ? sanitize_text_field($event['trackingNumber']) : '';
            if (empty($tn)) {
                continue;
            }
            $this->persist_event($tn, $event);
            do_action('fshipping_aiv_event_received', $tn, $event);
        }

        return new \WP_REST_Response(['ok' => true, 'count' => count($events)], 200);
    }

    /**
     * Verify fdx-signature HMAC using the shared secret from settings.
     *
     * @param string $raw_body
     * @param string $signature
     * @return bool
     * @since 1.1
     */
    private function verify_signature($raw_body, $signature) {
        $settings = get_option('fshipping_options');
        $secret   = !empty($settings['fshipping_aiv_shared_secret']) ? (string) $settings['fshipping_aiv_shared_secret'] : '';
        if (empty($secret)) {
            // Fail closed: with no shared secret configured there is no way to
            // authenticate the caller, so every delivery must be rejected.
            // Otherwise anyone could forge delivery events and mutate orders.
            return false;
        }
        if (empty($signature)) {
            return false;
        }
        $expected = base64_encode(hash_hmac('sha256', $raw_body, $secret, true));
        return hash_equals($expected, $signature);
    }

    /**
     * Detect a replayed delivery and record the new one.
     *
     * Two dedup layers, both fixed 24h transients (fail-open: a transient
     * write failure only weakens dedup, it never rejects a fresh event):
     *   1. Exact body hash — kills byte-identical replays of a captured
     *      valid POST, the common case for FedEx retries and captures.
     *   2. Event id, when the payload carries one — catches FedEx
     *      re-delivering the same event with, say, reordered JSON keys.
     *
     * @param string $raw_body
     * @param array  $payload
     * @return bool True when this delivery was already processed.
     * @since 1.2.3
     */
    private function is_replayed_delivery($raw_body, array $payload) {
        $hash = hash('sha256', (string) $raw_body);
        $body_key = 'fshipping_aiv_seen_' . substr($hash, 0, 32);
        if (false !== get_transient($body_key)) {
            $this->log_info('AIV webhook duplicate body skipped (' . substr($hash, 0, 32) . ').');
            return true;
        }
        set_transient($body_key, 1, DAY_IN_SECONDS);

        $event_id = $this->extract_event_id($payload);
        if ('' === $event_id) {
            return false;
        }
        $event_key = 'fshipping_aiv_eid_' . md5($event_id);
        if (false !== get_transient($event_key)) {
            $this->log_info('AIV webhook duplicate event id skipped: ' . $event_id);
            return true;
        }
        set_transient($event_key, 1, DAY_IN_SECONDS);

        return false;
    }

    /**
     * Pull the first non-empty event identifier from the payload.
     *
     * FedEx AIV payloads vary by subscription type, so check the common
     * id field names at the top level and inside the first event.
     *
     * @param array $payload
     * @return string Sanitized id, or '' when absent.
     * @since 1.2.3
     */
    private function extract_event_id(array $payload) {
        $candidates = [
            $payload['eventId']         ?? '',
            $payload['event_id']        ?? '',
            $payload['notificationId']  ?? '',
            $payload['notification_id'] ?? '',
        ];
        if (!empty($payload['events']) && is_array($payload['events'])) {
            $first = $payload['events'][0];
        } elseif (!empty($payload['notifications']) && is_array($payload['notifications'])) {
            $first = $payload['notifications'][0];
        } else {
            $first = $payload;
        }
        if (is_array($first)) {
            $candidates[] = $first['eventId']         ?? '';
            $candidates[] = $first['event_id']        ?? '';
            $candidates[] = $first['notificationId']  ?? '';
            $candidates[] = $first['notification_id'] ?? '';
        }
        foreach ($candidates as $candidate) {
            $candidate = sanitize_text_field((string) $candidate);
            if ('' !== $candidate) {
                return $candidate;
            }
        }
        return '';
    }

    /**
     * Best-effort event timestamp from the payload.
     *
     * Mirrors the eventDateTime/timestamp fallbacks used when persisting
     * and recording AIV events elsewhere in the plugin.
     *
     * @param array $payload
     * @return string Timestamp string, or '' when none present.
     * @since 1.2.3
     */
    private function extract_event_time(array $payload) {
        $candidates = [
            $payload['eventDateTime'] ?? '',
            $payload['timestamp']     ?? '',
            $payload['eventTime']     ?? '',
        ];
        if (!empty($payload['events']) && is_array($payload['events'])) {
            $first = $payload['events'][0];
        } elseif (!empty($payload['notifications']) && is_array($payload['notifications'])) {
            $first = $payload['notifications'][0];
        } else {
            $first = $payload;
        }
        if (is_array($first)) {
            $candidates[] = $first['eventDateTime'] ?? '';
            $candidates[] = $first['timestamp']     ?? '';
            $candidates[] = $first['eventTime']     ?? '';
        }
        foreach ($candidates as $candidate) {
            $candidate = sanitize_text_field((string) $candidate);
            if ('' !== $candidate) {
                return $candidate;
            }
        }
        return '';
    }

    /**
     * Staleness window: reject events older than 24h or more than 15
     * minutes in the future — loose enough for legitimate FedEx retries,
     * tight enough to kill ancient replays.
     *
     * @param string $event_time Raw timestamp string from the payload.
     * @return bool True when the timestamp is acceptable (unparseable
     *             timestamps are tolerated, the dedup layers still apply).
     * @since 1.2.3
     */
    private function is_fresh_event_time($event_time) {
        $ts = strtotime((string) $event_time);
        if (false === $ts) {
            return true;
        }
        $now = time();
        return $ts >= ($now - DAY_IN_SECONDS) && $ts <= ($now + 15 * MINUTE_IN_SECONDS);
    }

    /**
     * Log at info level to the WooCommerce log.
     *
     * @param string $message
     * @return void
     * @since 1.2.3
     */
    private function log_info($message) {
        if (!function_exists('wc_get_logger')) {
            return;
        }
        wc_get_logger()->info((string) $message, ['source' => 'teamz_fedex_webhook']);
    }

    /**
     * Normalize whatever shape FedEx sent into a flat list of events.
     *
     * @param array $payload
     * @return array
     * @since 1.1
     */
    private function extract_events(array $payload) {
        if (!empty($payload['events']) && is_array($payload['events'])) {
            return $payload['events'];
        }
        if (!empty($payload['notifications']) && is_array($payload['notifications'])) {
            return $payload['notifications'];
        }
        if (!empty($payload['trackingNumber'])) {
            return [$payload];
        }
        return [];
    }

    /**
     * Persist the latest event onto the matching shipment post.
     *
     * @param string $tracking_number
     * @param array  $event
     * @return void
     * @since 1.1
     */
    private function persist_event($tracking_number, array $event) {
        $shipment_id = $this->find_shipment_id_by_tracking_number($tracking_number);
        if (empty($shipment_id)) {
            return;
        }

        $status = $event['eventType']    ?? ($event['statusCode'] ?? '');
        $desc   = $event['eventDescription'] ?? ($event['description'] ?? '');
        $at     = $event['eventDateTime']    ?? ($event['timestamp'] ?? current_time('c'));

        update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
            'status'      => sanitize_text_field((string) $status),
            'description' => sanitize_text_field((string) $desc),
            'at'          => sanitize_text_field((string) $at),
            'raw'         => wp_kses_post(wp_json_encode($event)),
        ]);
        update_post_meta($shipment_id, '_fshipping_aiv_last_event_at', current_time('mysql'));
    }

    /**
     * @param string $tracking_number
     * @return int
     * @since 1.1
     */
    private function find_shipment_id_by_tracking_number($tracking_number) {
        if (empty($tracking_number)) {
            return 0;
        }
        $ids = get_posts([
            'post_type'      => 'fedex_shipping',
            'post_status'    => 'any',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Required for webhook routing; exact-match lookup on this plugin's fedex_shipping CPT by its _tracking_number meta to persist the AIV event, hard-limited to 1.
            'meta_query'     => [[
                'key'     => '_tracking_number',
                'value'   => $tracking_number,
                'compare' => '=',
            ]],
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ]);
        return !empty($ids) ? (int) reset($ids) : 0;
    }
}
