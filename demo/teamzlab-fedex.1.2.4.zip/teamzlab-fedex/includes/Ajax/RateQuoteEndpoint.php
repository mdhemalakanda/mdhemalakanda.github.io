<?php
namespace FSHIPPING\Ajax;

use FSHIPPING\HTTP\Rates;
use FSHIPPING\SingletonTrait;

/**
 * Public REST endpoint for the embeddable rate-calculator widget.
 *
 * Registers GET /wp-json/fshipping/v1/rate-quote so external sites can
 * embed a small form that asks this plugin for a rate. This is the
 * "free embeddable widget = free backlinks" growth loop described in
 * Section 5.4 of the research brief.
 *
 * The endpoint:
 *   - Is public (no auth). Rate-limited per-IP via a transient counter.
 *   - Emits CORS `Access-Control-Allow-Origin: *` so it can be embedded.
 *   - Sanitizes every input and caches by payload hash for 15 min.
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class RateQuoteEndpoint {
    use SingletonTrait;

    /** Per-IP requests allowed per hour. */
    const RATE_LIMIT_PER_HOUR = 60;

    /**
     * @return void
     * @since 1.1
     */
    public function init() {
        add_action('rest_api_init', [$this, 'register']);
    }

    /**
     * @return void
     * @since 1.1
     */
    public function register() {
        register_rest_route('fshipping/v1', '/rate-quote', [
            'methods'             => 'GET',
            'callback'            => [$this, 'handle'],
            'permission_callback' => '__return_true',
            'args' => [
                'origin_postcode'      => ['required' => true,  'sanitize_callback' => 'sanitize_text_field'],
                'origin_country'       => ['required' => false, 'sanitize_callback' => 'sanitize_text_field', 'default' => 'US'],
                'destination_postcode' => ['required' => true,  'sanitize_callback' => 'sanitize_text_field'],
                'destination_country'  => ['required' => false, 'sanitize_callback' => 'sanitize_text_field', 'default' => 'US'],
                'weight'               => ['required' => false, 'default' => 1],
                'weight_unit'          => ['required' => false, 'sanitize_callback' => 'sanitize_text_field', 'default' => 'LB'],
                'length'               => ['required' => false, 'default' => 10],
                'width'                => ['required' => false, 'default' => 10],
                'height'               => ['required' => false, 'default' => 10],
                'dimension_unit'       => ['required' => false, 'sanitize_callback' => 'sanitize_text_field', 'default' => 'IN'],
            ],
        ]);
    }

    /**
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     * @since 1.1
     */
    public function handle($request) {
        $ip          = $this->client_ip();
        $rate_key    = 'fshipping_rq_ip_' . md5($ip);
        $rate_count  = (int) get_transient($rate_key);
        if ($rate_count >= self::RATE_LIMIT_PER_HOUR) {
            return $this->cors(new \WP_REST_Response([
                'ok'    => false,
                'error' => 'rate_limited',
                'hint'  => 'Try again in an hour.',
            ], 429));
        }
        set_transient($rate_key, $rate_count + 1, HOUR_IN_SECONDS);

        $args = [
            'origin_postcode'      => (string) $request->get_param('origin_postcode'),
            'origin_country'       => (string) $request->get_param('origin_country'),
            'destination_postcode' => (string) $request->get_param('destination_postcode'),
            'destination_country'  => (string) $request->get_param('destination_country'),
            'weight'               => (float)  $request->get_param('weight'),
            'weight_unit'          => (string) $request->get_param('weight_unit'),
            'length'               => (int)    $request->get_param('length'),
            'width'                => (int)    $request->get_param('width'),
            'height'               => (int)    $request->get_param('height'),
            'dimension_unit'       => (string) $request->get_param('dimension_unit'),
        ];

        $cache_key  = 'fshipping_rq_' . md5(wp_json_encode($args));
        $cached     = get_transient($cache_key);
        if (false !== $cached) {
            return $this->cors(new \WP_REST_Response([
                'ok'     => true,
                'source' => 'cache',
                'rates'  => $cached,
            ], 200));
        }

        $reply = Rates::instance()->get_rates($args);
        $rates = $this->normalize_reply($reply);

        set_transient($cache_key, $rates, 15 * MINUTE_IN_SECONDS);

        return $this->cors(new \WP_REST_Response([
            'ok'     => true,
            'source' => 'live',
            'rates'  => $rates,
        ], 200));
    }

    /**
     * Flatten FedEx's rateReplyDetails into a shape friendly for the
     * widget to render (service name, transit days, lowest charge).
     *
     * @param array $reply
     * @return array
     * @since 1.1
     */
    private function normalize_reply(array $reply) {
        $out = [];
        foreach ($reply as $entry) {
            $rated = $entry['ratedShipmentDetails'] ?? [];
            $best  = null;
            $priority = ['INCENTIVE', 'ACCOUNT', 'PREFERRED', 'LIST'];
            foreach ($priority as $rt) {
                foreach ($rated as $rd) {
                    if (($rd['rateType'] ?? '') === $rt) {
                        $best = $rd;
                        break 2;
                    }
                }
            }
            if (empty($best) && !empty($rated[0])) {
                $best = $rated[0];
            }
            if (empty($best)) {
                continue;
            }
            $out[] = [
                'service_type'  => sanitize_text_field($entry['serviceType'] ?? ''),
                'service_name'  => sanitize_text_field($entry['serviceName'] ?? ''),
                'total_charge'  => (float)            ($best['totalNetCharge'] ?? 0),
                'currency'      => sanitize_text_field($best['currency'] ?? 'USD'),
                'transit_time'  => sanitize_text_field($entry['operationalDetail']['transitTime'] ?? ''),
                'delivery_date' => sanitize_text_field($entry['operationalDetail']['deliveryDate'] ?? ''),
            ];
        }
        return $out;
    }

    /**
     * Add CORS headers for embedding.
     *
     * @param \WP_REST_Response $response
     * @return \WP_REST_Response
     * @since 1.1
     */
    private function cors($response) {
        $response->header('Access-Control-Allow-Origin',  '*');
        $response->header('Access-Control-Allow-Methods', 'GET');
        $response->header('Cache-Control',                'public, max-age=900');
        return $response;
    }

    /**
     * Best-effort client IP for rate limiting.
     *
     * @return string
     * @since 1.1
     */
    private function client_ip() {
        // Rate-limit bucket on the connection peer only. Trusting spoofable
        // forwarding headers (Cf-Connecting-Ip / X-Forwarded-For) let callers
        // rotate fake IPs to bypass the throttle.
        $raw_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR'])) : '';
        if ($raw_ip !== '' && filter_var($raw_ip, FILTER_VALIDATE_IP)) {
            return $raw_ip;
        }
        return '0.0.0.0';
    }
}
