<?php
namespace FSHIPPING\Utils;

/**
 * Per-install randomized upload subdirectories for customer PDF documents.
 *
 * Label / return-label / SPOD PDFs are named after tracking numbers, which
 * recipients already know, so the historic flat folders under uploads were
 * guessable. Each kind now lives one level deeper inside a random
 * 16-hex-char directory generated once per install and persisted in the
 * `fshipping_secure_upload_dirs` option (autoload off).
 *
 * The random segment is the real access control (nginx ignores .htaccess);
 * the .htaccess + index.php guards are still written for Apache hosts and
 * to block directory listing. Stored meta keeps the FULL public URL, so
 * email / admin / portal consumers keep working unchanged.
 *
 * @since 1.2.3
 */
defined('ABSPATH') || exit;

class SecureUploads {

    /**
     * Option (autoload off): kind => relative path under the uploads base dir.
     */
    const OPTION_KEY = 'fshipping_secure_upload_dirs';

    /**
     * Public (non-secret) folder roots per document kind.
     *
     * @return array<string,string>
     */
    private static function roots(): array {
        return [
            'labels'  => 'fedex-labels',
            'returns' => 'fedex-return-labels',
            'spod'    => 'fedex-spod',
        ];
    }

    /**
     * Absolute path of the randomized directory for a kind; creates the
     * directory (plus guard files) on first use.
     *
     * @param string $kind labels | returns | spod.
     * @return string Directory path without trailing slash, or '' on failure.
     */
    public static function get_dir( string $kind ): string {
        $base_dir = self::base_dir();
        if ('' === $base_dir) {
            return '';
        }
        $relative = self::relative_path($kind);
        if ('' === $relative) {
            return '';
        }
        $dir = $base_dir . '/' . $relative;
        if (!wp_mkdir_p($dir)) {
            return '';
        }
        // Keep the historic guards on the public root folder as well.
        self::write_guards($base_dir . '/' . self::roots()[$kind]);
        self::write_guards($dir);

        return $dir;
    }

    /**
     * Public URL of the randomized directory for a kind.
     *
     * @param string $kind labels | returns | spod.
     * @return string Directory URL without trailing slash, or '' on failure.
     */
    public static function get_url( string $kind ): string {
        $base_url = self::base_url();
        if ('' === $base_url) {
            return '';
        }
        $relative = self::relative_path($kind);
        if ('' === $relative) {
            return '';
        }

        return $base_url . '/' . $relative;
    }

    /**
     * @return string Uploads base dir without trailing slash, or '' on failure.
     */
    private static function base_dir(): string {
        $upload_dir = wp_upload_dir();

        return empty($upload_dir['error']) ? untrailingslashit((string) $upload_dir['basedir']) : '';
    }

    /**
     * @return string Uploads base URL without trailing slash, or '' on failure.
     */
    private static function base_url(): string {
        $upload_dir = wp_upload_dir();

        return empty($upload_dir['error']) ? untrailingslashit((string) $upload_dir['baseurl']) : '';
    }

    /**
     * Relative path (`<public root>/<random segment>`) for a kind, generating
     * and persisting the random segment once per install.
     *
     * @param string $kind labels | returns | spod.
     * @return string Relative path, or '' for an unknown kind.
     */
    private static function relative_path( string $kind ): string {
        $roots = self::roots();
        if (!isset($roots[$kind])) {
            return '';
        }

        $map = get_option(self::OPTION_KEY);
        $map = is_array($map) ? $map : [];

        if (isset($map[$kind]) && self::is_valid_relative_path((string) $map[$kind], $roots[$kind])) {
            return (string) $map[$kind];
        }

        // 64 bits of entropy: unguessable directory for practical purposes.
        $map[$kind] = $roots[$kind] . '/' . bin2hex(random_bytes(8));

        // Re-read immediately before saving so parallel first-use requests for
        // different kinds never overwrite each other's segment.
        $fresh = get_option(self::OPTION_KEY);
        $fresh = is_array($fresh) ? $fresh : [];
        $fresh[$kind] = $map[$kind];
        update_option(self::OPTION_KEY, $fresh, false);

        return $map[$kind];
    }

    /**
     * Only accept stored paths shaped `<root>/<16 hex>` so a corrupted or
     * tampered option value can never introduce traversal or a known path.
     *
     * @param string $path Stored relative path.
     * @param string $root Public root folder for the kind.
     * @return bool
     */
    private static function is_valid_relative_path( string $path, string $root ): bool {
        return 1 === preg_match('/^' . preg_quote($root, '/') . '\/[0-9a-f]{16}$/', $path);
    }

    /**
     * Drop .htaccess (Apache deny) + index.php (listing guard) into a folder.
     *
     * @param string $dir Absolute directory path.
     * @return void
     */
    private static function write_guards( string $dir ): void {
        if ('' === $dir || !is_dir($dir)) {
            return;
        }
        $htaccess = $dir . '/.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "Require all denied\n");
        }
        $index = $dir . '/index.php';
        if (!file_exists($index)) {
            file_put_contents($index, "<?php\n// Silence is golden.\n");
        }
    }
}
