<?php
/**
 * Normalize WooCommerce / checkout addresses for FedEx REST payloads.
 *
 * Fixes common mapping issues: UK county names sent as "state", city equal to
 * country name, and postcode formatting for GB / US / CA.
 *
 * @package FSHIPPING
 */
namespace FSHIPPING\Utils;

defined('ABSPATH') || exit;

class AddressNormalizer {

    /**
     * FedEx typically omits or leaves blank stateOrProvinceCode for these.
     * Sending a truncated or county name here often breaks validation.
     */
    private const COUNTRIES_OMIT_STATE = ['GB', 'JE', 'GG', 'IM', 'IE'];

    /**
     * @param array{street_lines?:string|array,city?:string,state?:string,postal_code?:string,country?:string} $address
     * @return array{street_lines:array<int,string>,city:string,state:string,postal_code:string,country:string}
     */
    public static function normalize_for_fedex(array $address): array {
        $country = self::normalize_country_code((string) ($address['country'] ?? 'US'));
        $street_in = $address['street_lines'] ?? [];
        if (is_string($street_in)) {
            $street_lines = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $street_in))));
        } else {
            $street_lines = array_values(array_filter(array_map('trim', array_map('strval', (array) $street_in))));
        }

        $city = trim((string) ($address['city'] ?? ''));
        $city = self::strip_city_if_country_name($city, $country);

        $state = trim((string) ($address['state'] ?? ''));
        $state = self::normalize_state_for_country($country, $state);

        $postal = self::normalize_postal_for_country($country, (string) ($address['postal_code'] ?? ''));

        return [
            'street_lines' => $street_lines,
            'city'         => $city,
            'state'        => $state,
            'postal_code'  => $postal,
            'country'      => $country,
        ];
    }

    /**
     * @param \WC_Order $order
     * @return array{street_lines:array<int,string>,city:string,state:string,postal:string,country:string}
     */
    public static function normalize_from_order(\WC_Order $order): array {
        $street1 = trim((string) ($order->get_shipping_address_1() ?: $order->get_billing_address_1()));
        $street2 = trim((string) ($order->get_shipping_address_2() ?: $order->get_billing_address_2()));
        $lines   = array_values(array_filter([$street1, $street2]));

        $norm = self::normalize_for_fedex([
            'street_lines' => $lines,
            'city'         => (string) ($order->get_shipping_city() ?: $order->get_billing_city()),
            'state'        => (string) ($order->get_shipping_state() ?: $order->get_billing_state()),
            'postal_code'  => (string) ($order->get_shipping_postcode() ?: $order->get_billing_postcode()),
            'country'      => (string) ($order->get_shipping_country() ?: $order->get_billing_country()),
        ]);

        return [
            'street_lines' => !empty($norm['street_lines']) ? $norm['street_lines'] : array_filter([$street1]),
            'city'         => $norm['city'],
            'state'        => $norm['state'],
            'postal'       => $norm['postal_code'],
            'country'      => $norm['country'],
        ];
    }

    /**
     * @param string $country ISO 3166-1 alpha-2
     * @param string $state   Raw state from WooCommerce
     * @return string         FedEx stateOrProvinceCode (often empty for UK/IE)
     */
    public static function normalize_state_for_country(string $country, string $state): string {
        $cc = self::normalize_country_code($country);
        $state = trim($state);
        if ($state === '') {
            return '';
        }

        if (in_array($cc, self::COUNTRIES_OMIT_STATE, true)) {
            return '';
        }

        if (strlen($state) === 2 && ctype_alpha($state)) {
            return strtoupper($state);
        }

        if (function_exists('WC') && WC()->countries) {
            $states = WC()->countries->get_states($cc);
            if (is_array($states)) {
                foreach ($states as $code => $label) {
                    $code_s = (string) $code;
                    $label_s = (string) $label;
                    if (strcasecmp($code_s, $state) === 0) {
                        return strtoupper($code_s);
                    }
                    if (strcasecmp($label_s, $state) === 0) {
                        return strtoupper($code_s);
                    }
                }
            }
        }

        if (in_array($cc, ['US', 'CA', 'AU', 'MX', 'BR'], true)) {
            return '';
        }

        return sanitize_text_field(substr($state, 0, 35));
    }

    /**
     * @param string $country ISO code
     * @param string $postal
     * @return string
     */
    public static function normalize_postal_for_country(string $country, string $postal): string {
        $cc = self::normalize_country_code($country);
        $postal = trim($postal);
        if ($postal === '') {
            return '';
        }

        if ($cc === 'GB') {
            $compact = strtoupper(preg_replace('/\s+/', '', $postal));
            if (preg_match('/^(.{2,4})([A-Z0-9]{3})$/', $compact, $m)) {
                return $m[1] . ' ' . $m[2];
            }
            return strtoupper($postal);
        }

        if ($cc === 'US') {
            $digits = preg_replace('/\D+/', '', $postal);
            if (strlen((string) $digits) >= 9) {
                return substr((string) $digits, 0, 5) . '-' . substr((string) $digits, 5, 4);
            }
            if (strlen((string) $digits) >= 5) {
                return substr((string) $digits, 0, 5);
            }
            return strtoupper($postal);
        }

        if ($cc === 'CA') {
            $compact = strtoupper(preg_replace('/\s+/', '', $postal));
            if (preg_match('/^([A-Z][0-9][A-Z])([0-9][A-Z][0-9])$/', $compact, $m)) {
                return $m[1] . ' ' . $m[2];
            }
            return strtoupper($postal);
        }

        return strtoupper($postal);
    }

    /**
     * @param string $code Country from WooCommerce
     * @return string      ISO 3166-1 alpha-2
     */
    public static function normalize_country_code(string $code): string {
        $code = strtoupper(trim($code));
        if ($code === 'UK') {
            return 'GB';
        }
        return $code;
    }

    /**
     * @param string $city
     * @param string $country ISO code
     * @return string
     */
    private static function strip_city_if_country_name(string $city, string $country): string {
        if ($city === '') {
            return '';
        }
        $cc = self::normalize_country_code($country);
        if (strcasecmp($city, $cc) === 0) {
            return '';
        }

        if (function_exists('WC') && WC()->countries) {
            $countries = WC()->countries->get_countries();
            if (isset($countries[ $cc ]) && strcasecmp($city, $countries[ $cc ]) === 0) {
                return '';
            }
        }

        $bad = ['UNITED KINGDOM', 'UK', 'GREAT BRITAIN', 'ENGLAND', 'SCOTLAND', 'WALES', 'NORTHERN IRELAND', 'UNITED STATES', 'USA', 'U.S.A.', 'CANADA'];
        if (in_array(strtoupper($city), $bad, true)) {
            return '';
        }

        return $city;
    }
}
