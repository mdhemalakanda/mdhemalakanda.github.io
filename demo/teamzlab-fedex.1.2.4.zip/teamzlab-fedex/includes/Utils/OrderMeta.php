<?php
namespace FSHIPPING\Utils;
defined('ABSPATH') || exit;

/**
 * Order-scoped meta access that works under HPOS.
 *
 * The legacy get_post_meta()/update_post_meta() calls this module replaces
 * landed on the `shop_order_placehold` stub post under HPOS, so tracking
 * numbers, label URLs, box names and similar flags written there were
 * silently invisible to every WC_Order::get_meta() reader (the OpenShip
 * layer). Writes go through WC_Order — order tables under HPOS, postmeta
 * on legacy stores — and reads prefer order meta, falling back to post
 * meta so data written before the fix stays visible on migrated stores.
 */
class OrderMeta {

    /**
     * Write an order-scoped meta value.
     *
     * @param int    $order_id Order id.
     * @param string $key      Meta key.
     * @param mixed  $value    Meta value.
     * @return bool True when written via the order API.
     */
    public static function update( $order_id, $key, $value ): bool {
        $order = ( function_exists( 'wc_get_order' ) ) ? wc_get_order( $order_id ) : null;
        if ( $order instanceof \WC_Order ) {
            $order->update_meta_data( $key, $value );
            $order->save();
            return true;
        }

        // Not a real order (custom id space) — keep the legacy behaviour.
        return false !== update_post_meta( (int) $order_id, $key, $value ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
    }

    /**
     * Delete an order-scoped meta value.
     *
     * @param int    $order_id Order id.
     * @param string $key      Meta key.
     * @return bool
     */
    public static function delete( $order_id, $key ): bool {
        $order = ( function_exists( 'wc_get_order' ) ) ? wc_get_order( $order_id ) : null;
        if ( $order instanceof \WC_Order ) {
            $order->delete_meta_data( $key );
            $order->save();
            return true;
        }

        return false !== delete_post_meta( (int) $order_id, $key ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
    }

    /**
     * Read an order-scoped meta value.
     *
     * Order meta first; when empty, falls back to post meta so values
     * written before the HPOS fix (or by third-party code) still resolve.
     *
     * @param int    $order_id Order id.
     * @param string $key      Meta key.
     * @param bool   $single   Return single value.
     * @return mixed
     */
    public static function get( $order_id, $key, $single = true ) {
        $order = ( function_exists( 'wc_get_order' ) ) ? wc_get_order( $order_id ) : null;
        if ( ! $order instanceof \WC_Order ) {
            return get_post_meta( (int) $order_id, $key, $single ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
        }

        $value = $order->get_meta( $key, $single );
        $empty = ( '' === $value || null === $value || array() === $value );
        if ( $empty ) {
            $legacy = get_post_meta( (int) $order_id, $key, $single ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
            if ( '' !== $legacy && null !== $legacy && array() !== $legacy ) {
                return $legacy;
            }
        }

        return $value;
    }
}
