<?php
namespace FSHIPPING\Utils;

use FSHIPPING\OpenShip\Draft;
use FSHIPPING\SingletonTrait;
/**
 * This file is responsible handle all tasks related to shipment.
 * 
 * @since 1.0
 */
class Shipment {
    use SingletonTrait;

    /**
     * Create shipment post
     * 
     * @return void
     */
    public function create_shipment_post($order, $api_data) {
        $post_id = wp_insert_post([
            'post_title'  => 'Shipment for Order #' . $order->get_id(),
            'post_type'   => 'fedex_shipping',
            'post_status' => 'publish',
        ]);

        if ( ! is_wp_error( $post_id ) ) {
            $this->save_shipment_meta( $post_id, $api_data, $order );
            update_post_meta( $post_id, '_fedex_shipment_order_id', $order->get_id() );
            do_action('fshipping_send_shipment_confirmation_mail', $post_id, $api_data);

            if ( function_exists( 'wc_add_notice' ) ) {
                wc_add_notice( __( 'Shipment created successfully!', 'teamzlab-fedex' ), 'success' );
            }
        }
    }

    /**
     * Save shipment meta.
     *
     * @param int                     $post_id
     * @param array<string, mixed>    $api_data FedEx Ship / Open Ship response body.
     * @param \WC_Order|null $order Order used to read persisted local label paths (after {@see \FSHIPPING\HTTP\Shipment::persist_shipment_from_api_response}).
     * @return void
     */
    public function save_shipment_meta($post_id, $api_data, $order = null) {
        $shipments = isset($api_data['output']['transactionShipments']) && is_array($api_data['output']['transactionShipments'])
            ? $api_data['output']['transactionShipments']
            : [];
        if ($shipments === []) {
            return;
        }

        $shipment = reset($shipments);
        if (!is_array($shipment)) {
            return;
        }

        $csd    = isset($shipment['completedShipmentDetail']) && is_array($shipment['completedShipmentDetail'])
            ? $shipment['completedShipmentDetail']
            : [];
        $rating = isset($csd['shipmentRating']) && is_array($csd['shipmentRating']) ? $csd['shipmentRating'] : [];
        $srds   = isset($rating['shipmentRateDetails'][0]) && is_array($rating['shipmentRateDetails'][0])
            ? $rating['shipmentRateDetails'][0]
            : [];
        $total_shipping_cost = isset($srds['totalNetCharge']) ? (string) $srds['totalNetCharge'] : '';
        $currency            = isset($srds['currency']) ? sanitize_text_field((string) $srds['currency']) : 'USD';

        // save tracking number.
        $tracking_number = '';
        if (!empty($shipment['masterTrackingNumber'])) {
            $tracking_number = sanitize_text_field((string) $shipment['masterTrackingNumber']);
        } elseif (!empty($shipment['pieceResponses'][0]['trackingNumber'])) {
            $tracking_number = sanitize_text_field((string) $shipment['pieceResponses'][0]['trackingNumber']);
        } elseif (!empty($api_data['transactionId'])) {
            // Keep legacy fallback only if a tracking number is unavailable.
            $tracking_number = sanitize_text_field((string) $api_data['transactionId']);
        }
        update_post_meta($post_id, '_tracking_number', $tracking_number);
        update_post_meta($post_id, '_transaction_id', !empty($api_data['transactionId']) ? sanitize_text_field((string) $api_data['transactionId']) : '');

        // save service type.
        $service_type = !empty($shipment['serviceType']) ? sanitize_text_field((string) $shipment['serviceType']) : '';
        update_post_meta($post_id, '_service_type', $service_type);

        // save total charge.
        $total_charge = $total_shipping_cost !== '' ? ($total_shipping_cost . $currency) : '';
        update_post_meta($post_id, '_total_charge', $total_charge);
        update_post_meta($post_id, '_total_charge_amount', $total_shipping_cost !== '' ? $total_shipping_cost : '0');
        update_post_meta($post_id, '_total_charge_currency', $currency);

        $order_id = ($order instanceof \WC_Order) ? (int) $order->get_id() : 0;
        $primary_local = $order_id > 0 ? (string) OrderMeta::get($order_id, '_fedex_label_url') : '';
        if ($primary_local !== '') {
            update_post_meta($post_id, '_shipping_label', esc_url_raw($primary_local));
        } else {
            $label_url = !empty($shipment['pieceResponses'][0]['packageDocuments'][0]['url'])
                ? esc_url_raw((string) $shipment['pieceResponses'][0]['packageDocuments'][0]['url'])
                : '';
            update_post_meta($post_id, '_shipping_label', $label_url);
        }

        if ($order_id > 0) {
            $pkg_json = (string) OrderMeta::get($order_id, Draft::META_PACKAGE_LABEL_FILES);
            if ($pkg_json !== '') {
                update_post_meta($post_id, Draft::META_PACKAGE_LABEL_FILES, $pkg_json);
            }
            $merged_local = (string) OrderMeta::get($order_id, Draft::META_MERGED_LABEL_FILE);
            if ($merged_local !== '') {
                update_post_meta($post_id, Draft::META_MERGED_LABEL_FILE, esc_url_raw($merged_local));
            }
        }
    }
}