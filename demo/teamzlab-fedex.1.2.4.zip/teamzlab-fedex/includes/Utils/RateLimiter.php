<?php
/**
 * Fixed-window per-IP rate limiter backed by WP transients / object cache.
 *
 * Mirrors the per-IP counter already used by the public rate-quote REST
 * endpoint (Ajax\RateQuoteEndpoint): bucket on the connection peer only,
 * count hits in a transient keyed by a hash of the IP, reject once the
 * count reaches the limit. Shared by the nopriv AJAX proxies and the
 * tracking shortcode live-lookup so every unauthenticated path that
 * spends FedEx quota is throttled.
 *
 * @package FSHIPPING
 */
namespace FSHIPPING\Utils;

defined('ABSPATH') || exit;

class RateLimiter {

    /**
     * Record one hit for $bucket from the current client and report whether
     * the request may proceed.
     *
     * Fixed-window counter: the transient is (re)written with a fresh
     * $window expiry on every hit, same as the rate-quote endpoint, so a
     * client that keeps hammering never earns a new window. Storage
     * failures fail OPEN — a broken object cache must not be able to take
     * checkout-adjacent endpoints down, so the limiter only ever *adds*
     * rejections when it can actually count.
     *
     * @param string $bucket Logical endpoint name (e.g. 'track').
     * @param int    $limit  Hits allowed per window.
     * @param int    $window Window length in seconds.
     * @return bool True when allowed, false when the limit is exhausted.
     */
    public static function check( string $bucket, int $limit = 60, int $window = HOUR_IN_SECONDS ): bool {
        if ($limit < 1 || $window < 1) {
            return true;
        }

        $key   = self::transient_key($bucket);
        $count = get_transient($key);

        if (false === $count) {
            // First hit of the window (or the cache cannot be read). Try to
            // start a counter; if the write fails the cache is broken — fail
            // open instead of blocking legitimate traffic.
            return false !== set_transient($key, 1, $window);
        }

        $count = (int) $count;
        if ($count >= $limit) {
            return false;
        }

        // Best effort on races: whichever write lands last wins, so the
        // counter can undercount under heavy concurrency. Acceptable here —
        // the goal is quota protection, not exact accounting. A failed write
        // also fails open below: this hit is allowed either way.
        set_transient($key, $count + 1, $window);
        return true;
    }

    /**
     * Hits still available for $bucket in the current window.
     *
     * @param string $bucket Logical endpoint name.
     * @param int    $limit  Hits allowed per window.
     * @return int
     */
    public static function remaining( string $bucket, int $limit = 60 ): int {
        $count = get_transient(self::transient_key($bucket));
        if (false === $count) {
            return max(0, $limit);
        }
        return max(0, $limit - (int) $count);
    }

    /**
     * Transient key for a bucket + client IP pair.
     *
     * Key style follows Ajax\RateQuoteEndpoint (`fshipping_rq_ip_' . md5($ip)`).
     *
     * @param string $bucket Logical endpoint name.
     * @return string
     */
    private static function transient_key( string $bucket ): string {
        return 'fshipping_rl_' . sanitize_key($bucket) . '_' . md5(self::client_ip());
    }

    /**
     * Best-effort client IP for rate limiting.
     *
     * Rate-limit bucket on the connection peer only. Trusting spoofable
     * forwarding headers (Cf-Connecting-Ip / X-Forwarded-For) would let
     * callers rotate fake IPs to bypass the throttle — REMOTE_ADDR on this
     * stack is the real client.
     *
     * @return string
     */
    private static function client_ip(): string {
        $raw_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR'])) : '';
        if ($raw_ip !== '' && filter_var($raw_ip, FILTER_VALIDATE_IP)) {
            return $raw_ip;
        }
        return '0.0.0.0';
    }
}
