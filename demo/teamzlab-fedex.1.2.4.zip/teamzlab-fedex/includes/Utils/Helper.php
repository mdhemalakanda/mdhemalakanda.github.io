<?php
namespace FSHIPPING\Utils;

use FSHIPPING\SingletonTrait;
/**
 * This function will use for all helper related task.
 * 
 * @since 1.0
 */
defined('ABSPATH') || exit;

class Helper {
    use SingletonTrait;
    private const FEDEX_DEFAULT_WEIGHT_UNIT = 'KG';

    /**
     * Check if WooCommerce runtime is available before calling WC APIs.
     *
     * @return bool
     */
    private function is_woocommerce_ready() {
        return function_exists( 'WC' ) && WC() && class_exists( '\WC_Countries' );
    }

    public function get_base_url() {
        $option = get_option('fshipping_options');
        $env_raw = !empty($option['fshipping_select_environemnt']) ? sanitize_text_field($option['fshipping_select_environemnt']) : 'sandbox';
        $env     = strtolower($env_raw);
        $url = 'https://apis-sandbox.fedex.com';
        if ($env === 'production') {
            $url = 'https://apis.fedex.com';
        }
        return $url;
    }

    /**
     * Global FedEx weight unit for outbound payloads.
     *
     * @return string
     */
    public function fedex_weight_unit(): string {
        $unit = strtoupper((string) apply_filters('fshipping_fedex_weight_unit', self::FEDEX_DEFAULT_WEIGHT_UNIT));
        return in_array($unit, ['KG', 'LB'], true) ? $unit : self::FEDEX_DEFAULT_WEIGHT_UNIT;
    }

    /**
     * Global FedEx measurement system.
     *
     * @return string metric|imperial
     */
    public function fedex_measurement_system(): string {
        $system = strtolower((string) apply_filters(
            'fshipping_fedex_measurement_system',
            $this->fedex_weight_unit() === 'KG' ? 'metric' : 'imperial'
        ));
        return in_array($system, ['metric', 'imperial'], true) ? $system : 'metric';
    }

    /**
     * Dimension unit for the selected global system.
     *
     * @return string
     */
    public function fedex_dimension_unit(): string {
        return $this->fedex_measurement_system() === 'imperial' ? 'IN' : 'CM';
    }

    /**
     * Convert a weight value between KG/LB/G/OZ.
     *
     * @param mixed  $value
     * @param string $from_unit
     * @param string $to_unit
     * @return float
     */
    public function normalize_fedex_weight($value, string $from_unit, string $to_unit = 'KG'): float {
        $raw = is_numeric($value) ? (float) $value : 0.0;
        $from = strtoupper(trim($from_unit));
        $to   = strtoupper(trim($to_unit));
        if ($from === 'LBS') {
            $from = 'LB';
        }
        if (!in_array($from, ['KG', 'LB', 'G', 'OZ'], true)) {
            $from = $this->fedex_weight_unit();
        }
        if ($to === 'LBS') {
            $to = 'LB';
        }
        if (!in_array($to, ['KG', 'LB'], true)) {
            $to = $this->fedex_weight_unit();
        }
        if ($raw <= 0) {
            return 0.0;
        }
        if ($from === $to) {
            return round($raw, 3);
        }
        if (function_exists('wc_get_weight')) {
            // wc_get_weight() only understands Woo unit slugs — 'lbs', not the
            // FedEx-style 'lb' — and silently skips conversion (returns the
            // input unchanged) when it meets an unknown unit.
            $woo_from = 'LB' === $from ? 'lbs' : strtolower($from);
            $woo_to   = 'LB' === $to ? 'lbs' : strtolower($to);
            $converted = (float) wc_get_weight($raw, $woo_to, $woo_from);
            return round(max(0.0, $converted), 3);
        }
        if ($from === 'G') {
            $raw = $raw / 1000;
            $from = 'KG';
        } elseif ($from === 'OZ') {
            $raw = $raw * 0.0283495231;
            $from = 'KG';
        }
        if ($from === 'LB') {
            $raw = $raw * 0.45359237;
            $from = 'KG';
        }
        if ($to === 'KG') {
            return round($raw, 3);
        }
        if ($to === 'LB') {
            return round($raw / 0.45359237, 3);
        }
        return round($raw, 3);
    }

    /**
     * Public alias for weight normalization.
     *
     * @param mixed  $value
     * @param string $from_unit
     * @param string $to_unit
     * @return float
     */
    public function normalize_weight($value, string $from_unit, string $to_unit = 'KG'): float {
        return $this->normalize_fedex_weight($value, $from_unit, $to_unit);
    }

    /**
     * Convert from store unit to global FedEx unit.
     *
     * @param mixed       $value
     * @param string|null $to_unit
     * @return float
     */
    public function normalize_store_weight($value, ?string $to_unit = null): float {
        $store_unit = strtoupper((string) get_option('woocommerce_weight_unit'));
        $from = in_array($store_unit, ['KG', 'LB', 'LBS', 'G', 'OZ'], true) ? ($store_unit === 'LBS' ? 'LB' : $store_unit) : 'KG';
        $target = $to_unit !== null ? strtoupper($to_unit) : $this->fedex_weight_unit();
        return $this->normalize_fedex_weight($value, $from, $target);
    }

    /**
     * Convert dimensions between CM and IN.
     *
     * @param mixed  $value
     * @param string $from_unit
     * @param string $to_unit
     * @return float
     */
    public function normalize_fedex_dimension($value, string $from_unit, string $to_unit = 'CM'): float {
        $raw = is_numeric($value) ? (float) $value : 0.0;
        $from = strtoupper(trim($from_unit));
        $to   = strtoupper(trim($to_unit));
        if (!in_array($from, ['CM', 'IN'], true)) {
            $from = $this->fedex_dimension_unit();
        }
        if (!in_array($to, ['CM', 'IN'], true)) {
            $to = $this->fedex_dimension_unit();
        }
        if ($raw <= 0) {
            return 0.0;
        }
        if ($from === $to) {
            return round($raw, 2);
        }
        if (function_exists('wc_get_dimension')) {
            $converted = (float) wc_get_dimension($raw, strtolower($to), strtolower($from));
            return round(max(0.0, $converted), 2);
        }
        if ($from === 'CM' && $to === 'IN') {
            return round($raw * 0.3937007874, 2);
        }
        if ($from === 'IN' && $to === 'CM') {
            return round($raw / 0.3937007874, 2);
        }
        return round($raw, 2);
    }

    /**
     * Public alias for dimension normalization.
     *
     * @param mixed  $value
     * @param string $from_unit
     * @param string $to_unit
     * @return float
     */
    public function normalize_dimensions($value, string $from_unit, string $to_unit = 'CM'): float {
        return $this->normalize_fedex_dimension($value, $from_unit, $to_unit);
    }

    /**
     * Convert from store dimension unit to global FedEx unit.
     *
     * @param mixed       $value
     * @param string|null $to_unit
     * @return float
     */
    public function normalize_store_dimension($value, ?string $to_unit = null): float {
        $store_unit = strtoupper((string) get_option('woocommerce_dimension_unit'));
        $from = in_array($store_unit, ['CM', 'IN'], true) ? $store_unit : 'CM';
        $target = $to_unit !== null ? strtoupper($to_unit) : $this->fedex_dimension_unit();
        return $this->normalize_fedex_dimension($value, $from, $target);
    }

    /**
     * Recursively normalize all FedEx payload weight blocks.
     *
     * @param array  $payload
     * @param string $target_unit
     * @return array
     */
    public function normalize_fedex_payload_weight_units(array $payload, string $target_unit = 'KG'): array {
        $target = strtoupper($target_unit);
        if (!in_array($target, ['KG', 'LB'], true)) {
            $target = $this->fedex_weight_unit();
        }
        return $this->normalize_weight_node($payload, $target);
    }

    /**
     * Recursively normalize all FedEx payload dimensions blocks.
     *
     * @param array  $payload
     * @param string $target_unit
     * @return array
     */
    public function normalize_fedex_payload_dimension_units(array $payload, string $target_unit = 'CM'): array {
        $target = strtoupper($target_unit);
        if (!in_array($target, ['CM', 'IN'], true)) {
            $target = $this->fedex_dimension_unit();
        }
        return $this->normalize_dimension_node($payload, $target);
    }

    /**
     * Ensure declared/customs totals are aligned before send.
     *
     * @param array $payload
     * @return array
     */
    public function normalize_declared_value(array $payload): array {
        if (empty($payload['requestedShipment']) || !is_array($payload['requestedShipment'])) {
            return $payload;
        }
        $rs = $payload['requestedShipment'];
        $declared = isset($rs['totalDeclaredValue']) && is_array($rs['totalDeclaredValue']) ? $rs['totalDeclaredValue'] : [];
        $clearance = isset($rs['customsClearanceDetail']) && is_array($rs['customsClearanceDetail']) ? $rs['customsClearanceDetail'] : [];
        $customs = isset($clearance['totalCustomsValue']) && is_array($clearance['totalCustomsValue']) ? $clearance['totalCustomsValue'] : [];
        $declared_amount = isset($declared['amount']) && is_numeric($declared['amount']) ? (float) $declared['amount'] : 0.0;
        $customs_amount = isset($customs['amount']) && is_numeric($customs['amount']) ? (float) $customs['amount'] : 0.0;

        if ($declared_amount <= 0 && $customs_amount <= 0) {
            return $payload;
        }

        $currency = '';
        if (!empty($declared['currency'])) {
            $currency = strtoupper((string) $declared['currency']);
        } elseif (!empty($customs['currency'])) {
            $currency = strtoupper((string) $customs['currency']);
        }
        if ($currency === '') {
            $currency = 'USD';
        }

        $aligned = max($declared_amount, $customs_amount);
        $rs['totalDeclaredValue'] = [
            'amount' => round($aligned, 2),
            'currency' => $currency,
        ];
        $clearance['totalCustomsValue'] = [
            'amount' => round($aligned, 2),
            'currency' => $currency,
        ];

        // FedEx validates shipment totalDeclaredValue against package-level declaredValue sum.
        if (!empty($rs['requestedPackageLineItems']) && is_array($rs['requestedPackageLineItems'])) {
            $line_items = $rs['requestedPackageLineItems'];
            $package_sum = 0.0;
            $has_package_declared = false;

            foreach ($line_items as $idx => $line) {
                if (is_array($line) && !empty($line['declaredValue']) && is_array($line['declaredValue'])) {
                    $amount = $line['declaredValue']['amount'] ?? 0;
                    if (is_numeric($amount)) {
                        $rounded_amount = round((float) $amount, 2);
                        $line['declaredValue']['amount'] = $rounded_amount;
                        $line['declaredValue']['currency'] = $currency;
                        $line_items[$idx] = $line;
                        $package_sum += $rounded_amount;
                        $has_package_declared = true;
                    }
                }
            }

            if ($has_package_declared && $package_sum > 0) {
                $aligned = round($package_sum, 2);
                $rs['requestedPackageLineItems'] = $line_items;
                $rs['totalDeclaredValue'] = [
                    'amount' => $aligned,
                    'currency' => $currency,
                ];
            } else {
                $count = max(1, count($line_items));
                $base = round($aligned / $count, 2);
                $remainder = round($aligned - ($base * $count), 2);
                foreach ($line_items as $idx => $line) {
                    if (!is_array($line)) {
                        $line = [];
                    }
                    $amount = $base;
                    if ($idx === ($count - 1)) {
                        $amount = round($base + $remainder, 2);
                    }
                    $line['declaredValue'] = [
                        'amount' => $amount,
                        'currency' => $currency,
                    ];
                    $line_items[$idx] = $line;
                }
                $rs['requestedPackageLineItems'] = $line_items;
                $rs['totalDeclaredValue'] = [
                    'amount' => round($aligned, 2),
                    'currency' => $currency,
                ];
            }
        }

        $rs['customsClearanceDetail'] = $clearance;
        $payload['requestedShipment'] = $rs;
        return $payload;
    }

    /**
     * Collect all explicit weight units found in payload.
     *
     * @param array $payload
     * @return array<int,string>
     */
    public function collect_fedex_payload_weight_units(array $payload): array {
        $units = [];
        $this->walk_weight_units($payload, '', $units);
        return array_values(array_unique($units));
    }

    private function normalize_weight_node(array $node, string $target): array {
        foreach ($node as $key => $value) {
            if (!is_array($value)) {
                continue;
            }
            $is_weight_key = is_string($key) && stripos($key, 'weight') !== false;
            if ($is_weight_key && array_key_exists('value', $value)) {
                $from = isset($value['units']) ? strtoupper((string) $value['units']) : $target;
                $node[$key]['units'] = $target;
                $node[$key]['value'] = $this->normalize_fedex_weight($value['value'], $from, $target);
                continue;
            }
            $node[$key] = $this->normalize_weight_node($value, $target);
        }
        return $node;
    }

    private function normalize_dimension_node(array $node, string $target): array {
        foreach ($node as $key => $value) {
            if (!is_array($value)) {
                continue;
            }
            $is_dimensions_block = is_string($key) && stripos($key, 'dimensions') !== false;
            if ($is_dimensions_block && isset($value['units'])) {
                $from = strtoupper((string) $value['units']);
                foreach (['length', 'width', 'height'] as $dim_key) {
                    if (isset($value[$dim_key])) {
                        $node[$key][$dim_key] = $this->normalize_fedex_dimension($value[$dim_key], $from, $target);
                    }
                }
                $node[$key]['units'] = $target;
                continue;
            }
            $node[$key] = $this->normalize_dimension_node($value, $target);
        }
        return $node;
    }

    /**
     * @param array<string,mixed> $node
     * @param string              $path
     * @param array<int,string>   $units
     * @return void
     */
    private function walk_weight_units(array $node, string $path, array &$units): void {
        foreach ($node as $key => $value) {
            $current = $path === '' ? (string) $key : ($path . '.' . (string) $key);
            if (is_array($value)) {
                $is_weight_key = is_string($key) && stripos($key, 'weight') !== false;
                if ($is_weight_key && isset($value['units'])) {
                    $unit = strtoupper((string) $value['units']);
                    if ($unit !== '') {
                        $units[] = $unit;
                    }
                }
                $this->walk_weight_units($value, $current, $units);
            }
        }
    }

    /**
     * True when requests are sent to FedEx sandbox host (matches {@see get_base_url()}).
     *
     * @return bool
     */
    public function hits_sandbox_fedex_api_host(): bool {
        return str_contains(strtolower($this->get_base_url()), 'apis-sandbox.fedex.com');
    }

    /**
     * Whether plugin FedEx API base URL is sandbox (apis-sandbox.fedex.com).
     * Production account numbers are not valid resources in sandbox — use the test account from developer.fedex.com (see RUNBOOK_CREDENTIALS.md).
     *
     * @return bool
     */
    public function is_sandbox_environment(): bool {
        $option = get_option('fshipping_options');
        $env_raw = !empty($option['fshipping_select_environemnt']) ? sanitize_text_field($option['fshipping_select_environemnt']) : 'sandbox';
        $env     = strtolower($env_raw);
        return $env !== 'production';
    }

    public function get_field_options($type) {
        $options = array();
        if($type === 'pickup_type') {
           $options = array(
                'CONTACT_FEDEX_TO_SCHEDULE' => __('Schedule FedEx Pickup', 'teamzlab-fedex'),
                'DROPOFF_AT_FEDEX_LOCATION' => __('Drop Off at FedEx', 'teamzlab-fedex'),
                'USE_SCHEDULED_PICKUP'      => __('Use Scheduled Pickup', 'teamzlab-fedex')
            );
        } elseif( $type === 'country_by_code' ) {
            if ( $this->is_woocommerce_ready() && WC()->countries ) {
                $countries_obj   = WC()->countries;
                $countries_array = $countries_obj->get_countries();
                $options = array();
                foreach ( $countries_array as $code => $country_name ) {
                    $options[ $code ] = $country_name . ' (' . $code . ')';
                }
            }
        } elseif( $type === 'rate_request' ) {
            $options = array(
                'LIST' => __('List', 'teamzlab-fedex'),
                'INCENTIVE' => __('Incentive', 'teamzlab-fedex'),
                'ACCOUNT' => __('Account', 'teamzlab-fedex'),
                'PREFERRED' => __('Preferred', 'teamzlab-fedex'),
            );
        } elseif( $type === 'states' ) {
            if ( $this->is_woocommerce_ready() ) {
                $countries_obj = new \WC_Countries();
                $options       = $countries_obj->get_states();
            }
        }  elseif( $type === 'service_type' ) {
            $options = array(
                'FEDEX_INTERNATIONAL_PRIORITY_EXPRESS' => esc_html__( 'FedEx International Priority® Express', 'teamzlab-fedex' ),
                'INTERNATIONAL_FIRST'                 => esc_html__( 'FedEx International First®', 'teamzlab-fedex' ),
                'FEDEX_INTERNATIONAL_PRIORITY'         => esc_html__( 'FedEx International Priority®', 'teamzlab-fedex' ),
                'FEDEX_FREIGHT_PRIORITY'               => esc_html__( 'FedEx LTL Freight Priority', 'teamzlab-fedex' ),
                'FEDEX_FREIGHT_ECONOMY'                => esc_html__( 'FedEx LTL Freight Economy', 'teamzlab-fedex' ),
                'INTERNATIONAL_ECONOMY'                => esc_html__( 'FedEx International Economy®', 'teamzlab-fedex' ),
                'FEDEX_GROUND'                         => esc_html__( 'FedEx International/Domestic Ground®', 'teamzlab-fedex' ),
                'FIRST_OVERNIGHT'                      => esc_html__( 'FedEx First Overnight®', 'teamzlab-fedex' ),
                'FEDEX_FIRST_FREIGHT'                  => esc_html__( 'FedEx First Overnight® Freight', 'teamzlab-fedex' ),
                'FEDEX_1_DAY_FREIGHT'                  => esc_html__( 'FedEx 1Day® Freight', 'teamzlab-fedex' ),
                'FEDEX_2_DAY_FREIGHT'                  => esc_html__( 'FedEx 2Day® Freight', 'teamzlab-fedex' ),
                'FEDEX_3_DAY_FREIGHT'                  => esc_html__( 'FedEx 3Day® Freight', 'teamzlab-fedex' ),
                'INTERNATIONAL_PRIORITY_FREIGHT'       => esc_html__( 'FedEx International Priority® Freight', 'teamzlab-fedex' ),
                'INTERNATIONAL_ECONOMY_FREIGHT'        => esc_html__( 'FedEx International Economy® Freight', 'teamzlab-fedex' ),
                'FEDEX_INTERNATIONAL_CONNECT_PLUS'     => esc_html__( 'FedEx International Connect Plus®', 'teamzlab-fedex' ),
                'FEDEX_INTERNATIONAL_DEFERRED_FREIGHT' => esc_html__( 'FedEx® International Deferred Freight', 'teamzlab-fedex' ),
                'INTERNATIONAL_PRIORITY_DISTRIBUTION'  => esc_html__( 'FedEx International Priority DirectDistribution®', 'teamzlab-fedex' ),
                'INTERNATIONAL_DISTRIBUTION_FREIGHT'   => esc_html__( 'FedEx International Priority DirectDistribution® Freight', 'teamzlab-fedex' ),
                'INTL_GROUND_DISTRIBUTION'             => esc_html__( 'International Ground® Distribution (IGD)', 'teamzlab-fedex' ),
                'GROUND_HOME_DELIVERY'                 => esc_html__( 'FedEx Home Delivery®', 'teamzlab-fedex' ),
                'SMART_POST'                           => esc_html__( 'FedEx Ground® Economy (SmartPost)', 'teamzlab-fedex' ),
                'PRIORITY_OVERNIGHT'                   => esc_html__( 'FedEx Priority Overnight®', 'teamzlab-fedex' ),
                'STANDARD_OVERNIGHT'                   => esc_html__( 'FedEx Standard Overnight®', 'teamzlab-fedex' ),
                'FEDEX_2_DAY'                          => esc_html__( 'FedEx 2Day®', 'teamzlab-fedex' ),
                'FEDEX_2_DAY_AM'                       => esc_html__( 'FedEx 2Day® AM', 'teamzlab-fedex' ),
                'FEDEX_EXPRESS_SAVER'                  => esc_html__( 'FedEx Express Saver®', 'teamzlab-fedex' ),
                'SAME_DAY'                             => esc_html__( 'FedEx SameDay®', 'teamzlab-fedex' ),
                'SAME_DAY_CITY'                        => esc_html__( 'FedEx SameDay® City', 'teamzlab-fedex' ),
            );
        } elseif( $type === 'packaging_type' ) {
            $options = array(
                'YOUR_PACKAGING'           => esc_html__( 'Customer Packaging', 'teamzlab-fedex' ),
                'FEDEX_ENVELOPE'           => esc_html__( 'FedEx® Envelope', 'teamzlab-fedex' ),
                'FEDEX_BOX'                => esc_html__( 'FedEx® Box', 'teamzlab-fedex' ),
                'FEDEX_EXTRA_SMALL_BOX'    => esc_html__( 'FedEx® Extra Small Box', 'teamzlab-fedex' ),
                'FEDEX_SMALL_BOX'          => esc_html__( 'FedEx® Small Box', 'teamzlab-fedex' ),
                'FEDEX_MEDIUM_BOX'         => esc_html__( 'FedEx® Medium Box', 'teamzlab-fedex' ),
                'FEDEX_LARGE_BOX'          => esc_html__( 'FedEx® Large Box', 'teamzlab-fedex' ),
                'FEDEX_EXTRA_LARGE_BOX'    => esc_html__( 'FedEx® Extra Large Box', 'teamzlab-fedex' ),
                'FEDEX_10KG_BOX'           => esc_html__( 'FedEx® 10kg Box', 'teamzlab-fedex' ),
                'FEDEX_25KG_BOX'           => esc_html__( 'FedEx® 25kg Box', 'teamzlab-fedex' ),
                'FEDEX_PAK'                => esc_html__( 'FedEx® Pak', 'teamzlab-fedex' ),
                'FEDEX_TUBE'               => esc_html__( 'FedEx® Tube', 'teamzlab-fedex' ),
            );
        } elseif( $type === 'payment_type' ) {
            $options = array(
                'SENDER' => esc_html__( 'Sender', 'teamzlab-fedex' ),
                'RECIPIENT' => esc_html__( 'Recipient', 'teamzlab-fedex' ),
                'THIRD_PARTY'      => esc_html__( 'Third Party', 'teamzlab-fedex' ),
                'COLLECT'      => esc_html__( 'Collect', 'teamzlab-fedex' ),
            );
        } elseif( $type === 'label_stock_type' ) {
            $options = array(
                'PAPER_4X6'                      => esc_html__( 'Paper 4×6', 'teamzlab-fedex' ),
                'STOCK_4X675'                    => esc_html__( 'Stock 4×6.75', 'teamzlab-fedex' ),
                'PAPER_4X675'                    => esc_html__( 'Paper 4×6.75', 'teamzlab-fedex' ),
                'PAPER_4X8'                      => esc_html__( 'Paper 4×8', 'teamzlab-fedex' ),
                'PAPER_4X9'                      => esc_html__( 'Paper 4×9', 'teamzlab-fedex' ),
                'PAPER_7X475'                    => esc_html__( 'Paper 7×4.75', 'teamzlab-fedex' ),
                'PAPER_85X11_BOTTOM_HALF_LABEL'  => esc_html__( 'Paper 8.5×11 Bottom Half Label', 'teamzlab-fedex' ),
                'PAPER_85X11_TOP_HALF_LABEL'     => esc_html__( 'Paper 8.5×11 Top Half Label', 'teamzlab-fedex' ),
                'PAPER_LETTER'                   => esc_html__( 'Paper Letter', 'teamzlab-fedex' ),
                'STOCK_4X675_LEADING_DOC_TAB'    => esc_html__( 'Stock 4×6.75 Leading Doc Tab', 'teamzlab-fedex' ),
                'STOCK_4X8'                      => esc_html__( 'Stock 4×8', 'teamzlab-fedex' ),
                'STOCK_4X9_LEADING_DOC_TAB'      => esc_html__( 'Stock 4×9 Leading Doc Tab', 'teamzlab-fedex' ),
                'STOCK_4X6'                      => esc_html__( 'Stock 4×6', 'teamzlab-fedex' ),
                'STOCK_4X675_TRAILING_DOC_TAB'   => esc_html__( 'Stock 4×6.75 Trailing Doc Tab', 'teamzlab-fedex' ),
                'STOCK_4X9_TRAILING_DOC_TAB'     => esc_html__( 'Stock 4×9 Trailing Doc Tab', 'teamzlab-fedex' ),
                'STOCK_4X9'                      => esc_html__( 'Stock 4×9', 'teamzlab-fedex' ),
                'STOCK_4X85_TRAILING_DOC_TAB'    => esc_html__( 'Stock 4×8.5 Trailing Doc Tab', 'teamzlab-fedex' ),
                'STOCK_4X105_TRAILING_DOC_TAB'   => esc_html__( 'Stock 4×10.5 Trailing Doc Tab', 'teamzlab-fedex' ),
            );
        }

        return $options;
    }

    /**
     * Global fulfillment mode: Ship API at checkout vs Open Ship draft workflow.
     *
     * @return string 'instant'|'advanced'
     * @since 1.3
     */
    public function get_shipping_mode(): string {
        $options = get_option('fshipping_options');
        if (!is_array($options)) {
            return 'instant';
        }
        $mode = isset($options['fshipping_shipping_mode']) ? sanitize_text_field((string) $options['fshipping_shipping_mode']) : '';
        return in_array($mode, ['instant', 'advanced'], true) ? $mode : 'instant';
    }
}