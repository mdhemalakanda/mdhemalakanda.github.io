<?php
namespace FSHIPPING\Utils;

/**
 * Normalizes FedEx Ship **money** blocks on Open Ship **Add Package** line items
 * (declared value, COD collection amount, variable-handling fixed value): resolves
 * currency, rounds amounts. Values are sent to FedEx with the ISO currency you
 * enter (or the order currency when omitted).
 */
defined('ABSPATH') || exit;

class FedExMoneyUsd {
    /**
     * @param array<string, mixed> $line_item FedEx `RequestedPackageLineItem` fragment.
     * @param \WC_Order|null       $order
     * @param array<string, mixed> $package   Normalized package row (admin / Draft).
     * @return array<string, mixed>
     */
    public static function normalize_requested_package_line_item(array $line_item, $order, array $package): array {
        $fallback = self::fallback_currency($order, $package);

        if (!empty($line_item['declaredValue']) && is_array($line_item['declaredValue'])) {
            $line_item['declaredValue'] = self::normalize_money_block($line_item['declaredValue'], $fallback);
        }

        if (!empty($line_item['variableHandlingChargeDetail']['fixedValue']) && is_array($line_item['variableHandlingChargeDetail']['fixedValue'])) {
            $line_item['variableHandlingChargeDetail']['fixedValue'] = self::normalize_money_block(
                $line_item['variableHandlingChargeDetail']['fixedValue'],
                $fallback
            );
        }

        if (!empty($line_item['packageSpecialServices']['packageCODDetail']['codCollectionAmount'])
            && is_array($line_item['packageSpecialServices']['packageCODDetail']['codCollectionAmount'])) {
            $pss = $line_item['packageSpecialServices'];
            $pss['packageCODDetail']['codCollectionAmount'] = self::normalize_money_block(
                $pss['packageCODDetail']['codCollectionAmount'],
                $fallback
            );
            $line_item['packageSpecialServices'] = $pss;
        }

        /** @var array<string, mixed> */
        return apply_filters('fshipping_fedex_money_usd_line_item', $line_item, $order, $package);
    }

    /**
     * Currency used when a money block omits `currency` (declared value defaults to order currency).
     */
    public static function fallback_currency($order, array $package): string {
        if (!empty($package['declared_value_currency'])) {
            return strtoupper(sanitize_text_field((string) $package['declared_value_currency']));
        }
        if ($order instanceof \WC_Order && method_exists($order, 'get_currency')) {
            $c = (string) $order->get_currency();
            if ($c !== '') {
                return strtoupper($c);
            }
        }

        return 'USD';
    }

    /**
     * @param array<string, mixed> $block `amount` + `currency`
     * @return array{amount: string, currency: string}
     */
    public static function normalize_money_block(array $block, string $fallback_currency): array {
        $amt = isset($block['amount']) ? (float) $block['amount'] : 0.0;
        $cur = isset($block['currency']) ? strtoupper(trim((string) $block['currency'])) : '';
        if ($cur === '') {
            $cur = strtoupper(trim($fallback_currency));
        }
        if ($amt <= 0.0) {
            return [
                'amount'   => '0',
                'currency' => 'USD',
            ];
        }
        if ($cur === '' || strlen($cur) !== 3 || !ctype_alpha($cur)) {
            $cur = 'USD';
        }
        $decimals = ($cur === 'JPY' || $cur === 'KRW') ? 0 : 2;

        return [
            'amount'   => (string) round($amt, $decimals),
            'currency' => $cur,
        ];
    }

    /**
     * @deprecated Use {@see normalize_money_block()} — kept for backward compatibility.
     *
     * @param array<string, mixed> $block
     * @return array{amount: string, currency: string}
     */
    public static function money_block_to_usd(array $block, string $fallback_currency): array {
        return self::normalize_money_block($block, $fallback_currency);
    }
}
