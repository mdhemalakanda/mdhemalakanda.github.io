<?php
namespace FSHIPPING\Frontend;

use FSHIPPING\SingletonTrait;

/**
 * Customer-facing self-serve Return Tag portal.
 *
 * Renders the `[fshipping_return_portal]` shortcode: a logged-in customer
 * picks a delivered order, selects items + reason, submits, and gets a
 * Return Tag label emailed plus the three nearest FedEx Hold-at-Location
 * drop-offs.
 *
 * This class owns the *logic* — eligibility, input validation, HAL
 * formatting — so it's unit-testable in isolation. The HTML surface is
 * a thin `render()` wrapper and the WooCommerce glue (loading the order,
 * dispatching `HTTP\ReturnTag`, sending the customer email) lives in
 * orchestrator code that depends on a live WP install.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class ReturnPortal {
    use SingletonTrait;

    public const DEFAULT_WINDOW_DAYS = 30;

    /**
     * Valid return reasons. Keep this short + translatable via caller.
     *
     * @return array<string,string>
     * @since 1.2
     */
    public function allowed_reasons(): array {
        return [
            'damaged'        => 'Item arrived damaged',
            'wrong_item'     => 'Wrong item received',
            'not_as_described' => 'Not as described',
            'changed_mind'   => 'Changed my mind',
            'other'          => 'Other',
        ];
    }

    /**
     * Decide if an order is eligible for self-serve return.
     *
     * @param string $status        WooCommerce status slug (no `wc-` prefix).
     * @param int    $days_since_completed Whole days since the order was marked delivered / completed.
     * @param int    $window_days   Cut-off.
     * @return bool
     * @since 1.2
     */
    public function is_eligible(string $status, int $days_since_completed, int $window_days = self::DEFAULT_WINDOW_DAYS): bool {
        if (!in_array($status, ['completed', 'delivered'], true)) {
            return false;
        }
        if ($days_since_completed < 0) {
            return false;
        }
        return $days_since_completed <= $window_days;
    }

    /**
     * Validate + sanitize a submitted return request.
     *
     * @param array $input  User-submitted form values.
     * @return array{ok:bool,data:array,errors:array<string,string>} data['items']
     *                is an item list, or null when the caller sent no items
     *                (expanded to "all line items" by the handler).
     * @since 1.2
     */
    public function validate_request(array $input): array {
        $errors = [];
        $data   = [
            'order_id' => (int) ($input['order_id'] ?? 0),
            'email'    => sanitize_email((string) ($input['email'] ?? '')),
            'items'    => null,
            'reason'   => sanitize_text_field((string) ($input['reason'] ?? '')),
            'notes'    => sanitize_text_field((string) ($input['notes']  ?? '')),
        ];

        if ($data['order_id'] <= 0) {
            $errors['order_id'] = 'Missing order id.';
        }

        if ($data['email'] === '' || !is_email($data['email'])) {
            // Proof of ownership: the requester must know the billing email on
            // the order, otherwise any visitor could create paid return labels
            // for someone else's order id.
            $errors['email'] = 'Enter the billing email used on the order.';
        }

        // The rendered form ships without an item picker, so an absent `items`
        // key means "return every line item" — the handler expands it once the
        // order is loaded. A caller that *does* send `items` must send at
        // least one usable row.
        $raw_items = isset($input['items']) && is_array($input['items']) ? $input['items'] : null;
        if (is_array($raw_items)) {
            $data['items'] = [];
            foreach ($raw_items as $item) {
                $id  = (int) ($item['id']  ?? 0);
                $qty = (int) ($item['qty'] ?? 0);
                if ($id > 0 && $qty > 0) {
                    $data['items'][] = ['id' => $id, 'qty' => $qty];
                }
            }
            if (empty($data['items'])) {
                $errors['items'] = 'Pick at least one item to return.';
            }
        }

        if (!array_key_exists($data['reason'], $this->allowed_reasons())) {
            $errors['reason'] = 'Pick a return reason.';
        }

        return [
            'ok'     => empty($errors),
            'data'   => $data,
            'errors' => $errors,
        ];
    }

    /**
     * Extract a short HAL summary list from the raw Locations API response.
     *
     * @param array $locations_response Raw decoded body of /location/v1/locations.
     * @param int   $limit
     * @return array<int,array{name:string,street:string,city:string,state:string,postal:string,distance:float}>
     * @since 1.2
     */
    public function format_hal_dropoffs(array $locations_response, int $limit = 3): array {
        $results = [];
        $details = $locations_response['output']['locationDetailList'] ?? [];
        if (!is_array($details)) {
            return [];
        }

        foreach ($details as $loc) {
            if (!is_array($loc)) {
                continue;
            }
            $contact = $loc['contactAndAddress'] ?? [];
            $addr    = is_array($contact) ? ($contact['address'] ?? []) : [];
            $street  = is_array($addr['streetLines'] ?? null) ? implode(', ', $addr['streetLines']) : '';
            $results[] = [
                'name'     => (string) ($contact['contact']['companyName'] ?? ''),
                'street'   => $street,
                'city'     => (string) ($addr['city']                ?? ''),
                'state'    => (string) ($addr['stateOrProvinceCode'] ?? ''),
                'postal'   => (string) ($addr['postalCode']          ?? ''),
                'distance' => (float)  ($loc['distance']['value']    ?? 0.0),
            ];
            if (count($results) >= $limit) {
                break;
            }
        }

        return $results;
    }
}
