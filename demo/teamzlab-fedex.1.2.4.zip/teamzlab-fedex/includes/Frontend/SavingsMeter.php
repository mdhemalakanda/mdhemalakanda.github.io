<?php
namespace FSHIPPING\Frontend;

use FSHIPPING\SingletonTrait;

/**
 * Running "merchant dollars saved" counter.
 *
 * Every time AddressValidation reclassifies a shipping address from
 * residential → commercial (avoiding FedEx's ~$5 residential surcharge),
 * we record the delta here. The homepage renders a live "$X saved for
 * merchants this month" ticker — a concrete, shareable number.
 *
 * Not limited to surcharge savings — callers can record any named
 * reason (e.g. `better_service_selected`, `weight_rounding`). Stats are
 * windowable by reason + since-timestamp.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class SavingsMeter {
    use SingletonTrait;

    private const OPTION_LOG   = 'fshipping_savings_events';
    private const MAX_EVENTS   = 1000;

    public const REASON_RESIDENTIAL_TO_COMMERCIAL = 'residential_to_commercial';
    public const REASON_BETTER_SERVICE            = 'better_service_selected';
    public const REASON_WEIGHT_ROUNDING           = 'weight_rounding';

    /**
     * Record a savings event.
     *
     * @param int    $order_id
     * @param float  $amount_saved
     * @param string $reason
     * @param string $currency ISO 4217.
     * @param int    $at_ts    Unix ts; 0 = now.
     * @return bool
     * @since 1.2
     */
    public function record(int $order_id, float $amount_saved, string $reason, string $currency = 'USD', int $at_ts = 0): bool {
        if ($order_id <= 0 || $amount_saved <= 0 || $reason === '') {
            return false;
        }

        $log = $this->read_log();
        $log[] = [
            'order_id' => $order_id,
            'amount'   => round($amount_saved, 2),
            'reason'   => sanitize_text_field($reason),
            'currency' => strtoupper(sanitize_text_field($currency)),
            'at'       => $at_ts > 0 ? $at_ts : time(),
        ];

        if (count($log) > self::MAX_EVENTS) {
            $log = array_slice($log, -self::MAX_EVENTS);
        }
        update_option(self::OPTION_LOG, $log);
        return true;
    }

    /**
     * Summary totals, optionally filtered.
     *
     * @param int         $since_ts Unix ts; 0 = all time.
     * @param string|null $reason   Filter by reason, or null for all.
     * @param string      $currency Currency to include.
     * @return array{total:float,order_count:int,events:int,by_reason:array<string,float>,currency:string}
     * @since 1.2
     */
    public function totals(int $since_ts = 0, ?string $reason = null, string $currency = 'USD'): array {
        $currency = strtoupper($currency);
        $events   = $this->read_log();
        $orders   = [];
        $by_reason = [];
        $total    = 0.0;
        $count    = 0;

        foreach ($events as $e) {
            if (($e['currency'] ?? '') !== $currency) {
                continue;
            }
            if ($since_ts > 0 && (int) ($e['at'] ?? 0) < $since_ts) {
                continue;
            }
            if ($reason !== null && ($e['reason'] ?? '') !== $reason) {
                continue;
            }
            $amount = (float) ($e['amount'] ?? 0);
            $total += $amount;
            $count++;
            $orders[(int) ($e['order_id'] ?? 0)] = true;

            $r = (string) ($e['reason'] ?? 'unknown');
            $by_reason[$r] = ($by_reason[$r] ?? 0.0) + $amount;
        }

        return [
            'total'       => round($total, 2),
            'order_count' => count($orders),
            'events'      => $count,
            'by_reason'   => array_map(static fn($v) => round($v, 2), $by_reason),
            'currency'    => $currency,
        ];
    }

    /**
     * Pretty-format an amount using a simple locale-agnostic rule.
     * $1,234.56 / €1.234,56 etc. are left to WC on the render path.
     *
     * @param float  $amount
     * @param string $currency
     * @return string
     * @since 1.2
     */
    public function format_currency(float $amount, string $currency = 'USD'): string {
        $symbols = [
            'USD' => '$',
            'CAD' => 'CA$',
            'EUR' => '€',
            'GBP' => '£',
            'AUD' => 'A$',
        ];
        $symbol = $symbols[strtoupper($currency)] ?? (strtoupper($currency) . ' ');
        return $symbol . number_format($amount, 2, '.', ',');
    }

    /**
     * @return array<int,array<string,mixed>>
     * @since 1.2
     */
    public function events(): array {
        return $this->read_log();
    }

    /**
     * @return void
     * @since 1.2
     */
    public function clear(): void {
        update_option(self::OPTION_LOG, []);
    }

    /**
     * @return array<int,array<string,mixed>>
     * @since 1.2
     */
    private function read_log(): array {
        $log = get_option(self::OPTION_LOG, []);
        return is_array($log) ? $log : [];
    }
}
