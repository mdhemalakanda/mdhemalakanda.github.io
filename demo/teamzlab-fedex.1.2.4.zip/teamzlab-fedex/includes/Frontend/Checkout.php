<?php
/**
 * This class will create shpping.
 * 
 * @since 1.0
 */
namespace FSHIPPING\Frontend;

use FSHIPPING\HTTP\AddressValidation;
use FSHIPPING\HTTP\OpenShip;
use FSHIPPING\HTTP\PostalCodeValidation;
use FSHIPPING\HTTP\Shipment;
use FSHIPPING\Licensing\ShipmentQuota;
use FSHIPPING\OpenShip\Draft;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\AddressNormalizer;
use FSHIPPING\Utils\Helper;
defined('ABSPATH') || exit;

class Checkout {
    use SingletonTrait;

    public function init() {
        add_action('woocommerce_checkout_process', array($this, 'precheck_before_order_creation'), 20, 0);
        add_action('woocommerce_checkout_order_processed', array($this, 'create_shipment'), 20, 2);
        // Block checkout (WooCommerce Store API) never fires
        // woocommerce_checkout_order_processed — orders placed through it got
        // no shipment at all. Its equivalent passes the WC_Order object as the
        // first argument, which wc_get_order() accepts directly; the second
        // create_shipment() parameter is unused, so this binds 1:1.
        add_action('woocommerce_store_api_checkout_order_processed', array($this, 'create_shipment'), 20, 1);
    }

    /**
     * Run pre-ship guard before WooCommerce creates the order.
     * Blocks checkout when the guard returns false.
     *
     * @return void
     */
    public function precheck_before_order_creation(): void {
        if (!function_exists('WC') || !WC()->session || !WC()->cart) {
            return;
        }
        $contexts = $this->checkout_fedex_shipping_contexts_from_session();
        if (empty($contexts)) {
            return;
        }

        if ( ShipmentQuota::is_quota_reached() ) {
            $message = ShipmentQuota::checkout_notice_message();
            wc_add_notice( $message, 'error' );
            throw new \Exception( esc_html( $message ) );
        }

        $order_proxy = $this->build_precheck_order_proxy();
        foreach ($contexts as $ctx) {
            $this->trace(
                1,
                0,
                'CHECKOUT_TRIGGER',
                [
                    'shipping_method' => $ctx['id'] ?? '',
                    'shipping_meta'   => $ctx['meta'] ?? [],
                    'phase'           => 'checkout_process',
                ]
            );
            $this->trace(
                5,
                0,
                'SHIPMENT_GUARD_TRIGGERED',
                [
                    'filter'          => 'fshipping_pre_ship_check',
                    'shipping_method' => $ctx['id'] ?? '',
                    'phase'           => 'checkout_process',
                ]
            );
            $can_ship = apply_filters('fshipping_pre_ship_check', true, $order_proxy, $ctx);
            if (false === $can_ship) {
                $this->trace(
                    6,
                    0,
                    'SHIPMENT_BLOCKED',
                    [
                        'shipping_method' => $ctx['id'] ?? '',
                        'phase'           => 'checkout_process',
                    ]
                );
                $this->trace(
                    6,
                    0,
                    'CHECKOUT_BLOCKED',
                    [
                        'reason'          => 'fshipping_pre_ship_check_returned_false',
                        'shipping_method' => $ctx['id'] ?? '',
                    ]
                );
                if (function_exists('wc_add_notice')) {
                    wc_add_notice(
                        __('FedEx shipment blocked by pre-flight customs/compliance checks. Please review your shipping details and try again.', 'teamzlab-fedex'),
                        'error'
                    );
                }
                throw new \Exception(esc_html__('FedEx shipment blocked by pre-flight customs/compliance checks.', 'teamzlab-fedex'));
            }
        }
    }

    /**
     * Create shipment.
     *
     * This runs on woocommerce_checkout_order_processed /
     * woocommerce_store_api_checkout_order_processed — the order already
     * exists (and is normally already paid) when we get here. A failed label
     * purchase must therefore never surface as a checkout error: on the
     * Store API an uncaught exception from this hook turns into an HTTP 500
     * *after* the order was created, so the customer sees a broken checkout
     * while their order sits stranded (observed as order #131: HTTP 500,
     * order stuck in `pending`). Everything below records the failure on
     * the order and returns instead of throwing.
     */
    public function create_shipment($order_id, $data = []) {
        try {
            $this->create_shipment_for_order($order_id, $data);
        } catch (\Throwable $e) {
            $order = wc_get_order($order_id);
            $message = 'FedEx shipment creation failed after checkout: ' . wp_strip_all_tags($e->getMessage());
            if ($order) {
                $order->add_order_note($message, false);
                $order->update_meta_data('_fshipping_last_error', sanitize_text_field($e->getMessage()));
                $order->save();
            }
            if (function_exists('wc_get_logger')) {
                wc_get_logger()->error($message, ['source' => 'teamz_fedex_checkout']);
            }
        }
    }

    /**
     * Create the shipment for an order (guarded by create_shipment()).
     */
    private function create_shipment_for_order($order_id, $data = []) {
        unset($data);
        $order = wc_get_order($order_id);
        if (empty($order)) {
            return;
        }
        // The Store API hook passes a WC_Order object; downstream trace()
        // calls expect a plain int id.
        $order_id = method_exists($order, 'get_id') ? (int) $order->get_id() : (int) $order_id;

        // Duplicate-shipment guard: woocommerce_checkout_order_processed can
        // fire twice for one order (double-submit, gateway retries), and each
        // pass buys a *paid* FedEx label. Bail if a shipment record already
        // exists for this order.
        $existing = get_posts([
            'post_type'   => 'fedex_shipping',
            'post_status' => 'any',
            'fields'      => 'ids',
            'numberposts' => 1,
            'meta_key'    => '_fedex_shipment_order_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
            'meta_value'  => (string) $order_id,         // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
        ]);
        if (!empty($existing)) {
            $order->add_order_note(__('FedEx shipment already exists for this order; skipped duplicate shipment creation.', 'teamzlab-fedex'));
            return;
        }

        $shipping_methods = $order->get_shipping_methods();
        if (empty($shipping_methods)) {
            return;
        }

        $selected_method_ids = [];
        foreach ($shipping_methods as $item) {
            $method_id = (string) $item->get_method_id();
            $selected_method_ids[] = $method_id;
            if (!$this->is_fedex_shipping_method($method_id)) {
                continue;
            }

            $meta = [
                'service_type' => $item->get_meta('service_type'),
                'currency'     => $item->get_meta('currency'),
                'package'      => $item->get_meta('package')
            ];

            $current_shipping = [
                'id'    => $item->get_method_id(),
                'name'  => $item->get_name(),
                'total' => $item->get_total(),
                'meta'  => $meta
            ];
            $this->trace(
                1,
                (int) $order_id,
                'CHECKOUT_TRIGGER',
                [
                    'shipping_method' => $current_shipping['id'] ?? '',
                    'shipping_meta'   => $current_shipping['meta'] ?? [],
                ]
            );

            /**
             * Allow a guard (e.g. Events\ShipmentGuard running a
             * pre-flight Global Trade compliance check) to block a
             * Ship call before it fires. Return false to abort.
             *
             * @since 1.1
             * @param bool      $can_ship
             * @param \WC_Order $order
             * @param array     $current_shipping
             */
            $this->trace(
                5,
                (int) $order_id,
                'SHIPMENT_GUARD_TRIGGERED',
                [
                    'filter'          => 'fshipping_pre_ship_check',
                    'shipping_method' => $current_shipping['id'] ?? '',
                ]
            );
            $can_ship = apply_filters('fshipping_pre_ship_check', true, $order, $current_shipping);
            if (false === $can_ship) {
                $order->add_order_note(__('FedEx Ship call skipped by pre-flight guard.', 'teamzlab-fedex'), false);
                $this->trace(6, (int) $order_id, 'SHIP_API_GATE', ['decision' => 'BLOCK']);
                return;
            }

            if ($this->is_checkout_address_validation_enabled()) {
                $validation = $this->validate_order_for_fedex($order);
                if (empty($validation['valid'])) {
                    $message = !empty($validation['message'])
                        ? (string) $validation['message']
                        : __('FedEx shipment blocked: checkout address validation failed.', 'teamzlab-fedex');
                    $order->add_order_note($message, false);
                    throw new \Exception(esc_html(wp_strip_all_tags($message)));
                }
                if (!empty($validation['warning'])) {
                    $order->add_order_note((string) $validation['warning'], false);
                }
            }
            $this->trace(6, (int) $order_id, 'SHIP_API_GATE', ['decision' => 'ALLOW']);

            if ( ShipmentQuota::is_quota_reached() ) {
                // Fail soft here: the order row already exists, and throwing
                // after it was created only stranded an unpaid order on every
                // over-quota attempt. precheck_before_order_creation() is the
                // clean pre-order gate; this late check just prevents the
                // label purchase.
                $order->add_order_note( ShipmentQuota::checkout_notice_message(), false );
                return;
            }

            if (Helper::instance()->get_shipping_mode() === 'advanced') {
                $this->create_openship_draft($order, $current_shipping);
                return;
            }

            $order->update_meta_data(Draft::META_FULFILLMENT_MODE, 'instant');
            $order->save();

            Shipment::instance()->create_shipment($current_shipping, $order);
            return;
        }

        $order->add_order_note(
            sprintf(
                /* translators: %s: comma-separated list of the selected checkout shipping method IDs. */
                __('FedEx shipment skipped because selected checkout shipping method is not FedEx. Selected method(s): %s', 'teamzlab-fedex'),
                implode(', ', $selected_method_ids)
            ),
            false
        );
    }

    /**
     * FedEx checkout method ids are expected to be `fshipping_custom`.
     * Some stores/custom code may suffix ids; accept that shape too.
     */
    private function is_fedex_shipping_method(string $method_id): bool {
        if ($method_id === 'fshipping_custom') {
            return true;
        }

        return strpos($method_id, 'fshipping_custom_') === 0;
    }

    /**
     * Build checkout-stage FedEx shipping contexts from Woo session rates.
     *
     * @return array<int,array{id:string,name:string,total:float,meta:array}>
     */
    private function checkout_fedex_shipping_contexts_from_session(): array {
        $chosen = WC()->session ? (array) WC()->session->get('chosen_shipping_methods', []) : [];
        $contexts = [];
        foreach ($chosen as $pkg_index => $rate_id) {
            $session_pkg = (array) (WC()->session->get('shipping_for_package_' . $pkg_index, []) ?: []);
            $rates = isset($session_pkg['rates']) && is_array($session_pkg['rates']) ? $session_pkg['rates'] : [];
            if ($rate_id === '' || empty($rates[$rate_id]) || !is_object($rates[$rate_id])) {
                continue;
            }
            $rate = $rates[$rate_id];
            $method_id = method_exists($rate, 'get_method_id') ? (string) $rate->get_method_id() : '';
            if (!$this->is_fedex_shipping_method($method_id)) {
                continue;
            }
            $meta_data = method_exists($rate, 'get_meta_data') ? (array) $rate->get_meta_data() : [];
            $contexts[] = [
                'id'    => $method_id,
                'name'  => method_exists($rate, 'get_label') ? (string) $rate->get_label() : $method_id,
                'total' => method_exists($rate, 'get_cost') ? (float) $rate->get_cost() : 0.0,
                'meta'  => [
                    'service_type' => (string) ($meta_data['service_type'] ?? ''),
                    'currency'     => (string) ($meta_data['currency'] ?? get_woocommerce_currency()),
                    'package'      => is_array($meta_data['package'] ?? null) ? $meta_data['package'] : [],
                ],
            ];
        }
        return $contexts;
    }

    /**
     * Minimal order-like object for pre-order ShipmentGuard filtering.
     */
    private function build_precheck_order_proxy() {
        $customer = WC()->customer;
        $cart = WC()->cart;
        $items = [];
        foreach ((array) $cart->get_cart() as $line) {
            $product = isset($line['data']) ? $line['data'] : null;
            $qty = isset($line['quantity']) ? (int) $line['quantity'] : 1;
            $name = is_object($product) && method_exists($product, 'get_name') ? (string) $product->get_name() : '';
            $line_total = isset($line['line_total']) ? (float) $line['line_total'] : 0.0;
            $items[] = new class($product, $qty, $name, $line_total) {
                public function __construct(private $product, private int $qty, private string $name, private float $line_total) {}
                public function get_product() { return $this->product; }
                public function get_quantity(): int { return $this->qty; }
                public function get_name(): string { return $this->name; }
                public function get_total(): float { return $this->line_total; }
            };
        }

        return new class($customer, $cart, $items) {
            private array $notes = [];
            public function __construct(private $customer, private $cart, private array $items) {}
            public function get_id(): int { return 0; }
            public function get_shipping_country(): string { return (string) $this->customer->get_shipping_country(); }
            public function get_billing_country(): string { return (string) $this->customer->get_billing_country(); }
            public function get_shipping_postcode(): string { return (string) $this->customer->get_shipping_postcode(); }
            public function get_billing_postcode(): string { return (string) $this->customer->get_billing_postcode(); }
            public function get_shipping_state(): string { return (string) $this->customer->get_shipping_state(); }
            public function get_billing_state(): string { return (string) $this->customer->get_billing_state(); }
            public function get_total(): float { return (float) $this->cart->get_total('edit'); }
            public function get_currency(): string { return function_exists('get_woocommerce_currency') ? (string) get_woocommerce_currency() : 'USD'; }
            public function get_items(): array { return $this->items; }
            public function add_order_note($note, $is_customer_note = false): void { $this->notes[] = [$note, $is_customer_note]; }
        };
    }

    /**
     * Whether checkout address validation is enabled in settings.
     *
     * @return bool
     */
    private function is_checkout_address_validation_enabled(): bool {
        $options = get_option('fshipping_options');
        return !isset($options['fshipping_enable_checkout_address_validation'])
            || !empty($options['fshipping_enable_checkout_address_validation']);
    }

    /**
     * Server-side guard to avoid firing FedEx Ship with invalid destination data.
     *
     * @param \WC_Order $order
     * @return array{valid:bool,message:string,warning?:string}
     */
    private function validate_order_for_fedex($order): array {
        if ($this->order_has_address_validation_override($order)) {
            return [
                'valid'   => true,
                'message' => '',
                'warning' => __('FedEx checkout address validation skipped (order override).', 'teamzlab-fedex'),
            ];
        }

        $dest = AddressNormalizer::normalize_from_order($order);
        $street1 = !empty($dest['street_lines'][0]) ? (string) $dest['street_lines'][0] : '';
        $city    = (string) $dest['city'];
        $state   = (string) $dest['state'];
        $postal  = (string) $dest['postal'];
        $country = (string) $dest['country'];

        if ('' === $street1 || '' === $city || '' === $postal || '' === $country) {
            return [
                'valid'   => false,
                'message' => __('FedEx shipment blocked: destination address is incomplete.', 'teamzlab-fedex'),
            ];
        }
        if (in_array(strtoupper($country), ['US', 'CA'], true) && '' === $state) {
            return [
                'valid'   => false,
                'message' => __('FedEx shipment blocked: state/province is required for this destination.', 'teamzlab-fedex'),
            ];
        }

        $resolved = AddressValidation::instance()->validate([[
            'street_lines' => $dest['street_lines'],
            'city'         => $city,
            'state'        => $state,
            'postal_code'  => $postal,
            'country'      => $country,
        ]]);
        if (empty($resolved)) {
            if ($this->allow_shipment_when_address_validation_fails($order)) {
                $warn = __('FedEx Address Validation did not return a match; shipment allowed by store policy. Check the address on the label.', 'teamzlab-fedex');
                $order->add_order_note($warn, false);
                return [
                    'valid'   => true,
                    'message' => '',
                    'warning' => $warn,
                ];
            }
            return [
                'valid'   => false,
                'message' => __('FedEx shipment blocked: destination address could not be validated.', 'teamzlab-fedex'),
            ];
        }

        $postal_result = PostalCodeValidation::instance()->validate($postal, $country, ['state' => $state]);
        if (!empty($postal_result['errors'])) {
            return [
                'valid'   => false,
                'message' => __('FedEx shipment blocked: ZIP/postal code is invalid for the selected destination.', 'teamzlab-fedex'),
            ];
        }
        if (empty($postal_result)) {
            // FedEx can return no postal output for valid sandbox/test lanes.
            // Treat this as non-blocking and continue shipment creation.
            return [
                'valid'    => true,
                'message'  => '',
                'warning'  => __('FedEx postal validation returned no data at checkout; shipment proceeded with manual ZIP/postal verification.', 'teamzlab-fedex'),
            ];
        }

        return ['valid' => true, 'message' => ''];
    }

    /**
     * Order meta `_fshipping_address_validation_override` = yes skips FedEx AV at checkout.
     *
     * @param \WC_Order $order
     * @return bool
     */
    private function order_has_address_validation_override($order): bool {
        if (apply_filters('fshipping_address_validation_override', false, $order)) {
            return true;
        }
        return $order->get_meta('_fshipping_address_validation_override') === 'yes';
    }

    /**
     * When enabled in settings or via filter, do not block checkout if Address Validation returns no match.
     *
     * @param \WC_Order $order
     * @return bool
     */
    private function allow_shipment_when_address_validation_fails($order): bool {
        return apply_filters(
            'fshipping_allow_shipment_without_address_validation',
            $this->is_address_validation_fail_open_enabled(),
            $order
        );
    }

    /**
     * @return bool
     */
    private function is_address_validation_fail_open_enabled(): bool {
        $options = get_option('fshipping_options');
        return is_array($options) && !empty($options['fshipping_address_validation_allow_on_failure']);
    }

    /**
     * Advanced mode: Open Ship /start, store draft meta, optional package sync to FedEx.
     *
     * @param \WC_Order $order
     * @param array     $current_shipping
     * @return void
     */
    private function create_openship_draft($order, array $current_shipping) {
        $full = Shipment::instance()->prepare_shipment_payload($current_shipping, $order);
        $req  = $full['requestedShipment'] ?? [];
        $pkgs = Draft::packages_from_requested_shipment(is_array($req) ? $req : []);

        if (is_array($req)) {
            Draft::seed_shipment_overrides_from_payload($order, $req);
        }

        $out = OpenShip::instance()->start_from_order($order, $current_shipping);
        $ok  = [] !== $out && OpenShip::openship_create_response_body_indicates_success($out);

        if (!$ok) {
            $summary = [] === $out
                ? __('FedEx Open Ship: session could not be started (no valid response from FedEx). Check API credentials, account, and wp-content/debug.log.', 'teamzlab-fedex')
                : OpenShip::summarize_fedex_start_failure($out);
            $order->update_meta_data(Draft::META_FULFILLMENT_MODE, 'advanced');
            $order->update_meta_data(Draft::META_LIFECYCLE, Draft::LIFE_DRAFT);
            Draft::set_packages($order, $pkgs);
            $order->add_order_note($summary, false);
            $order->save();

            if (apply_filters('fshipping_openship_throw_on_checkout_start_failure', true, $order, is_array($out) ? $out : [], $current_shipping)) {
                throw new \Exception(esc_html(wp_strip_all_tags($summary)));
            }

            $order->update_status('wc-fedex-draft', __('FedEx Open Ship draft (session start failed).', 'teamzlab-fedex'));
            return;
        }

        $session = OpenShip::instance()->extract_openship_session_from_create_output($out);
        $index   = $session['shipmentIndex'];
        $order->update_meta_data(Draft::META_FULFILLMENT_MODE, 'advanced');
        if ($session['shipmentIndex'] !== '' && $session['shipmentIdIndex'] !== '') {
            Draft::set_openship_session_meta($order, $session);
        }
        $order->update_meta_data(Draft::META_LIFECYCLE, Draft::LIFE_DRAFT);
        $order->update_meta_data(Draft::META_CONFIRMED, 'no');

        if ($session['shipmentIndex'] !== '') {
            $pkgs = Draft::push_packages_to_fedex($order, $pkgs);
            Draft::sync_openship_session_status_after_packages_pushed($order, $pkgs);
        }

        Draft::set_packages($order, $pkgs);

        $order->add_order_note(
            sprintf(
                /* translators: %s: FedEx Open Ship shipment index */
                __('FedEx Open Ship draft created (session %s). Confirm packages in the order admin, then confirm shipment.', 'teamzlab-fedex'),
                $index !== '' ? $index : '—'
            ),
            false
        );
        $order->update_status('wc-fedex-draft', __('FedEx Open Ship draft created.', 'teamzlab-fedex'));
    }

    /**
     * Write Checkout execution trace to wp-content/debug.log.
     *
     * @param int    $step
     * @param int    $order_id
     * @param string $stage
     * @param array  $context
     * @return void
     */
    private function trace(int $step, int $order_id, string $stage, array $context = []): void {
        unset($step, $order_id, $stage, $context);
    }
}

