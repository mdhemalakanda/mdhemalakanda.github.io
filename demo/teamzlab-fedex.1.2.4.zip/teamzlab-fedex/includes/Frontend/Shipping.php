<?php
namespace FSHIPPING\Frontend;

use FSHIPPING\SingletonTrait;
use FSHIPPING\HTTP\Shipping as HTTPShipping;
use FSHIPPING\Licensing\ShipmentQuota;

/**
 * This class will use for custom shipping.
 * 
 * @since 1.0
 */
class Shipping extends \WC_Shipping_Method {
    use SingletonTrait;
    private const ADMIN_WARNING_SESSION_KEY = 'fshipping_checkout_admin_warning';
    private const QUOTA_REACHED_SESSION_KEY = 'fshipping_quota_reached_today';
    private static $warning_hook_registered = false;

    public function __construct( $instance_id = 0 ) {
        $this->id                 = 'fshipping_custom'; // Unique ID
        $this->instance_id        = absint( $instance_id );
        $this->method_title       = __( 'Fedex Shipping', 'teamzlab-fedex' );
        $this->method_description = __( 'Custom API-based dynamic shipping rates.', 'teamzlab-fedex' );
        $this->supports           = array( 'shipping-zones', 'instance-settings', 'instance-settings-modal' );

        $this->init();
    }

    public function init() {
        $this->init_form_fields();
        $this->init_settings();

        $this->enabled = $this->get_option( 'enabled' );
        $this->title   = $this->get_option( 'title', __( 'Custom Shipping', 'teamzlab-fedex' ) );

        // Action to save settings in admin
        add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );

        if ( ! self::$warning_hook_registered ) {
            add_action( 'woocommerce_before_checkout_form', array( $this, 'maybe_show_admin_checkout_warning' ), 5 );
            add_filter( 'woocommerce_no_shipping_available_html', array( $this, 'maybe_override_no_shipping_message' ) );
            add_filter( 'woocommerce_cart_no_shipping_available_html', array( $this, 'maybe_override_no_shipping_message' ) );
            self::$warning_hook_registered = true;
        }
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __( 'Enable/Disable', 'teamzlab-fedex' ),
                'type'    => 'checkbox',
                'label'   => __( 'Enable this shipping method', 'teamzlab-fedex' ),
                'default' => 'yes',
            ),
            'title'   => array(
                'title'       => __( 'Method Title', 'teamzlab-fedex' ),
                'type'        => 'text',
                'description' => __( 'This controls the title which the user sees during checkout.', 'teamzlab-fedex' ),
                'default'     => __( 'Standard Shipping', 'teamzlab-fedex' ),
                'desc_tip'    => true,
            ),
        );
    }

    public function calculate_shipping( $package = array() ) {
        do_action( 'fshipping_calculate_shipping_start', $this, $package );

        if ( ShipmentQuota::is_quota_reached() ) {
            $this->set_quota_reached_notice( ShipmentQuota::checkout_notice_message() );
            return;
        }
        $this->clear_quota_reached_notice();

        $shipping_http = HTTPShipping::instance();
        $allowed_service_types = $this->get_allowed_service_types();
        $response = $shipping_http->get_shipping_rates( $package );
        $response = apply_filters( 'fshipping_calculate_shipping_rates', $response, $this, $package );
        $last_error = $shipping_http->get_last_error_message();
        if ( ! empty( $last_error ) ) {
            $this->set_admin_checkout_warning( $last_error );
        } else {
            $this->clear_admin_checkout_warning();
        }

        // Optional ServiceAvailability pre-filter — drops any rate for
        // a service FedEx wouldn't actually run on this lane. Opt-in
        // via fshipping_enable_service_availability_filter setting so
        // merchants who've already validated their lanes can skip the
        // extra API call.
        $available_allow_list = null;
        $settings = get_option( 'fshipping_options' );
        if ( ! empty( $settings['fshipping_enable_service_availability_filter'] ) ) {
            $current_package = isset( $package['contents'] ) ? $package : ( isset( $package[0]['contents'] ) ? $package[0] : array() );
            $destination     = isset( $current_package['destination'] ) ? $current_package['destination'] : array();
            $services = \FSHIPPING\HTTP\ServiceAvailability::instance()->get_available_services( [
                'origin' => [
                    'postal_code' => !empty( $settings['fshipping_postal_code']  ) ? sanitize_text_field( $settings['fshipping_postal_code'] ) : '',
                    'country'     => !empty( $settings['fshipping_country_code'] ) ? sanitize_text_field( $settings['fshipping_country_code'] ) : 'US',
                ],
                'destination' => [
                    'postal_code' => isset( $destination['postcode'] ) ? sanitize_text_field( $destination['postcode'] ) : '',
                    'country'     => isset( $destination['country']  ) ? sanitize_text_field( $destination['country']  ) : 'US',
                ],
            ] );
            if ( ! empty( $services ) && is_array( $services ) ) {
                $available_allow_list = array();
                foreach ( $services as $opt ) {
                    if ( ! empty( $opt['service'] ) ) {
                        $available_allow_list[] = sanitize_text_field( $opt['service'] );
                    }
                }
            }
        }
        $added_count = 0;
        if(!empty($response)) {
            foreach($response as $rate) {
                $service_code = !empty($rate['serviceType']) ? sanitize_text_field($rate['serviceType']): '';
                $service_name = !empty($rate['serviceName']) ? sanitize_text_field($rate['serviceName']): '';

                if ( ! $this->is_allowed_service_type( $service_code, $allowed_service_types ) ) {
                    continue;
                }

                // Service-availability guarantee: if we ran the pre-filter
                // above and this service isn't in the allow-list, drop it.
                if ( is_array( $available_allow_list ) && ! in_array( $service_code, $available_allow_list, true ) ) {
                    continue;
                }

                if ( $this->add_checkout_rate_from_fedex_row( $rate, $service_code, $service_name, $package ) ) {
                    $added_count++;
                }
            }
        }

        // Fallback: FedEx returned rates but local filters removed all.
        // This keeps checkout usable for heavy/freight carts when only freight
        // services are returned by FedEx and selected service filters are narrower.
        if ( 0 === $added_count && ! empty( $response ) ) {
            foreach ( $response as $rate ) {
                $service_code = ! empty( $rate['serviceType'] ) ? sanitize_text_field( $rate['serviceType'] ) : '';
                $service_name = ! empty( $rate['serviceName'] ) ? sanitize_text_field( $rate['serviceName'] ) : '';
                if ( $this->add_checkout_rate_from_fedex_row( $rate, $service_code, $service_name, $package ) ) {
                    $added_count++;
                }
            }
        }
    }

    /**
     * Add one Woo checkout rate from a FedEx `rateReplyDetails[]` row.
     *
     * @param array  $rate
     * @param string $service_code
     * @param string $service_name
     * @param array  $package
     * @return bool True when rate is added.
     */
    private function add_checkout_rate_from_fedex_row( array $rate, string $service_code, string $service_name, array $package ): bool {
        if ( '' === $service_code || '' === $service_name ) {
            return false;
        }

        $rated_details = isset( $rate['ratedShipmentDetails'] ) ? $rate['ratedShipmentDetails'] : array();
        $final_rate    = null;
        $priority_order = array( 'INCENTIVE', 'ACCOUNT', 'PREFERRED', 'LIST' );

        foreach ( $priority_order as $type ) {
            foreach ( $rated_details as $detail ) {
                if ( isset( $detail['rateType'] ) && $detail['rateType'] === $type ) {
                    $final_rate = $detail;
                    break 2;
                }
            }
        }
        if ( ! is_array( $final_rate ) || ! isset( $final_rate['totalNetCharge'] ) ) {
            return false;
        }

        $cost = (float) $final_rate['totalNetCharge'];
        if ( $cost < 0 ) {
            return false;
        }
        $currency = isset( $final_rate['currency'] ) ? $final_rate['currency'] : '';

        $this->add_rate(
            [
                'id'    => $this->id . '_' . strtolower( $service_code ),
                'label' => $service_name,
                'cost'  => $cost,
                'meta_data' => [
                    'service_type' => $service_code,
                    'currency'     => $currency,
                    'package'      => $package,
                ],
            ]
        );

        return true;
    }

    /**
     * Show latest FedEx rates warning to admins on checkout.
     *
     * @return void
     */
    public function maybe_show_admin_checkout_warning() {
        if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) ) {
            return;
        }

        if ( ! current_user_can( 'manage_options' ) || ! function_exists( 'WC' ) || ! WC()->session ) {
            return;
        }

        $warning = WC()->session->get( self::ADMIN_WARNING_SESSION_KEY );
        if ( empty( $warning ) ) {
            return;
        }

        wc_print_notice(
            sprintf(
                '%s %s',
                esc_html( $warning ),
                esc_html__( 'See wp-content/debug.log for FedEx error details.', 'teamzlab-fedex' )
            ),
            'notice'
        );
    }

    /**
     * Persist warning in Woo session.
     *
     * @param string $message
     * @return void
     */
    private function set_admin_checkout_warning( $message ) {
        if ( function_exists( 'WC' ) && WC()->session ) {
            WC()->session->set( self::ADMIN_WARNING_SESSION_KEY, sanitize_text_field( (string) $message ) );
        }
    }

    /**
     * Remove warning when rates recover.
     *
     * @return void
     */
    private function clear_admin_checkout_warning() {
        if ( function_exists( 'WC' ) && WC()->session ) {
            WC()->session->set( self::ADMIN_WARNING_SESSION_KEY, '' );
        }
    }

    /**
     * Override default no-shipping text when daily quota is reached.
     *
     * @param string $html
     * @return string
     */
    public function maybe_override_no_shipping_message( $html ) {
        if ( ! function_exists( 'WC' ) || ! WC()->session ) {
            return $html;
        }

        $quota_msg = (string) WC()->session->get( self::QUOTA_REACHED_SESSION_KEY );
        if ( '' === $quota_msg ) {
            return $html;
        }

        return esc_html( $quota_msg );
    }

    /**
     * Persist quota warning message in session for shipping-method area.
     *
     * @param string $message
     * @return void
     */
    private function set_quota_reached_notice( string $message ): void {
        if ( function_exists( 'WC' ) && WC()->session ) {
            WC()->session->set( self::QUOTA_REACHED_SESSION_KEY, sanitize_text_field( $message ) );
        }
    }

    /**
     * Remove quota warning when quota is not reached.
     *
     * @return void
     */
    private function clear_quota_reached_notice(): void {
        if ( function_exists( 'WC' ) && WC()->session ) {
            WC()->session->set( self::QUOTA_REACHED_SESSION_KEY, '' );
        }
    }

    /**
     * Selected service types from plugin settings.
     *
     * @return array
     */
    private function get_allowed_service_types() {
        $settings = get_option( 'fshipping_options' );
        $service_types = isset( $settings['fshipping_shipping_methods'] ) ? $settings['fshipping_shipping_methods'] : array();

        if ( empty( $service_types ) ) {
            return array();
        }

        if ( ! is_array( $service_types ) ) {
            $service_types = array( $service_types );
        }

        return array_values(
            array_filter(
                array_map( 'sanitize_text_field', $service_types )
            )
        );
    }

    /**
     * Check if service type should be shown at checkout.
     *
     * @param string $service_code
     * @param array  $allowed_service_types
     * @return bool
     */
    private function is_allowed_service_type( $service_code, $allowed_service_types ) {
        if ( empty( $allowed_service_types ) ) {
            return true;
        }

        return in_array( (string) $service_code, $allowed_service_types, true );
    }
}