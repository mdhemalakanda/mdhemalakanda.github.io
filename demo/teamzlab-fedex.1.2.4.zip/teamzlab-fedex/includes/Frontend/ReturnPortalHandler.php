<?php
namespace FSHIPPING\Frontend;

use FSHIPPING\HTTP\Locations;
use FSHIPPING\HTTP\ReturnTag;
use FSHIPPING\SingletonTrait;

/**
 * POST handler for the [fshipping_return_portal] shortcode.
 *
 * Listens on template_redirect, intercepts the return-request submission,
 * validates the form against ReturnPortal's rules, loads the WC order,
 * enforces the eligibility window, asks HTTP\ReturnTag for a label, and
 * finds the three nearest Hold-at-Location drop-offs. Redirects back to
 * the shortcode page with a status querystring so the shortcode can
 * render a success / error notice.
 *
 * The orchestration method `handle(array $input, array $ctx)` is pure
 * (no direct WP globals) so it can be unit-tested without a live
 * WooCommerce install.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class ReturnPortalHandler {
    use SingletonTrait;

    public const RESULT_SUBMITTED = 'submitted';
    public const RESULT_INVALID   = 'invalid';
    public const RESULT_INELIGIBLE = 'ineligible';
    public const RESULT_NOT_FOUND  = 'not_found';
    public const RESULT_API_FAIL   = 'api_fail';

    /**
     * @return void
     * @since 1.2
     */
    public function init() {
        add_action('template_redirect', [$this, 'maybe_dispatch']);
    }

    /**
     * WordPress hook target: pulls request state + calls handle().
     *
     * @return void
     * @since 1.2
     */
    public function maybe_dispatch() {
        if (empty($_POST['_fshipping_return_nonce'])) {
            return;
        }
        if (!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_fshipping_return_nonce'])), 'fshipping_return_portal')) {
            return;
        }

        $ctx = [
            'load_order'       => static fn($id) => function_exists('wc_get_order') ? wc_get_order($id) : null,
            'create_return'    => [ReturnTag::instance(), 'create_tag'],
            'search_locations' => [Locations::instance(), 'search'],
            'now_timestamp'    => time(),
        ];

        $result = $this->handle(wp_unslash($_POST), $ctx);

        // The form posts to the page it is rendered on (action=""), so the
        // current request URI is the authoritative redirect target. The
        // Referer header is unreliable (privacy settings, proxies) and the
        // old home_url('/') fallback dropped customers on the blog listing
        // where the shortcode — and its status notice — doesn't exist.
        $uri    = isset($_SERVER['REQUEST_URI']) ? esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'])) : '';
        $target = ($uri !== '' && 0 === strpos($uri, '/') && 0 !== strpos($uri, '//'))
            ? $uri
            : (wp_get_referer() ?: home_url('/'));

        $url = add_query_arg('fshipping_return_status', rawurlencode($result['status']), $target);

        // Field-level errors + the values the customer typed travel via a
        // short-lived transient behind an unguessable token: user input stays
        // out of the querystring/browser history and the shortcode can
        // re-fill the form after the bounce.
        if (self::RESULT_INVALID === $result['status'] && !empty($result['errors'])) {
            $key = wp_generate_password(24, false, false);
            set_transient(
                'fshipping_return_feedback_' . $key,
                [
                    'errors' => $result['errors'],
                    'fields' => [
                        'order_id' => isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0,
                        'email'    => isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '',
                    ],
                ],
                5 * MINUTE_IN_SECONDS
            );
            $url = add_query_arg('fshipping_return_notice', $key, $url);
        }

        wp_safe_redirect($url);
        exit;
    }

    /**
     * Orchestrate a return request. Pure — no WP globals.
     *
     * @param array $input  Sanitized-but-raw POST array.
     * @param array $ctx    Injected dependencies:
     *     - load_order       callable(int): \WC_Order|null
     *     - create_return    callable(int,array): array (output from HTTP\ReturnTag)
     *     - search_locations callable(array): array (output from HTTP\Locations)
     *     - now_timestamp    int
     * @return array{status:string,errors?:array,hal?:array,tracking?:string,label_url?:string}
     * @since 1.2
     */
    public function handle(array $input, array $ctx): array {
        $validator = ReturnPortal::instance()->validate_request($input);
        if (empty($validator['ok'])) {
            return ['status' => self::RESULT_INVALID, 'errors' => $validator['errors']];
        }

        $data   = $validator['data'];
        $loader = $ctx['load_order'] ?? null;
        $order  = is_callable($loader) ? $loader((int) $data['order_id']) : null;

        if (empty($order) || !is_object($order)) {
            return ['status' => self::RESULT_NOT_FOUND];
        }

        // Ownership proof: the billing email must match the order. Comparison
        // is lowercase + constant-time so order ids stay unenumerable.
        $given    = strtolower((string) ($data['email'] ?? ''));
        $expected = strtolower((string) (method_exists($order, 'get_billing_email') ? $order->get_billing_email() : ''));
        if ($expected === '' || $given === '' || !hash_equals($expected, $given)) {
            return ['status' => self::RESULT_NOT_FOUND];
        }

        [$status_slug, $days_since] = $this->order_status_and_age($order, (int) ($ctx['now_timestamp'] ?? time()));
        if (!ReturnPortal::instance()->is_eligible($status_slug, $days_since)) {
            return ['status' => self::RESULT_INELIGIBLE];
        }

        // Thin form has no item picker: an absent items list means the
        // customer is returning every line item on the order.
        if (null === $data['items']) {
            $data['items'] = $this->order_line_items($order);
        }

        $create = $ctx['create_return'] ?? null;
        $api    = is_callable($create) ? $create($data['order_id'], ['items' => $data['items'], 'reason' => $data['reason']]) : [];

        $tracking  = (string) ($api['transactionShipments'][0]['masterTrackingNumber']       ?? '');
        $label_url = (string) ($api['transactionShipments'][0]['pieceResponses'][0]
                                    ['packageDocuments'][0]['url']                            ?? '');
        if ($tracking === '' && $label_url === '') {
            return ['status' => self::RESULT_API_FAIL];
        }

        $hal_raw = [];
        $search  = $ctx['search_locations'] ?? null;
        if (is_callable($search)) {
            $postal = $this->destination_postal($order);
            $country = $this->destination_country($order);
            if ($postal !== '') {
                $hal_raw = (array) $search([
                    'postal_code' => $postal,
                    'country'     => $country,
                    'limit'       => 3,
                ]);
            }
        }
        $hal = ReturnPortal::instance()->format_hal_dropoffs(['output' => ['locationDetailList' => $hal_raw]], 3);

        return [
            'status'    => self::RESULT_SUBMITTED,
            'tracking'  => $tracking,
            'label_url' => $label_url,
            'hal'       => $hal,
        ];
    }

    /**
     * Extract status slug + days-since-completion from a WC order.
     *
     * @param object $order Any object exposing get_status() and get_date_completed() or ->date_completed.
     * @param int    $now_ts
     * @return array{0:string,1:int}
     * @since 1.2
     */
    private function order_status_and_age(object $order, int $now_ts): array {
        $status = method_exists($order, 'get_status') ? (string) $order->get_status() : '';
        $completed_ts = 0;
        if (method_exists($order, 'get_date_completed')) {
            $dt = $order->get_date_completed();
            if (is_object($dt) && method_exists($dt, 'getTimestamp')) {
                $completed_ts = (int) $dt->getTimestamp();
            }
        } elseif (isset($order->date_completed)) {
            $completed_ts = is_numeric($order->date_completed)
                ? (int) $order->date_completed
                : (strtotime((string) $order->date_completed) ?: 0);
        }
        $days = $completed_ts > 0 ? (int) floor(($now_ts - $completed_ts) / 86400) : 0;
        return [$status, $days];
    }

    /**
     * Every purchasable line item on an order, in the handler's item shape.
     *
     * @param object $order Any object exposing get_items() of WC_Order_Item_Product-like rows.
     * @return array<int,array{id:int,qty:int}>
     * @since 1.2
     */
    private function order_line_items(object $order): array {
        if (!method_exists($order, 'get_items')) {
            return [];
        }
        $items = [];
        foreach ($order->get_items() as $item) {
            if (is_object($item) && method_exists($item, 'get_id') && method_exists($item, 'get_quantity')) {
                $items[] = [
                    'id'  => (int) $item->get_id(),
                    'qty' => (int) $item->get_quantity(),
                ];
            }
        }
        return $items;
    }

    /**
     * @param object $order
     * @return string
     * @since 1.2
     */
    private function destination_postal(object $order): string {
        if (method_exists($order, 'get_shipping_postcode')) {
            return (string) $order->get_shipping_postcode();
        }
        return (string) ($order->shipping_postcode ?? '');
    }

    /**
     * @param object $order
     * @return string
     * @since 1.2
     */
    private function destination_country(object $order): string {
        if (method_exists($order, 'get_shipping_country')) {
            return (string) $order->get_shipping_country();
        }
        return (string) ($order->shipping_country ?? 'US');
    }
}
