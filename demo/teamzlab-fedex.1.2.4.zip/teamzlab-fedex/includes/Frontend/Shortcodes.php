<?php
namespace FSHIPPING\Frontend;

use FSHIPPING\HTTP\Locations;
use FSHIPPING\HTTP\Shipment;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Widget\DimensionalWeightCalculator;
use FSHIPPING\Widget\RateCalculatorEmbed;

/**
 * Customer-facing shortcodes.
 *
 * Registers:
 *   [fshipping_track]             — tracking lookup form + live status.
 *   [fshipping_locations]         — postal-code drop-off finder.
 *   [fshipping_tracking_timeline] — chronological AIV event list for an order.
 *   [fshipping_return_portal]     — self-serve Return Tag request UI.
 *   [fshipping_rate_widget]       — copy-paste embed snippet for the public rate widget.
 *
 * Shortcodes prefer cached AIV webhook event data from post-meta before
 * falling back to live API calls.
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class Shortcodes {
    use SingletonTrait;

    /**
     * Register shortcodes.
     *
     * @return void
     * @since 1.1
     */
    public function init() {
        add_shortcode('fshipping_track',             [$this, 'render_tracking']);
        add_shortcode('fshipping_locations',         [$this, 'render_locations']);
        add_shortcode('fshipping_tracking_timeline', [$this, 'render_tracking_timeline']);
        add_shortcode('fshipping_return_portal',     [$this, 'render_return_portal']);
        add_shortcode('fshipping_rate_widget',       [$this, 'render_rate_widget']);
        add_shortcode('fshipping_dim_weight',        [$this, 'render_dim_weight']);
    }

    /**
     * Render [fshipping_dim_weight unit="IN"] — pure-client-side FedEx
     * dimensional-weight calculator. No API calls.
     *
     * @param array $atts
     * @return string
     * @since 1.2
     */
    public function render_dim_weight($atts) {
        $atts = shortcode_atts(['unit' => 'IN'], $atts, 'fshipping_dim_weight');
        $this->enqueue_shortcode_assets();
        return DimensionalWeightCalculator::instance()->render($atts);
    }

    /**
     * Render [fshipping_track tracking_id="…"].
     *
     * @param array $atts
     * @return string
     * @since 1.1
     */
    public function render_tracking($atts) {
        $atts = shortcode_atts([
            'tracking_id' => '',
            'placeholder' => __('Enter your FedEx tracking number', 'teamzlab-fedex'),
        ], $atts, 'fshipping_track');

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public read-only tracking lookup rendered by a shortcode; anonymous visitors cannot be issued a nonce.
        $tracking_id = sanitize_text_field($atts['tracking_id'] ?: (isset($_GET['fshipping_tracking']) ? wp_unslash($_GET['fshipping_tracking']) : ''));
        $this->enqueue_shortcode_assets();

        ob_start();
        ?>
        <div class="fshipping-track-shortcode">
            <form method="get" class="fshipping-track-form">
                <input type="text" name="fshipping_tracking" value="<?php echo esc_attr($tracking_id); ?>" placeholder="<?php echo esc_attr($atts['placeholder']); ?>" />
                <button type="submit"><?php esc_html_e('Track', 'teamzlab-fedex'); ?></button>
            </form>
            <?php if (!empty($tracking_id)) {
                echo wp_kses_post($this->render_tracking_status($tracking_id)); // markup built here; every dynamic value is escaped inside.
            } ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render the status block for a single tracking number.
     *
     * Prefer cached AIV webhook data, fall back to live Track API.
     *
     * @param string $tracking_id
     * @return string
     * @since 1.1
     */
    private function render_tracking_status($tracking_id) {
        $tracking_id = sanitize_text_field($tracking_id);
        $cached      = $this->load_cached_event($tracking_id);

        if (!empty($cached['status'])) {
            return $this->render_status_card([
                'tracking'    => $tracking_id,
                'status'      => $cached['status'],
                'description' => $cached['description'] ?? '',
                'at'          => $cached['at'] ?? '',
                'source'      => __('Live webhook', 'teamzlab-fedex'),
            ]);
        }

        $live = Shipment::instance()->track_shipment($tracking_id);
        $track_result = $live['output']['completeTrackResults'][0]['trackResults'][0] ?? [];
        if (empty($track_result)) {
            return '<p class="fshipping-track-empty">' . esc_html__('No tracking details available yet. Please try again later.', 'teamzlab-fedex') . '</p>';
        }

        return $this->render_status_card([
            'tracking'    => $track_result['trackingNumberInfo']['trackingNumber'] ?? $tracking_id,
            'status'      => $track_result['latestStatusDetail']['statusByLocale']  ?? '',
            'description' => $track_result['latestStatusDetail']['description']     ?? '',
            'at'          => $track_result['dateAndTimes'][0]['dateTime']           ?? '',
            'source'      => __('FedEx live lookup', 'teamzlab-fedex'),
        ]);
    }

    /**
     * Load the cached AIV event for a tracking number, if any.
     *
     * @param string $tracking_number
     * @return array
     * @since 1.1
     */
    private function load_cached_event($tracking_number) {
        $ids = get_posts([
            'post_type'      => 'fedex_shipping',
            'post_status'    => 'any',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Exact-match lookup on this plugin's own fedex_shipping CPT by its _tracking_number meta to read the cached AIV event; single post, hard-limited to 1.
            'meta_query'     => [[
                'key'     => '_tracking_number',
                'value'   => $tracking_number,
                'compare' => '=',
            ]],
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ]);
        if (empty($ids)) {
            return [];
        }
        $event = get_post_meta((int) reset($ids), '_fshipping_aiv_last_event', true);
        return is_array($event) ? $event : [];
    }

    /**
     * @param array $data
     * @return string
     * @since 1.1
     */
    private function render_status_card(array $data) {
        ob_start();
        ?>
        <div class="fshipping-tracking-card">
            <p><strong><?php esc_html_e('Tracking:', 'teamzlab-fedex'); ?></strong> <?php echo esc_html($data['tracking']); ?></p>
            <p><strong><?php esc_html_e('Status:', 'teamzlab-fedex'); ?></strong> <?php echo esc_html($data['status'] ?: '—'); ?></p>
            <?php if (!empty($data['description'])) : ?>
                <p class="fshipping-track-desc"><?php echo esc_html($data['description']); ?></p>
            <?php endif; ?>
            <?php if (!empty($data['at'])) : ?>
                <p><strong><?php esc_html_e('Updated:', 'teamzlab-fedex'); ?></strong> <?php echo esc_html($data['at']); ?></p>
            <?php endif; ?>
            <?php if (!empty($data['source'])) : ?>
                <p class="fshipping-track-source">
                    <small><?php echo esc_html(sprintf(
                        /* translators: %s: source of the tracking status (cached webhook event or live FedEx lookup). */
                        __('Source: %s', 'teamzlab-fedex'),
                        $data['source']
                    )); ?></small>
                </p>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render [fshipping_locations postal_code="…" country="US" limit="10"].
     *
     * @param array $atts
     * @return string
     * @since 1.1
     */
    /**
     * Render [fshipping_tracking_timeline order_id="…"] — ordered AIV events.
     *
     * @param array $atts
     * @return string
     * @since 1.2
     */
    public function render_tracking_timeline($atts) {
        $atts = shortcode_atts(['order_id' => 0], $atts, 'fshipping_tracking_timeline');
        $this->enqueue_shortcode_assets();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public read-only timeline rendered by a shortcode; anonymous visitors cannot be issued a nonce.
        $shipment_id = (int) ($atts['order_id'] ?: sanitize_text_field(wp_unslash($_GET['fshipping_order'] ?? 0)));
        if ($shipment_id <= 0) {
            return '<p class="fshipping-timeline-empty">' . esc_html__('No shipment id provided.', 'teamzlab-fedex') . '</p>';
        }

        // Ownership gate: shipment ids are sequential CPT ids, so without this
        // any visitor could enumerate ?fshipping_order=N and read another
        // customer's tracking events. Store staff passes; everyone else must
        // supply the billing email of the order the shipment belongs to.
        if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
            $order_id = (int) get_post_meta($shipment_id, '_fedex_shipment_order_id', true);
            $order    = $order_id > 0 && function_exists('wc_get_order') ? wc_get_order($order_id) : null;
            $expected = (is_object($order) && method_exists($order, 'get_billing_email'))
                ? strtolower((string) $order->get_billing_email())
                : '';
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only comparison against the order's billing email; no state changes.
            $given = isset($_GET['fshipping_email']) ? strtolower(sanitize_email(wp_unslash($_GET['fshipping_email']))) : '';
            if ($expected === '' || $given === '' || !hash_equals($expected, $given)) {
                return '<p class="fshipping-timeline-empty">' . esc_html__('Not authorized to view this shipment timeline.', 'teamzlab-fedex') . '</p>';
            }
        }

        $rows = TrackingTimeline::instance()->format(TrackingTimeline::instance()->get($shipment_id));
        if (empty($rows)) {
            return '<p class="fshipping-timeline-empty">' . esc_html__('No events yet for this shipment.', 'teamzlab-fedex') . '</p>';
        }

        ob_start();
        ?>
        <ol class="fshipping-tracking-timeline">
            <?php foreach ($rows as $row) : ?>
                <li class="fshipping-tt-<?php echo esc_attr($row['icon']); ?>">
                    <strong><?php echo esc_html($row['label']); ?></strong>
                    <?php if (!empty($row['description'])) : ?>
                        <div class="fshipping-tt-desc"><?php echo esc_html($row['description']); ?></div>
                    <?php endif; ?>
                    <?php if (!empty($row['location'])) : ?>
                        <div class="fshipping-tt-loc"><?php echo esc_html($row['location']); ?></div>
                    <?php endif; ?>
                    <small>
                        <?php echo esc_html($row['when']); ?>
                        <?php if (!empty($row['relative'])) : ?> · <?php echo esc_html($row['relative']); ?><?php endif; ?>
                    </small>
                </li>
            <?php endforeach; ?>
        </ol>
        <?php
        return ob_get_clean();
    }

    /**
     * Render [fshipping_return_portal] — self-serve return flow.
     *
     * This shortcode intentionally renders a thin form only; the POST
     * handler + HTTP\ReturnTag orchestration live alongside the existing
     * Ajax endpoints. The eligibility + validation logic is owned by
     * Frontend\ReturnPortal so it's unit-testable in isolation.
     *
     * @param array $atts
     * @return string
     * @since 1.2
     */
    public function render_return_portal($atts) {
        $atts = shortcode_atts([
            'window_days' => ReturnPortal::DEFAULT_WINDOW_DAYS,
        ], $atts, 'fshipping_return_portal');

        $reasons = ReturnPortal::instance()->allowed_reasons();
        $this->enqueue_shortcode_assets();
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Status slug echoed by this plugin's own redirect after the nonce-verified POST handler runs; display only.
        $notice = isset($_GET['fshipping_return_status']) ? sanitize_text_field(wp_unslash($_GET['fshipping_return_status'])) : '';

        // The POST handler bounces validation failures back with a one-time
        // token pointing at a transient holding the field errors + the values
        // the customer already typed. Read once, then burn it.
        $fields = [];
        $errors = [];
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only display of this plugin's own redirect payload; token is unguessable and single-use.
        $token = isset($_GET['fshipping_return_notice']) ? sanitize_text_field(wp_unslash($_GET['fshipping_return_notice'])) : '';
        if ($token !== '' && preg_match('/^[A-Za-z0-9]{10,64}$/', $token)) {
            $feedback = get_transient('fshipping_return_feedback_' . $token);
            if (is_array($feedback)) {
                $fields = (array) ($feedback['fields'] ?? []);
                $errors = (array) ($feedback['errors'] ?? []);
                delete_transient('fshipping_return_feedback_' . $token);
            }
        }

        $messages = [
            'invalid'    => __('We could not process that request. Please review the form and try again.', 'teamzlab-fedex'),
            'ineligible' => __('This order is not eligible for a self-serve return. Returns open once the order is completed and stay open for 30 days.', 'teamzlab-fedex'),
            'not_found'  => __('No order matches that order number and billing email.', 'teamzlab-fedex'),
            'api_fail'   => __('FedEx could not create the return label right now. Please try again in a few minutes.', 'teamzlab-fedex'),
        ];

        ob_start();
        ?>
        <div class="fshipping-return-portal">
            <h3><?php esc_html_e('Start a FedEx return', 'teamzlab-fedex'); ?></h3>
            <?php if ($notice === 'submitted') : ?>
                <p class="fshipping-return-ok"><?php esc_html_e('Return submitted. Check your email for the FedEx label + nearest drop-off.', 'teamzlab-fedex'); ?></p>
            <?php elseif (isset($messages[$notice])) : ?>
                <p class="fshipping-return-error"><?php echo esc_html($messages[$notice]); ?></p>
                <?php if (!empty($errors)) : ?>
                    <ul class="fshipping-return-errors">
                        <?php foreach ($errors as $error) : ?>
                            <li><?php echo esc_html((string) $error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            <?php endif; ?>
            <form method="post" action="">
                <?php wp_nonce_field('fshipping_return_portal', '_fshipping_return_nonce'); ?>
                <p>
                    <label for="fshipping_return_order_id"><?php esc_html_e('Order number', 'teamzlab-fedex'); ?></label>
                    <input type="number" id="fshipping_return_order_id" name="order_id" min="1" required value="<?php echo esc_attr((string) ($fields['order_id'] ?? '')); ?>" />
                </p>
                <p>
                    <label for="fshipping_return_email"><?php esc_html_e('Billing email', 'teamzlab-fedex'); ?></label>
                    <input type="email" id="fshipping_return_email" name="email" required value="<?php echo esc_attr((string) ($fields['email'] ?? '')); ?>" />
                </p>
                <p>
                    <label for="fshipping_return_reason"><?php esc_html_e('Reason', 'teamzlab-fedex'); ?></label>
                    <select id="fshipping_return_reason" name="reason" required>
                        <?php foreach ($reasons as $slug => $label) : ?>
                            <option value="<?php echo esc_attr($slug); ?>"><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </p>
                <p>
                    <label for="fshipping_return_notes"><?php esc_html_e('Notes (optional)', 'teamzlab-fedex'); ?></label>
                    <textarea id="fshipping_return_notes" name="notes" rows="3"></textarea>
                </p>
                <p>
                    <button type="submit" class="button button-primary"><?php esc_html_e('Request return label', 'teamzlab-fedex'); ?></button>
                </p>
                <p class="fshipping-return-note">
                    <small><?php echo esc_html(sprintf(
                        /* translators: %d: number of days after delivery in which a return can be requested. */
                        __('Returns accepted within %d days of delivery.', 'teamzlab-fedex'),
                        (int) $atts['window_days']
                    )); ?></small>
                </p>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Render [fshipping_rate_widget site_url="https://tool.teamzlab.com" origin="38116"]
     * — the copy-paste embed snippet for third-party sites.
     *
     * @param array $atts
     * @return string
     * @since 1.2
     */
    public function render_rate_widget($atts) {
        $atts = shortcode_atts([
            'site_url' => home_url(),
            'origin'   => '',
            'country'  => '',
        ], $atts, 'fshipping_rate_widget');

        $overrides = array_filter([
            'origin'  => (string) $atts['origin'],
            'country' => (string) $atts['country'],
        ], static fn($v) => $v !== '');

        $snippet = RateCalculatorEmbed::instance()->build_embed_snippet(
            (string) $atts['site_url'],
            $overrides
        );

        if ($snippet === '') {
            return '';
        }

        $this->enqueue_shortcode_assets();

        ob_start();
        ?>
        <div class="fshipping-rate-widget-embed">
            <div class="fshipping-rate-widget-embed-bar">
                <span class="fshipping-rate-widget-embed-title"><?php esc_html_e('Add the FedEx rate widget to any site', 'teamzlab-fedex'); ?></span>
                <button type="button" class="fshipping-rate-widget-copy"><?php esc_html_e('Copy code', 'teamzlab-fedex'); ?></button>
            </div>
            <pre><code><?php echo esc_html($snippet); ?></code></pre>
        </div>
        <script>
        (function () {
            var LABEL_COPY   = '<?php echo esc_js(__('Copy code', 'teamzlab-fedex')); ?>';
            var LABEL_COPIED = '<?php echo esc_js(__('Copied!', 'teamzlab-fedex')); ?>';
            var btns = document.querySelectorAll('.fshipping-rate-widget-copy:not([data-bound])');
            btns.forEach(function (btn) {
                btn.setAttribute('data-bound', '1');
                btn.addEventListener('click', function () {
                    var block = btn.closest('.fshipping-rate-widget-embed');
                    var code  = block ? block.querySelector('code') : null;
                    var text  = code ? code.textContent : '';
                    if (!text) {
                        return;
                    }
                    var done = function () {
                        btn.classList.add('is-copied');
                        btn.textContent = LABEL_COPIED;
                        setTimeout(function () {
                            btn.classList.remove('is-copied');
                            btn.textContent = LABEL_COPY;
                        }, 2000);
                    };
                    var fallback = function () {
                        var ta = document.createElement('textarea');
                        ta.value = text;
                        ta.setAttribute('readonly', '');
                        ta.style.position = 'fixed';
                        ta.style.opacity = '0';
                        document.body.appendChild(ta);
                        ta.select();
                        try {
                            document.execCommand('copy');
                            done();
                        } catch (e) {}
                        document.body.removeChild(ta);
                    };
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(text).then(done, fallback);
                    } else {
                        fallback();
                    }
                });
            });
        })();
        </script>
        <?php
        return (string) ob_get_clean();
    }

    public function render_locations($atts) {
        $get  = wp_unslash($_GET); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public drop-off finder search form; anonymous visitors cannot be issued a nonce.
        $atts = shortcode_atts([
            'postal_code' => isset($get['fshipping_zip']) ? sanitize_text_field($get['fshipping_zip']) : '',
            'country'     => isset($get['fshipping_country']) ? sanitize_text_field($get['fshipping_country']) : 'US',
            'limit'       => isset($get['fshipping_limit']) ? (int) $get['fshipping_limit'] : 10,
            'unit'        => isset($get['fshipping_unit']) ? sanitize_text_field($get['fshipping_unit']) : 'mile',
        ], $atts, 'fshipping_locations');

        $atts['country'] = strtoupper(substr((string) $atts['country'], 0, 2));
        $atts['limit']   = max(1, min(75, (int) $atts['limit']));
        $atts['unit']    = $this->normalize_distance_unit((string) $atts['unit']);

        $this->enqueue_locations_assets();

        $results = [];
        if (!empty($atts['postal_code'])) {
            $results = Locations::instance()->search([
                'postal_code' => (string) $atts['postal_code'],
                'country'     => (string) $atts['country'],
                'limit'       => (int) $atts['limit'],
                'sort_by'     => 'distance',
            ]);
        }

        ob_start();
        ?>
        <section class="teamzzlab-fedex-locations-shortcode">
            <header class="teamzzlab-fedex-locations-header">
                <h3><?php esc_html_e('Find a nearby FedEx drop-off location', 'teamzlab-fedex'); ?></h3>
                <p><?php esc_html_e('Search by postal code and choose how distance is displayed.', 'teamzlab-fedex'); ?></p>
            </header>

            <form method="get" class="teamzzlab-fedex-locations-form">
                <div class="teamzzlab-fedex-locations-fields">
                    <label class="teamzzlab-fedex-locations-field">
                        <span><?php esc_html_e('Country code', 'teamzlab-fedex'); ?></span>
                        <input
                            type="text"
                            name="fshipping_country"
                            value="<?php echo esc_attr($atts['country']); ?>"
                            placeholder="<?php esc_attr_e('US', 'teamzlab-fedex'); ?>"
                            maxlength="2"
                            required
                        />
                    </label>
                    <label class="teamzzlab-fedex-locations-field">
                        <span><?php esc_html_e('ZIP / postal code', 'teamzlab-fedex'); ?></span>
                        <input
                            type="text"
                            name="fshipping_zip"
                            value="<?php echo esc_attr($atts['postal_code']); ?>"
                            placeholder="<?php esc_attr_e('94105', 'teamzlab-fedex'); ?>"
                            required
                        />
                    </label>
                    <label class="teamzzlab-fedex-locations-field">
                        <span><?php esc_html_e('Distance unit', 'teamzlab-fedex'); ?></span>
                        <select name="fshipping_unit">
                            <option value="mile" <?php selected($atts['unit'], 'mile'); ?>><?php esc_html_e('Miles', 'teamzlab-fedex'); ?></option>
                            <option value="km" <?php selected($atts['unit'], 'km'); ?>><?php esc_html_e('Kilometers', 'teamzlab-fedex'); ?></option>
                        </select>
                    </label>
                    <label class="teamzzlab-fedex-locations-field">
                        <span><?php esc_html_e('Results', 'teamzlab-fedex'); ?></span>
                        <select name="fshipping_limit">
                            <?php foreach ([5, 10, 15, 20, 25, 30, 50, 75] as $opt) : ?>
                                <option value="<?php echo esc_attr((string) $opt); ?>" <?php selected((int) $atts['limit'], $opt); ?>>
                                    <?php echo esc_html((string) $opt); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                </div>
                <button type="submit" class="teamzzlab-fedex-locations-submit"><?php esc_html_e('Find locations', 'teamzlab-fedex'); ?></button>
            </form>

            <?php if (!empty($atts['postal_code'])) : ?>
                <?php if (empty($results)) : ?>
                    <div class="teamzzlab-fedex-locations-empty">
                        <?php esc_html_e('No FedEx locations were found for this search. Try a nearby postal code or increase the result count.', 'teamzlab-fedex'); ?>
                    </div>
                <?php else : ?>
                    <?php
                    $total_results = count($results);
                    $unit_label    = 'km' === $atts['unit']
                        ? __('km', 'teamzlab-fedex')
                        : __('mi', 'teamzlab-fedex');
                    ?>
                    <div
                        class="teamzzlab-fedex-locations-results"
                        data-distance-unit="<?php echo esc_attr((string) $atts['unit']); ?>"
                    >
                        <p class="teamzzlab-fedex-locations-meta">
                            <?php
                            echo esc_html(sprintf(
                                /* translators: 1: count 2: postal code 3: country code */
                                _n(
                                    'Found %1$d location near %2$s (%3$s).',
                                    'Found %1$d locations near %2$s (%3$s).',
                                    $total_results,
                                    'teamzlab-fedex'
                                ),
                                $total_results,
                                (string) $atts['postal_code'],
                                (string) $atts['country']
                            ));
                            ?>
                        </p>

                        <div class="teamzzlab-fedex-locations-toolbar" role="region" aria-label="<?php echo esc_attr(__('Filter locations', 'teamzlab-fedex')); ?>">
                            <label class="teamzzlab-fedex-locations-search">
                                <span class="teamzzlab-fedex-locations-sr-only"><?php esc_html_e('Filter by name or address', 'teamzlab-fedex'); ?></span>
                                <input
                                    type="search"
                                    class="teamzzlab-fedex-locations-filter-search"
                                    placeholder="<?php esc_attr_e('Search name or address…', 'teamzlab-fedex'); ?>"
                                    autocomplete="off"
                                />
                            </label>
                            <div class="teamzzlab-fedex-locations-toolbar-controls">
                                <label class="teamzzlab-fedex-locations-control">
                                    <span><?php esc_html_e('Sort', 'teamzlab-fedex'); ?></span>
                                    <select class="teamzzlab-fedex-locations-sort">
                                        <option value="distance-asc"><?php esc_html_e('Distance · nearest first', 'teamzlab-fedex'); ?></option>
                                        <option value="distance-desc"><?php esc_html_e('Distance · farthest first', 'teamzlab-fedex'); ?></option>
                                        <option value="name-asc"><?php esc_html_e('Name · A–Z', 'teamzlab-fedex'); ?></option>
                                    </select>
                                </label>
                                <label class="teamzzlab-fedex-locations-control">
                                    <span><?php esc_html_e('Max distance', 'teamzlab-fedex'); ?></span>
                                    <span class="teamzzlab-fedex-locations-max-wrap">
                                        <input
                                            type="number"
                                            class="teamzzlab-fedex-locations-max-dist"
                                            min="0"
                                            step="0.1"
                                            placeholder="<?php esc_attr_e('No limit', 'teamzlab-fedex'); ?>"
                                        />
                                        <abbr class="teamzzlab-fedex-locations-max-unit" title="<?php echo esc_attr($unit_label); ?>"><?php echo esc_html($unit_label); ?></abbr>
                                    </span>
                                </label>
                                <label class="teamzzlab-fedex-locations-control teamzzlab-fedex-locations-control--checkbox">
                                    <input type="checkbox" class="teamzzlab-fedex-locations-phone-only" />
                                    <span><?php esc_html_e('Phone listed only', 'teamzlab-fedex'); ?></span>
                                </label>
                            </div>
                        </div>

                        <p class="teamzzlab-fedex-locations-showing" aria-live="polite">
                            <?php
                            echo wp_kses(
                                sprintf(
                                    /* translators: 1: visible match count 2: total locations returned */
                                    __('Showing <span class="teamzzlab-fedex-locations-visible-count">%1$d</span> of <span class="teamzzlab-fedex-locations-total-count">%2$d</span>.', 'teamzlab-fedex'),
                                    (int) $total_results,
                                    (int) $total_results
                                ),
                                [
                                    'span' => [
                                        'class' => true,
                                    ],
                                ]
                            );
                            ?>
                        </p>

                        <ul class="teamzzlab-fedex-locations-list">
                            <?php foreach ($results as $location) :
                                $contact   = $location['contactAndAddress'] ?? $location;
                                $name      = $contact['contact']['companyName'] ?? ($location['locationId'] ?? __('FedEx location', 'teamzlab-fedex'));
                                $phone     = $contact['contact']['phoneNumber'] ?? '';
                                $address   = $contact['address'] ?? [];
                                $street    = implode(', ', array_filter((array) ($address['streetLines'] ?? [])));
                                $city      = $address['city'] ?? '';
                                $state     = $address['stateOrProvinceCode'] ?? '';
                                $zip       = $address['postalCode'] ?? '';
                                $full_addr = trim(sprintf('%s, %s %s %s', $street, $city, $state, $zip), ', ');
                                $distance  = $this->format_location_distance($location, (string) $atts['unit']);
                                $map_query = rawurlencode(trim($full_addr));
                                $km        = $this->location_distance_km($location);
                                $km_attr   = null !== $km ? (string) round($km, 6) : '';
                                $blob      = strtolower($name . ' ' . $full_addr . ' ' . $phone);
                                $blob      = preg_replace('/\s+/', ' ', $blob) ?? $blob;
                                ?>
                                <li
                                    class="teamzzlab-fedex-location-row"
                                    data-teamzzlab-km="<?php echo esc_attr($km_attr); ?>"
                                    data-teamzzlab-name="<?php echo esc_attr($name); ?>"
                                    data-teamzzlab-text="<?php echo esc_attr($blob); ?>"
                                    data-teamzzlab-has-phone="<?php echo $phone !== '' ? '1' : '0'; ?>"
                                >
                                    <div class="teamzzlab-fedex-location-row-main">
                                        <div class="teamzzlab-fedex-location-title"><?php echo esc_html($name); ?></div>
                                        <div class="teamzzlab-fedex-location-address"><?php echo esc_html($full_addr !== '' ? $full_addr : __('Address unavailable', 'teamzlab-fedex')); ?></div>
                                    </div>
                                    <div class="teamzzlab-fedex-location-row-aside">
                                        <?php if ($distance !== '') : ?>
                                            <span class="teamzzlab-fedex-location-distance"><?php echo esc_html($distance); ?></span>
                                        <?php endif; ?>
                                        <?php if ($phone !== '') : ?>
                                            <a class="teamzzlab-fedex-location-phone" href="tel:<?php echo esc_attr(preg_replace('/[^0-9\+]/', '', (string) $phone)); ?>"><?php echo esc_html($phone); ?></a>
                                        <?php endif; ?>
                                        <?php if ($full_addr !== '') : ?>
                                            <a
                                                class="teamzzlab-fedex-location-map"
                                                href="<?php echo esc_url('https://www.google.com/maps/search/?api=1&query=' . $map_query); ?>"
                                                target="_blank"
                                                rel="noopener noreferrer"
                                            ><?php esc_html_e('Directions', 'teamzlab-fedex'); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </section>
        <?php
        return ob_get_clean();
    }

    /**
     * @param string $unit
     * @return string
     */
    private function normalize_distance_unit(string $unit): string {
        $unit = strtolower(sanitize_text_field($unit));
        return in_array($unit, ['km', 'kilometer', 'kilometers'], true) ? 'km' : 'mile';
    }

    /**
     * Numeric distance in kilometers for sort/filter (client-side).
     *
     * @param array $location
     * @return float|null
     */
    private function location_distance_km(array $location): ?float {
        if (empty($location['distance']) || !is_array($location['distance']) || !isset($location['distance']['value'])) {
            return null;
        }
        $value = (float) $location['distance']['value'];
        $unit  = strtoupper((string) ($location['distance']['units'] ?? 'MI'));
        if (in_array($unit, ['KM', 'KILOMETER', 'KILOMETERS'], true)) {
            return $value;
        }
        if (in_array($unit, ['MI', 'MILE', 'MILES'], true)) {
            return $value * 1.60934;
        }
        return $value * 1.60934;
    }

    /**
     * @param array  $location
     * @param string $preferred_unit
     * @return string
     */
    private function format_location_distance(array $location, string $preferred_unit): string {
        if (empty($location['distance']) || !is_array($location['distance'])) {
            return '';
        }

        $distance = $location['distance'];
        if (!isset($distance['value'])) {
            return '';
        }

        $value = (float) $distance['value'];
        $unit  = strtoupper((string) ($distance['units'] ?? 'MI'));

        if ($preferred_unit === 'km' && in_array($unit, ['MI', 'MILE', 'MILES'], true)) {
            $value *= 1.60934;
            $unit = 'KM';
        } elseif ($preferred_unit === 'mile' && in_array($unit, ['KM', 'KILOMETER', 'KILOMETERS'], true)) {
            $value *= 0.621371;
            $unit = 'MI';
        }

        if (in_array($unit, ['KILOMETER', 'KILOMETERS'], true)) {
            $unit = 'KM';
        } elseif (in_array($unit, ['MILE', 'MILES'], true)) {
            $unit = 'MI';
        }

        $formatted_value = number_format($value, 1, '.', '');
        $formatted_value = rtrim(rtrim($formatted_value, '0'), '.');
        $unit_label = $unit === 'KM' ? __('km', 'teamzlab-fedex') : __('mi', 'teamzlab-fedex');

        return trim($formatted_value . ' ' . $unit_label);
    }

    /**
     * Enqueue the shared public-shortcode stylesheet (calculator, embed
     * block, tracking, timeline, return portal). Called from each shortcode
     * renderer so the CSS only loads on pages that actually use one.
     *
     * @return void
     * @since 1.2.3
     */
    private function enqueue_shortcode_assets(): void {
        $css_rel = 'assets/frontend/css/fshipping-shortcodes.css';
        $base    = defined('FSHIPPING_DIR_PATH') ? FSHIPPING_DIR_PATH : '';
        $css_ver = '1.0.0';
        if ($base !== '' && file_exists($base . $css_rel)) {
            $css_ver = (string) filemtime($base . $css_rel);
        }

        wp_enqueue_style(
            'fshipping-shortcodes',
            plugins_url($css_rel, FSHIPPING_FILE),
            [],
            $css_ver,
            'all'
        );
    }

    /**
     * @return void
     */
    private function enqueue_locations_assets(): void {
        $css_rel = 'assets/frontend/css/teamzzlab-fedex-locations.css';
        $js_rel  = 'assets/frontend/js/teamzzlab-fedex-locations.js';
        $base    = defined('FSHIPPING_DIR_PATH') ? FSHIPPING_DIR_PATH : '';
        $css_ver = '1.0.0';
        $js_ver  = '1.0.0';
        if ($base !== '') {
            $css_path = $base . $css_rel;
            $js_path  = $base . $js_rel;
            if (file_exists($css_path)) {
                $css_ver = (string) filemtime($css_path);
            }
            if (file_exists($js_path)) {
                $js_ver = (string) filemtime($js_path);
            }
        }

        wp_enqueue_style(
            'teamzzlab-fedex-locations',
            plugins_url($css_rel, FSHIPPING_FILE),
            [],
            $css_ver,
            'all'
        );
        wp_enqueue_script(
            'teamzzlab-fedex-locations',
            plugins_url($js_rel, FSHIPPING_FILE),
            [],
            $js_ver,
            true
        );
    }
}
