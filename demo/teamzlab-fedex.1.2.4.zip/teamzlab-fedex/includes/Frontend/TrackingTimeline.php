<?php
namespace FSHIPPING\Frontend;

use FSHIPPING\SingletonTrait;

/**
 * Live tracking timeline for customer order pages.
 *
 * The existing Ajax\TrackingWebhookReceiver stores only the latest AIV
 * event on each shipment. This class layers an append-only history on
 * top, formats rows for UI, and exposes a pure renderer that can be
 * reused by shortcodes, My-Account templates, or REST responses.
 *
 * Hooks into the `fshipping_aiv_event_received` action fired by the
 * receiver — no refactor of the receiver required.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class TrackingTimeline {
    use SingletonTrait;

    public const META_LOG        = '_fshipping_aiv_event_log';
    public const MAX_LOG_ENTRIES = 100;

    /**
     * Append a single event to a shipment's timeline.
     *
     * @param int   $shipment_id The fedex_shipping CPT post id.
     * @param array $event       Raw event dictionary from FedEx AIV webhook.
     * @return int New total count of events after append.
     * @since 1.2
     */
    public function append(int $shipment_id, array $event): int {
        if ($shipment_id <= 0) {
            return 0;
        }

        $log = get_post_meta($shipment_id, self::META_LOG, true);
        $log = is_array($log) ? $log : [];

        $log[] = $this->normalize_event($event);

        if (count($log) > self::MAX_LOG_ENTRIES) {
            $log = array_slice($log, -self::MAX_LOG_ENTRIES);
        }

        update_post_meta($shipment_id, self::META_LOG, $log);
        return count($log);
    }

    /**
     * Read the timeline for a shipment, oldest-first.
     *
     * @param int $shipment_id
     * @return array<int,array{status:string,description:string,at:string,city:string,state:string,country:string}>
     * @since 1.2
     */
    public function get(int $shipment_id): array {
        if ($shipment_id <= 0) {
            return [];
        }
        $log = get_post_meta($shipment_id, self::META_LOG, true);
        return is_array($log) ? $log : [];
    }

    /**
     * Render a compact row list suitable for the customer order page.
     * Each row gets a human-friendly status label + relative-time hint.
     *
     * @param array $log          Result of get().
     * @param int   $current_ts   Current unix timestamp (injectable for tests).
     * @return array<int,array{label:string,description:string,when:string,relative:string,location:string,icon:string}>
     * @since 1.2
     */
    public function format(array $log, int $current_ts = 0): array {
        $current_ts = $current_ts > 0 ? $current_ts : time();
        $rows = [];

        foreach ($log as $entry) {
            $status      = (string) ($entry['status']      ?? '');
            $description = (string) ($entry['description'] ?? '');
            $at_raw      = (string) ($entry['at']          ?? '');
            $ts          = $at_raw !== '' ? strtotime($at_raw) : false;
            $when        = is_int($ts) ? wp_date('Y-m-d H:i', $ts) : $at_raw;
            $relative    = is_int($ts) ? $this->human_time_diff($ts, $current_ts) : '';

            $rows[] = [
                'label'       => $this->label_for_status($status),
                'description' => $description,
                'when'        => $when,
                'relative'    => $relative,
                'location'    => $this->format_location(
                    (string) ($entry['city']    ?? ''),
                    (string) ($entry['state']   ?? ''),
                    (string) ($entry['country'] ?? '')
                ),
                'icon'        => $this->icon_for_status($status),
            ];
        }

        return $rows;
    }

    /**
     * Map FedEx event codes to short UX labels.
     *
     * @param string $status
     * @return string
     * @since 1.2
     */
    public function label_for_status(string $status): string {
        $map = [
            'OC'  => 'Order created',
            'PU'  => 'Picked up',
            'IT'  => 'In transit',
            'AR'  => 'Arrived at facility',
            'DP'  => 'Departed facility',
            'OD'  => 'Out for delivery',
            'DL'  => 'Delivered',
            'DE'  => 'Delivery exception',
            'HL'  => 'Hold at location',
            'RS'  => 'Returning to sender',
        ];
        return $map[strtoupper($status)] ?? ($status === '' ? 'Status update' : $status);
    }

    /**
     * @param string $status
     * @return string
     * @since 1.2
     */
    public function icon_for_status(string $status): string {
        $terminal = ['DL', 'DE', 'RS'];
        $exception = ['DE'];
        $upper = strtoupper($status);
        if (in_array($upper, $exception, true)) return 'alert';
        if (in_array($upper, $terminal, true))  return 'check';
        return 'truck';
    }

    /**
     * @param array $event
     * @return array{status:string,description:string,at:string,city:string,state:string,country:string}
     * @since 1.2
     */
    private function normalize_event(array $event): array {
        $location = $event['scanLocation'] ?? ($event['location'] ?? []);
        $location = is_array($location) ? $location : [];
        return [
            'status'      => sanitize_text_field((string) ($event['eventType']        ?? ($event['statusCode']  ?? ''))),
            'description' => sanitize_text_field((string) ($event['eventDescription'] ?? ($event['description'] ?? ''))),
            'at'          => sanitize_text_field((string) ($event['eventDateTime']    ?? ($event['timestamp']   ?? current_time('c')))),
            'city'        => sanitize_text_field((string) ($location['city']                ?? '')),
            'state'       => sanitize_text_field((string) ($location['stateOrProvinceCode'] ?? '')),
            'country'     => sanitize_text_field((string) ($location['countryCode']         ?? '')),
        ];
    }

    /**
     * @param string $city
     * @param string $state
     * @param string $country
     * @return string
     * @since 1.2
     */
    private function format_location(string $city, string $state, string $country): string {
        $parts = array_filter([$city, $state, $country], static fn($p) => $p !== '');
        return implode(', ', $parts);
    }

    /**
     * Minimal human-readable diff, testable without a live WP install.
     *
     * @param int $past
     * @param int $now
     * @return string
     * @since 1.2
     */
    private function human_time_diff(int $past, int $now): string {
        $delta = max(0, $now - $past);
        if ($delta < 60)    return $delta . 's ago';
        if ($delta < 3600)  return (int) floor($delta / 60) . 'm ago';
        if ($delta < 86400) return (int) floor($delta / 3600) . 'h ago';
        return (int) floor($delta / 86400) . 'd ago';
    }
}
