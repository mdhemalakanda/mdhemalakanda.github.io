<?php
namespace FSHIPPING\Boxing;

use FSHIPPING\SingletonTrait;

/**
 * Converts weight and dimension values for Product Box packing.
 *
 * @since 1.9
 */
defined('ABSPATH') || exit;

class UnitConverter
{
    use SingletonTrait;

    /**
     * @param float  $value
     * @param string $from_unit
     * @param string $to_unit
     * @return float
     */
    public function convert_weight(float $value, string $from_unit, string $to_unit): float
    {
        $from = strtoupper(trim($from_unit));
        $to = strtoupper(trim($to_unit));
        if ($value <= 0) {
            return 0.0;
        }
        if (!in_array($from, ['KG', 'LB', 'G', 'OZ'], true) || !in_array($to, ['KG', 'LB', 'G', 'OZ'], true)) {
            return 0.0;
        }

        if ($from === $to) {
            return round($value, 3);
        }

        $kg = $value;
        if ($from === 'LB') {
            $kg = $value * 0.45359237;
        } elseif ($from === 'G') {
            $kg = $value / 1000;
        } elseif ($from === 'OZ') {
            $kg = $value * 0.0283495231;
        }

        if ($to === 'KG') {
            return round($kg, 3);
        }
        if ($to === 'LB') {
            return round($kg / 0.45359237, 3);
        }
        if ($to === 'G') {
            return round($kg * 1000, 3);
        }

        return round($kg / 0.0283495231, 3);
    }

    /**
     * @param mixed  $value
     * @param string $target_unit
     * @return float
     */
    public function normalize_store_weight_to_target($value, string $target_unit): float
    {
        $raw = is_numeric($value) ? (float) $value : 0.0;
        if ($raw <= 0) {
            return 0.0;
        }
        $store_unit = strtoupper((string) get_option('woocommerce_weight_unit', 'kg'));
        if ($store_unit === 'LBS') {
            $store_unit = 'LB';
        }
        if (!in_array($store_unit, ['KG', 'LB', 'G', 'OZ'], true)) {
            $store_unit = 'KG';
        }

        $target = strtoupper(trim($target_unit));
        if (!in_array($target, ['KG', 'LB'], true)) {
            $target = 'KG';
        }

        return $this->convert_weight($raw, $store_unit, $target);
    }

    /**
     * @param float  $value
     * @param string $from_unit
     * @param string $to_unit
     * @return float
     */
    public function convert_dimension(float $value, string $from_unit, string $to_unit): float
    {
        $from = strtoupper(trim($from_unit));
        $to = strtoupper(trim($to_unit));
        if ($value <= 0) {
            return 0.0;
        }
        if (!in_array($from, ['IN', 'CM'], true) || !in_array($to, ['IN', 'CM'], true)) {
            return 0.0;
        }
        if ($from === $to) {
            return round($value, 2);
        }
        if ($from === 'CM' && $to === 'IN') {
            return round($value * 0.3937007874, 2);
        }

        return round($value / 0.3937007874, 2);
    }
}

