<?php
namespace FSHIPPING\Boxing;

use FSHIPPING\SingletonTrait;

/**
 * Stores and sanitizes Product Box configuration.
 *
 * @since 1.9
 */
defined('ABSPATH') || exit;

class BoxCatalog
{
    use SingletonTrait;

    public const OPTION_KEY = 'fshipping_product_boxes';

    /**
     * FedEx standard-supply packaging presets. Dimensions are FedEx's
     * published interior/usable sizes in inches (Length × Width × Height);
     * flat supplies (Envelope, Pak) get a nominal 0.5" height because the
     * box catalog requires a positive height. Keys mirror the FedEx REST
     * packagingType enum values. Picking a preset on the Product Box screen
     * only auto-fills the box dimensions — it never changes API payloads by
     * itself.
     *
     * @return array<string,array<string,mixed>>
     */
    public static function packaging_presets(): array
    {
        return [
            'FEDEX_ENVELOPE' => ['label' => 'FedEx Envelope', 'length' => 13.19, 'width' => 9.25, 'height' => 0.5],
            'FEDEX_PAK' => ['label' => 'FedEx Pak', 'length' => 15.5, 'width' => 12.0, 'height' => 0.5],
            'FEDEX_TUBE' => ['label' => 'FedEx Tube', 'length' => 38.0, 'width' => 6.0, 'height' => 6.0],
            'FEDEX_SMALL_BOX' => ['label' => 'FedEx Small Box', 'length' => 12.38, 'width' => 10.88, 'height' => 1.5],
            'FEDEX_MEDIUM_BOX' => ['label' => 'FedEx Medium Box', 'length' => 17.5, 'width' => 11.25, 'height' => 2.38],
            'FEDEX_LARGE_BOX' => ['label' => 'FedEx Large Box', 'length' => 17.88, 'width' => 12.38, 'height' => 3.0],
            'FEDEX_EXTRA_LARGE_BOX' => ['label' => 'FedEx Extra Large Box', 'length' => 15.75, 'width' => 14.13, 'height' => 6.0],
            'FEDEX_10KG_BOX' => ['label' => 'FedEx 10kg Box', 'length' => 15.81, 'width' => 12.94, 'height' => 10.19],
            'FEDEX_25KG_BOX' => ['label' => 'FedEx 25kg Box', 'length' => 21.56, 'width' => 16.56, 'height' => 13.19],
        ];
    }

    /**
     * @return array<string,mixed>
     */
    public function get(): array
    {
        $raw = get_option(self::OPTION_KEY, []);
        if (!is_array($raw)) {
            $raw = [];
        }

        return $this->sanitize_config($raw);
    }

    /**
     * @param array<string,mixed> $config
     * @return array<string,mixed>
     */
    public function save(array $config): array
    {
        $sanitized = $this->sanitize_config($config);
        update_option(self::OPTION_KEY, $sanitized);

        return $sanitized;
    }

    /**
     * @return array<string,mixed>
     */
    public function defaults(): array
    {
        return [
            'weight_output_unit' => 'KG',
            'dimension_unit' => 'CM',
            'boxes' => [],
        ];
    }

    /**
     * @param array<string,mixed> $config
     * @return array<string,mixed>
     */
    public function sanitize_config(array $config): array
    {
        $defaults = $this->defaults();

        $weight_output_unit = isset($config['weight_output_unit']) ? strtoupper(sanitize_text_field((string) $config['weight_output_unit'])) : $defaults['weight_output_unit'];
        if (!in_array($weight_output_unit, ['LB', 'KG'], true)) {
            $weight_output_unit = $defaults['weight_output_unit'];
        }

        $dimension_unit = isset($config['dimension_unit']) ? strtoupper(sanitize_text_field((string) $config['dimension_unit'])) : $defaults['dimension_unit'];
        if (!in_array($dimension_unit, ['IN', 'CM'], true)) {
            $dimension_unit = $defaults['dimension_unit'];
        }

        $raw_boxes = isset($config['boxes']) && is_array($config['boxes']) ? $config['boxes'] : [];
        $boxes = [];
        foreach ($raw_boxes as $box) {
            if (!is_array($box)) {
                continue;
            }
            $sanitized = $this->sanitize_box($box, $dimension_unit);
            if (!empty($sanitized)) {
                $boxes[] = $sanitized;
            }
        }

        return [
            'weight_output_unit' => $weight_output_unit,
            'dimension_unit' => $dimension_unit,
            'boxes' => $boxes,
        ];
    }

    /**
     * @param array<string,mixed> $box
     * @param string $default_dimension_unit
     * @return array<string,mixed>
     */
    private function sanitize_box(array $box, string $default_dimension_unit): array
    {
        $id = isset($box['id']) ? sanitize_key((string) $box['id']) : '';
        if ($id === '') {
            $id = 'box_' . wp_generate_password(10, false, false);
        }

        $name = isset($box['name']) ? sanitize_text_field((string) $box['name']) : '';
        if ($name === '') {
            return [];
        }

        $preset = isset($box['preset']) ? (string) $box['preset'] : '';
        if ($preset !== '' && !array_key_exists($preset, self::packaging_presets())) {
            $preset = '';
        }

        $dims = isset($box['dimensions']) && is_array($box['dimensions']) ? $box['dimensions'] : [];
        $length = isset($dims['length']) ? (float) $dims['length'] : 0.0;
        $width = isset($dims['width']) ? (float) $dims['width'] : 0.0;
        $height = isset($dims['height']) ? (float) $dims['height'] : 0.0;
        $dim_unit = isset($dims['units']) ? strtoupper(sanitize_text_field((string) $dims['units'])) : $default_dimension_unit;
        if (!in_array($dim_unit, ['IN', 'CM'], true)) {
            $dim_unit = $default_dimension_unit;
        }
        if ($length <= 0 || $width <= 0 || $height <= 0) {
            return [];
        }

        $empty = isset($box['empty_weight']) && is_array($box['empty_weight']) ? $box['empty_weight'] : [];
        $empty_value = isset($empty['value']) ? (float) $empty['value'] : 0.0;
        $empty_unit = isset($empty['unit']) ? strtoupper(sanitize_text_field((string) $empty['unit'])) : 'KG';
        if (!in_array($empty_unit, ['LB', 'KG', 'OZ', 'G'], true)) {
            $empty_unit = 'KG';
        }
        if ($empty_value < 0) {
            $empty_value = 0.0;
        }

        $raw_rules = isset($box['product_rules']) && is_array($box['product_rules']) ? $box['product_rules'] : [];
        $rules = [];
        foreach ($raw_rules as $rule) {
            if (!is_array($rule)) {
                continue;
            }
            $product_id = isset($rule['product_id']) ? absint($rule['product_id']) : 0;
            $capacity_qty = isset($rule['capacity_qty']) ? absint($rule['capacity_qty']) : 0;
            if ($product_id < 1 || $capacity_qty < 1) {
                continue;
            }
            $rules[] = [
                'product_id' => $product_id,
                'capacity_qty' => $capacity_qty,
            ];
        }

        if (empty($rules)) {
            return [];
        }

        return [
            'id' => $id,
            'name' => $name,
            'preset' => $preset,
            'dimensions' => [
                'length' => round($length, 2),
                'width' => round($width, 2),
                'height' => round($height, 2),
                'units' => $dim_unit,
            ],
            'empty_weight' => [
                'value' => round($empty_value, 3),
                'unit' => $empty_unit,
            ],
            'product_rules' => $rules,
        ];
    }
}

