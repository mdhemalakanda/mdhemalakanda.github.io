<?php
namespace FSHIPPING\Boxing;

use FSHIPPING\SingletonTrait;

/**
 * Builds FedEx package rows from Product Box rules.
 *
 * @since 1.9
 */
defined('ABSPATH') || exit;

class BoxPacker
{
    use SingletonTrait;

    /**
     * @param array<int,array<string,mixed>> $order_items
     * @param array<string,mixed>            $catalog
     * @return array<string,mixed>
     */
    public function pack(array $order_items, array $catalog): array
    {
        $weight_unit = strtoupper((string) ($catalog['weight_output_unit'] ?? 'KG'));
        if (!in_array($weight_unit, ['KG', 'LB'], true)) {
            $weight_unit = 'KG';
        }

        $boxes = $this->build_box_index(isset($catalog['boxes']) && is_array($catalog['boxes']) ? $catalog['boxes'] : []);
        if (empty($boxes)) {
            return [
                'matched_packages' => [],
                'unmatched_items' => $this->normalize_order_items($order_items, $weight_unit),
                'weight_output_unit' => $weight_unit,
            ];
        }

        $remaining = [];
        foreach ($this->normalize_order_items($order_items, $weight_unit) as $item) {
            $remaining[(int) $item['product_id']] = $item;
        }

        $matched = [];
        $loop_guard = 0;
        while (!empty($remaining) && $loop_guard < 1000) {
            $loop_guard++;
            $best = $this->pick_best_box_plan($boxes, $remaining, $weight_unit);
            if (empty($best['plan']) || empty($best['box'])) {
                break;
            }
            $plan = $best['plan'];
            $box = $best['box'];

            $products = [];
            $products_weight = 0.0;
            $products_price = 0.0;
            foreach ($plan as $product_id => $qty) {
                if (!isset($remaining[$product_id])) {
                    continue;
                }
                $unit_weight = (float) $remaining[$product_id]['unit_weight'];
                $unit_price = isset($remaining[$product_id]['unit_price']) ? (float) $remaining[$product_id]['unit_price'] : 0.0;
                $products[] = [
                    'product_id' => (int) $product_id,
                    'product_name' => isset($remaining[$product_id]['product_name']) ? sanitize_text_field((string) $remaining[$product_id]['product_name']) : '',
                    'qty' => (int) $qty,
                    'unit_weight' => $unit_weight,
                    'unit_price' => $unit_price,
                ];
                $products_weight += ($unit_weight * (int) $qty);
                $products_price += ($unit_price * (int) $qty);
                $remaining[$product_id]['qty'] = (int) $remaining[$product_id]['qty'] - (int) $qty;
                if ((int) $remaining[$product_id]['qty'] <= 0) {
                    unset($remaining[$product_id]);
                }
            }

            if (!empty($products)) {
                $empty_in_output = $this->convert_weight_precise(
                    (float) $box['empty_weight_value'],
                    (string) $box['empty_weight_unit'],
                    $weight_unit
                );
                $total_weight = $products_weight + $empty_in_output;
                $matched[] = [
                    'box_id' => (string) ($box['id'] ?? ''),
                    'box_name' => (string) ($box['name'] ?? ''),
                    'dimensions' => $box['dimensions'],
                    'weight' => [
                        'units' => $weight_unit,
                        'value' => round($total_weight, 3),
                    ],
                    'weight_breakdown' => [
                        'products_weight' => round($products_weight, 4),
                        'empty_weight' => round($empty_in_output, 4),
                        'total_weight' => round($total_weight, 4),
                        'units' => $weight_unit,
                    ],
                    'price_breakdown' => [
                        'products_price' => round($products_price, 4),
                    ],
                    'products' => $products,
                ];
            }
        }

        return [
            'matched_packages' => $matched,
            'unmatched_items' => array_values($remaining),
            'weight_output_unit' => $weight_unit,
        ];
    }

    /**
     * @param array<int,array<string,mixed>> $order_items
     * @param string                         $weight_unit
     * @return array<int,array<string,mixed>>
     */
    private function normalize_order_items(array $order_items, string $weight_unit): array
    {
        $normalized = [];
        foreach ($order_items as $item) {
            if (!is_array($item)) {
                continue;
            }
            $product_id = isset($item['product_id']) ? absint($item['product_id']) : 0;
            $qty = isset($item['qty']) ? absint($item['qty']) : 0;
            $weight = isset($item['unit_weight']) && is_numeric($item['unit_weight']) ? (float) $item['unit_weight'] : 0.0;
            $unit_price = isset($item['unit_price']) && is_numeric($item['unit_price']) ? (float) $item['unit_price'] : 0.0;
            if ($product_id < 1 || $qty < 1 || $weight <= 0) {
                continue;
            }
            $normalized[] = [
                'product_id' => $product_id,
                'product_name' => isset($item['product_name']) ? sanitize_text_field((string) $item['product_name']) : '',
                'qty' => $qty,
                'unit_weight' => round($weight, 3),
                'unit_price' => round(max(0.0, $unit_price), 4),
                'units' => $weight_unit,
            ];
        }
        return $normalized;
    }

    /**
     * @param array<int,mixed> $boxes
     * @return array<int,array<string,mixed>>
     */
    private function build_box_index(array $boxes): array
    {
        $indexed = [];
        foreach ($boxes as $box) {
            if (!is_array($box) || empty($box['product_rules']) || !is_array($box['product_rules'])) {
                continue;
            }
            $rules = [];
            $max_capacity = 0;
            foreach ($box['product_rules'] as $rule) {
                if (!is_array($rule)) {
                    continue;
                }
                $product_id = isset($rule['product_id']) ? absint($rule['product_id']) : 0;
                $capacity = isset($rule['capacity_qty']) ? absint($rule['capacity_qty']) : 0;
                if ($product_id < 1 || $capacity < 1) {
                    continue;
                }
                $rules[$product_id] = $capacity;
                if ($capacity > $max_capacity) {
                    $max_capacity = $capacity;
                }
            }
            if (empty($rules) || $max_capacity < 1) {
                continue;
            }
            $dimensions = isset($box['dimensions']) && is_array($box['dimensions']) ? $box['dimensions'] : [];
            $empty = isset($box['empty_weight']) && is_array($box['empty_weight']) ? $box['empty_weight'] : [];
            $empty_value = isset($empty['value']) && is_numeric($empty['value']) ? (float) $empty['value'] : 0.0;
            $empty_unit = isset($empty['unit']) ? strtoupper(trim((string) $empty['unit'])) : 'KG';
            if (!in_array($empty_unit, ['LB', 'KG', 'G', 'OZ'], true)) {
                $empty_unit = 'KG';
            }
            $indexed[] = [
                'id' => (string) ($box['id'] ?? ''),
                'name' => (string) ($box['name'] ?? ''),
                'dimensions' => [
                    'length' => isset($dimensions['length']) ? (float) $dimensions['length'] : 0.0,
                    'width' => isset($dimensions['width']) ? (float) $dimensions['width'] : 0.0,
                    'height' => isset($dimensions['height']) ? (float) $dimensions['height'] : 0.0,
                    'units' => isset($dimensions['units']) ? strtoupper((string) $dimensions['units']) : 'CM',
                ],
                'empty_weight_value' => $empty_value,
                'empty_weight_unit' => $empty_unit,
                'rules' => $rules,
                'max_capacity' => $max_capacity,
            ];
        }
        return $indexed;
    }

    /**
     * @param array<int,array<string,mixed>>       $boxes
     * @param array<int,array<string,mixed>>       $remaining
     * @param string                               $weight_unit
     * @return array<string,mixed>
     */
    private function pick_best_box_plan(array $boxes, array $remaining, string $weight_unit): array
    {
        $best = [
            'box' => null,
            'plan' => [],
            'packed_count' => 0,
            'waste' => PHP_INT_MAX,
            'capacity' => 0,
        ];

        foreach ($boxes as $box) {
            $plan = [];

            $candidates = [];
            foreach ($remaining as $product_id => $item) {
                if (!isset($box['rules'][$product_id])) {
                    continue;
                }
                $candidates[$product_id] = (int) $item['qty'];
            }
            if (empty($candidates)) {
                continue;
            }
            // Phase 1 (single-SKU-first): dedicate the box to the highest-remaining SKU first.
            $primary_product_id = 0;
            $primary_qty_remaining = 0;
            foreach ($candidates as $product_id => $qty_remaining) {
                $product_id = (int) $product_id;
                $qty_remaining = (int) $qty_remaining;
                if (
                    $qty_remaining > $primary_qty_remaining
                    || ($qty_remaining === $primary_qty_remaining && ($primary_product_id === 0 || $product_id < $primary_product_id))
                ) {
                    $primary_product_id = $product_id;
                    $primary_qty_remaining = $qty_remaining;
                }
            }
            if ($primary_product_id > 0) {
                $box_capacity_for_plan = (int) $box['rules'][$primary_product_id];
                if ($box_capacity_for_plan < 1) {
                    continue;
                }
                $capacity_left = $box_capacity_for_plan;
                $take_primary = min($primary_qty_remaining, $box_capacity_for_plan, $capacity_left);
                if ($take_primary > 0) {
                    $plan[$primary_product_id] = $take_primary;
                    $capacity_left -= $take_primary;
                }
            } else {
                continue;
            }

            // Phase 2 (optional top-up): fill leftover capacity with other SKUs, highest qty first.
            if ($capacity_left > 0) {
                $top_up_candidates = [];
                foreach ($candidates as $product_id => $qty_remaining) {
                    $product_id = (int) $product_id;
                    if ($product_id === $primary_product_id) {
                        continue;
                    }
                    $top_up_candidates[] = [
                        'product_id' => $product_id,
                        'qty' => (int) $qty_remaining,
                    ];
                }
                usort($top_up_candidates, static function (array $a, array $b): int {
                    if ($a['qty'] === $b['qty']) {
                        return $a['product_id'] <=> $b['product_id'];
                    }
                    return $b['qty'] <=> $a['qty'];
                });

                foreach ($top_up_candidates as $row) {
                    if ($capacity_left < 1) {
                        break;
                    }
                    $product_id = (int) $row['product_id'];
                    $qty_remaining = (int) $row['qty'];
                    $rule_capacity = (int) $box['rules'][$product_id];
                    $take = min($qty_remaining, $rule_capacity, $capacity_left);
                    if ($take < 1) {
                        continue;
                    }
                    $plan[$product_id] = $take;
                    $capacity_left -= $take;
                }
            }

            $packed_count = array_sum($plan);
            if ($packed_count < 1) {
                continue;
            }

            $waste = max(0, (int) $box_capacity_for_plan - $packed_count);
            if (
                $packed_count > $best['packed_count']
                || ($packed_count === $best['packed_count'] && $waste < $best['waste'])
                || ($packed_count === $best['packed_count'] && $waste === $best['waste'] && (int) $box_capacity_for_plan > $best['capacity'])
            ) {
                $best = [
                    'box' => $box,
                    'plan' => $plan,
                    'packed_count' => $packed_count,
                    'waste' => $waste,
                    'capacity' => (int) $box_capacity_for_plan,
                    'weight_output_unit' => $weight_unit,
                ];
            }
        }

        return $best;
    }

    /**
     * Convert without intermediate rounding so debug breakdown stays precise.
     *
     * @param float  $value
     * @param string $from_unit
     * @param string $to_unit
     * @return float
     */
    private function convert_weight_precise(float $value, string $from_unit, string $to_unit): float
    {
        $from = strtoupper(trim($from_unit));
        $to = strtoupper(trim($to_unit));
        if ($value <= 0) {
            return 0.0;
        }
        if (!in_array($from, ['KG', 'LB', 'G', 'OZ'], true) || !in_array($to, ['KG', 'LB', 'G', 'OZ'], true)) {
            return 0.0;
        }
        if ($from === $to) {
            return $value;
        }

        $kg = $value;
        if ($from === 'LB') {
            $kg = $value * 0.45359237;
        } elseif ($from === 'G') {
            $kg = $value / 1000;
        } elseif ($from === 'OZ') {
            $kg = $value * 0.0283495231;
        }

        if ($to === 'KG') {
            return $kg;
        }
        if ($to === 'LB') {
            return $kg / 0.45359237;
        }
        if ($to === 'G') {
            return $kg * 1000;
        }
        return $kg / 0.0283495231;
    }
}

