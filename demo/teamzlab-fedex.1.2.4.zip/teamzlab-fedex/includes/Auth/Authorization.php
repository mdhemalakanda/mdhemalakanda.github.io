<?php
namespace FSHIPPING\Auth;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\Helper;
defined('ABSPATH') || exit;
/**
 * This file will work for authorization.
 * 
 * @since 1.0
 */

class Authorization {
    use SingletonTrait;

    /**
     * Get secret token.
     * 
     * This function will generate token based on auth credentials.
     * 
     * @return string $token
     */
    public function get_secret_token() {
        $options = get_option('fshipping_options');
        $client_id = isset($options['fshipping_client_id']) ? sanitize_text_field($options['fshipping_client_id']) : '';
        $client_secret = isset($options['fshipping_client_secret']) ? sanitize_text_field($options['fshipping_client_secret']) : '';
        $endpoint = Helper::instance()->get_base_url(). '/oauth/token';

        // Cache per environment + credential pair: a token minted by the
        // sandbox host (or with an old key) is a 401 against any other, so
        // the cache key must move whenever the credentials do. The original
        // unscoped read here caused stale-token 401s after sandbox↔production
        // switches, which is why caching had been disabled entirely — costing
        // a live OAuth POST on every rate/ship/track call.
        $cache_key = 'fshipping_auth_token_' . md5($endpoint . '|' . $client_id . '|' . $client_secret);
        $token = get_transient($cache_key);
        if (!empty($token)) {
            return $token;
        }

        $args = array(
            'method'      => 'POST',
            'timeout'     => 60,
            'headers'     => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
            ),
            'body'        => array(
                'grant_type'    => 'client_credentials',
                'client_id'     => $client_id,
                'client_secret' => $client_secret,
            ),
        );

        $response = wp_remote_post($endpoint, $args);

        if (is_wp_error($response)) {
            return '';
        }

        $result = json_decode(wp_remote_retrieve_body($response), true);
        $access_token = !empty($result['access_token']) ? sanitize_text_field($result['access_token']): '';
        $expire = !empty($result['expires_in']) ? sanitize_text_field($result['expires_in']): '';

        if(!empty($access_token) && !empty($expire)) {
            // Renew 5 minutes before FedEx expires the token so in-flight
            // calls never use one that is about to die.
            set_transient($cache_key, $access_token, max(60, (int) $expire - 300));
            return $access_token;
        }
        return '';
    }

    /**
     * Get secret token.
     * 
     * This function will generate token based on auth credentials.
     * 
     * @return string $token
     */
    public function get_track_secret_token() {
        $options = get_option('fshipping_options');
        $client_id = isset($options['fshipping_tracking_client_id']) ? sanitize_text_field($options['fshipping_tracking_client_id']) : '';
        $client_secret = isset($options['fshipping_tracking_client_secret']) ? sanitize_text_field($options['fshipping_tracking_client_secret']) : '';
        $endpoint = Helper::instance()->get_base_url(). '/oauth/token';

        // Same per-credential cache key as get_secret_token() — see there.
        $cache_key = 'fshipping_track_auth_token_' . md5($endpoint . '|' . $client_id . '|' . $client_secret);
        $token = get_transient($cache_key);
        if (!empty($token)) {
            return $token;
        }

        $args = array(
            'method'      => 'POST',
            'timeout'     => 60,
            'headers'     => array(
                'Content-Type' => 'application/x-www-form-urlencoded',
            ),
            'body'        => array(
                'grant_type'    => 'client_credentials',
                'client_id'     => $client_id,
                'client_secret' => $client_secret,
            ),
        );

        $response = wp_remote_post($endpoint, $args);

        if (is_wp_error($response)) {
            return '';
        }

        $result = json_decode(wp_remote_retrieve_body($response), true);
        $access_token = !empty($result['access_token']) ? sanitize_text_field($result['access_token']): '';
        $expire = !empty($result['expires_in']) ? sanitize_text_field($result['expires_in']): '';

        if(!empty($access_token) && !empty($expire)) {
            set_transient($cache_key, $access_token, max(60, (int) $expire - 300));
            return $access_token;
        }

        return '';
    }
}