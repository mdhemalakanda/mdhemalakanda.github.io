<?php
namespace FSHIPPING;
use FSHIPPING\Dashboard\Settings;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\Helper;

/**
 * This will create all required menu for this plugin.
 * 
 * @since 1.0
 */
class Menu {
    use SingletonTrait;

    public function init() {
        add_action('admin_menu', array($this, 'add_menu'));
    }

    public function add_menu() {
        add_menu_page(
            __('FedEx Shipping', 'teamzlab-fedex'),
            __('FedEx Shipping', 'teamzlab-fedex'),
            'manage_options',
            'fedex_shipping',
            '',
            'dashicons-airplane'
        );

        if (Helper::instance()->get_shipping_mode() !== 'advanced') {
            add_submenu_page(
                'fedex_shipping',
                __('Shipments & Printings', 'teamzlab-fedex'),
                __('Shipments & Printings', 'teamzlab-fedex'),
                'manage_options',
                'edit.php?post_type=fedex_shipping',
                '',
                10
            );
        }

        // Same slug as parent — required WP pattern; position 999 keeps it last in the FedEx submenu.
        add_submenu_page(
            'fedex_shipping',
            __('Settings', 'teamzlab-fedex'),
            __('Settings', 'teamzlab-fedex'),
            'manage_options',
            'fedex_shipping',
            array(Settings::instance(), 'display_settings'),
            999
        );

    }
}