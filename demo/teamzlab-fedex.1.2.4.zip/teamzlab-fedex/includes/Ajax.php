<?php
namespace FSHIPPING;

use FSHIPPING\Utils\AddressNormalizer;
use FSHIPPING\Utils\RateLimiter;
use FSHIPPING\Utils\OrderMeta;

/**
 * This class will use for handle ajax.
 */
defined('ABSPATH') || exit;

class Ajax {
    use SingletonTrait;

    public function init() {
        add_action('wp_ajax_fshipping_cancel_shipment', array($this, 'cancel_shipment'));
        // Cancel calls the paid FedEx void endpoint and mutates orders — logged-in admins only;
        // the nopriv registration was removed (any visitor held the public nonce).

        add_action('wp_ajax_fshipping_track_shipment', array($this, 'fshipping_track_shipment'));
        add_action('wp_ajax_nopriv_fshipping_track_shipment', array($this, 'fshipping_track_shipment'));

        // Address Validation — drives the residential-surcharge shield at checkout.
        add_action('wp_ajax_fshipping_validate_address',       array($this, 'validate_address'));
        add_action('wp_ajax_nopriv_fshipping_validate_address', array($this, 'validate_address'));
        add_action('wp_ajax_fshipping_validate_postal_code',       array($this, 'validate_postal_code'));
        add_action('wp_ajax_nopriv_fshipping_validate_postal_code', array($this, 'validate_postal_code'));

        // Pickup request — admin-only; protected by manage_options + nonce.
        add_action('wp_ajax_fshipping_get_ready_pickups', array($this, 'get_ready_pickups'));
        add_action('wp_ajax_fshipping_request_pickup', array($this, 'request_pickup'));
        add_action('wp_ajax_fshipping_request_pickup_batch', array($this, 'request_pickup_batch'));
        add_action('wp_ajax_fshipping_cancel_pickup',  array($this, 'cancel_pickup'));
        add_action('wp_ajax_fshipping_cancel_pickup_by_confirmation', array($this, 'cancel_pickup_by_confirmation'));

        // Return-tag creation — admin-only.
        add_action('wp_ajax_fshipping_create_return',  array($this, 'create_return'));

        // SPOD PDF download — admin-only.
        add_action('wp_ajax_fshipping_download_spod',  array($this, 'download_spod'));

        // Label printed toggle — admin-only.
        add_action('wp_ajax_fshipping_toggle_label_printed', array($this, 'toggle_label_printed'));
        add_action('wp_ajax_fshipping_upload_trade_documents', array($this, 'upload_trade_documents'));
    }

    /**
     * AJAX: mark shipment label as printed/not printed.
     *
     * @return void
     */
    public function toggle_label_printed() {
        if (!current_user_can('manage_options') && !current_user_can('edit_shop_orders')) {
            wp_send_json_error(['error' => 'forbidden'], 403);
        }
        check_ajax_referer('fshipping_nonce', 'nonce');

        $shipment_id = !empty($_POST['shipment_id']) ? (int) $_POST['shipment_id'] : 0;
        $openship_order_id = !empty($_POST['openship_order_id']) ? (int) $_POST['openship_order_id'] : 0;
        if ($shipment_id <= 0 && $openship_order_id <= 0) {
            wp_send_json_error(['error' => 'missing_shipment_or_order_id'], 400);
        }

        $printed = !empty($_POST['printed']) ? sanitize_text_field(wp_unslash($_POST['printed'])) : '0';
        $is_printed = in_array(strtolower((string) $printed), ['1', 'true', 'yes', 'on'], true);
        $value = $is_printed ? 'yes' : 'no';

        $meta_target_id = 0;
        if ($shipment_id > 0) {
            $post = get_post($shipment_id);
            if (!$post || 'fedex_shipping' !== $post->post_type) {
                wp_send_json_error(['error' => 'invalid_shipment'], 400);
            }
            $meta_target_id = $shipment_id;
        } else {
            $order = function_exists('wc_get_order') ? wc_get_order($openship_order_id) : null;
            if (!$order) {
                wp_send_json_error(['error' => 'invalid_openship_order'], 400);
            }
            $meta_target_id = $openship_order_id;
        }

        $ok = OrderMeta::update($meta_target_id, '_fshipping_label_printed', $value);
        if (false === $ok) {
            wp_send_json_error(['error' => 'update_failed'], 500);
        }

        wp_send_json_success([
            'shipment_id' => $shipment_id,
            'openship_order_id' => $openship_order_id,
            'printed'     => $is_printed,
            'value'       => $value,
        ]);
    }

    /**
     * AJAX: download the Signature Proof of Delivery PDF for a
     * shipment. Delegates to HTTP\Tracking::download_spod.
     *
     * @return void
     * @since 1.2
     */
    public function download_spod() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['error' => 'forbidden'], 403);
        }
        check_ajax_referer('fshipping_nonce', 'nonce');

        $tracking = !empty($_POST['trackingId']) ? sanitize_text_field(wp_unslash($_POST['trackingId'])) : '';
        if (empty($tracking)) {
            wp_send_json_error(['error' => 'missing_tracking_id'], 400);
        }
        $url = HTTP\Tracking::instance()->download_spod($tracking);
        if (empty($url)) {
            wp_send_json_error([
                'error'   => 'spod_unavailable',
                'message' => __('SPOD not available yet. FedEx returns SPOD only for delivered Express/Ground shipments; signature images are not available in sandbox.', 'teamzlab-fedex'),
            ], 404);
        }
        wp_send_json_success(['url' => $url]);
    }

    /**
     * AJAX: create a FedEx return tag for a given order / shipment.
     *
     * @return void
     * @since 1.1
     */
    public function create_return() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['error' => 'forbidden'], 403);
        }
        check_ajax_referer('fshipping_nonce', 'nonce');

        $order_id = !empty($_POST['order_id']) ? (int) $_POST['order_id'] : 0;
        if (empty($order_id)) {
            wp_send_json_error(['error' => 'missing_order_id'], 400);
        }

        $result = HTTP\ReturnTag::instance()->create_tag($order_id, [
            'reason' => __('WooCommerce customer return', 'teamzlab-fedex'),
        ]);
        if (empty($result)) {
            wp_send_json_error(['error' => 'return_tag_failed'], 502);
        }

        $label_url = OrderMeta::get($order_id, '_fshipping_return_label_url');
        $tracking  = OrderMeta::get($order_id, '_fshipping_return_tracking');

        wp_send_json_success([
            'label_url' => $label_url,
            'tracking'  => $tracking,
        ]);
    }

    /**
     * AJAX: upload post-shipment customs documents for a FedEx shipment row.
     *
     * @return void
     */
    public function upload_trade_documents() {
        if (!current_user_can('manage_options') && !current_user_can('edit_shop_orders')) {
            wp_send_json_error(['error' => 'forbidden'], 403);
        }
        check_ajax_referer('fshipping_nonce', 'nonce');

        // Self-hosted build: do not hard-gate Trade Documents behind Freemius plan checks.

        $shipment_id = !empty($_POST['shipment_id']) ? (int) $_POST['shipment_id'] : 0;
        $openship_order_id = !empty($_POST['openship_order_id']) ? (int) $_POST['openship_order_id'] : 0;
        if ($shipment_id <= 0 && $openship_order_id <= 0) {
            wp_send_json_error(['error' => 'missing_shipment_or_order_id'], 400);
        }

        $meta_target_id = 0;
        $tracking = '';
        $order_id = 0;
        $order = null;

        if ($shipment_id > 0) {
            $post = get_post($shipment_id);
            if (!$post || 'fedex_shipping' !== $post->post_type) {
                wp_send_json_error(['error' => 'invalid_shipment'], 400);
            }
            $tracking = sanitize_text_field((string) get_post_meta($shipment_id, '_tracking_number', true));
            $order_id = (int) get_post_meta($shipment_id, '_fedex_shipment_order_id', true);
            $meta_target_id = $shipment_id;
            $order = $order_id > 0 && function_exists('wc_get_order') ? wc_get_order($order_id) : null;
        } else {
            $order_id = $openship_order_id;
            $order = $order_id > 0 && function_exists('wc_get_order') ? wc_get_order($order_id) : null;
            if (!$order || !\FSHIPPING\OpenShip\Draft::is_advanced_order($order)) {
                wp_send_json_error(['error' => 'invalid_openship_order'], 400);
            }
            $tracking = sanitize_text_field((string) $order->get_meta('_fedex_tracking', true));
            if ($tracking === '') {
                $tracking = sanitize_text_field((string) $order->get_meta(\FSHIPPING\OpenShip\Draft::META_SHIPMENT_ID_INDEX, true));
            }
            if ($tracking === '') {
                $tracking = sanitize_text_field((string) $order->get_meta(\FSHIPPING\OpenShip\Draft::META_SHIPMENT_INDEX, true));
            }
            $meta_target_id = $order_id;
        }

        if ('' === $tracking) {
            wp_send_json_error(['error' => 'missing_tracking_number'], 400);
        }
        $dest_country = '';
        if ($order) {
            $dest_country = (string) ($order->get_shipping_country() ?: $order->get_billing_country());
        }
        $settings = get_option('fshipping_options');
        $origin_country = sanitize_text_field((string) ($settings['fshipping_country_code'] ?? 'US'));
        $normalize_country_code = static function (string $code): string {
            $code = strtoupper(trim($code));
            if ($code === 'UK') {
                return 'GB';
            }
            if (preg_match('/^[A-Z]{2}$/', $code)) {
                return $code;
            }
            return '';
        };
        $normalize_location_code = static function (string $code): string {
            $code = strtoupper(trim($code));
            if (preg_match('/^[A-Z0-9]{2,12}$/', $code)) {
                return $code;
            }
            return '';
        };
        $normalize_shipment_datetime = static function (string $value): string {
            $value = trim($value);
            if ($value === '') {
                return '';
            }
            $value = str_replace(' ', 'T', $value);
            // HTML datetime-local gives YYYY-MM-DDTHH:MM ; FedEx expects seconds.
            if (preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $value)) {
                return $value . ':00';
            }
            if (preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/', $value)) {
                return $value;
            }
            return '';
        };
        $origin_country_input = isset($_POST['origin_country']) ? sanitize_text_field((string) wp_unslash($_POST['origin_country'])) : '';
        if ('' !== $origin_country_input) {
            $origin_country = $normalize_country_code($origin_country_input);
        }
        $dest_country_input = isset($_POST['destination_country']) ? sanitize_text_field((string) wp_unslash($_POST['destination_country'])) : '';
        if ('' !== $dest_country_input) {
            $dest_country = $normalize_country_code($dest_country_input);
        }
        $origin_country = $normalize_country_code($origin_country);
        $dest_country = $normalize_country_code($dest_country);
        $shipment_date = sanitize_text_field((string) get_post_meta($meta_target_id, '_ship_date', true));
        if ('' === $shipment_date) {
            $shipment_date = current_time('Y-m-d\TH:i:s');
        }

        $mode = isset($_POST['upload_mode']) ? sanitize_text_field((string) wp_unslash($_POST['upload_mode'])) : 'documents';
        $workflow_name = isset($_POST['workflow_name']) ? sanitize_text_field((string) wp_unslash($_POST['workflow_name'])) : 'ETDPostShipment';
        $carrier_code = isset($_POST['carrier_code']) ? sanitize_text_field((string) wp_unslash($_POST['carrier_code'])) : 'FDXE';
        $tracking_input = isset($_POST['tracking_number']) ? sanitize_text_field((string) wp_unslash($_POST['tracking_number'])) : '';
        if ('' !== $tracking_input) {
            $tracking = $tracking_input;
        }
        $shipment_date_input = isset($_POST['shipment_date']) ? sanitize_text_field((string) wp_unslash($_POST['shipment_date'])) : '';
        if ('' !== $shipment_date_input) {
            $normalized_date = $normalize_shipment_datetime($shipment_date_input);
            if ($normalized_date !== '') {
                $shipment_date = $normalized_date;
            }
        }
        $origin_location_code = isset($_POST['origin_location_code']) ? sanitize_text_field((string) wp_unslash($_POST['origin_location_code'])) : '';
        $destination_location_code = isset($_POST['destination_location_code']) ? sanitize_text_field((string) wp_unslash($_POST['destination_location_code'])) : '';
        $origin_location_code = $normalize_location_code($origin_location_code);
        $destination_location_code = $normalize_location_code($destination_location_code);
        $form_code = isset($_POST['form_code']) ? sanitize_text_field((string) wp_unslash($_POST['form_code'])) : '';

        $doc_types = !empty($_POST['doc_types']) && is_array($_POST['doc_types'])
            ? array_values(array_map('sanitize_text_field', wp_unslash($_POST['doc_types'])))
            : [];
        $descriptions = !empty($_POST['doc_descriptions']) && is_array($_POST['doc_descriptions'])
            ? array_values(array_map('sanitize_text_field', wp_unslash($_POST['doc_descriptions'])))
            : [];

        if (!function_exists('wp_handle_upload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }

        $allowed_types = [
            'COMMERCIAL_INVOICE',
            'CERTIFICATE_OF_ORIGIN',
            'ETD_LABEL',
            'USMCA_CERTIFICATION_OF_ORIGIN',
            'USMCA_COMMERCIAL_INVOICE_CERTIFICATION_OF_ORIGIN',
            'OTHER',
            'PRO_FORMA_INVOICE',
        ];
        $upload_mimes = [
            'pdf'  => 'application/pdf',
            'txt'  => 'text/plain',
            'png'  => 'image/png',
            'jpg'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'gif'  => 'image/gif',
            'bmp'  => 'image/bmp',
            'tif'  => 'image/tiff',
            'tiff' => 'image/tiff',
            'rtf'  => 'application/rtf',
            'doc'  => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls'  => 'application/vnd.ms-excel',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ];

        if ('' === $origin_country || '' === $dest_country) {
            wp_send_json_error([
                'error'   => 'invalid_country_code',
                'message' => __('Origin and destination country codes must be valid ISO-2 values (example: US, GB, IN).', 'teamzlab-fedex'),
            ], 400);
        }

        $shared_meta = [
            'shipment_id'              => $tracking,
            'origin_country'           => $origin_country,
            'destination_country'      => sanitize_text_field($dest_country),
            'workflow_name'            => $workflow_name,
            'tracking_number'          => $tracking,
            'shipment_date'            => $shipment_date,
            'carrier_code'             => $carrier_code,
            'origin_location_code'     => $origin_location_code,
            'destination_location_code'=> $destination_location_code,
            'form_code'                => $form_code,
        ];

        $upload = [];
        $temp_paths = [];
        if ('encoded' === $mode) {
            wp_send_json_error([
                'error'   => 'encoded_mode_disabled',
                'message' => __('Encoded document upload mode is disabled in this build. Use Upload Documents or Upload Images.', 'teamzlab-fedex'),
            ], 400);
        } elseif ('documents' !== $mode && 'images' !== $mode) {
            wp_send_json_error([
                'error'   => 'invalid_upload_mode',
                'message' => __('Invalid trade document upload mode.', 'teamzlab-fedex'),
            ], 400);
        } else {
            if (empty($_FILES['trade_doc_files'])) {
                wp_send_json_error(['error' => 'missing_files'], 400);
            }
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Raw $_FILES structure is only handed to wp_handle_upload(), which validates type, size and uploaded-file status; tmp_name is a filesystem path that must not be text-sanitized.
            $files = $_FILES['trade_doc_files'];
            $documents = [];
            $count = is_array($files['name'] ?? null) ? count($files['name']) : 0;
            $image_types = !empty($_POST['image_types']) && is_array($_POST['image_types'])
                ? array_values(array_map('sanitize_text_field', wp_unslash($_POST['image_types'])))
                : [];
            for ($i = 0; $i < $count && count($documents) < 5; $i++) {
                $name = (string) ($files['name'][$i] ?? '');
                $tmp_name = (string) ($files['tmp_name'][$i] ?? '');
                if ($name === '' || $tmp_name === '') {
                    continue;
                }
                $single = [
                    'name'     => $name,
                    'type'     => (string) ($files['type'][$i] ?? ''),
                    'tmp_name' => $tmp_name,
                    'error'    => (int) ($files['error'][$i] ?? 0),
                    'size'     => (int) ($files['size'][$i] ?? 0),
                ];
                $upload_file = wp_handle_upload($single, [
                    'test_form' => false,
                    'mimes'     => $upload_mimes,
                ]);
                if (empty($upload_file['file'])) {
                    continue;
                }
                $temp_paths[] = (string) $upload_file['file'];
                $type = strtoupper((string) ($doc_types[$i] ?? 'COMMERCIAL_INVOICE'));
                if (!in_array($type, $allowed_types, true)) {
                    $type = 'OTHER';
                }
                $documents[] = [
                    'path'        => (string) $upload_file['file'],
                    'name'        => basename((string) $upload_file['file']),
                    'content_type'=> sanitize_text_field((string) ($upload_file['type'] ?? 'application/octet-stream')),
                    'type'        => $type,
                    'description' => (string) ($descriptions[$i] ?? ''),
                    'image_type'  => (string) ($image_types[$i] ?? 'LETTER_HEAD'),
                ];
            }
            if (empty($documents)) {
                wp_send_json_error(['error' => 'no_valid_documents'], 400);
            }
            if ('images' === $mode) {
                $upload = HTTP\TradeDocuments::instance()->upload_images($documents, $shared_meta);
            } else {
                $upload = HTTP\TradeDocuments::instance()->upload_documents($documents, $shared_meta, false);
            }
        }

        foreach ($temp_paths as $temp_path) {
            if (is_string($temp_path) && $temp_path !== '' && file_exists($temp_path)) {
                wp_delete_file($temp_path);
            }
        }

        $meta_rows = is_array($upload['meta'] ?? null) ? $upload['meta'] : [];
        $uploaded_rows = [];
        foreach ($meta_rows as $idx => $row) {
            $doc_id = sanitize_text_field((string) ($row['docId'] ?? $row['uploadedDocumentId'] ?? ''));
            if ($doc_id === '') {
                continue;
            }
            $uploaded_rows[] = [
                'id'          => $doc_id,
                'type'        => (string) ($documents[$idx]['type'] ?? 'OTHER'),
                'description' => (string) ($documents[$idx]['description'] ?? ''),
                'folder_id'   => sanitize_text_field((string) ($row['folderId'] ?? '')),
                'document_type' => sanitize_text_field((string) ($row['documentType'] ?? '')),
                'uploaded_at' => current_time('mysql', true),
                'user_id'     => get_current_user_id(),
            ];
        }

        if (empty($uploaded_rows)) {
            $fedex_error = method_exists(HTTP\TradeDocuments::instance(), 'get_last_error_message')
                ? sanitize_text_field((string) HTTP\TradeDocuments::instance()->get_last_error_message())
                : '';
            $message = '' !== $fedex_error
                ? sprintf(
                    /* translators: %s: FedEx error message. */
                    __('FedEx Trade Documents upload failed: %s', 'teamzlab-fedex'),
                    $fedex_error
                )
                : __('FedEx Trade Documents upload did not return document IDs.', 'teamzlab-fedex');
            OrderMeta::update($meta_target_id, '_fshipping_trade_doc_last_error', $message);
            if ($order && method_exists($order, 'add_order_note')) {
                $order->add_order_note($message, false);
            }
            wp_send_json_error([
                'error'   => 'no_uploaded_document_ids',
                'message' => $message,
            ], 502);
        }

        $existing = OrderMeta::get($meta_target_id, '_fshipping_trade_doc_upload_ids');
        if (is_string($existing)) {
            $decoded = json_decode($existing, true);
            $existing = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($existing)) {
            $existing = [];
        }
        $merged = array_merge($existing, $uploaded_rows);
        OrderMeta::update($meta_target_id, '_fshipping_trade_doc_upload_ids', wp_json_encode($merged));
        OrderMeta::delete($meta_target_id, '_fshipping_trade_doc_last_error');

        if ($order && method_exists($order, 'add_order_note')) {
            $order->add_order_note(
                sprintf(
                    /* translators: 1: count, 2: tracking number */
                    __('FedEx ETD post-shipment upload succeeded: %1$d document(s) linked to tracking %2$s.', 'teamzlab-fedex'),
                    count($uploaded_rows),
                    $tracking
                ),
                false
            );
        }

        wp_send_json_success([
            'shipment_id' => $shipment_id,
            'openship_order_id' => $openship_order_id,
            'tracking'    => $tracking,
            'uploads'     => $uploaded_rows,
        ]);
    }

    /**
     * AJAX: validate and classify an address.
     *
     * Input (POST): street_lines, city, state, postal_code, country.
     * Output: FedEx resolvedAddress[0] with classification so the UI can
     * surface "this looks residential — expect a surcharge" before the
     * rate call.
     *
     * @return void
     * @since 1.1
     */
    public function validate_address() {
        check_ajax_referer('fshipping_nonce', 'nonce');

        // Throttle anonymous Address Validation API spend per IP (SEC-05).
        if (!RateLimiter::check('addr_validate')) {
            wp_send_json_error(array('error' => 'rate_limited'), 429);
        }

        try {
            $address = AddressNormalizer::normalize_for_fedex($this->build_checkout_address_from_request());
            $street_check = '';
            if (isset($address['street_lines'])) {
                $street_check = is_array($address['street_lines'])
                    ? trim(implode(' ', $address['street_lines']))
                    : trim((string) $address['street_lines']);
            }

            $contact = [
                'first_name' => isset($_POST['first_name']) ? sanitize_text_field(wp_unslash($_POST['first_name'])) : '',
                'last_name'  => isset($_POST['last_name'])  ? sanitize_text_field(wp_unslash($_POST['last_name']))  : '',
                'email'      => isset($_POST['email'])      ? sanitize_email(wp_unslash($_POST['email']))            : '',
                'phone'      => isset($_POST['phone'])      ? sanitize_text_field(wp_unslash($_POST['phone']))       : '',
            ];
            $strict = !empty($_POST['strict']) && in_array(strtolower((string) wp_unslash($_POST['strict'])), ['1', 'true', 'yes', 'on'], true);
            $address_started = (
                '' !== $street_check ||
                '' !== (string) $address['city'] ||
                '' !== (string) $address['state'] ||
                '' !== (string) $address['postal_code']
            );
            $contact_started = (
                '' !== $contact['first_name'] ||
                '' !== $contact['last_name'] ||
                '' !== $contact['email'] ||
                '' !== $contact['phone']
            );

            $field_errors = [];
            if (($strict || $contact_started) && '' === $contact['first_name']) {
                $field_errors['first_name'] = __('First name is required.', 'teamzlab-fedex');
            }
            if (($strict || $contact_started) && '' === $contact['last_name']) {
                $field_errors['last_name'] = __('Last name is required.', 'teamzlab-fedex');
            }
            if (($strict || $contact_started) && ('' === $contact['email'] || !is_email($contact['email']))) {
                $field_errors['email'] = __('Please enter a valid email address.', 'teamzlab-fedex');
            }
            if (($strict || $contact_started) && '' === $contact['phone']) {
                $field_errors['phone'] = __('Phone number is required.', 'teamzlab-fedex');
            } elseif ('' !== $contact['phone']) {
                $digits = preg_replace('/\D+/', '', $contact['phone']);
                if (strlen((string) $digits) < 7) {
                    $field_errors['phone'] = __('Please enter a valid phone number.', 'teamzlab-fedex');
                }
            }

            if (($strict || $address_started) && '' === $street_check) {
                $field_errors['street_lines'] = __('Street address is required.', 'teamzlab-fedex');
            }
            if (($strict || $address_started) && '' === $address['city']) {
                $field_errors['city'] = __('City is required.', 'teamzlab-fedex');
            }
            if (($strict || $address_started) && '' === $address['postal_code']) {
                $field_errors['postal_code'] = __('ZIP / postal code is required.', 'teamzlab-fedex');
            }
            if (($strict || $address_started) && '' === $address['country']) {
                $field_errors['country'] = __('Country is required.', 'teamzlab-fedex');
            }
            $country = strtoupper((string) $address['country']);
            if (($strict || $address_started) && in_array($country, ['US', 'CA'], true) && '' === $address['state']) {
                $field_errors['state'] = __('State / province is required for this country.', 'teamzlab-fedex');
            }

            $resolved = HTTP\AddressValidation::instance()->validate([$address]);
            $first    = !empty($resolved[0]) ? $resolved[0] : [];
            $classification = !empty($first['classification']) ? sanitize_text_field($first['classification']) : 'UNKNOWN';

            $is_valid = empty($field_errors);

            wp_send_json_success([
                'classification' => $classification,
                'resolved'       => $first,
                'postal'         => [],
                'postal_valid'   => false,
                'postal_warning' => '',
                'field_errors'   => $field_errors,
                'valid'          => $is_valid,
            ]);
        } catch (\Throwable $e) {
            wp_send_json_success([
                'classification' => 'UNKNOWN',
                'resolved'       => [],
                'postal'         => [],
                'postal_valid'   => false,
                'postal_warning' => '',
                'field_errors'   => [
                    'postal_code' => __('Validation service is temporarily unavailable. Please review address details and try again.', 'teamzlab-fedex'),
                ],
                'valid'          => false,
                'server_error'   => true,
            ]);
        }
    }

    /**
     * AJAX: validate postal/ZIP code only.
     *
     * Kept separate from address classification so checkout can run both calls
     * in parallel and render independent loading states.
     *
     * @return void
     * @since 1.2
     */
    public function validate_postal_code() {
        check_ajax_referer('fshipping_nonce', 'nonce');

        // Throttle anonymous Postal Code Validation API spend per IP (SEC-05).
        if (!RateLimiter::check('postal_validate')) {
            wp_send_json_error(array('error' => 'rate_limited'), 429);
        }

        try {
            $address = AddressNormalizer::normalize_for_fedex($this->build_checkout_address_from_request());
            $strict = !empty($_POST['strict']) && in_array(strtolower((string) wp_unslash($_POST['strict'])), ['1', 'true', 'yes', 'on'], true);
            $postal_started = (
                '' !== (string) $address['postal_code'] ||
                '' !== (string) $address['country'] ||
                '' !== (string) $address['state']
            );

            $field_errors = [];
            $country = strtoupper((string) $address['country']);
            if (($strict || $postal_started) && '' === (string) $address['postal_code']) {
                $field_errors['postal_code'] = __('ZIP / postal code is required.', 'teamzlab-fedex');
            }
            if (($strict || $postal_started) && '' === (string) $address['country']) {
                $field_errors['country'] = __('Country is required.', 'teamzlab-fedex');
            }
            if (($strict || $postal_started) && in_array($country, ['US', 'CA'], true) && '' === (string) $address['state']) {
                $field_errors['state'] = __('State / province is required for this country.', 'teamzlab-fedex');
            }
            if (($strict || $postal_started) && !isset($field_errors['postal_code']) && !isset($field_errors['country'])) {
                $formatted_postal = (string) $address['postal_code'];
                if (function_exists('wc_format_postcode')) {
                    $formatted_postal = wc_format_postcode($formatted_postal, $country);
                }
                if (class_exists('\WC_Validation') && method_exists('\WC_Validation', 'is_postcode')) {
                    if (!\WC_Validation::is_postcode($formatted_postal, $country)) {
                        $field_errors['postal_code'] = __('ZIP / postal code format is invalid for the selected country.', 'teamzlab-fedex');
                    }
                }
            }

            $postal_result = [];
            $postal_valid = false;
            $postal_warning = '';
            $postal_unknown = false;
            if (!isset($field_errors['postal_code']) && !isset($field_errors['country'])) {
                try {
                    $postal_client = class_exists('\FSHIPPING\HTTP\PostalCodeValidation')
                        ? new HTTP\PostalCodeValidation()
                        : null;
                    if ($postal_client && method_exists($postal_client, 'validate')) {
                        $postal_result = $postal_client->validate(
                            (string) $address['postal_code'],
                            (string) $address['country'],
                            ['state' => (string) $address['state']]
                        );

                        // Only hard-fail when FedEx explicitly reports an error.
                        if (!empty($postal_result['errors'])) {
                            $field_errors['postal_code'] = __('ZIP / postal code could not be validated for the selected country/state.', 'teamzlab-fedex');
                        } elseif (!empty($postal_result)) {
                            $postal_valid = true;
                        } else {
                            $postal_unknown = true;
                        }
                    }
                } catch (\Throwable $postal_error) {
                    $postal_warning = __('Postal validation service is temporarily unavailable.', 'teamzlab-fedex');
                }
            }

            wp_send_json_success([
                'postal'         => $postal_result,
                'postal_valid'   => $postal_valid,
                'postal_warning' => $postal_warning,
                'postal_unknown' => $postal_unknown,
                'field_errors'   => $field_errors,
                'valid'          => empty($field_errors),
            ]);
        } catch (\Throwable $e) {
            wp_send_json_success([
                'postal'         => [],
                'postal_valid'   => false,
                'postal_warning' => '',
                'postal_unknown' => false,
                'field_errors'   => [
                    'postal_code' => __('Validation service is temporarily unavailable. Please review address details and try again.', 'teamzlab-fedex'),
                ],
                'valid'          => false,
                'server_error'   => true,
            ]);
        }
    }

    /**
     * Normalize checkout address payload from request.
     *
     * @return array{street_lines:string,city:string,state:string,postal_code:string,country:string}
     */
    private function build_checkout_address_from_request(): array {
        check_ajax_referer('fshipping_nonce', 'nonce');
        return [
            'street_lines' => isset($_POST['street_lines']) ? sanitize_text_field(wp_unslash($_POST['street_lines'])) : '',
            'city'         => isset($_POST['city'])        ? sanitize_text_field(wp_unslash($_POST['city']))        : '',
            'state'        => isset($_POST['state'])       ? sanitize_text_field(wp_unslash($_POST['state']))       : '',
            'postal_code'  => isset($_POST['postal_code']) ? sanitize_text_field(wp_unslash($_POST['postal_code'])) : '',
            'country'      => isset($_POST['country'])     ? sanitize_text_field(wp_unslash($_POST['country']))     : 'US',
        ];
    }

    /**
     * AJAX: schedule a FedEx pickup for a shipment.
     *
     * Requires manage_options and the fshipping_nonce. Payload is minimal;
     * origin comes from settings. Post-meta on the shipment CPT row stores
     * the returned pickup confirmation code.
     *
     * @return void
     * @since 1.1
     */
    public function request_pickup() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['error' => 'forbidden'], 403);
        }
        check_ajax_referer('fshipping_nonce', 'nonce');

        $shipment_id = !empty($_POST['shipment_id']) ? (int) $_POST['shipment_id'] : 0;
        if (empty($shipment_id)) {
            wp_send_json_error(['error' => 'missing_shipment_id'], 400);
        }

        $pickup_date = !empty($_POST['pickup_date'])
            ? sanitize_text_field(wp_unslash($_POST['pickup_date']))
            : '';
        $ready_datetime = !empty($_POST['ready_datetime'])
            ? sanitize_text_field(wp_unslash($_POST['ready_datetime']))
            : $this->next_business_ready_datetime($pickup_date);
        $carrier_code = !empty($_POST['carrier_code'])
            ? sanitize_text_field(wp_unslash($_POST['carrier_code']))
            : 'FDXE';

        $result = HTTP\Pickup::instance()->create_pickup([
            'ready_datetime' => $ready_datetime,
            'package_count'  => 1,
            'weight'         => 5,
            'carrier_code'   => $carrier_code,
            'remarks'        => sprintf(
                /* translators: %d: shipment post ID. */
                __('WooCommerce shipment %d pickup', 'teamzlab-fedex'),
                $shipment_id
            ),
        ]);
        if (empty($result)) {
            $fedex_error = HTTP\Pickup::instance()->get_last_error_message();
            wp_send_json_error([
                'error'       => 'pickup_failed',
                'fedex_error' => $fedex_error,
            ], 502);
        }

        $confirmation = !empty($result['pickupConfirmationCode']) ? sanitize_text_field($result['pickupConfirmationCode']) : '';
        if (!empty($confirmation)) {
            $location = $this->extract_pickup_location($result);
            $carrier_from_result = $this->extract_pickup_carrier($result);
            update_post_meta($shipment_id, '_fshipping_pickup_confirmation', $confirmation);
            update_post_meta($shipment_id, '_fshipping_pickup_ready',        $ready_datetime);
            update_post_meta($shipment_id, '_fshipping_pickup_carrier',      $carrier_from_result !== '' ? $carrier_from_result : $carrier_code);
            update_post_meta($shipment_id, '_fshipping_pickup_scope',        'single');
            update_post_meta($shipment_id, '_fshipping_pickup_group_ref',    $confirmation);
            update_post_meta($shipment_id, '_fshipping_pickup_group_size',   1);
            update_post_meta($shipment_id, '_fshipping_pickup_output',       wp_json_encode($result));
            if ('' !== $location) {
                update_post_meta($shipment_id, '_fshipping_pickup_location', $location);
            }

            $this->record_pickup_history([
                'confirmation' => $confirmation,
                'scope'        => 'single',
                'shipment_ids' => [$shipment_id],
                'ready'        => $ready_datetime,
                'carrier_code' => $carrier_from_result !== '' ? $carrier_from_result : $carrier_code,
                'weight'       => (float) 5,
                'weight_unit'  => $this->pickup_weight_unit(),
                'output'       => $result,
                'status'       => 'scheduled',
                'location'     => $location,
            ]);
        }
        wp_send_json_success(['confirmation' => $confirmation, 'output' => $result]);
    }

    /**
     * AJAX: list all shipments ready for consolidated pickup.
     *
     * @return void
     */
    public function get_ready_pickups() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['error' => 'forbidden'], 403);
        }
        check_ajax_referer('fshipping_nonce', 'nonce');

        $eligibility = [];
        $shipments = $this->collect_ready_pickup_shipments([], $eligibility);
        $weight_unit = $this->pickup_weight_unit();
        $total_weight = 0.0;
        foreach ($shipments as $shipment) {
            $total_weight += (float) ($shipment['weight'] ?? 0);
        }

        wp_send_json_success([
            'shipments'    => $shipments,
            'count'        => count($shipments),
            'weight'       => round(max(1.0, $total_weight), 2),
            'weight_unit'  => $weight_unit,
        ]);
    }

    /**
     * AJAX: schedule one pickup request for many ready shipments.
     *
     * @return void
     */
    public function request_pickup_batch() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['error' => 'forbidden'], 403);
        }
        check_ajax_referer('fshipping_nonce', 'nonce');

        $shipment_ids = [];
        if (!empty($_POST['shipment_ids']) && is_array($_POST['shipment_ids'])) {
            $shipment_ids = array_values(array_unique(array_map('intval', wp_unslash($_POST['shipment_ids']))));
        }

        $eligibility = [];
        $shipments = $this->collect_ready_pickup_shipments($shipment_ids, $eligibility);
        if (empty($shipments)) {
            wp_send_json_error(['error' => 'no_ready_shipments'], 400);
        }

        $pickup_date = !empty($_POST['pickup_date'])
            ? sanitize_text_field(wp_unslash($_POST['pickup_date']))
            : '';
        $ready_datetime = !empty($_POST['ready_datetime'])
            ? sanitize_text_field(wp_unslash($_POST['ready_datetime']))
            : $this->next_business_ready_datetime($pickup_date);
        $carrier_code = !empty($_POST['carrier_code'])
            ? sanitize_text_field(wp_unslash($_POST['carrier_code']))
            : 'FDXE';

        $weight_unit = $this->pickup_weight_unit();
        $total_weight = 0.0;
        $shipment_id_list = [];
        foreach ($shipments as $shipment) {
            $total_weight += (float) ($shipment['weight'] ?? 0);
            $shipment_id_list[] = (int) ($shipment['shipment_id'] ?? 0);
        }
        $total_weight = round(max(1.0, $total_weight), 2);

        $pickup_args = [
            'ready_datetime' => $ready_datetime,
            'package_count'  => count($shipments),
            'weight'         => $total_weight,
            'weight_unit'    => $weight_unit,
            'carrier_code'   => $carrier_code,
            'remarks'        => sprintf(
                /* translators: %d: number of shipments. */
                __('WooCommerce consolidated pickup (%d shipments)', 'teamzlab-fedex'),
                count($shipments)
            ),
        ];

        $result = HTTP\Pickup::instance()->create_pickup($pickup_args);
        if (empty($result)) {
            wp_send_json_error([
                'error'       => 'pickup_failed',
                'fedex_error' => HTTP\Pickup::instance()->get_last_error_message(),
            ], 502);
        }

        $confirmation = !empty($result['pickupConfirmationCode']) ? sanitize_text_field($result['pickupConfirmationCode']) : '';
        if ('' === $confirmation) {
            wp_send_json_error([
                'error'       => 'pickup_missing_confirmation',
                'fedex_error' => __('FedEx pickup response did not include a confirmation code.', 'teamzlab-fedex'),
            ], 502);
        }

        $location = $this->extract_pickup_location($result);
        $carrier_from_result = $this->extract_pickup_carrier($result);
        $effective_carrier = $carrier_from_result !== '' ? $carrier_from_result : $carrier_code;

        foreach ($shipment_id_list as $shipment_id) {
            if ($shipment_id <= 0) {
                continue;
            }
            update_post_meta($shipment_id, '_fshipping_pickup_confirmation', $confirmation);
            update_post_meta($shipment_id, '_fshipping_pickup_ready',        $ready_datetime);
            update_post_meta($shipment_id, '_fshipping_pickup_carrier',      $effective_carrier);
            update_post_meta($shipment_id, '_fshipping_pickup_scope',        'batch');
            update_post_meta($shipment_id, '_fshipping_pickup_group_ref',    $confirmation);
            update_post_meta($shipment_id, '_fshipping_pickup_group_size',   count($shipment_id_list));
            update_post_meta($shipment_id, '_fshipping_pickup_output',       wp_json_encode($result));
            if ('' !== $location) {
                update_post_meta($shipment_id, '_fshipping_pickup_location', $location);
            }
        }

        $this->record_pickup_history([
            'confirmation' => $confirmation,
            'scope'        => 'batch',
            'shipment_ids' => $shipment_id_list,
            'ready'        => $ready_datetime,
            'carrier_code' => $effective_carrier,
            'weight'       => (float) $total_weight,
            'weight_unit'  => $weight_unit,
            'output'       => $result,
            'status'       => 'scheduled',
            'location'     => $location,
        ]);

        wp_send_json_success([
            'confirmation' => $confirmation,
            'shipment_ids' => $shipment_id_list,
            'count'        => count($shipment_id_list),
            'weight'       => $total_weight,
            'weight_unit'  => $weight_unit,
            'carrier_code' => $effective_carrier,
            'output'       => $result,
        ]);
    }

    /**
     * Next pickup-ready datetime on a business day (Mon-Fri, 10:00 local).
     *
     * @return string
     */
    private function next_business_ready_datetime(string $pickup_date = '') {
        $pickup_date = sanitize_text_field($pickup_date);
        $tz = function_exists('wp_timezone') ? wp_timezone() : new \DateTimeZone('UTC');
        $now = new \DateTimeImmutable('now', $tz);

        $target = null;
        if ('' !== $pickup_date) {
            $parsed = \DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $pickup_date . ' 10:00:00', $tz);
            if ($parsed instanceof \DateTimeImmutable) {
                $target = $parsed;
            }
        }

        if (!$target) {
            $target = $now->modify('+1 day')->setTime(10, 0, 0);
        }

        // FedEx requires the ready time to be at least two hours from now;
        // roll a too-soon target to the next day's 10:00 slot.
        if ($target < $now->modify('+2 hours')) {
            $target = $now->modify('+1 day')->setTime(10, 0, 0);
        }

        // FedEx pickup windows are typically near-term; cap to a safe horizon.
        $max_days_ahead = (int) apply_filters('fshipping_pickup_max_days_ahead', 2);
        if ($max_days_ahead < 0) {
            $max_days_ahead = 2;
        }
        $max_date = $now->setTime(10, 0, 0)->modify('+' . $max_days_ahead . ' day');
        if ($target > $max_date && $max_date >= $now->modify('+2 hours')) {
            $target = $max_date;
        }

        // Skip weekends because FedEx pickup API rejects non-working days.
        while (in_array((int) $target->format('N'), [6, 7], true)) {
            $target = $target->modify('+1 day')->setTime(10, 0, 0);
        }

        // FedEx pickup create requires an ISO 8601 timestamp that carries the
        // UTC offset (e.g. 2026-10-22T10:00:00-05:00); naive local strings are
        // rejected as "missing or invalid".
        return $target->format('c');
    }

    /**
     * AJAX: cancel a previously scheduled pickup.
     *
     * @return void
     * @since 1.1
     */
    public function cancel_pickup() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['error' => 'forbidden'], 403);
        }
        check_ajax_referer('fshipping_nonce', 'nonce');

        $shipment_id = !empty($_POST['shipment_id']) ? (int) $_POST['shipment_id'] : 0;
        if (empty($shipment_id)) {
            wp_send_json_error(['error' => 'missing_shipment_id'], 400);
        }

        $confirmation = get_post_meta($shipment_id, '_fshipping_pickup_confirmation', true);
        if (empty($confirmation)) {
            wp_send_json_error(['error' => 'no_pickup_on_record'], 404);
        }

        $extra = $this->build_pickup_cancel_extra_from_shipment_id($shipment_id);

        $ok = HTTP\Pickup::instance()->cancel_pickup($confirmation, $extra);
        if ($ok) {
            $linked_shipments = $this->get_shipment_ids_by_pickup_confirmation($confirmation);
            if (empty($linked_shipments)) {
                $linked_shipments = [$shipment_id];
            }
            $this->complete_pickup_after_fedex_cancel($confirmation, '', $linked_shipments);
            wp_send_json_success(['shipment_ids' => array_map('intval', $linked_shipments)]);
        }
        wp_send_json_error([
            'error'       => 'cancel_failed',
            'fedex_error' => HTTP\Pickup::instance()->get_last_error_message(),
        ], 502);
    }

    /**
     * AJAX: cancel pickup from Pickup History (by confirmation + optional history row id).
     *
     * FedEx expects pickup confirmation code; scheduled date, carrier, and location
     * help the cancel call succeed and are merged with retrieve() inside HTTP\Pickup.
     *
     * @return void
     */
    public function cancel_pickup_by_confirmation() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['error' => 'forbidden'], 403);
        }
        check_ajax_referer('fshipping_nonce', 'nonce');

        $confirmation = !empty($_POST['confirmation']) ? sanitize_text_field(wp_unslash($_POST['confirmation'])) : '';
        if ('' === $confirmation) {
            wp_send_json_error(['error' => 'missing_confirmation'], 400);
        }

        $history_id = !empty($_POST['history_id']) ? sanitize_text_field(wp_unslash($_POST['history_id'])) : '';

        $row = $this->find_pickup_history_row($confirmation, $history_id, false);
        if ($row && 'canceled' === strtolower((string) ($row['status'] ?? ''))) {
            wp_send_json_error(['error' => 'already_canceled'], 400);
        }

        $extra = $this->resolve_pickup_cancel_extra_for_confirmation($confirmation, $history_id);

        $ok = HTTP\Pickup::instance()->cancel_pickup($confirmation, $extra);
        if ($ok) {
            $linked_shipments = $this->get_shipment_ids_by_pickup_confirmation($confirmation);
            $this->complete_pickup_after_fedex_cancel($confirmation, $history_id, $linked_shipments);
            wp_send_json_success(['shipment_ids' => array_map('intval', $linked_shipments)]);
        }
        wp_send_json_error([
            'error'       => 'cancel_failed',
            'fedex_error' => HTTP\Pickup::instance()->get_last_error_message(),
        ], 502);
    }

    /**
     * @param string $confirmation
     * @param string $history_id
     * @param array  $linked_shipments
     * @return void
     */
    private function complete_pickup_after_fedex_cancel($confirmation, $history_id, array $linked_shipments) {
        $this->mark_pickup_history_canceled($confirmation, $history_id);
        $this->clear_pickup_meta($linked_shipments);
    }

    /**
     * @param string $confirmation
     * @return array<int>
     */
    private function get_shipment_ids_by_pickup_confirmation($confirmation) {
        $confirmation = sanitize_text_field((string) $confirmation);
        if ('' === $confirmation) {
            return [];
        }
        $ids = get_posts([
            'post_type'      => 'fedex_shipping',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Exact-match lookup on this plugin's fedex_shipping CPT by _fshipping_pickup_confirmation so cancelling a pickup clears every shipment on it; ID-only fetch, intentionally unbounded.
            'meta_query'     => [[
                'key'   => '_fshipping_pickup_confirmation',
                'value' => $confirmation,
            ]],
        ]);
        return array_map('intval', is_array($ids) ? $ids : []);
    }

    /**
     * Build cancel payload fields from a shipment CPT row.
     *
     * @param int $shipment_id
     * @return array{scheduled_date:string,location:string,carrier_code:string}
     */
    private function build_pickup_cancel_extra_from_shipment_id($shipment_id) {
        $shipment_id = (int) $shipment_id;
        $scheduled_date = '';
        $ready_datetime = (string) get_post_meta($shipment_id, '_fshipping_pickup_ready', true);
        if ('' !== $ready_datetime) {
            $ts = strtotime($ready_datetime);
            if (false !== $ts) {
                $scheduled_date = gmdate('Y-m-d', $ts);
            }
        }

        $location = (string) get_post_meta($shipment_id, '_fshipping_pickup_location', true);
        $carrier  = (string) get_post_meta($shipment_id, '_fshipping_pickup_carrier', true);
        if ('' === $location) {
            $raw_output = (string) get_post_meta($shipment_id, '_fshipping_pickup_output', true);
            $parsed     = json_decode($raw_output, true);
            if (is_array($parsed)) {
                $location = $this->extract_pickup_location($parsed);
                if ('' === $carrier) {
                    $carrier = $this->extract_pickup_carrier($parsed);
                }
            }
        }

        return [
            'scheduled_date' => $scheduled_date,
            'location'       => $location,
            'carrier_code'   => $carrier,
        ];
    }

    /**
     * Resolve FedEx cancel extras: prefer live shipment meta, else history row.
     *
     * @param string $confirmation
     * @param string $history_id
     * @return array{scheduled_date:string,location:string,carrier_code:string}
     */
    private function resolve_pickup_cancel_extra_for_confirmation($confirmation, $history_id) {
        $linked = $this->get_shipment_ids_by_pickup_confirmation($confirmation);
        if (!empty($linked[0])) {
            return $this->build_pickup_cancel_extra_from_shipment_id((int) $linked[0]);
        }

        $row = $this->find_pickup_history_row($confirmation, $history_id, '' === $history_id);
        if (!is_array($row)) {
            return [
                'scheduled_date' => '',
                'location'       => '',
                'carrier_code'   => '',
            ];
        }

        $scheduled_date = '';
        $ready = (string) ($row['ready'] ?? '');
        if ('' !== $ready) {
            $ts = strtotime($ready);
            if (false !== $ts) {
                $scheduled_date = gmdate('Y-m-d', $ts);
            }
        }

        return [
            'scheduled_date' => $scheduled_date,
            'location'       => (string) ($row['location'] ?? ''),
            'carrier_code'   => (string) ($row['carrier_code'] ?? ''),
        ];
    }

    /**
     * @param string $confirmation
     * @param string $history_id
     * @param bool   $only_scheduled When true and `$history_id` is empty, return the first scheduled row only.
     * @return array<string,mixed>|null
     */
    private function find_pickup_history_row($confirmation, $history_id, $only_scheduled = false) {
        $confirmation = sanitize_text_field((string) $confirmation);
        $history_id   = sanitize_text_field((string) $history_id);
        $history      = get_option('fshipping_pickup_history', []);
        if (!is_array($history)) {
            return null;
        }

        foreach ($history as $row) {
            if (!is_array($row)) {
                continue;
            }
            $c = sanitize_text_field((string) ($row['confirmation'] ?? ''));
            if ($c !== $confirmation) {
                continue;
            }
            if ('' !== $history_id && (string) ($row['id'] ?? '') !== $history_id) {
                continue;
            }
            if ($only_scheduled && '' === $history_id && 'scheduled' !== strtolower((string) ($row['status'] ?? ''))) {
                continue;
            }
            return $row;
        }

        return null;
    }

    /**
     * Extract location value from varied FedEx pickup create outputs.
     *
     * @param array $result
     * @return string
     */
    private function extract_pickup_location(array $result) {
        $candidates = [
            $result['location'] ?? '',
            $result['pickupLocation'] ?? '',
            $result['pickupLocationCode'] ?? '',
            $result['output']['location'] ?? '',
            $result['output']['pickupLocation'] ?? '',
            $result['output']['pickupLocationCode'] ?? '',
            $result['pickupConfirmationDetails'][0]['location'] ?? '',
            $result['pickupConfirmationDetails'][0]['pickupLocation'] ?? '',
        ];

        foreach ($candidates as $candidate) {
            $candidate = sanitize_text_field((string) $candidate);
            if ($candidate !== '') {
                return $candidate;
            }
        }

        return '';
    }

    /**
     * Extract carrier code from pickup create output when available.
     *
     * @param array $result
     * @return string
     */
    private function extract_pickup_carrier(array $result) {
        $candidates = [
            $result['carrierCode'] ?? '',
            $result['output']['carrierCode'] ?? '',
            $result['pickupConfirmationDetails'][0]['carrierCode'] ?? '',
        ];

        foreach ($candidates as $candidate) {
            $candidate = sanitize_text_field((string) $candidate);
            if ($candidate !== '') {
                return $candidate;
            }
        }

        return '';
    }

    /**
     * Fetch shipments that are eligible for pickup scheduling.
     *
     * @param array $requested_ids
     * @return array<int,array{shipment_id:int,tracking_number:string,order_id:int,service_type:string,weight:float}>
     */
    private function collect_ready_pickup_shipments(array $requested_ids = [], array &$eligibility = []) {
        $eligibility = [
            'total_candidates' => 0,
            'skipped'          => [
                'invalid_post'           => 0,
                'already_has_pickup'     => 0,
                'missing_tracking_number'=> 0,
                'canceled'               => 0,
            ],
        ];
        $shipment_ids = [];
        if (!empty($requested_ids)) {
            foreach ($requested_ids as $shipment_id) {
                if ((int) $shipment_id > 0) {
                    $shipment_ids[] = (int) $shipment_id;
                }
            }
            $shipment_ids = array_values(array_unique($shipment_ids));
        } else {
            $shipment_ids = get_posts([
                'post_type'      => 'fedex_shipping',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'fields'         => 'ids',
            ]);
        }

        $ready = [];
        $eligibility['total_candidates'] = count((array) $shipment_ids);
        foreach ($shipment_ids as $shipment_id) {
            $shipment_id = (int) $shipment_id;
            if ($shipment_id <= 0) {
                continue;
            }

            $post = get_post($shipment_id);
            if (!$post || 'fedex_shipping' !== $post->post_type) {
                $eligibility['skipped']['invalid_post']++;
                continue;
            }

            $confirmation = (string) get_post_meta($shipment_id, '_fshipping_pickup_confirmation', true);
            $tracking = (string) get_post_meta($shipment_id, '_tracking_number', true);
            $status = strtolower((string) get_post_meta($shipment_id, 'order_status', true));
            if ('' !== $confirmation) {
                $eligibility['skipped']['already_has_pickup']++;
                continue;
            }
            if ('' === $tracking) {
                $eligibility['skipped']['missing_tracking_number']++;
                continue;
            }
            if ('canceled' === $status) {
                $eligibility['skipped']['canceled']++;
                continue;
            }

            $order_id = (int) get_post_meta($shipment_id, '_fedex_shipment_order_id', true);
            $service_type = (string) get_post_meta($shipment_id, '_service_type', true);
            $weight = $this->estimate_shipment_weight($order_id);
            $ready[] = [
                'shipment_id'     => $shipment_id,
                'tracking_number' => $tracking,
                'order_id'        => $order_id,
                'service_type'    => $service_type,
                'weight'          => $weight,
            ];
        }

        return $ready;
    }

    /**
     * Estimate shipment weight from Woo order items for pickup aggregation.
     *
     * @param int $order_id
     * @return float
     */
    private function estimate_shipment_weight($order_id) {
        $order_id = (int) $order_id;
        if ($order_id <= 0 || !function_exists('wc_get_order')) {
            return 1.0;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return 1.0;
        }

        $weight = 0.0;
        foreach ($order->get_items() as $item) {
            if (!method_exists($item, 'get_product')) {
                continue;
            }
            $product = $item->get_product();
            if (!$product || !method_exists($item, 'get_quantity')) {
                continue;
            }
            $item_weight = (float) $product->get_weight();
            $qty = (int) $item->get_quantity();
            if ($item_weight > 0 && $qty > 0) {
                $weight += $item_weight * $qty;
            }
        }

        return $weight > 0 ? round($weight, 2) : 1.0;
    }

    /**
     * Resolve pickup payload weight unit from WooCommerce settings.
     *
     * @return string
     */
    private function pickup_weight_unit() {
        return strtoupper((string) get_option('woocommerce_weight_unit')) === 'KG' ? 'KG' : 'LB';
    }

    /**
     * Remove pickup-related metadata from shipment rows.
     *
     * @param array $shipment_ids
     * @return void
     */
    private function clear_pickup_meta(array $shipment_ids) {
        $keys = [
            '_fshipping_pickup_confirmation',
            '_fshipping_pickup_ready',
            '_fshipping_pickup_carrier',
            '_fshipping_pickup_location',
            '_fshipping_pickup_output',
            '_fshipping_pickup_scope',
            '_fshipping_pickup_group_ref',
            '_fshipping_pickup_group_size',
        ];

        foreach (array_map('intval', $shipment_ids) as $shipment_id) {
            if ($shipment_id <= 0) {
                continue;
            }
            foreach ($keys as $key) {
                delete_post_meta($shipment_id, $key);
            }
        }
    }

    /**
     * Persist pickup schedule records for admin history/audit.
     *
     * @param array $entry
     * @return void
     */
    private function record_pickup_history(array $entry) {
        $history = get_option('fshipping_pickup_history', []);
        if (!is_array($history)) {
            $history = [];
        }

        $shipment_ids = array_values(array_unique(array_filter(array_map('intval', (array) ($entry['shipment_ids'] ?? [])))));
        $tracking_numbers = [];
        foreach ($shipment_ids as $shipment_id) {
            $tracking = (string) get_post_meta($shipment_id, '_tracking_number', true);
            if ('' !== $tracking) {
                $tracking_numbers[] = $tracking;
            }
        }

        $record = [
            'id'               => uniqid('pickup_', true),
            'confirmation'     => sanitize_text_field((string) ($entry['confirmation'] ?? '')),
            'scope'            => sanitize_text_field((string) ($entry['scope'] ?? 'single')),
            'status'           => sanitize_text_field((string) ($entry['status'] ?? 'scheduled')),
            'created_at'       => current_time('mysql', true),
            'canceled_at'      => '',
            'shipment_ids'     => $shipment_ids,
            'tracking_numbers' => array_values(array_unique(array_map('sanitize_text_field', $tracking_numbers))),
            'shipment_count'   => count($shipment_ids),
            'ready'            => sanitize_text_field((string) ($entry['ready'] ?? '')),
            'carrier_code'     => sanitize_text_field((string) ($entry['carrier_code'] ?? '')),
            'weight'           => (float) ($entry['weight'] ?? 0),
            'weight_unit'      => sanitize_text_field((string) ($entry['weight_unit'] ?? 'LB')),
            'location'         => sanitize_text_field((string) ($entry['location'] ?? '')),
            'output'           => is_array($entry['output'] ?? null) ? $entry['output'] : [],
        ];

        array_unshift($history, $record);
        if (count($history) > 300) {
            $history = array_slice($history, 0, 300);
        }

        update_option('fshipping_pickup_history', $history, false);
    }

    /**
     * Mark a pickup history record as canceled.
     *
     * When `$history_id` is set, only that row is updated (Pickup History cancel).
     * Otherwise the first matching non-canceled row for the confirmation is updated
     * (shipment-row cancel flow).
     *
     * @param string $confirmation
     * @param string $history_id
     * @return void
     */
    private function mark_pickup_history_canceled($confirmation, $history_id = '') {
        $confirmation = sanitize_text_field((string) $confirmation);
        if ('' === $confirmation) {
            return;
        }

        $history_id = sanitize_text_field((string) $history_id);

        $history = get_option('fshipping_pickup_history', []);
        if (!is_array($history) || empty($history)) {
            return;
        }

        $updated = false;
        foreach ($history as &$record) {
            $record_confirmation = sanitize_text_field((string) ($record['confirmation'] ?? ''));
            $record_status = strtolower(sanitize_text_field((string) ($record['status'] ?? '')));
            if ($record_confirmation !== $confirmation) {
                continue;
            }
            if ('' !== $history_id && (string) ($record['id'] ?? '') !== $history_id) {
                continue;
            }
            if ('canceled' === $record_status) {
                continue;
            }
            $record['status'] = 'canceled';
            $record['canceled_at'] = current_time('mysql', true);
            $updated = true;
            break;
        }
        unset($record);

        if ($updated) {
            update_option('fshipping_pickup_history', $history, false);
        }
    }

    public function cancel_shipment() {
        check_ajax_referer('fshipping_nonce', 'nonce');

        // Voids a paid FedEx shipment and cancels orders — shop managers only.
        // The shared fshipping_nonce is printed on public pages, so capability
        // (not the nonce) is the real gate here.
        if (!current_user_can('manage_woocommerce') && !current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions.', 'teamzlab-fedex')), 403);
        }

        $tracking_id = !empty($_POST['trackingId']) ? sanitize_text_field(wp_unslash($_POST['trackingId'])): '';

        $cancel_shipment = HTTP\Shipment::instance()->cancel_shipment($tracking_id);

        if($cancel_shipment) {
            return wp_send_json_success();
        }
    }

    public function fshipping_track_shipment() {
        check_ajax_referer('fshipping_nonce', 'nonce');

        // The printed fshipping_nonce ships on every public page, so it is not
        // access control — throttle anonymous Track API spend per IP (SEC-05).
        if (!RateLimiter::check('track')) {
            wp_send_json_error(array('error' => 'rate_limited'), 429);
        }

        $tracking_id = !empty($_POST['trackingId']) ? sanitize_text_field(wp_unslash($_POST['trackingId'])): '';
        $track_shipment = HTTP\Shipment::instance()->track_shipment($tracking_id);
        $tracking_number = '';
        $status = '';
        $status_desc = '';
        $delivery_date = '';
        $carrier = '';
        $shipper_city = '';
        $recipient_city = '';

        if(empty($track_shipment) || is_wp_error($track_shipment)) {
            wp_send_json_success(array('html' => self::track_popup_error_html(
                __('Please enter valid tracking info.', 'teamzlab-fedex')
            )));
        }
        $track_results = $track_shipment['output']['completeTrackResults'][0]['trackResults'][0] ?? array();
        if (!empty($track_results['error']['message'])) {
            wp_send_json_success(array('html' => self::track_popup_error_html(
                (string) $track_results['error']['message']
            )));
        }
        if (!empty($track_results)) {

            $tracking_number = $track_results['trackingNumberInfo']['trackingNumber'] ?? '';
            $status          = $track_results['latestStatusDetail']['statusByLocale'] ?? '';
            $status_desc     = $track_results['latestStatusDetail']['description'] ?? '';
            $delivery_date   = $track_results['dateAndTimes'][0]['dateTime'] ?? '';
            $carrier         = $track_results['serviceDetail']['description'] ?? '';
            $shipper_city    = $track_results['shipperInformation']['address']['city'] ?? '';
            $recipient_city  = $track_results['recipientInformation']['address']['city'] ?? '';
        } elseif (!empty($track_shipment['errors'][0]['message'])) {
            wp_send_json_success(array('html' => self::track_popup_error_html(
                (string) $track_shipment['errors'][0]['message']
            )));
        } else {
            wp_send_json_success(array('html' => self::track_popup_error_html(
                __('Tracking details are not available right now. Please try again later.', 'teamzlab-fedex')
            )));
        }

        ob_start();
        ?>
        <div class="fshipping-tracking-card">
            <h3><?php esc_html_e('Shipment Details', 'teamzlab-fedex'); ?></h3>

            <table class="fshipping-track-table">
                <tbody>

                    <tr>
                        <td class="fshipping-track-label">
                            <?php esc_html_e('Tracking Number', 'teamzlab-fedex'); ?>
                        </td>
                        <td class="fshipping-track-value fshipping-track-mono">
                            <?php echo esc_html($tracking_number ?: $tracking_id ?: '-'); ?>
                        </td>
                    </tr>

                    <tr>
                        <td class="fshipping-track-label">
                            <?php esc_html_e('Current Status', 'teamzlab-fedex'); ?>
                        </td>
                        <td class="fshipping-track-value">
                            <?php if (!empty($status)) : ?>
                                <span class="fshipping-status-badge <?php echo esc_attr(self::track_status_variant($status)); ?>">
                                    <?php echo esc_html($status); ?>
                                </span>
                                <?php if (!empty($status_desc)) : ?>
                                    <small class="fshipping-track-muted"><?php echo esc_html($status_desc); ?></small>
                                <?php endif; ?>
                            <?php else : ?>
                                -
                            <?php endif; ?>
                        </td>
                    </tr>

                    <tr>
                        <td class="fshipping-track-label">
                            <?php esc_html_e('Delivery Date', 'teamzlab-fedex'); ?>
                        </td>
                        <td class="fshipping-track-value">
                            <?php
                            if (!empty($delivery_date)) {
                                echo esc_html(wp_date("F j, Y, g:i a", strtotime($delivery_date)));
                            } else {
                                echo '-';
                            }
                            ?>
                        </td>
                    </tr>

                    <tr>
                        <td class="fshipping-track-label">
                            <?php esc_html_e('Service Type', 'teamzlab-fedex'); ?>
                        </td>
                        <td class="fshipping-track-value">
                            <?php echo esc_html($carrier ?: '-'); ?>
                        </td>
                    </tr>

                    <tr>
                        <td class="fshipping-track-label">
                            <?php esc_html_e('Route', 'teamzlab-fedex'); ?>
                        </td>
                        <td class="fshipping-track-value fshipping-track-route">
                            <strong><?php echo esc_html($shipper_city ?: '-'); ?></strong>
                            <span class="fshipping-route-arrow" aria-hidden="true">&rarr;</span>
                            <strong><?php echo esc_html($recipient_city ?: '-'); ?></strong>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>
        <?php
        $html = ob_get_clean();

        wp_send_json_success(array('html' => $html));
    }

    /**
     * Error/empty-state card for the tracking popup (classes live in the
     * admin design system stylesheet).
     *
     * @param string $message
     * @return string
     */
    private static function track_popup_error_html($message) {
        return sprintf(
            '<div class="fshipping-tracking-card fshipping-tracking-card--error"><h3>%s</h3></div>',
            esc_html($message)
        );
    }

    /**
     * Map a FedEx tracking status string to a badge variant, so an
     * exception isn't rendered in success green.
     *
     * @param string $status
     * @return string
     */
    private static function track_status_variant($status) {
        $s = strtolower((string) $status);
        if (strpos($s, 'deliv') !== false && strpos($s, 'out for') === false) {
            return 'fshipping-status-badge--ok';
        }
        if (strpos($s, 'exception') !== false || strpos($s, 'delay') !== false || strpos($s, 'hold') !== false || strpos($s, 'cancel') !== false) {
            return 'fshipping-status-badge--danger';
        }
        if (strpos($s, 'out for') !== false || strpos($s, 'transit') !== false || strpos($s, 'pickup') !== false || strpos($s, 'depart') !== false || strpos($s, 'arriv') !== false) {
            return 'fshipping-status-badge--info';
        }
        return '';
    }
}