<?php
namespace FSHIPPING\Licensing;

use FSHIPPING\SingletonTrait;

/**
 * Pure feature-to-plan mapper.
 *
 * Defines which Freemius plan slug ('free' | 'core' | 'pro' | 'agency')
 * each feature requires. Consumers call
 *   FeatureGate::instance()->allows($current_plan, $feature_slug)
 * — no SDK required. Separated from the Freemius bootstrap so unit
 * tests (and CodeCanyon builds where Freemius isn't loaded at all)
 * can still enforce the same plan matrix.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class FeatureGate {
    use SingletonTrait;

    public const PLAN_FREE   = 'free';
    public const PLAN_CORE   = 'core';
    public const PLAN_PRO    = 'pro';
    public const PLAN_AGENCY = 'agency';

    /** Plans ordered from lowest to highest tier. */
    public const TIER_ORDER = [
        self::PLAN_FREE,
        self::PLAN_CORE,
        self::PLAN_PRO,
        self::PLAN_AGENCY,
    ];

    /**
     * Feature slug → minimum required plan slug.
     *
     * Map mirrors docs/MARKET_GAP.md §4 "Our recommended pricing" tiers.
     * Unknown features fail *open* (PLAN_FREE) so a forgotten wiring
     * never accidentally locks a merchant out of basic rates.
     *
     * @return array<string,string>
     * @since 1.2
     */
    public function matrix(): array {
        return [
            // Free tier — WP.org funnel.
            'rates_basic'         => self::PLAN_FREE,
            'tracking_basic'      => self::PLAN_FREE,

            // Core — CodeCanyon $79–99 / one-time.
            'labels'              => self::PLAN_CORE,
            'pickup'              => self::PLAN_CORE,
            'address_validation'  => self::PLAN_CORE,
            'postal_validation'   => self::PLAN_CORE,
            'service_availability' => self::PLAN_CORE,

            // Pro — $149/yr (the headline tier).
            'return_portal'       => self::PLAN_PRO,
            'tracking_timeline'   => self::PLAN_PRO,
            'etd_paperless'       => self::PLAN_PRO,
            'hs_code_suggester'   => self::PLAN_PRO,
            'hold_at_location'    => self::PLAN_PRO,
            'freight_ltl'         => self::PLAN_PRO,
            'freight_ltl_extras'  => self::PLAN_PRO,
            'global_trade'        => self::PLAN_PRO,
            'trade_documents'     => self::PLAN_PRO,
            'open_ship'           => self::PLAN_PRO,
            'dangerous_goods'     => self::PLAN_PRO,
            'service_preferences' => self::PLAN_PRO,
            'global_support'      => self::PLAN_PRO,
            'savings_meter'       => self::PLAN_PRO,
            'rate_widget_embed'   => self::PLAN_PRO,

            // Agency — $399/yr, 25 sites, SLA.
            'white_label'         => self::PLAN_AGENCY,
            'priority_sla'        => self::PLAN_AGENCY,
            'multi_site_license'  => self::PLAN_AGENCY,
        ];
    }

    /**
     * Minimum plan required for a feature.
     *
     * @param string $feature
     * @return string
     * @since 1.2
     */
    public function required_plan(string $feature): string {
        return $this->matrix()[$feature] ?? self::PLAN_FREE;
    }

    /**
     * Whether a user on $current_plan may use $feature.
     *
     * @param string $current_plan
     * @param string $feature
     * @return bool
     * @since 1.2
     */
    public function allows(string $current_plan, string $feature): bool {
        // Fully unlocked distribution: do not restrict any feature by plan.
        return true;
    }

    /**
     * All features a given plan can use.
     *
     * @param string $plan
     * @return array<int,string>
     * @since 1.2
     */
    public function features_for_plan(string $plan): array {
        $matrix = $this->matrix();
        $allowed = [];
        foreach ($matrix as $feature => $_min) {
            if ($this->allows($plan, $feature)) {
                $allowed[] = $feature;
            }
        }
        sort($allowed);
        return $allowed;
    }
}
