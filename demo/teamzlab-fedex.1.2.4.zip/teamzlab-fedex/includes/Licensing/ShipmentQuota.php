<?php
namespace FSHIPPING\Licensing;

defined( 'ABSPATH' ) || exit;

/**
 * Daily checkout quota by plan.
 *
 * Freemius plan slugs for this product are `free`, `core`, `pro`, `agency`;
 * legacy slugs `premium`/`golden` are still honoured. Effective caps:
 *
 * - free: max 10 successful FedEx checkouts/day.
 * - core, pro (legacy premium): max 100/day.
 * - agency (legacy golden): unlimited (limit 0 — see is_quota_reached()).
 *
 * Filter `fshipping_daily_shipment_limit` receives (int) $limit and
 * (string) $plan_slug for per-site overrides.
 *
 * @since 1.2.2
 */
class ShipmentQuota {
    private const RESET_BASELINE_OPTION = 'fshipping_quota_daily_reset_baseline';

    /**
     * Detect golden plan status via Freemius.
     *
     * @return bool
     */
    public static function is_golden_plan(): bool {
        return self::is_plan( 'golden' );
    }

    /**
     * Detect premium plan status via Freemius (100/day cap; not golden).
     *
     * @return bool
     */
    public static function is_premium_plan(): bool {
        return self::is_plan( 'premium' );
    }

    /**
     * Detect an arbitrary Freemius plan slug (guards against a missing SDK).
     *
     * @param string $slug Plan slug.
     * @return bool
     */
    private static function is_plan( string $slug ): bool {
        if ( ! function_exists( 'fshipping_fs' ) ) {
            return false;
        }

        $fs = fshipping_fs();
        if ( ! is_object( $fs ) || ! method_exists( $fs, 'is_plan' ) ) {
            return false;
        }

        return (bool) $fs->is_plan( $slug );
    }

    /**
     * Plan slug for quota UI and fshipping_daily_shipment_limit second argument.
     *
     * Checked highest tier first; returns 'free' when no paid plan applies.
     *
     * @return string
     */
    public static function quota_plan_slug(): string {
        foreach ( array( 'agency', 'golden', 'pro', 'premium', 'core' ) as $slug ) {
            if ( self::is_plan( $slug ) ) {
                return $slug;
            }
        }
        return 'free';
    }

    /**
     * Localized plan name for admin quota display.
     *
     * @return string
     */
    public static function admin_plan_label(): string {
        switch ( self::quota_plan_slug() ) {
            case 'agency':
                return __( 'Agency', 'teamzlab-fedex' );
            case 'golden':
                return __( 'Golden', 'teamzlab-fedex' );
            case 'pro':
                return __( 'Pro', 'teamzlab-fedex' );
            case 'premium':
                return __( 'Premium', 'teamzlab-fedex' );
            case 'core':
                return __( 'Core', 'teamzlab-fedex' );
            default:
                return __( 'Free', 'teamzlab-fedex' );
        }
    }

    /**
     * Plan-aware daily max shipment count.
     *
     * Entry tier (free) 10/day, paid tiers (core/pro, legacy premium)
     * 100/day, top tier (agency, legacy golden) unlimited.
     *
     * @return int 0 means unlimited.
     */
    public static function daily_limit(): int {
        $slug = self::quota_plan_slug();
        if ( 'agency' === $slug || 'golden' === $slug ) {
            $limit = 0;
        } elseif ( 'pro' === $slug || 'premium' === $slug || 'core' === $slug ) {
            $limit = 100;
        } else {
            $limit = 10;
        }
        return (int) apply_filters( 'fshipping_daily_shipment_limit', $limit, $slug );
    }

    /**
     * Message shown when quota is reached.
     *
     * @return string
     */
    public static function checkout_notice_message(): string {
        return (string) apply_filters(
            'fshipping_quota_reached_checkout_message',
            __( 'Checkout limit has been exceeded for today. Please try tomorrow.', 'teamzlab-fedex' )
        );
    }

    /**
     * Count successful checkouts created today (site local day)
     * where FedEx shipping was selected.
     *
     * Reads the order table matching the store's storage backend — under
     * HPOS the legacy wp_posts side only holds `shop_order_placehold`
     * stubs, so a posts-only COUNT is always 0 and the quota silently
     * never fires on exactly the stores this plugin declares support for.
     *
     * Cached for 60 seconds; use reset_today_quota_baseline() (or
     * wp_cache_delete on the key) when a fresh count is required.
     *
     * @return int
     */
    public static function raw_count_shipments_today(): int {
        global $wpdb;

        $today     = current_time( 'Y-m-d' );
        $cache_key = 'fshipping_quota_raw_count_' . $today;
        $cached    = wp_cache_get( $cache_key, 'fshipping_quota' );
        if ( false !== $cached ) {
            return (int) $cached;
        }

        // Half-open [local midnight, next local midnight) day window.
        // HPOS stores GMT (wc_orders.date_created_gmt — there is no local
        // date_created column), so its bounds are the UTC instants of the
        // site's local day; legacy posts store site-local post_date and
        // keep local strings. Bounds stay sargable — no DATE() wrapping.
        $day_start = $today . ' 00:00:00';
        $day_end   = date( 'Y-m-d', current_time( 'timestamp' ) + DAY_IN_SECONDS ) . ' 00:00:00'; // phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date

        try {
            $midnight_local = new \DateTimeImmutable( $today . ' 00:00:00', wp_timezone() );
            $day_start_gmt  = $midnight_local->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
            $day_end_gmt    = $midnight_local->modify( '+1 day' )->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
        } catch ( \Exception $e ) {
            return 0;
        }

        $hpos = class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
            && method_exists( '\Automattic\WooCommerce\Utilities\OrderUtil', 'custom_orders_table_usage_is_enabled' )
            && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();

        // Prepared COUNT on core WP/WC order tables for quota enforcement;
        // result cached in the object cache for 60 seconds. Direct queries are
        // required here: HPOS orders live in custom tables with no count API.
        if ( $hpos ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Prepared COUNT on core order tables; cached in object cache for 60s.
            $count = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(DISTINCT o.id)
                FROM {$wpdb->prefix}wc_orders o
                INNER JOIN {$wpdb->prefix}woocommerce_order_items oi
                    ON oi.order_id = o.id
                   AND oi.order_item_type = 'shipping'
                INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim
                    ON oim.order_item_id = oi.order_item_id
                   AND oim.meta_key = 'method_id'
                WHERE o.type = 'shop_order'
                  AND o.status NOT IN ('trash', 'auto-draft', 'draft')
                  AND o.date_created_gmt >= %s
                  AND o.date_created_gmt < %s
                  AND (oim.meta_value = %s OR oim.meta_value LIKE %s)",
                $day_start_gmt,
                $day_end_gmt,
                'fshipping_custom',
                $wpdb->esc_like( 'fshipping_custom' ) . '%'
            ) );
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Prepared COUNT on core order tables; cached in object cache for 60s.
            $count = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(DISTINCT p.ID)
                FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->prefix}woocommerce_order_items oi
                    ON oi.order_id = p.ID
                   AND oi.order_item_type = 'shipping'
                INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim
                    ON oim.order_item_id = oi.order_item_id
                   AND oim.meta_key = 'method_id'
                WHERE p.post_type = 'shop_order'
                  AND p.post_status NOT IN ('trash', 'auto-draft', 'draft')
                  AND p.post_date >= %s
                  AND p.post_date < %s
                  AND (oim.meta_value = %s OR oim.meta_value LIKE %s)",
                $day_start,
                $day_end,
                'fshipping_custom',
                $wpdb->esc_like( 'fshipping_custom' ) . '%'
            ) );
        }

        wp_cache_set( $cache_key, $count, 'fshipping_quota', MINUTE_IN_SECONDS );

        return $count;
    }

    /**
     * Current baseline for today after admin reset action.
     *
     * @return int
     */
    public static function get_reset_baseline_for_today(): int {
        $store = get_option( self::RESET_BASELINE_OPTION, array() );
        if ( ! is_array( $store ) ) {
            return 0;
        }

        $today = current_time( 'Y-m-d' );
        return isset( $store[ $today ] ) ? max( 0, (int) $store[ $today ] ) : 0;
    }

    /**
     * Effective count used for quota checks after applying today's baseline.
     *
     * @return int
     */
    public static function effective_count_shipments_today(): int {
        $raw      = self::raw_count_shipments_today();
        $baseline = self::get_reset_baseline_for_today();
        return max( 0, $raw - $baseline );
    }

    /**
     * Backward-compatible alias for current daily count in quota logic.
     *
     * @return int
     */
    public static function count_shipments_today(): int {
        return self::effective_count_shipments_today();
    }

    /**
     * Reset today's quota usage by storing raw-count baseline.
     *
     * @return void
     */
    public static function reset_today_quota_baseline(): void {
        $today = current_time( 'Y-m-d' );

        // Bypass the 60s count cache so the stored baseline is exact.
        wp_cache_delete( 'fshipping_quota_raw_count_' . $today, 'fshipping_quota' );

        $store = get_option( self::RESET_BASELINE_OPTION, array() );
        if ( ! is_array( $store ) ) {
            $store = array();
        }

        // Keep only today's key to avoid option growth.
        $store = array(
            $today => self::raw_count_shipments_today(),
        );
        update_option( self::RESET_BASELINE_OPTION, $store, false );
    }

    /**
     * Whether quota has been reached for the current day.
     *
     * @return bool
     */
    public static function is_quota_reached(): bool {
        $limit = self::daily_limit();
        if ( $limit <= 0 ) {
            return false;
        }
        return self::effective_count_shipments_today() >= $limit;
    }
}
