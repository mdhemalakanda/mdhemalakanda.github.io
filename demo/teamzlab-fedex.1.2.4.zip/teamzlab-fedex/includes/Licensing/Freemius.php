<?php
namespace FSHIPPING\Licensing;

use FSHIPPING\SingletonTrait;

/**
 * Freemius SDK bootstrap.
 *
 * Activation is gated by three things:
 *   1. The plugin is built for the Freemius distro (FSHIPPING_DISTRO !== 'codecanyon').
 *   2. The three Freemius constants are defined with real values.
 *   3. The Freemius SDK is physically present at freemius/start.php.
 *
 * If any of those miss, init() silently no-ops — `can_use()` falls back
 * to FeatureGate against the 'free' plan, so missing licensing never
 * breaks the plugin. This is on purpose: CodeCanyon builds ship with
 * no Freemius SDK and no keys, and they still need to work.
 *
 * Activation path for merchants:
 *   1. Sign up at freemius.com, create the product, get ID + public key.
 *   2. Drop the Freemius SDK into FSHIPPING_DIR_PATH . '/freemius/'.
 *   3. Add to wp-config.php:
 *        define('FSHIPPING_FREEMIUS_ID', 12345);
 *        define('FSHIPPING_FREEMIUS_PUBLIC_KEY', 'pk_xxxxxxxxxxxxx');
 *   4. Plugin reloads → licensing + auto-updates + Freemius menu are live.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class Freemius {
    use SingletonTrait;

    /** The SDK return value from fs_dynamic_init(). Null when inactive. */
    private $sdk = null;

    /**
     * Wire the SDK into WordPress. Called from Main::init().
     *
     * @return void
     * @since 1.2
     */
    public function init(): void {
        // feedex-shipping.php already boots the SDK via fshipping_fs() with the
        // bundled product constants. Booting a second fs_dynamic_init() with
        // the same slug duplicates admin pages/notices and creates two plan
        // sources (ShipmentQuota reads fshipping_fs()), so defer to that boot
        // whenever it produced an SDK.
        if (function_exists('fshipping_fs') && fshipping_fs()) {
            return;
        }

        if (!$this->is_activatable()) {
            return;
        }

        $sdk_path = $this->sdk_path();
        if (!file_exists($sdk_path)) {
            return;
        }

        if (!function_exists('fs_dynamic_init')) {
            require_once $sdk_path;
        }
        if (!function_exists('fs_dynamic_init')) {
            return;
        }

        $this->sdk = fs_dynamic_init([
            'id'             => FSHIPPING_FREEMIUS_ID,
            'slug'           => FSHIPPING_FREEMIUS_SLUG,
            'public_key'     => FSHIPPING_FREEMIUS_PUBLIC_KEY,
            'is_premium'     => defined('FSHIPPING_DISTRO') && FSHIPPING_DISTRO !== 'codecanyon',
            'has_addons'     => false,
            'has_paid_plans' => true,
            'menu'           => [
                'slug'      => 'fedex_shipping',
                'first-path' => 'admin.php?page=fedex_shipping',
                'support'   => false,
            ],
            'is_live'        => true,
        ]);

        do_action('fshipping_freemius_loaded', $this->sdk);
    }

    /**
     * Whether licensing is enabled for this distro + environment.
     *
     * @return bool
     * @since 1.2
     */
    public function is_activatable(): bool {
        if (defined('FSHIPPING_DISTRO') && FSHIPPING_DISTRO === 'codecanyon') {
            return false;
        }
        if (!defined('FSHIPPING_FREEMIUS_ID') ||
            !defined('FSHIPPING_FREEMIUS_PUBLIC_KEY') ||
            !defined('FSHIPPING_FREEMIUS_SLUG')) {
            return false;
        }
        if ((int) FSHIPPING_FREEMIUS_ID <= 0) {
            return false;
        }
        if (in_array((string) FSHIPPING_FREEMIUS_PUBLIC_KEY, ['', 'pk_placeholder'], true)) {
            return false;
        }
        return true;
    }

    /**
     * Current plan slug for the active site, or 'free' when inactive.
     *
     * @return string One of FeatureGate::PLAN_*.
     * @since 1.2
     */
    public function current_plan(): string {
        if (!is_object($this->sdk)) {
            return FeatureGate::PLAN_FREE;
        }

        // Freemius's is_plan() signature: is_plan($slug, $exact = false).
        // `true` enforces exact match rather than "this plan or higher".
        foreach ([FeatureGate::PLAN_AGENCY, FeatureGate::PLAN_PRO, FeatureGate::PLAN_CORE] as $candidate) {
            if (method_exists($this->sdk, 'is_plan') && $this->sdk->is_plan($candidate, true)) {
                return $candidate;
            }
        }
        return FeatureGate::PLAN_FREE;
    }

    /**
     * Whether a feature is licensed for the current site.
     *
     * @param string $feature
     * @return bool
     * @since 1.2
     */
    public function can_use(string $feature): bool {
        // This distribution is intentionally fully unlocked.
        // Keep method for compatibility with older callers.
        return true;
    }

    /**
     * Raw SDK instance for edge-case callers (null when inactive).
     *
     * @return mixed
     * @since 1.2
     */
    public function sdk() {
        return $this->sdk;
    }

    /**
     * Absolute path to start.php inside the SDK folder.
     *
     * @return string
     * @since 1.2
     */
    public function sdk_path(): string {
        $root = defined('FSHIPPING_DIR_PATH') ? rtrim(FSHIPPING_DIR_PATH, '/\\') . '/' : '';
        return $root . 'freemius/start.php';
    }
}
