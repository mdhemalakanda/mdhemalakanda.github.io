<?php
namespace FSHIPPING;
use FSHIPPING\SingletonTrait;
class Order {
    use SingletonTrait;

    public function init() {
        // When order is moved to trash
        add_action( 'woocommerce_trash_order', array( $this, 'sync_fedex_shipping_status' ) );
        
        // When order is restored from trash
        add_action( 'woocommerce_untrash_order', array( $this, 'sync_fedex_shipping_status' ) );
        
        // When order is deleted permanently
        add_action( 'woocommerce_before_delete_order', array( $this, 'sync_fedex_shipping_status' ) );
    }

    /**
     * Helper to find the shipment ID based on Order ID
     */
    private function get_shipment_id_by_order( $order_id ) {
        $shipments = get_posts( array(
            'post_type'      => 'fedex_shipping',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key, WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- WooCommerce order sync on trash/restore/delete: finds the single fedex_shipping post linked to this order by its _fedex_shipment_order_id meta, hard-limited to 1.
            'meta_key'       => '_fedex_shipment_order_id',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Same single-post order lookup as above; a keyed equality match on plugin meta, not an unbounded scan.
            'meta_value'     => $order_id,
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'post_status'    => array( 'any', 'trash' ), // Look in trash too if restoring
        ) );

        return ! empty( $shipments ) ? $shipments[0] : false;
    }

    /**
     * Main logic to sync the status
     */
    public function sync_fedex_shipping_status( $order_id ) {
        $shipment_id = $this->get_shipment_id_by_order( $order_id );

        if ( ! $shipment_id ) {
            return;
        }

        $current_action = current_action();
        if ( 'woocommerce_trash_order' === $current_action ) {
            // Move to trash
            wp_trash_post( $shipment_id );
            
        } elseif ( 'woocommerce_untrash_order' === $current_action ) {
            // Restore from trash
            wp_untrash_post( $shipment_id );
            
        } elseif ( 'woocommerce_before_delete_order' === $current_action ) {
            // Delete permanently (true = bypass trash)
            wp_delete_post( $shipment_id, true );
        }
    }
}