<?php
namespace FSHIPPING\Dashboard;

use FSHIPPING\Licensing\ShipmentQuota;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\Helper;

defined('ABSPATH') || exit;

class Settings {
    use SingletonTrait;

    public function init() {
        add_action('admin_init', array($this, 'initialize_settings_fields'));
    }

    public function initialize_settings_fields() {
        register_setting(
            'fshipping_auth_group',
            'fshipping_options',
            array(
                'sanitize_callback' => array($this, 'sanitize_fshipping_options'),
            )
        );

        // --- Tab 1: Authorization ---
        $this->authorization_settings();

        // --- Tab 2: Account ---
        $this->account_settings();

        // --- Tab 3: Shipping ---
        $this->account_shipping();

        // --- Tab 4: Labeling ---
        $this->account_labeling();

        $this->tracking_settings();

        // Webhook and Freight tabs were intentionally removed from the
        // Settings UI per product scope decisions.
    }

    /**
     * Merge posted keys into the existing option so fields not rendered
     * (removed tabs, future hooks) are not wiped on save.
     *
     * @param mixed $input Raw POST value for `fshipping_options`.
     * @return array<string, mixed>
     */
    public function sanitize_fshipping_options($input): array {
        $prev = get_option('fshipping_options', array());
        if (!is_array($prev)) {
            $prev = array();
        }
        if (!is_array($input)) {
            return $prev;
        }

        $merged = array_merge($prev, $input);

        // Webhook HMAC key — whitespace or markup in it would silently break
        // every signature check, so normalize it here.
        if (isset($merged['fshipping_aiv_shared_secret'])) {
            $merged['fshipping_aiv_shared_secret'] = sanitize_text_field((string) $merged['fshipping_aiv_shared_secret']);
        }

        return $merged;
    }

    /**
     * Tracking Settings (Mirrored Auth Fields)
     */
    private function tracking_settings() {
        add_settings_section(
            'fshipping_tracking_section',
            __('Tracking API Authorizations', 'teamzlab-fedex'),
            function() { 
                echo '<p>' . esc_html__('Enter your FedEx API credentials specifically for Tracking services.', 'teamzlab-fedex') . '</p>'; 
            },
            'fshipping_tracking_tab'
        );

        add_settings_field(
            'fshipping_tracking_client_id',
            __('Tracking Client ID', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_tracking_tab',
            'fshipping_tracking_section',
            array(
                'key'         => 'fshipping_tracking_client_id',
                'type'        => 'text',
                'description' => __('Client ID from the FedEx project that has the Tracking API enabled.', 'teamzlab-fedex'),
            )
        );

        add_settings_field(
            'fshipping_tracking_client_secret',
            __('Tracking Client Secret', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_tracking_tab',
            'fshipping_tracking_section',
            array(
                'key'         => 'fshipping_tracking_client_secret',
                'type'        => 'password',
                'description' => __('Matching secret for the same Tracking API project.', 'teamzlab-fedex'),
            )
        );

        // AIV webhook shared secret — TrackingWebhookReceiver fail-closes
        // (401 on every delivery) until this is set, and before this field
        // existed there was no UI to set it at all, so the webhook receiver
        // was only configurable via wp-cli.
        add_settings_section(
            'fshipping_aiv_section',
            __('Tracking Webhooks (AIV)', 'teamzlab-fedex'),
            function() {
                echo '<p>' . esc_html__('Shared secret used to verify HMAC-SHA256 signatures (fdx-signature header) on webhook deliveries. Deliveries are rejected until this matches the secret configured in your FedEx webhook subscription.', 'teamzlab-fedex') . '</p>';
                $webhook_url = rest_url('fshipping/v1/aiv-webhook');
                echo '<p><code class="fshipping-code">' . esc_html($webhook_url) . '</code>';
                echo ' <button type="button" class="button button-small fshipping-copy-inline" data-copy="' . esc_attr($webhook_url) . '">' . esc_html__('Copy', 'teamzlab-fedex') . '</button></p>';
            },
            'fshipping_tracking_tab'
        );

        add_settings_field(
            'fshipping_aiv_shared_secret',
            __('Webhook Shared Secret', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_tracking_tab',
            'fshipping_aiv_section',
            array('key' => 'fshipping_aiv_shared_secret', 'type' => 'password')
        );
    }

    /**
     * Account Labeling
     */
    public function account_labeling() {
        add_settings_section(
            'fshipping_labeling_section',
            __('Account Labeling', 'teamzlab-fedex'),
            function() { echo '<p>' . esc_html__('Enter your FedEx Labeling information.', 'teamzlab-fedex') . '</p>'; },
            'fshipping_labeling_tab'
        );

        add_settings_field(
            'fshipping_labeling_streetline',
            __('Street Lines ( enter per line )', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_labeling_tab',
            'fshipping_labeling_section',
            array('key' => 'fshipping_labeling_streetline', 'type' => 'textarea')
        );

        $packaging_type = Helper::instance()->get_field_options('packaging_type');
        add_settings_field(
            'fshipping_labeling_packaging_type',
            __('Packaging Type', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_labeling_tab',
            'fshipping_labeling_section',
            array('key' => 'fshipping_labeling_packaging_type', 'type' => 'select', 'fields' => $packaging_type)
        );

        $pickup_type = Helper::instance()->get_field_options('pickup_type');
        add_settings_field(
            'fshipping_labeling_pickup_type',
            __('Pickup Type', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_labeling_tab',
            'fshipping_labeling_section',
            array('key' => 'fshipping_labeling_pickup_type', 'type' => 'select', 'fields' => $pickup_type)
        );

        add_settings_section(
            'fshipping_labeling_charge_payment_section',
            __('Shipping Charge Payment', 'teamzlab-fedex'),
            function() { echo '<p>' . esc_html__('Specifies the payment details specifying the method and means of payment to FedEx for providing shipping services.', 'teamzlab-fedex') . '</p>'; },
            'fshipping_labeling_tab'
        );

        $payment_type = Helper::instance()->get_field_options('payment_type');
        add_settings_field(
            'fshipping_labeling_payment_type',
            __('Payment Type', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_labeling_tab',
            'fshipping_labeling_charge_payment_section',
            array('key' => 'fshipping_labeling_payment_type', 'type' => 'select', 'fields' => $payment_type)
        );

        add_settings_section(
            'fshipping_labeling_specification',
            __('Label Specification', 'teamzlab-fedex'),
            function() { echo '<p>' . esc_html__('These are label specification details includes the image type, printer format, and label stock for label. Can also specify specific details such as doc-tab content, regulatory labels, and masking data on the label.', 'teamzlab-fedex') . '</p>'; },
            'fshipping_labeling_tab'
        );

        $label_format_type = array(
            'COMMON2D' => __('Common 2D', 'teamzlab-fedex'),
            'LABEL_DATA_ONLY' => __('Label Data Only', 'teamzlab-fedex'),
        );
        add_settings_field(
            'fshipping_labeling_label_format_type',
            __('Label Format Type', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_labeling_tab',
            'fshipping_labeling_specification',
            array('key' => 'fshipping_labeling_label_format_type', 'type' => 'select', 'fields' => $label_format_type)
        );

        $label_order = array(
            'SHIPPING_LABEL_FIRST' => __('Shipping Label First', 'teamzlab-fedex'),
            'SHIPPING_LABEL_LAST' => __('Shipping Label Last', 'teamzlab-fedex'),
        );
        add_settings_field(
            'fshipping_labeling_label_order',
            __('Label Order', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_labeling_tab',
            'fshipping_labeling_specification',
            array('key' => 'fshipping_labeling_label_order', 'type' => 'select', 'fields' => $label_order)
        );
        
        $label_stock_type = Helper::instance()->get_field_options('label_stock_type');
        add_settings_field(
            'fshipping_labeling_stock_type',
            __('Label Stock Type', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_labeling_tab',
            'fshipping_labeling_specification',
            array('key' => 'fshipping_labeling_stock_type', 'type' => 'select', 'fields' => $label_stock_type)
        );

        $label_rotation = array(
            'LEFT' => __('Left', 'teamzlab-fedex'),
            'RIGHT' => __('Right', 'teamzlab-fedex'),
            'UPSIDE_DOWN' => __('Upside Down', 'teamzlab-fedex'),
            'NONE' => __('None', 'teamzlab-fedex'),
        );
        add_settings_field(
            'fshipping_labeling_rotation',
            __('Label Rotation', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_labeling_tab',
            'fshipping_labeling_specification',
            array('key' => 'fshipping_labeling_rotation', 'type' => 'select', 'fields' => $label_rotation)
        );
        
        $image_type = array(
            'ZPLII' => __('ZPL II', 'teamzlab-fedex'),
            'EPL2' => __('EPL2', 'teamzlab-fedex'),
            'PDF' => __('PDF', 'teamzlab-fedex'),
            'PNG' => __('PNG', 'teamzlab-fedex'),
        );
        add_settings_field(
            'fshipping_labeling_image_type',
            __('Image Type', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_labeling_tab',
            'fshipping_labeling_specification',
            array('key' => 'fshipping_labeling_image_type', 'type' => 'select', 'fields' => $image_type)
        );

        $label_printing_orientation = array(
            'BOTTOM_EDGE_OF_TEXT_FIRST' => __('Bottom Edge of Text First', 'teamzlab-fedex'),
            'TOP_EDGE_OF_TEXT_FIRST' => __('Top Edge of Text First', 'teamzlab-fedex')
        );
        add_settings_field(
            'fshipping_labeling_bottom_orientation',
            __('Label Printing Orientation', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_labeling_tab',
            'fshipping_labeling_specification',
            array('key' => 'fshipping_labeling_bottom_orientation', 'type' => 'select', 'fields' => $label_printing_orientation)
        );
    }

    /**
     * Add account settings.
     */
    private function account_settings() {
        add_settings_section(
            'fshipping_account_section',
            __('Account Details', 'teamzlab-fedex'),
            function() { echo '<p>' . esc_html__('Enter your FedEx Account information.', 'teamzlab-fedex') . '</p>'; },
            'fshipping_account_tab'
        );

        add_settings_field(
            'fshipping_acc_number',
            __('Account Number', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_account_tab',
            'fshipping_account_section',
            array('key' => 'fshipping_acc_number', 'type' => 'text')
        );

        add_settings_field(
            'fshipping_person_name',
            __('Person Name', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_account_tab',
            'fshipping_account_section',
            array('key' => 'fshipping_person_name', 'type' => 'text')
        );

        add_settings_field(
            'fshipping_phone_number',
            __('Phone Number', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_account_tab',
            'fshipping_account_section',
            array('key' => 'fshipping_phone_number', 'type' => 'text')
        );

        add_settings_field(
            'fshipping_postal_code',
            __('Postal Code', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_account_tab',
            'fshipping_account_section',
            array('key' => 'fshipping_postal_code', 'type' => 'text')
        );

        $countries = Helper::instance()->get_field_options('country_by_code');
        add_settings_field(
            'fshipping_country_code',
            __('Country', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_account_tab',
            'fshipping_account_section',
            array('key' => 'fshipping_country_code', 'type' => 'select', 'fields' => $countries)
        );

        $states = Helper::instance()->get_field_options('states');

        add_settings_field(
            'fshipping_city',
            __('City', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_account_tab',
            'fshipping_account_section',
            array('key' => 'fshipping_city', 'type' => 'text')
        );

        add_settings_field(
            'state_provincecod',
            __('State Or Province Code', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_account_tab',
            'fshipping_account_section',
            array('key' => 'state_provincecod', 'type' => 'select_group', 'fields' => $states)
        );

        $environment = array(
            'sandbox' => __('Sandbox', 'teamzlab-fedex'),
            'production' => __('Production', 'teamzlab-fedex')
        );
        add_settings_field(
            'fshipping_select_environemnt',
            __('Environment', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_account_tab',
            'fshipping_account_section',
            array(
                'key'         => 'fshipping_select_environemnt',
                'type'        => 'select',
                'fields'      => $environment,
                'description' => __('Sandbox issues test labels only; production creates real shipments with real charges.', 'teamzlab-fedex'),
            )
        );
    }

    /**
     * Add account settings.
     */
    private function account_shipping() {
        add_settings_section(
            'fshipping_sepping_section',
            __('Shipping', 'teamzlab-fedex'),
            function() { echo '<p>' . esc_html__('Enter your FedEx Shipping information.', 'teamzlab-fedex') . '</p>'; },
            'fshipping_shipping_tab'
        );

        add_settings_field(
            'fshipping_shipping_mode',
            __('Shipping mode', 'teamzlab-fedex'),
            array($this, 'render_shipping_mode_field'),
            'fshipping_shipping_tab',
            'fshipping_sepping_section'
        );

        $pickup_types = Helper::instance()->get_field_options('pickup_type');
        add_settings_field(
            'fshipping_pickup_type',
            __('Pickup Type', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_shipping_tab',
            'fshipping_sepping_section',
            array('key' => 'fshipping_pickup_type', 'type' => 'select', 'fields' => $pickup_types)
        );

        $rate_requests = Helper::instance()->get_field_options('rate_request');
        add_settings_field(
            'fshipping_rate_request_type',
            __('Rate Request Type', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_shipping_tab',
            'fshipping_sepping_section',
            array('key' => 'fshipping_rate_request_type', 'type' => 'select', 'fields' => $rate_requests, 'multiple' => true)
        );

        $service_types = Helper::instance()->get_field_options('service_type');
        add_settings_field(
            'fshipping_shipping_methods',
            __('Shipping Methods', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_shipping_tab',
            'fshipping_sepping_section',
            array('key' => 'fshipping_shipping_methods', 'type' => 'select', 'fields' => $service_types, 'multiple' => true)
        );

        add_settings_field(
            'fshipping_enable_service_availability_filter',
            __('Guarantee "every rate is really available"', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_shipping_tab',
            'fshipping_sepping_section',
            array('key' => 'fshipping_enable_service_availability_filter', 'type' => 'checkbox')
        );

        add_settings_field(
            'fshipping_enable_checkout_address_validation',
            __('Enable checkout address validation', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_shipping_tab',
            'fshipping_sepping_section',
            array('key' => 'fshipping_enable_checkout_address_validation', 'type' => 'checkbox')
        );

        add_settings_field(
            'fshipping_address_validation_allow_on_failure',
            __('If address validation fails: allow shipment anyway (log + order note)', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_shipping_tab',
            'fshipping_sepping_section',
            array('key' => 'fshipping_address_validation_allow_on_failure', 'type' => 'checkbox')
        );
    }

    /**
     * Add authorization settings.
     */
    private function authorization_settings() {
        add_settings_section(
            'fshipping_auth_section',
            __('Authorizations', 'teamzlab-fedex'),
            function() { echo '<p>' . esc_html__('Enter your FedEx API credentials.', 'teamzlab-fedex') . '</p>'; },
            'fshipping_auth_tab'
        );

        add_settings_field(
            'fshipping_client_id',
            __('Client ID', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_auth_tab',
            'fshipping_auth_section',
            array(
                'key'         => 'fshipping_client_id',
                'type'        => 'text',
                'description' => __('FedEx OAuth API key from your FedEx Developer account.', 'teamzlab-fedex'),
            )
        );

        add_settings_field(
            'fshipping_client_secret',
            __('Client Secret', 'teamzlab-fedex'),
            array($this, 'render_field'),
            'fshipping_auth_tab',
            'fshipping_auth_section',
            array(
                'key'         => 'fshipping_client_secret',
                'type'        => 'password',
                'description' => __('Matching API secret key from the same project.', 'teamzlab-fedex'),
            )
        );
       
    }

    /**
     * Shipping mode: Ship API vs Open Ship draft.
     *
     * @return void
     * @since 1.3
     */
    public function render_shipping_mode_field() {
        $this->render_field([
            'key'         => 'fshipping_shipping_mode',
            'type'        => 'select',
            'default'     => 'instant',
            'fields'      => [
                'instant'  => __('Instant Shipping (Ship API)', 'teamzlab-fedex'),
                'advanced' => __('Advanced Shipping (Open Ship API)', 'teamzlab-fedex'),
            ],
            'description' => __(
                'Instant: label at checkout (Ship API). Advanced: Open Ship draft on the order — edit packages in admin, then confirm to generate labels.',
                'teamzlab-fedex'
            ),
        ]);
    }

    /**
     * Common Field Implementation
     * * @param array $args Contains 'key' and 'type' passed from add_settings_field
     */
    public function render_field($args) {
        $options = get_option('fshipping_options');
        $key     = isset($args['key']) ? sanitize_text_field($args['key']): '';
        $type    = isset($args['type']) ? sanitize_text_field($args['type']): '';
        $value   = isset($options[$key]) ? $options[$key] : '';
        $desc    = isset($args['description']) ? $args['description'] : '';

        if(
            $type === 'text' ||
            $type === 'email' ||
            $type === 'password'
        ) {
            if ( $type === 'password' ) {
                // Secrets get a Show/Hide reveal instead of the dots-only field.
                $input_id = 'fshipping-field-' . $key;
                echo '<span class="fshipping-secret-wrap">';
                echo sprintf(
                    '<input type="password" id="%1$s" name="fshipping_options[%2$s]" value="%3$s" class="regular-text" />',
                    esc_attr($input_id),
                    esc_attr($key),
                    esc_attr($value)
                );
                echo ' <button type="button" class="button button-small fshipping-secret-toggle" data-target="' . esc_attr($input_id) . '" aria-pressed="false">' . esc_html__('Show', 'teamzlab-fedex') . '</button>';
                echo '</span>';
            } else {
                echo sprintf(
                    '<input type="%s" name="fshipping_options[%s]" value="%s" class="regular-text" />',
                    esc_attr($type),
                    esc_attr($key),
                    esc_attr($value)
                );
            }
        } elseif( $type === 'checkbox' ) {
            echo sprintf(
                '<input type="hidden" name="fshipping_options[%1$s]" value="0" /><label><input type="checkbox" name="fshipping_options[%1$s]" value="1" %2$s /> %3$s</label>',
                esc_attr($key),
                checked(!empty($value), true, false),
                esc_html__('Enabled', 'teamzlab-fedex')
            );
        } elseif( $type === 'textarea' ) {
            echo sprintf(
                '<textarea name="fshipping_options[%s]" class="regular-text" rows="5" cols="50">%s</textarea>',
                esc_attr($key),
                esc_textarea($value)
            );
        } elseif( $type === 'select' ) {
            if ($value === '' || $value === null) {
                if (isset($args['default']) && $args['default'] !== '' && $args['default'] !== null) {
                    $value = $args['default'];
                }
            }
            $fields   = isset($args['fields']) ? $args['fields'] : array();
            $multiple = !empty($args['multiple']) ? 'multiple' : '';
            $name_attr = "fshipping_options[" . esc_attr($key) . "]";
            if ( $multiple ) {
                $name_attr .= "[]";
            }

            if ( is_array($fields) && !empty($fields) ) :
            ?>
            <select <?php echo esc_attr($multiple); ?> class="fedex-select2" name="<?php echo esc_attr($name_attr); ?>" style="width: 100%; min-width: 25rem;">
                <?php foreach ( $fields as $option_value => $option_label ) :
                    $is_selected = false;
                    if ( is_array($value) ) {
                        $is_selected = in_array( (string)$option_value, $value );
                    } else {
                        $is_selected = ( (string)$option_value === (string)$value );
                    }
                    ?>
                    <option value="<?php echo esc_attr($option_value); ?>" <?php selected( $is_selected, true ); ?>>
                        <?php echo esc_html($option_label); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <?php
            endif;
        }  elseif( 'select_group' === $type ) {
            $fields   = isset($args['fields']) ? $args['fields'] : array();
            $multiple = !empty($args['multiple']) ? 'multiple' : '';
            $name_attr = "fshipping_options[" . esc_attr($key) . "]";
            if ( $multiple ) {
                $name_attr .= "[]";
            }

            if ( is_array($fields) && !empty($fields) ) :
            ?>
            <select <?php echo esc_attr($multiple); ?> class="fedex-select2" name="<?php echo esc_attr($name_attr); ?>" style="width: 100%; min-width: 25rem;">
                <option value=""><?php esc_html_e('Select a state...', 'teamzlab-fedex'); ?></option>
                <?php foreach ( $fields as $country_code => $states ) : ?>
                    <?php if ( ! empty( $states ) && is_array( $states ) ) : ?>
                        <optgroup label="<?php echo esc_attr( $country_code ); ?>">
                            <?php foreach ( $states as $state_code => $state_name ) :
                                $is_selected = false;
                                if ( is_array($value) ) {
                                    $is_selected = in_array( (string)$state_code, $value );
                                } else {
                                    $is_selected = ( (string)$state_code === (string)$value );
                                }
                                ?>
                                <option value="<?php echo esc_attr($state_code); ?>" <?php selected( $is_selected, true ); ?>>
                                    <?php echo esc_html($state_name); ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
            <?php
            endif;
        }

        if ( is_string($desc) && $desc !== '' ) {
            echo '<p class="description">' . esc_html($desc) . '</p>';
        }
    }

    /**
     * Render read-only daily shipment quota details.
     *
     * @return void
     */
    private function render_quota_reset_controls() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $plan_label      = ShipmentQuota::admin_plan_label();
        $limit           = ShipmentQuota::daily_limit();
        $usage           = ShipmentQuota::effective_count_shipments_today();
        $quota_reached   = ShipmentQuota::is_quota_reached();
        $unlimited       = ShipmentQuota::is_golden_plan();
        ?>
        <div class="fshipping-quota">
            <div class="fshipping-quota__head">
                <h2><?php echo esc_html__( 'Daily Quota Controls', 'teamzlab-fedex' ); ?></h2>
                <span class="fshipping-badge fshipping-badge--purple"><?php echo esc_html( $plan_label ); ?></span>
            </div>
            <p class="fshipping-quota__usage">
                <?php
                if ( $unlimited ) {
                    echo esc_html(
                        sprintf(
                            /* translators: 1: plan label, 2: usage */
                            __( 'Plan: %1$s. Today usage: %2$d (unlimited daily quota).', 'teamzlab-fedex' ),
                            $plan_label,
                            $usage
                        )
                    );
                } else {
                    echo esc_html(
                        sprintf(
                            /* translators: 1: plan label, 2: usage, 3: limit */
                            __( 'Plan: %1$s. Today usage: %2$d / %3$d.', 'teamzlab-fedex' ),
                            $plan_label,
                            $usage,
                            $limit
                        )
                    );
                }
                ?>
            </p>
            <?php if ( ! $unlimited && $limit > 0 ) :
                $percent = min( 100, (int) round( ( $usage / $limit ) * 100 ) );
                ?>
                <div
                    class="fshipping-progress"
                    role="progressbar"
                    aria-label="<?php echo esc_attr__( 'Daily shipment quota usage', 'teamzlab-fedex' ); ?>"
                    aria-valuemin="0"
                    aria-valuemax="<?php echo esc_attr( $limit ); ?>"
                    aria-valuenow="<?php echo esc_attr( $usage ); ?>"
                >
                    <span class="fshipping-progress__bar<?php echo $quota_reached ? ' fshipping-progress__bar--full' : ''; ?>" style="width: <?php echo esc_attr( $percent ); ?>%;"></span>
                </div>
            <?php endif; ?>
            <?php if ( $quota_reached ) : ?>
                <p class="fshipping-quota__reached"><?php echo esc_html__( 'Quota is currently reached.', 'teamzlab-fedex' ); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render the settings screen: branded page header with environment
     * badge, accessible tab nav, one card per tab, sticky save bar and
     * the quota panel.
     *
     * @return void
     */
    public function display_settings() {
        $options     = get_option('fshipping_options', array());
        $environment = isset($options['fshipping_select_environemnt']) ? $options['fshipping_select_environemnt'] : '';
        $is_prod     = ('production' === $environment);
        // key = panel element id (JS hook), value = tab label + settings page slug.
        $tabs        = array(
            'fshipping-auth'     => array(
                'label' => __('Authorization', 'teamzlab-fedex'),
                'page'  => 'fshipping_auth_tab',
            ),
            'fshipping-tracking' => array(
                'label' => __('Tracking', 'teamzlab-fedex'),
                'page'  => 'fshipping_tracking_tab',
            ),
            'fshipping-account'  => array(
                'label' => __('Account', 'teamzlab-fedex'),
                'page'  => 'fshipping_account_tab',
            ),
            'fshipping-shipping' => array(
                'label' => __('Shipping', 'teamzlab-fedex'),
                'page'  => 'fshipping_shipping_tab',
            ),
            'fshipping-labling'  => array(
                'label' => __('Labeling', 'teamzlab-fedex'),
                'page'  => 'fshipping_labeling_tab',
            ),
        );
        ?>
        <div class="wrap fshipping-settings">
            <div class="fshipping-page-header">
                <div class="fshipping-page-header__main">
                    <h1 class="fshipping-page-title">
                        <span class="dashicons dashicons-airplane" aria-hidden="true"></span>
                        <?php echo esc_html(get_admin_page_title()); ?>
                    </h1>
                    <p class="fshipping-page-subtitle"><?php echo esc_html__('Connect your FedEx account, choose how labels are created, and tune the shipping methods offered at checkout.', 'teamzlab-fedex'); ?></p>
                </div>
                <div class="fshipping-page-header__aside">
                    <span class="fshipping-badge <?php echo $is_prod ? 'fshipping-badge--orange' : 'fshipping-badge--purple'; ?>">
                        <?php echo esc_html($is_prod ? __('Production', 'teamzlab-fedex') : __('Sandbox', 'teamzlab-fedex')); ?>
                    </span>
                </div>
            </div>

            <div class="fshipping-tabs">
                <div class="fshipping-tab-head" role="tablist" aria-label="<?php echo esc_attr__('FedEx settings sections', 'teamzlab-fedex'); ?>">
                    <?php $is_first = true; foreach ( $tabs as $tab_id => $tab ) : ?>
                        <button
                            type="button"
                            role="tab"
                            data-id="<?php echo esc_attr($tab_id); ?>"
                            id="tab-<?php echo esc_attr($tab_id); ?>"
                            aria-controls="<?php echo esc_attr($tab_id); ?>"
                            aria-selected="<?php echo $is_first ? 'true' : 'false'; ?>"
                            class="<?php echo $is_first ? 'active' : ''; ?>"
                        ><?php echo esc_html($tab['label']); ?></button>
                    <?php $is_first = false; endforeach; ?>
                </div>

                <div class="fshipping-tab-content">
                    <form action="options.php" method="post">
                        <?php settings_fields('fshipping_auth_group'); ?>

                        <?php foreach ( $tabs as $tab_id => $tab ) : ?>
                            <div
                                class="fshipping-tab-content-single<?php echo 'fshipping-auth' === $tab_id ? ' active' : ''; ?>"
                                id="<?php echo esc_attr($tab_id); ?>"
                                role="tabpanel"
                                aria-labelledby="tab-<?php echo esc_attr($tab_id); ?>"
                            >
                                <?php do_settings_sections($tab['page']); ?>
                            </div>
                        <?php endforeach; ?>

                        <div class="fshipping-savebar">
                            <?php submit_button(__('Save Changes', 'teamzlab-fedex'), 'primary', 'submit', false); ?>
                        </div>
                    </form>
                    <?php $this->render_quota_reset_controls(); ?>
                </div>
            </div>
        </div>
        <?php
    }
}