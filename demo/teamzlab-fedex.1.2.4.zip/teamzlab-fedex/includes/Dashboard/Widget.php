<?php
namespace FSHIPPING\Dashboard;

use FSHIPPING\SingletonTrait;

/**
 * Admin dashboard widget — last 10 shipments + their current status.
 *
 * Pulls the latest AIV webhook event from post-meta and falls back to
 * the stored service type if no event has landed yet. Powers the
 * "see your shipments at a glance" admin UX.
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class Widget {
    use SingletonTrait;

    /**
     * Register the dashboard widget.
     *
     * @return void
     * @since 1.1
     */
    public function init() {
        add_action('wp_dashboard_setup', [$this, 'register']);
    }

    /**
     * @return void
     * @since 1.1
     */
    public function register() {
        if (!current_user_can('manage_options')) {
            return;
        }
        wp_add_dashboard_widget(
            'fshipping_recent_shipments',
            __('Recent FedEx shipments', 'teamzlab-fedex'),
            [$this, 'render']
        );
    }

    /**
     * @return void
     * @since 1.1
     */
    public function render() {
        $shipments = get_posts([
            'post_type'      => 'fedex_shipping',
            'post_status'    => 'any',
            'posts_per_page' => 10,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);

        if (empty($shipments)) {
            echo '<p class="fshipping-widget-empty">' . esc_html__('No FedEx shipments yet.', 'teamzlab-fedex') . '</p>';
            return;
        }

        echo '<table class="widefat striped fshipping-widget-table">';
        echo '<thead><tr>';
        echo '<th scope="col">' . esc_html__('Tracking', 'teamzlab-fedex') . '</th>';
        echo '<th scope="col">' . esc_html__('Status', 'teamzlab-fedex') . '</th>';
        echo '<th scope="col">' . esc_html__('Order', 'teamzlab-fedex') . '</th>';
        echo '</tr></thead><tbody>';

        foreach ($shipments as $post) {
            $tracking = get_post_meta($post->ID, '_tracking_number', true);
            $event    = get_post_meta($post->ID, '_fshipping_aiv_last_event', true);
            $status   = is_array($event) && !empty($event['status'])
                ? $event['status']
                : (get_post_meta($post->ID, '_service_type', true) ?: __('Pending', 'teamzlab-fedex'));
            $order_id = get_post_meta($post->ID, '_fedex_shipment_order_id', true);
            $order_url = $order_id ? admin_url('post.php?post=' . (int) $order_id . '&action=edit') : '';
            $badge_class = 'fshipping-status-badge' . $this->status_badge_variant($status);

            echo '<tr>';
            echo '<td class="fshipping-widget-tracking">' . esc_html($tracking ?: '—') . '</td>';
            echo '<td><span class="' . esc_attr($badge_class) . '">' . esc_html($status) . '</span></td>';
            echo '<td>';
            if ($order_url) {
                echo '<a href="' . esc_url($order_url) . '">#' . esc_html((string) $order_id) . '</a>';
            } else {
                echo '—';
            }
            echo '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';

        echo '<p class="fshipping-widget-footer"><a href="' . esc_url(admin_url('edit.php?post_type=fedex_shipping')) . '">'
            . esc_html__('View all shipments', 'teamzlab-fedex') . '</a></p>';
    }

    /**
     * Map a shipment status string to a fshipping-status-badge variant.
     *
     * Checked danger-first so compound labels like "Delivery exception"
     * land on the danger variant, not the ok one. Unrecognized statuses
     * (service-type fallbacks, "Pending", ...) get the neutral default.
     *
     * @param string $status Raw status value from the AIV event or service meta.
     * @return string Empty string for the default variant, else "--ok"/"--info"/"--danger".
     * @since 1.1
     */
    private function status_badge_variant($status) {
        $s = strtolower((string) $status);

        if (strpos($s, 'exception') !== false
            || strpos($s, 'cancel') !== false
            || strpos($s, 'error') !== false
            || strpos($s, 'fail') !== false
            || strpos($s, 'delay') !== false
            || strpos($s, 'return') !== false
        ) {
            return '--danger';
        }

        if (strpos($s, 'deliver') !== false
            || strpos($s, 'ok') !== false
            || strpos($s, 'complete') !== false
            || strpos($s, 'success') !== false
        ) {
            return '--ok';
        }

        if (strpos($s, 'transit') !== false
            || strpos($s, 'info') !== false
            || strpos($s, 'pickup') !== false
            || strpos($s, 'shipped') !== false
            || strpos($s, 'label') !== false
        ) {
            return '--info';
        }

        return '';
    }
}
