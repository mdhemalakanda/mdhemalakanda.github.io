<?php
namespace Teamz\Wp\Kit\Traits;

defined( 'ABSPATH' ) || exit;

/**
 * Compatibility fallback for kit LogsHttp trait.
 */
trait LogsHttp {
    /** @var string */
    protected $log_source = 'fshipping_http';

    /**
     * @param string $message
     * @param mixed  $context
     * @return void
     */
    protected function log( $message, $context = null ) {
        // Intentionally no-op: checkout FedEx rates log only (see HTTP\Shipping teamzlab_fedex_shippnig).
    }
}
