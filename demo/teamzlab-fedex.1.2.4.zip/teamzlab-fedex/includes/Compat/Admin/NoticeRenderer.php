<?php
namespace Teamz\Wp\Kit\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Compatibility fallback for Teamz kit admin notices.
 */
class NoticeRenderer {
    /**
     * @param string $message
     * @return void
     */
    public static function success( string $message ): void {
        self::render( 'success', $message );
    }

    /**
     * @param string $message
     * @return void
     */
    public static function error( string $message ): void {
        self::render( 'error', $message );
    }

    /**
     * @param string $type
     * @param string $message
     * @return void
     */
    private static function render( string $type, string $message ): void {
        printf(
            '<div class="notice notice-%1$s"><p>%2$s</p></div>',
            esc_attr( $type ),
            wp_kses_post( $message )
        );
    }
}
