<?php
namespace Teamz\Wp\Kit\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * Compatibility fallback for Teamz kit status badges.
 */
class StatusBadge {
    /**
     * Render a small status badge.
     *
     * @param string $type
     * @param string $label
     * @return string
     */
    public static function render( string $type, string $label ): string {
        $colors = array(
            'success' => '#46b450',
            'warning' => '#ffb900',
            'danger'  => '#dc3232',
            'error'   => '#dc3232',
            'info'    => '#2271b1',
        );

        $color = $colors[ $type ] ?? $colors['info'];

        return sprintf(
            '<span style="%s">%s</span>',
            esc_attr( 'display:inline-block;padding:2px 8px;border-radius:999px;font-size:12px;font-weight:600;background:' . $color . ';color:#fff;' ),
            esc_html( $label )
        );
    }
}
