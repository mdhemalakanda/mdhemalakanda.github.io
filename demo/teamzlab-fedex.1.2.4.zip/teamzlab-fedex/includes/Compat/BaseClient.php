<?php
namespace Teamz\Wp\Kit\Http;

defined( 'ABSPATH' ) || exit;

/**
 * Compatibility HTTP base client when Teamz kit is not bundled.
 *
 * This keeps plugin API classes operational in builds that do not include
 * the ./kit submodule.
 */
abstract class BaseClient {
    protected string $log_source = 'fshipping_http';
    /**
     * Kept for compatibility with tests that reset singleton instance
     * via Reflection on concrete HTTP classes.
     *
     * @var static|null
     */
    protected static $instance = null;

    /**
     * Shared singleton accessor used by plugin call sites.
     *
     * @return static
     */
    public static function instance() {
        if ( ! ( static::$instance instanceof static ) ) {
            static::$instance = new static();
        }

        return static::$instance;
    }

    /**
     * @return string
     */
    abstract protected function base_url(): string;

    /**
     * @return string
     */
    abstract protected function auth_header(): string;

    /**
     * Build request headers.
     *
     * @param string $auth
     * @return array
     */
    protected function build_headers( string $auth ): array {
        $headers = array(
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
        );

        if ( ! empty( $auth ) ) {
            $headers['Authorization'] = $auth;
        }

        return $headers;
    }

    /**
     * Send HTTP request and decode JSON response to array.
     *
     * @param string $method
     * @param string $endpoint
     * @param array  $payload
     * @return array
     */
    protected function request( string $method, string $endpoint, array $payload = array() ): array {
        $method = strtoupper( $method );
        $url    = rtrim( $this->base_url(), '/' ) . '/' . ltrim( $endpoint, '/' );
        $auth   = $this->auth_header();
        $args   = array(
            'method'  => $method,
            'headers' => $this->build_headers( $auth ),
            'timeout' => 45,
        );

        if ( 'GET' === $method ) {
            if ( ! empty( $payload ) ) {
                $url = add_query_arg( $payload, $url );
            }
        } else {
            $args['body'] = wp_json_encode( $payload );
        }

        $response = wp_remote_request( $url, $args );

        if ( is_wp_error( $response ) ) {
            return array(
                'errors' => array(
                    array(
                        'code'    => 'wp_http_error',
                        'message' => $response->get_error_message(),
                    ),
                ),
            );
        }

        $status  = isset( $response['response']['code'] ) ? (int) $response['response']['code'] : 0;
        if ( 0 === $status && function_exists( 'wp_remote_retrieve_response_code' ) ) {
            $status = (int) wp_remote_retrieve_response_code( $response );
        }
        $body    = wp_remote_retrieve_body( $response );
        $decoded = json_decode( (string) $body, true );

        if ( ! is_array( $decoded ) ) {
            $decoded = array();
        }

        if ( $status < 200 || $status >= 300 ) {
            if ( empty( $decoded['errors'] ) ) {
                $decoded['errors'] = array(
                    array(
                        'code'    => 'http_error',
                        'message' => sprintf( 'HTTP %d from FedEx API.', $status ),
                    ),
                );
            }
        }

        return $decoded;
    }

    /**
     * @param string $endpoint
     * @param array  $payload
     * @return array
     */
    protected function post( string $endpoint, array $payload = array() ): array {
        return $this->request( 'POST', $endpoint, $payload );
    }

    /**
     * @param string $endpoint
     * @param array  $query
     * @return array
     */
    protected function get( string $endpoint, array $query = array() ): array {
        return $this->request( 'GET', $endpoint, $query );
    }
}
