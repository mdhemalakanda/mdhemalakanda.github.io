<?php
namespace FSHIPPING\Schedule;

use FSHIPPING\SingletonTrait;

/**
 * This class will help to schedule an event or hook.
 * 
 * @since 1.0
 */
defined('ABSPATH') || exit;

class Shipment {
    use SingletonTrait;

    public function init() {
        add_action('fshipping_send_shipment_confirmation_mail', array($this, 'send_shipment_confirmation_mail'), 10, 2);
    }

    /**
     * Send shipment confirmation mail.
     * 
     * @param mixed $post_id This will store created shipment post id.
     * @param mixed $api_data This will be data comming from fexex api.
     * @return void
     */
    public function send_shipment_confirmation_mail($post_id, $api_data) {
        if ( ! wp_next_scheduled('fshipping_send_shipment_email', array($post_id, $api_data)) ) {
            wp_schedule_single_event(
                time() + 300,
                'fshipping_send_shipment_email',
                array(
                    $post_id,
                    $api_data
                )
            );
        }
    }
}