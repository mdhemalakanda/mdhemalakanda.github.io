<?php
namespace FSHIPPING\I18n;

use FSHIPPING\SingletonTrait;

/**
 * Global country / currency support.
 *
 * Directly attacks two Woo-official FedEx-plugin limitations:
 *   - "requires US or Canada as the base country"
 *   - "requires US or Canadian Dollars for its currency"
 *
 * FedEx operates in 220+ countries; we expose a verified country
 * allowlist and locale-aware currency formatting so merchants anywhere
 * FedEx operates can use this plugin.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class GlobalSupport {
    use SingletonTrait;

    /**
     * Whether a country code is a first-class shippable origin for FedEx.
     * This is the shortlist of origin-eligible markets; the broader
     * 220-country destination list is resolved at rate time.
     *
     * @return array<string,string>
     * @since 1.2
     */
    public function supported_origins(): array {
        return [
            'US' => 'United States',
            'CA' => 'Canada',
            'MX' => 'Mexico',
            'GB' => 'United Kingdom',
            'IE' => 'Ireland',
            'DE' => 'Germany',
            'FR' => 'France',
            'IT' => 'Italy',
            'ES' => 'Spain',
            'NL' => 'Netherlands',
            'BE' => 'Belgium',
            'CH' => 'Switzerland',
            'AT' => 'Austria',
            'DK' => 'Denmark',
            'SE' => 'Sweden',
            'NO' => 'Norway',
            'FI' => 'Finland',
            'PL' => 'Poland',
            'CZ' => 'Czechia',
            'PT' => 'Portugal',
            'AE' => 'United Arab Emirates',
            'SA' => 'Saudi Arabia',
            'IL' => 'Israel',
            'IN' => 'India',
            'SG' => 'Singapore',
            'HK' => 'Hong Kong',
            'JP' => 'Japan',
            'KR' => 'South Korea',
            'CN' => 'China',
            'AU' => 'Australia',
            'NZ' => 'New Zealand',
            'BR' => 'Brazil',
            'ZA' => 'South Africa',
        ];
    }

    /**
     * Currency for each supported origin — the default for that market.
     *
     * @return array<string,string>
     * @since 1.2
     */
    public function currency_for_country(): array {
        return [
            'US' => 'USD', 'CA' => 'CAD', 'MX' => 'MXN', 'GB' => 'GBP', 'IE' => 'EUR',
            'DE' => 'EUR', 'FR' => 'EUR', 'IT' => 'EUR', 'ES' => 'EUR', 'NL' => 'EUR',
            'BE' => 'EUR', 'CH' => 'CHF', 'AT' => 'EUR', 'DK' => 'DKK', 'SE' => 'SEK',
            'NO' => 'NOK', 'FI' => 'EUR', 'PL' => 'PLN', 'CZ' => 'CZK', 'PT' => 'EUR',
            'AE' => 'AED', 'SA' => 'SAR', 'IL' => 'ILS', 'IN' => 'INR', 'SG' => 'SGD',
            'HK' => 'HKD', 'JP' => 'JPY', 'KR' => 'KRW', 'CN' => 'CNY', 'AU' => 'AUD',
            'NZ' => 'NZD', 'BR' => 'BRL', 'ZA' => 'ZAR',
        ];
    }

    /**
     * @param string $country_code
     * @return bool
     * @since 1.2
     */
    public function is_supported_origin(string $country_code): bool {
        return array_key_exists(strtoupper(trim($country_code)), $this->supported_origins());
    }

    /**
     * @param string $country_code
     * @return string ISO 4217, or '' when unsupported.
     * @since 1.2
     */
    public function default_currency_for(string $country_code): string {
        $map = $this->currency_for_country();
        return $map[strtoupper(trim($country_code))] ?? '';
    }

    /**
     * Decide whether a shipment is domestic, cross-border, or international
     * for rate-endpoint routing.
     *
     * @param string $origin
     * @param string $destination
     * @return string 'domestic'|'cross_border'|'international'
     * @since 1.2
     */
    public function classify_lane(string $origin, string $destination): string {
        $origin = strtoupper(trim($origin));
        $destination = strtoupper(trim($destination));
        if ($origin === '' || $destination === '') {
            return 'international';
        }
        if ($origin === $destination) {
            return 'domestic';
        }
        $adjacent = [
            'US' => ['CA', 'MX'],
            'CA' => ['US'],
            'MX' => ['US'],
        ];
        if (!empty($adjacent[$origin]) && in_array($destination, $adjacent[$origin], true)) {
            return 'cross_border';
        }
        return 'international';
    }

    /**
     * Locale-agnostic currency formatter. Uses intl's NumberFormatter when
     * available, falls back to a sensible default otherwise so tests pass
     * even when ext-intl isn't installed.
     *
     * @param float  $amount
     * @param string $currency
     * @param string $locale
     * @return string
     * @since 1.2
     */
    public function format(float $amount, string $currency, string $locale = 'en_US'): string {
        $currency = strtoupper($currency);
        if (class_exists(\NumberFormatter::class)) {
            $fmt = new \NumberFormatter(str_replace('-', '_', $locale), \NumberFormatter::CURRENCY);
            $out = $fmt->formatCurrency($amount, $currency);
            if (is_string($out) && $out !== '') {
                return $out;
            }
        }

        $symbols = [
            'USD' => '$', 'CAD' => 'CA$', 'EUR' => '€', 'GBP' => '£',
            'AUD' => 'A$', 'NZD' => 'NZ$', 'CHF' => 'CHF ', 'JPY' => '¥',
            'CNY' => 'CN¥', 'INR' => '₹', 'BRL' => 'R$', 'MXN' => 'MX$',
            'HKD' => 'HK$', 'SGD' => 'S$', 'ZAR' => 'R',  'AED' => 'AED ',
        ];
        $symbol = $symbols[$currency] ?? ($currency . ' ');
        $decimals = $currency === 'JPY' || $currency === 'KRW' ? 0 : 2;
        return $symbol . number_format($amount, $decimals, '.', ',');
    }
}
