<?php
namespace FSHIPPING\Events;

use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\OrderMeta;

/**
 * Injects FedEx specialServicesRequested blocks + third-party billing
 * into the Ship payload, driven by plugin settings and per-order meta.
 *
 * Hooks the fshipping_ship_payload filter exposed by HTTP\Shipment.
 * One class covers every special-service vertical because they all
 * flow through the same FedEx payload key:
 *
 *   SATURDAY_DELIVERY
 *   SIGNATURE_OPTION  — DIRECT_SIGNATURE_REQUIRED / ADULT signature / etc.
 *   DANGEROUS_GOODS   — hazmat
 *   DRY_ICE
 *   ALCOHOL
 *   COD               — Collect on Delivery
 *   HOLD_AT_LOCATION  — label destined for a FedEx Office
 *
 * Plus `shippingChargesPayment` override for third-party billing.
 *
 * Global defaults (fshipping_options; no longer on **Fedex → Settings** UI — set via existing DB values, `update_option`, or WP-CLI):
 *   fshipping_saturday_delivery       (checkbox)
 *   fshipping_signature_option        (select: 'NONE'|'DIRECT'|'ADULT'|'INDIRECT')
 *   fshipping_third_party_account     (text — account number)
 *
 * Per-order overrides via post-meta on the WC order:
 *   _fshipping_hazmat                 (1 = enable dangerous goods)
 *   _fshipping_alcohol                (1 = enable alcohol + adult signature)
 *   _fshipping_dry_ice                (1 = enable dry ice)
 *   _fshipping_dry_ice_weight         (float, kg of dry ice)
 *   _fshipping_cod_amount             (float, currency)
 *   _fshipping_cod_type               ('ANY' | 'GUARANTEED_FUNDS' | 'CASH')
 *   _fshipping_hold_at_location_id    (FedEx location id)
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class SpecialServicesInjector {
    use SingletonTrait;

    /**
     * @return void
     * @since 1.2
     */
    public function init() {
        add_filter('fshipping_ship_payload', [$this, 'inject'], 10, 3);
    }

    /**
     * @param array $payload
     * @param \WC_Order|null $order
     * @param array $current_shipment
     * @return array
     * @since 1.2
     */
    public function inject(array $payload, $order, array $current_shipment): array {
        if (empty($payload['requestedShipment'])) {
            return $payload;
        }

        $settings = get_option('fshipping_options');
        $services = [];

        // Saturday delivery (settings-wide default; can also be set per-order).
        $saturday = !empty($settings['fshipping_saturday_delivery'])
            || ($order && '1' === (string) $order->get_meta('_fshipping_saturday_delivery'));
        if ($saturday) {
            $services[] = 'SATURDAY_DELIVERY';
        }

        // Signature option → specialServicesRequested + signatureOptionDetail.
        $sig_source = '';
        if ($order && !empty($order->get_meta('_fshipping_signature_option'))) {
            $sig_source = sanitize_text_field((string) $order->get_meta('_fshipping_signature_option'));
        } elseif (!empty($settings['fshipping_signature_option'])) {
            $sig_source = sanitize_text_field((string) $settings['fshipping_signature_option']);
        }
        if ($sig_source && $sig_source !== 'NONE') {
            $services[] = 'SIGNATURE_OPTION';
            $payload['requestedShipment']['shipmentSpecialServiceDetail']['signatureOptionDetail'] = [
                'optionType' => $this->resolve_signature_option($sig_source),
            ];
        }

        // --- Per-order vertical toggles ----------------------------------
        if ($order) {
            $order_id = $order->get_id();

            // Hazmat / Dangerous Goods
            if ('1' === (string) OrderMeta::get($order_id, '_fshipping_hazmat')) {
                $services[] = 'DANGEROUS_GOODS';
                $payload['requestedShipment']['shipmentSpecialServiceDetail']['dangerousGoodsDetail'] = [
                    'accessibility' => 'ACCESSIBLE',
                    'options'       => ['HAZARDOUS_MATERIALS'],
                ];
            }

            // Alcohol → requires ADULT signature
            if ('1' === (string) OrderMeta::get($order_id, '_fshipping_alcohol')) {
                $services[] = 'ALCOHOL';
                $payload['requestedShipment']['shipmentSpecialServiceDetail']['alcoholDetail'] = [
                    'alcoholRecipientType'  => 'CONSUMER',
                ];
                // Force adult signature.
                if (!in_array('SIGNATURE_OPTION', $services, true)) {
                    $services[] = 'SIGNATURE_OPTION';
                }
                $payload['requestedShipment']['shipmentSpecialServiceDetail']['signatureOptionDetail'] = [
                    'optionType' => 'ADULT',
                ];
            }

            // Dry ice
            if ('1' === (string) OrderMeta::get($order_id, '_fshipping_dry_ice')) {
                $services[] = 'DRY_ICE';
                $weight_kg = (float) OrderMeta::get($order_id, '_fshipping_dry_ice_weight');
                $payload['requestedShipment']['shipmentSpecialServiceDetail']['dryIceDetail'] = [
                    'totalWeight'  => ['units' => 'KG', 'value' => (string) ($weight_kg ?: 1)],
                    'packageCount' => 1,
                ];
            }

            // COD
            $cod_amount = (float) OrderMeta::get($order_id, '_fshipping_cod_amount');
            if ($cod_amount > 0) {
                $services[] = 'COD';
                $payload['requestedShipment']['shipmentSpecialServiceDetail']['shipmentCODDetail'] = [
                    'codCollectionAmount' => [
                        'amount'   => $cod_amount,
                        'currency' => sanitize_text_field((string) $order->get_currency()),
                    ],
                    'codCollectionType' => sanitize_text_field((string) OrderMeta::get($order_id, '_fshipping_cod_type')) ?: 'ANY',
                ];
            }

            // Hold at Location (as a delivery destination)
            $hal_location = sanitize_text_field((string) OrderMeta::get($order_id, '_fshipping_hold_at_location_id'));
            if (!empty($hal_location)) {
                $services[] = 'HOLD_AT_LOCATION';
                $payload['requestedShipment']['shipmentSpecialServiceDetail']['holdAtLocationDetail'] = [
                    'locationId'   => $hal_location,
                    'locationType' => 'FEDEX_OFFICE',
                ];
            }
        }

        // Write the final special-services list if any were added.
        if (!empty($services)) {
            $payload['requestedShipment']['shipmentSpecialServiceDetail']['specialServiceTypes']
                = array_values(array_unique($services));
        }

        // Third-party billing — overrides shippingChargesPayment payor.
        if (!empty($settings['fshipping_third_party_account'])) {
            $third_party = sanitize_text_field((string) $settings['fshipping_third_party_account']);
            $payload['requestedShipment']['shippingChargesPayment'] = [
                'paymentType' => 'THIRD_PARTY',
                'payor' => [
                    'responsibleParty' => [
                        'accountNumber' => ['value' => $third_party],
                    ],
                ],
            ];
        }

        return $payload;
    }

    /**
     * Map a friendly signature name to FedEx's enum.
     *
     * @param string $name
     * @return string
     * @since 1.2
     */
    private function resolve_signature_option(string $name): string {
        $name = strtoupper($name);
        switch ($name) {
            case 'DIRECT':         return 'DIRECT';
            case 'ADULT':          return 'ADULT';
            case 'INDIRECT':       return 'INDIRECT';
            case 'NO_SIGNATURE_REQUIRED':
            case 'NONE':           return 'NO_SIGNATURE_REQUIRED';
            default:               return 'SERVICE_DEFAULT';
        }
    }
}
