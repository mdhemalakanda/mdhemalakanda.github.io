<?php
namespace FSHIPPING\Events;

use FSHIPPING\Boxing\BoxCatalog;
use FSHIPPING\Boxing\BoxPacker;
use FSHIPPING\Boxing\UnitConverter;
use FSHIPPING\OpenShip\Draft;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\OrderMeta;

/**
 * Inject Product Box package line items into Ship payload.
 *
 * @since 1.9
 */
defined('ABSPATH') || exit;

class ProductBoxPayloadInjector
{
    use SingletonTrait;

    public const SHIP_PRIORITY = 35;

    /**
     * @return void
     */
    public function init()
    {
        add_filter('fshipping_ship_payload', [$this, 'inject'], self::SHIP_PRIORITY, 3);
    }

    /**
     * @param array $payload
     * @param mixed $order
     * @param array $current_shipment
     * @return array
     */
    public function inject(array $payload, $order, array $current_shipment): array
    {
        unset($current_shipment);
        if (empty($payload['requestedShipment']) || !is_array($payload['requestedShipment']) || !is_object($order) || !method_exists($order, 'get_items')) {
            return $payload;
        }

        $catalog = BoxCatalog::instance()->get();
        $boxes = isset($catalog['boxes']) && is_array($catalog['boxes']) ? $catalog['boxes'] : [];
        if (empty($boxes)) {
            return $payload;
        }

        $weight_unit = isset($catalog['weight_output_unit']) ? strtoupper((string) $catalog['weight_output_unit']) : 'KG';
        if (!in_array($weight_unit, ['KG', 'LB'], true)) {
            $weight_unit = 'KG';
        }
        // Ship API package lines always store box size in inches; values in CM (or per-box unit) are converted here.
        $ship_line_dimension_unit = 'IN';

        $order_items = $this->build_order_items($order, $weight_unit);
        if (empty($order_items)) {
            return $payload;
        }

        $packed = BoxPacker::instance()->pack($order_items, $catalog);
        $matched = isset($packed['matched_packages']) && is_array($packed['matched_packages']) ? $packed['matched_packages'] : [];
        $unmatched = isset($packed['unmatched_items']) && is_array($packed['unmatched_items']) ? $packed['unmatched_items'] : [];
        $this->log_packing_summary($order, $matched, $unmatched);
        if (empty($matched)) {
            return $payload;
        }

        $existing_line_items = isset($payload['requestedShipment']['requestedPackageLineItems']) && is_array($payload['requestedShipment']['requestedPackageLineItems'])
            ? $payload['requestedShipment']['requestedPackageLineItems']
            : [];

        $new_line_items = [];
        $box_name_map = [];
        $sequence = 1;
        $currency = is_object($order) && method_exists($order, 'get_currency') ? (string) $order->get_currency() : 'USD';
        if ($currency === '') {
            $currency = 'USD';
        }
        $order_products_total = 0.0;
        foreach ($order_items as $order_item) {
            if (!is_array($order_item)) {
                continue;
            }
            $qty = isset($order_item['qty']) ? (int) $order_item['qty'] : 0;
            $unit_price = isset($order_item['unit_price']) && is_numeric($order_item['unit_price']) ? (float) $order_item['unit_price'] : 0.0;
            if ($qty > 0 && $unit_price > 0) {
                $order_products_total += ($qty * $unit_price);
            }
        }
        $matched_products_total = 0.0;
        $box_occurrence_map = [];
        $display_rows = [];
        foreach ($matched as $pkg) {
            if (!is_array($pkg) || empty($pkg['dimensions']) || empty($pkg['weight'])) {
                continue;
            }
            $dimensions = $pkg['dimensions'];
            $weight = $pkg['weight'];
            $from_dimension_unit = strtoupper((string) ($dimensions['units'] ?? $ship_line_dimension_unit));
            if (!in_array($from_dimension_unit, ['CM', 'IN'], true)) {
                $from_dimension_unit = 'IN';
            }
            $length = UnitConverter::instance()->convert_dimension((float) ($dimensions['length'] ?? 0), $from_dimension_unit, $ship_line_dimension_unit);
            $width = UnitConverter::instance()->convert_dimension((float) ($dimensions['width'] ?? 0), $from_dimension_unit, $ship_line_dimension_unit);
            $height = UnitConverter::instance()->convert_dimension((float) ($dimensions['height'] ?? 0), $from_dimension_unit, $ship_line_dimension_unit);
            $line = [
                'sequenceNumber' => (string) $sequence,
                'weight' => [
                    'units' => strtoupper((string) ($weight['units'] ?? $weight_unit)),
                    'value' => isset($weight['value']) ? round((float) $weight['value'], 3) : 0.0,
                ],
                'dimensions' => [
                    'length' => round($length, 2),
                    'width' => round($width, 2),
                    'height' => round($height, 2),
                    'units' => $ship_line_dimension_unit,
                ],
            ];
            $price_breakdown = isset($pkg['price_breakdown']) && is_array($pkg['price_breakdown']) ? $pkg['price_breakdown'] : [];
            $line_declared = isset($price_breakdown['products_price']) && is_numeric($price_breakdown['products_price'])
                ? round((float) $price_breakdown['products_price'], 2)
                : 0.0;
            if ($line_declared > 0) {
                $line['declaredValue'] = [
                    'amount' => $line_declared,
                    'currency' => $currency,
                ];
                $matched_products_total += $line_declared;
            }
            if ($line['weight']['value'] <= 0 || $line['dimensions']['length'] <= 0 || $line['dimensions']['width'] <= 0 || $line['dimensions']['height'] <= 0) {
                continue;
            }
            $new_line_items[] = $line;
            $box_name = isset($pkg['box_name']) ? trim((string) $pkg['box_name']) : '';
            if ($box_name !== '') {
                $box_name_map[(string) $sequence] = sanitize_text_field($box_name);
            }

            $box_label_base = $box_name !== '' ? $box_name : __('Unnamed', 'teamzlab-fedex');
            $box_key = strtolower($box_label_base);
            if (!isset($box_occurrence_map[$box_key])) {
                $box_occurrence_map[$box_key] = 0;
            }
            $box_occurrence_map[$box_key]++;
            $box_title = sprintf(
                /* translators: 1: configured box name 2: occurrence index for that name */
                __('%1$s Box %2$d', 'teamzlab-fedex'),
                $box_label_base,
                (int) $box_occurrence_map[$box_key]
            );
            $product_lines = [];
            $pkg_products = isset($pkg['products']) && is_array($pkg['products']) ? $pkg['products'] : [];
            foreach ($pkg_products as $product_row) {
                if (!is_array($product_row)) {
                    continue;
                }
                $pqty = isset($product_row['qty']) ? (int) $product_row['qty'] : 0;
                if ($pqty < 1) {
                    continue;
                }
                $pname = isset($product_row['product_name']) ? trim((string) $product_row['product_name']) : '';
                if ($pname === '') {
                    $pname = 'Product #' . (int) ($product_row['product_id'] ?? 0);
                }
                $product_lines[] = [
                    'name' => sanitize_text_field($pname),
                    'qty' => $pqty,
                ];
            }
            $display_rows[] = [
                'box' => sanitize_text_field($box_title),
                'products' => $product_lines,
            ];

            $sequence++;
        }

        if (empty($new_line_items)) {
            return $payload;
        }

        if (!empty($unmatched) && !empty($existing_line_items[0]) && is_array($existing_line_items[0])) {
            $fallback = $existing_line_items[0];
            $fallback['sequenceNumber'] = (string) $sequence;
            $fallback_declared = round(max(0.0, $order_products_total - $matched_products_total), 2);
            if ($fallback_declared > 0) {
                $fallback['declaredValue'] = [
                    'amount' => $fallback_declared,
                    'currency' => $currency,
                ];
            }
            $new_line_items[] = $fallback;

            $fb_products = [];
            foreach ($unmatched as $u) {
                if (!is_array($u)) {
                    continue;
                }
                $uqty = isset($u['qty']) ? (int) $u['qty'] : 0;
                if ($uqty < 1) {
                    continue;
                }
                $uname = isset($u['product_name']) ? trim((string) $u['product_name']) : '';
                if ($uname === '') {
                    $uname = 'Product #' . (int) ($u['product_id'] ?? 0);
                }
                $fb_products[] = [
                    'name' => sanitize_text_field($uname),
                    'qty' => $uqty,
                ];
            }
            if (!empty($fb_products)) {
                $display_rows[] = [
                    'box' => sanitize_text_field(__('Other items (fallback package)', 'teamzlab-fedex')),
                    'products' => $fb_products,
                ];
            }
        }

        $payload['requestedShipment']['requestedPackageLineItems'] = $new_line_items;
        $payload['requestedShipment']['totalPackageCount'] = count($new_line_items);
        $this->persist_product_box_display($order, $display_rows);
        $this->persist_box_name_sequence_map($order, $box_name_map);

        return $payload;
    }

    /**
     * Persist human-readable box → product rows for admin Shipments list column.
     *
     * @param mixed                       $order
     * @param array<int,array<string,mixed>> $rows
     * @return void
     */
    private function persist_product_box_display($order, array $rows): void
    {
        if (!is_object($order) || !method_exists($order, 'get_id')) {
            return;
        }
        $order_id = (int) $order->get_id();
        if ($order_id <= 0) {
            return;
        }
        if (empty($rows)) {
            OrderMeta::delete($order_id, Draft::META_PRODUCT_BOX_DISPLAY);
            return;
        }
        OrderMeta::update($order_id, Draft::META_PRODUCT_BOX_DISPLAY, wp_json_encode($rows));
    }

    /**
     * @param mixed                     $order
     * @param array<string,string>      $box_name_map
     * @return void
     */
    private function persist_box_name_sequence_map($order, array $box_name_map): void
    {
        if (!is_object($order) || !method_exists($order, 'get_id')) {
            return;
        }
        $order_id = (int) $order->get_id();
        if ($order_id <= 0) {
            return;
        }
        if (empty($box_name_map)) {
            OrderMeta::delete($order_id, Draft::META_PACKAGE_BOX_NAME_MAP);
            return;
        }
        OrderMeta::update($order_id, Draft::META_PACKAGE_BOX_NAME_MAP, wp_json_encode($box_name_map));
    }

    /**
     * @param mixed  $order
     * @param string $target_weight_unit
     * @return array<int,array<string,mixed>>
     */
    private function build_order_items($order, string $target_weight_unit): array
    {
        $items = [];
        foreach ((array) $order->get_items() as $item) {
            if (!is_object($item) || !method_exists($item, 'get_product')) {
                continue;
            }
            $product = $item->get_product();
            if (!is_object($product) || !method_exists($product, 'get_id')) {
                continue;
            }
            $product_id = (int) $product->get_id();
            $product_name = method_exists($product, 'get_name') ? (string) $product->get_name() : '';
            $qty = method_exists($item, 'get_quantity') ? (int) $item->get_quantity() : 0;
            $raw_weight = method_exists($product, 'get_weight') ? $product->get_weight() : 0;
            $unit_weight = UnitConverter::instance()->normalize_store_weight_to_target($raw_weight, $target_weight_unit);
            $line_subtotal = method_exists($item, 'get_subtotal') ? (float) $item->get_subtotal() : 0.0;
            if ($line_subtotal <= 0 && method_exists($item, 'get_total')) {
                $line_subtotal = (float) $item->get_total();
            }
            $unit_price = 0.0;
            if ($qty > 0 && $line_subtotal > 0) {
                $unit_price = $line_subtotal / $qty;
            } elseif (method_exists($product, 'get_price')) {
                $unit_price = (float) $product->get_price();
            }
            if ($product_id < 1 || $qty < 1 || $unit_weight <= 0) {
                continue;
            }
            $items[] = [
                'product_id' => $product_id,
                'product_name' => sanitize_text_field($product_name),
                'qty' => $qty,
                'unit_weight' => $unit_weight,
                'unit_price' => round(max(0.0, $unit_price), 4),
            ];
        }

        return $items;
    }

    /**
     * @param mixed $order
     * @param array<int,array<string,mixed>> $matched
     * @param array<int,array<string,mixed>> $unmatched
     * @return void
     */
    private function log_packing_summary($order, array $matched, array $unmatched): void
    {
        unset($order, $matched, $unmatched);
    }
}


