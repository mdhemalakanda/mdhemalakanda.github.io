<?php
namespace FSHIPPING\Events;

use FSHIPPING\HTTP\GlobalTrade;
use FSHIPPING\HTTP\TradeDocuments;
use FSHIPPING\SingletonTrait;

/**
 * ETD (Electronic Trade Documents) orchestrator.
 *
 * "ETD paperless" is the ability to submit customs paperwork
 * digitally instead of printing + stapling to the box. It's a
 * three-step dance FedEx doesn't wrap in one endpoint, so this
 * class stitches them together:
 *
 *   1. GlobalTrade::check_compliance() — figure out which documents
 *      customs requires for this origin/destination/commodity set.
 *   2. TradeDocuments::upload() — push each required doc electronically.
 *   3. Populate the Ship payload's electronicTradeDocuments block via
 *      the fshipping_ship_payload filter so the Ship call references
 *      the uploaded document ids.
 *
 * Runs on woocommerce_checkout_order_processed at priority 15 — after
 * ShipmentGuard (10) and before Frontend\Checkout's Ship call (20).
 *
 * This is opt-in: the merchant must attach the commercial invoice PDF
 * to the order post-meta `_fshipping_etd_invoice_path` (absolute file
 * path). If the meta is empty, the orchestrator is a noop.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class ETDOrchestrator {
    use SingletonTrait;

    /**
     * @return void
     * @since 1.2
     */
    public function init() {
        add_action('woocommerce_checkout_order_processed', [$this, 'handle'], 15, 1);
        add_filter('fshipping_ship_payload',               [$this, 'inject'], 20, 3);
    }

    /**
     * After checkout, run Global Trade + Trade Documents Upload if the
     * merchant has attached ETD paperwork to the order.
     *
     * @param int $order_id
     * @return void
     * @since 1.2
     */
    public function handle($order_id): void {
        $order_id = (int) $order_id;
        $this->trace(2, $order_id, 'ETD_ORCHESTRATOR_ENTRY');
        $order    = function_exists('wc_get_order') ? wc_get_order($order_id) : null;
        if (empty($order)) {
            $this->trace(5, $order_id, 'ETD_ORCHESTRATOR_DECISION', ['decision' => 'ALLOW', 'reason' => 'order_not_found']);
            return;
        }

        $invoice_path = sanitize_text_field((string) get_post_meta($order_id, '_fshipping_etd_invoice_path', true));
        if (empty($invoice_path) || !file_exists($invoice_path)) {
            $this->trace(5, $order_id, 'ETD_ORCHESTRATOR_DECISION', ['decision' => 'ALLOW', 'reason' => 'invoice_path_missing']);
            return;
        }

        $dest_country = $order->get_shipping_country() ?: $order->get_billing_country();
        $settings     = get_option('fshipping_options');
        $origin       = sanitize_text_field((string) ($settings['fshipping_country_code'] ?? 'US'));
        if (empty($dest_country) || $origin === $dest_country) {
            $this->trace(
                5,
                $order_id,
                'ETD_ORCHESTRATOR_DECISION',
                ['decision' => 'ALLOW', 'reason' => 'domestic_lane', 'origin_country' => $origin, 'dest_country' => $dest_country]
            );
            return;
        }

        // 1. Global Trade — what docs does customs require?
        $required_docs = ['COMMERCIAL_INVOICE'];
        $compliance    = GlobalTrade::instance()->check_compliance([
            'order_id'     => $order_id,
            'origin'       => ['country' => $origin],
            'destination'  => ['country' => $dest_country],
            'commodities'  => [[
                'description' => sanitize_text_field((string) $order->get_items()[array_key_first($order->get_items())]->get_name()),
                'quantity'    => 1,
                'weight'      => 1,
            ]],
            'customs_value' => (float) $order->get_total(),
            'currency'      => sanitize_text_field((string) $order->get_currency()),
        ]);
        $this->trace(4, $order_id, 'ETD_GLOBAL_TRADE_COMPLIANCE', ['response' => $compliance]);
        foreach ((array) ($compliance['documentsRequired'] ?? []) as $doc) {
            $type = sanitize_text_field((string) (is_array($doc) ? ($doc['documentType'] ?? '') : $doc));
            if (!empty($type) && !in_array($type, $required_docs, true)) {
                $required_docs[] = $type;
            }
        }

        // 2. Upload each doc we have on hand. The merchant's commercial
        //    invoice is always the commercial invoice; any additional
        //    required doc type falls through and will need a merchant
        //    follow-up.
        $documents = [[
            'path'        => $invoice_path,
            'type'        => 'COMMERCIAL_INVOICE',
            /* translators: %s: WooCommerce order number. */
            'description' => sprintf(__('Commercial invoice for order %s', 'teamzlab-fedex'), $order->get_order_number()),
        ]];

        $upload = TradeDocuments::instance()->upload($documents, [
            'shipment_id'         => (string) $order_id,
            'origin_country'      => $origin,
            'destination_country' => $dest_country,
        ]);
        $this->trace(4, $order_id, 'ETD_TRADE_DOCS_UPLOAD_RESPONSE', ['response' => $upload]);

        $uploaded_ids = [];
        foreach ((array) ($upload['meta'] ?? []) as $row) {
            $id = sanitize_text_field((string) ($row['uploadedDocumentId'] ?? ''));
            if (!empty($id)) {
                $uploaded_ids[] = $id;
            }
        }

        if (empty($uploaded_ids)) {
            $order->add_order_note(
                __('ETD: Trade Documents Upload returned no document ids; falling back to paper customs paperwork.', 'teamzlab-fedex'),
                false
            );
            $this->trace(5, $order_id, 'ETD_ORCHESTRATOR_DECISION', ['decision' => 'FAIL-OPEN', 'reason' => 'no_uploaded_document_ids']);
            return;
        }

        // 3. Stash the ids on post-meta so inject() can pick them up
        //    when fshipping_ship_payload fires a few seconds later.
        update_post_meta($order_id, '_fshipping_etd_document_ids', $uploaded_ids);

        $missing = array_diff($required_docs, ['COMMERCIAL_INVOICE']);
        if (!empty($missing)) {
            $order->add_order_note(
                sprintf(
                    /* translators: %s is a comma-separated list of document types */
                    __('ETD: commercial invoice uploaded. Still need: %s — upload via the Trade Documents Upload UI before customs clearance.', 'teamzlab-fedex'),
                    implode(', ', $missing)
                ),
                false
            );
            $this->trace(
                5,
                $order_id,
                'ETD_ORCHESTRATOR_DECISION',
                ['decision' => 'WARN', 'missing_documents' => array_values($missing), 'uploaded_document_ids' => $uploaded_ids]
            );
        } else {
            $order->add_order_note(
                __('ETD: all required customs documents uploaded digitally. No paper paperwork needed.', 'teamzlab-fedex'),
                false
            );
            $this->trace(5, $order_id, 'ETD_ORCHESTRATOR_DECISION', ['decision' => 'ALLOW', 'uploaded_document_ids' => $uploaded_ids]);
        }
    }

    /**
     * Inject the electronicTradeDocuments block into the Ship payload
     * using the document ids we stashed in handle().
     *
     * @param array          $payload
     * @param \WC_Order|null $order
     * @param array          $current_shipment
     * @return array
     * @since 1.2
     */
    public function inject(array $payload, $order, array $current_shipment): array {
        if (empty($order) || empty($payload['requestedShipment'])) {
            return $payload;
        }

        $ids = get_post_meta($order->get_id(), '_fshipping_etd_document_ids', true);
        if (empty($ids) || !is_array($ids)) {
            return $payload;
        }

        $references = [];
        foreach ($ids as $id) {
            $references[] = [
                'documentType' => 'COMMERCIAL_INVOICE',
                'documentId'   => sanitize_text_field((string) $id),
            ];
        }

        $payload['requestedShipment']['shippingDocumentSpecification']['shippingDocumentTypes'] = ['COMMERCIAL_INVOICE'];
        $payload['requestedShipment']['customsClearanceDetail']['commercialInvoice']            = [
            'customerReferences' => $references,
        ];
        // Key FedEx flag that turns on paperless mode.
        $payload['requestedShipment']['customsClearanceDetail']['electronicTradeDocuments'] = [
            'requested'                  => true,
            'uploadedDocumentReferences' => $references,
        ];

        return $payload;
    }

    /**
     * Write ETD orchestrator execution trace to wp-content/debug.log.
     *
     * @param int    $step
     * @param int    $order_id
     * @param string $stage
     * @param array  $context
     * @return void
     */
    private function trace(int $step, int $order_id, string $stage, array $context = []): void {
        unset($step, $order_id, $stage, $context);
    }
}
