<?php
namespace FSHIPPING\Events;

use FSHIPPING\HTTP\GlobalTrade;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Trade\CommodityNormalizer;

/**
 * Pre-flight guard that runs before a FedEx Ship call on international
 * orders.
 *
 * Hooks the `fshipping_pre_ship_check` filter (fired by
 * Frontend\Checkout right before it calls HTTP\Shipment). For any
 * international shipment it calls HTTP\GlobalTrade::check_compliance
 * and:
 *
 * - If FedEx returns any `prohibitions[]` → short-circuit the Ship
 *   call and add a merchant-facing order note. The label never gets
 *   printed; no charge hits the merchant's FedEx account.
 * - If FedEx returns `documentsRequired[]` non-empty → allow the Ship
 *   call but add an order note listing which documents need uploading.
 *
 * The plugin's Ship API client is grandfathered (it throws instead of
 * returning `[]`), so this guard exists as a separate, additive layer
 * that doesn't touch Ship itself.
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class ShipmentGuard {
    use SingletonTrait;

    /**
     * @return void
     * @since 1.1
     */
    public function init() {
        add_filter('fshipping_pre_ship_check', [$this, 'check'], 10, 3);
        $this->debug_log_init_state();
    }

    /**
     * @param bool      $can_ship
     * @param \WC_Order $order
     * @param array     $shipping_meta Checkout payload from `Frontend\Checkout`
     *                                 (`id`, `name`, `total`, `meta` with
     *                                 `service_type`, `currency`, `package`).
     * @return bool False to block the Ship call.
     * @since 1.1
     */
    public function check($can_ship, $order, $shipping_meta) {
        $order_id = (is_object($order) && method_exists($order, 'get_id')) ? (int) $order->get_id() : 0;
        $this->debug_log_running();
        $this->trace(
            2,
            $order_id,
            'SHIPMENT_GUARD_ENTRY',
            [
                'can_ship'      => (bool) $can_ship,
                'shipping_meta' => is_array($shipping_meta) ? $shipping_meta : [],
            ]
        );

        if (false === $can_ship) {
            $this->trace(5, $order_id, 'SHIPMENT_GUARD_DECISION', ['decision' => 'BLOCK', 'reason' => 'prior_guard_blocked']);
            return false;
        }
        if (empty($order)) {
            $this->trace(5, $order_id, 'SHIPMENT_GUARD_DECISION', ['decision' => 'ALLOW', 'reason' => 'missing_order_object']);
            return $can_ship;
        }

        $shipping_meta = is_array($shipping_meta) ? $shipping_meta : [];

        $settings       = get_option('fshipping_options');
        $origin_country = !empty($settings['fshipping_country_code']) ? sanitize_text_field($settings['fshipping_country_code']) : 'US';
        $origin_country = strtoupper(trim((string) $origin_country));
        $meta_dest_country  = $this->destination_country_from_shipping_meta($shipping_meta);
        $order_dest_country = strtoupper(trim((string) $order->get_shipping_country()));

        $resolved     = $this->resolve_destination_country($order, $shipping_meta);
        $dest_country = $resolved['country'];
        $dest_source  = $resolved['source'];
        $is_international = ($origin_country !== '' && $dest_country !== '' && $origin_country !== $dest_country);
        $force_global_trade = $this->should_force_global_trade();
        $this->debug_log_destination_resolution(
            $origin_country,
            $meta_dest_country,
            $order_dest_country,
            $dest_country,
            $dest_source,
            $is_international,
            $force_global_trade
        );

        // Only international shipments trigger the Global Trade check.
        if (!$force_global_trade && (empty($dest_country) || !$is_international)) {
            $this->trace(
                5,
                $order_id,
                'SHIPMENT_GUARD_DECISION',
                ['decision' => 'ALLOW', 'reason' => 'domestic_lane', 'origin_country' => $origin_country, 'dest_country' => $dest_country]
            );
            return true;
        }

        $commodities = $this->build_commodities_from_order($order);
        if (!$this->commodities_are_valid($commodities)) {
            $this->trace(
                5,
                $order_id,
                'SHIPMENT_GUARD_COMMODITIES_AUTOFIX',
                [
                    'decision'    => 'WARN',
                    'reason'      => 'invalid_commodities_detected_after_normalization',
                    'commodities' => $commodities,
                ]
            );
            // Do not hard-block checkout when data can be auto-recovered by
            // downstream GlobalTrade normalizer/fail-open handling.
        }

        $args = [
            'order_id' => $order_id,
            'origin' => [
                'country'     => $origin_country,
                'postal_code' => !empty($settings['fshipping_postal_code']) ? sanitize_text_field($settings['fshipping_postal_code']) : '',
                'state'       => !empty($settings['state_provincecod'])     ? sanitize_text_field($settings['state_provincecod'])     : '',
            ],
            'destination' => [
                'country'     => $dest_country,
                'postal_code' => sanitize_text_field((string) ($order->get_shipping_postcode() ?: $order->get_billing_postcode())),
                'state'       => sanitize_text_field((string) ($order->get_shipping_state()    ?: $order->get_billing_state())),
            ],
            'commodities'   => $commodities,
            'customs_value' => (float) $order->get_total(),
            'currency'      => sanitize_text_field((string) $order->get_currency()),
            'carrier_code'  => $this->resolve_carrier_code($shipping_meta),
            'service_type'  => sanitize_text_field((string) ($shipping_meta['meta']['service_type'] ?? '')),
        ];

        $output = GlobalTrade::instance()->check_compliance($args);
        $this->trace(
            4,
            $order_id,
            'GLOBAL_TRADE_RESPONSE_PARSING',
            ['output' => $output]
        );

        if (empty($output)) {
            // Global Trade API unavailable. Don't block — let the Ship
            // call proceed; FedEx will still validate.
            $order->add_order_note(
                __('Global Trade pre-check unavailable; proceeding with Ship call anyway.', 'teamzlab-fedex'),
                false
            );
            $this->trace(5, $order_id, 'SHIPMENT_GUARD_DECISION', ['decision' => 'FAIL-OPEN', 'reason' => 'empty_global_trade_output']);
            return true;
        }

        // 1. Prohibitions → hard block.
        if (GlobalTrade::instance()->has_prohibitions($output)) {
            $reasons = [];
            foreach ((array) $output['prohibitions'] as $p) {
                $reasons[] = sanitize_text_field((string) ($p['reason'] ?? ($p['message'] ?? 'unspecified')));
            }
            $order->add_order_note(
                sprintf(
                    /* translators: %s is a list of prohibition reasons */
                    __('FedEx Global Trade blocked this shipment. Reasons: %s. Ship call aborted — no label was printed and your FedEx account was not charged.', 'teamzlab-fedex'),
                    implode('; ', $reasons)
                ),
                true
            );
            $this->trace(
                5,
                $order_id,
                'SHIPMENT_GUARD_DECISION',
                ['decision' => 'BLOCK', 'reason' => 'prohibitions', 'prohibitions' => $output['prohibitions'] ?? []]
            );
            return false;
        }

        // 2. Documents required → warn, allow ship.
        if (!empty($output['documentsRequired']) && is_array($output['documentsRequired'])) {
            $docs = [];
            foreach ($output['documentsRequired'] as $d) {
                $docs[] = sanitize_text_field((string) (is_array($d) ? ($d['documentType'] ?? ($d['type'] ?? 'unknown')) : $d));
            }
            $order->add_order_note(
                sprintf(
                    /* translators: %s is a comma-separated list of document types */
                    __('FedEx Global Trade flagged this international shipment. Documents required for clearance: %s. Upload via the Trade Documents Upload feature before the package reaches customs.', 'teamzlab-fedex'),
                    implode(', ', $docs)
                ),
                false
            );
            $this->trace(
                5,
                $order_id,
                'SHIPMENT_GUARD_DECISION',
                ['decision' => 'WARN', 'documentsRequired' => $output['documentsRequired']]
            );

            return true;
        }

        $this->trace(5, $order_id, 'SHIPMENT_GUARD_DECISION', ['decision' => 'ALLOW', 'reason' => 'no_prohibitions_or_docs_required']);
        return true;
    }

    /**
     * Produce a minimal commodities array from the WC order line items.
     *
     * @param \WC_Order $order
     * @return array
     * @since 1.1
     */
    /**
     * Read destination country from the WooCommerce package snapshot on the
     * shipping line (`Frontend\Checkout` passes it as `$current_shipping['meta']['package']`).
     *
     * @param array $shipping_meta Third argument to `fshipping_pre_ship_check`.
     * @return string Uppercase ISO code or empty string.
     */
    private function destination_country_from_shipping_meta(array $shipping_meta): string {
        $package = [];
        if (!empty($shipping_meta['meta']['package']) && is_array($shipping_meta['meta']['package'])) {
            $package = $shipping_meta['meta']['package'];
        } elseif (!empty($shipping_meta['package']) && is_array($shipping_meta['package'])) {
            $package = $shipping_meta['package'];
        }
        $dest = isset($package['destination']) && is_array($package['destination']) ? $package['destination'] : [];
        $raw  = isset($dest['country']) ? trim((string) $dest['country']) : '';

        return $raw === '' ? '' : strtoupper(sanitize_text_field($raw));
    }

    /**
     * Prefer checkout-rate package snapshot destination country first,
     * then fallback to persisted Woo order shipping country.
     *
     * @param \WC_Order $order
     * @param array     $shipping_meta
     * @return array{country:string,source:string}
     */
    private function resolve_destination_country($order, array $shipping_meta): array {
        $from_meta = $this->destination_country_from_shipping_meta($shipping_meta);
        if ($from_meta !== '') {
            return [
                'country' => $from_meta,
                'source'  => 'meta',
            ];
        }
        if ($order && is_object($order)) {
            $c = trim((string) $order->get_shipping_country());
            if ($c !== '') {
                return [
                    'country' => strtoupper(sanitize_text_field($c)),
                    'source'  => 'order',
                ];
            }
        }

        return [
            'country' => '',
            'source'  => 'order',
        ];
    }

    /**
     * @param string $origin_country
     * @param string $dest_country
     * @param string $source
     * @return void
     */
    private function debug_log_destination_resolution(
        string $origin_country,
        string $meta_dest_country,
        string $order_dest_country,
        string $dest_country,
        string $source,
        bool $is_international,
        bool $force_global_trade
    ): void {
        unset($origin_country, $meta_dest_country, $order_dest_country, $dest_country, $source, $is_international, $force_global_trade);
    }

    /**
     * Temporary debug switch to verify Global Trade call wiring.
     * Enable in wp-config.php:
     * define('FSHIPPING_SHIPMENT_GUARD_FORCE_GLOBAL_TRADE', true);
     */
    private function should_force_global_trade(): bool {
        return defined('FSHIPPING_SHIPMENT_GUARD_FORCE_GLOBAL_TRADE')
            && (bool) FSHIPPING_SHIPMENT_GUARD_FORCE_GLOBAL_TRADE;
    }

    private function debug_log_running(): void {
    }

    private function debug_log_init_state(): void {
    }

    private function build_commodities_from_order($order): array {
        $items        = $order->get_items();
        $commodities  = [];
        $origin_cc    = sanitize_text_field((string) (get_option('fshipping_options')['fshipping_country_code'] ?? 'US'));
        $normalizer   = CommodityNormalizer::instance();

        foreach ($items as $item) {
            $product = method_exists($item, 'get_product') ? $item->get_product() : null;
            if (empty($product) && !method_exists($item, 'get_name')) {
                continue;
            }
            $commodities[] = $normalizer->normalize_item($item, $origin_cc);
        }

        return $commodities;
    }

    private function commodities_are_valid(array $commodities): bool {
        if (empty($commodities)) {
            return false;
        }
        foreach ($commodities as $commodity) {
            $description = trim((string) ($commodity['description'] ?? ''));
            $hs = preg_replace('/[^0-9]/', '', (string) ($commodity['harmonized_code'] ?? ''));
            if ($description === '' || $hs === '' || strlen((string) $hs) < 6) {
                return false;
            }
        }
        return true;
    }

    private function resolve_carrier_code(array $shipping_meta): string {
        $raw = '';
        if (!empty($shipping_meta['meta']['carrier_code'])) {
            $raw = (string) $shipping_meta['meta']['carrier_code'];
        }
        if ($raw === '' && !empty($shipping_meta['meta']['service_type'])) {
            // FedEx service types (e.g. FEDEX_GROUND) generally map to Express/Ground carriers.
            $svc = strtoupper((string) $shipping_meta['meta']['service_type']);
            if (strpos($svc, 'GROUND') !== false || strpos($svc, 'HOME_DELIVERY') !== false) {
                $raw = 'FDXG';
            } else {
                $raw = 'FDXE';
            }
        }
        if ($raw === '') {
            $raw = 'FDXE';
        }
        return sanitize_text_field(strtoupper($raw));
    }

    /**
     * Write ShipmentGuard execution trace to wp-content/debug.log.
     *
     * @param int    $step
     * @param int    $order_id
     * @param string $stage
     * @param array  $context
     * @return void
     */
    private function trace(int $step, int $order_id, string $stage, array $context = []): void {
        unset($step, $order_id, $stage, $context);
    }
}
