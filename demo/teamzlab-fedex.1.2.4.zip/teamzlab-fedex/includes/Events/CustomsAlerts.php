<?php
namespace FSHIPPING\Events;

use FSHIPPING\SingletonTrait;

/**
 * Customs-related AIV event handler.
 *
 * Listens on the `fshipping_aiv_event_received` action (fired by the
 * webhook receiver) and reacts to FedEx customs / clearance event
 * codes. This is the "package stuck at the airport by customs"
 * scenario — the one business case most competitor tools silently
 * ignore.
 *
 * Event codes handled (TODO: verify exact codes against live sandbox):
 *   - CH (Customs Hold)              — airport-blocked
 *   - CP (Customs Clearance Delay)   — active customs issue
 *   - CC (Clearance in Progress)     — informational
 *   - CA (Customs Clearance Action)  — action required by merchant
 *   - CD (Clearance Delay)           — alias for CP in some responses
 *   - HL (Held at Location)          — physically waiting at a FedEx facility
 *
 * On a "hold" event the merchant (admin or configured recipient) gets
 * an email with the tracking number, order link, and a direct link to
 * upload additional customs documents. Customer is NOT spammed —
 * customs holds are usually a merchant problem, not a customer one.
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class CustomsAlerts {
    use SingletonTrait;

    /**
     * Event codes that require an immediate merchant alert.
     */
    private const BLOCKING_CODES = ['CH', 'CP', 'CD', 'CA', 'HL', 'CUSTOMS_HOLD', 'CUSTOMS_DELAY'];

    /**
     * Event codes that are informational (logged but not emailed).
     */
    private const INFO_CODES = ['CC', 'CLEARANCE_IN_PROGRESS', 'CLEARANCE_COMPLETE'];

    /**
     * @return void
     * @since 1.1
     */
    public function init() {
        add_action('fshipping_aiv_event_received', [$this, 'handle'], 10, 2);
    }

    /**
     * @param string $tracking_number
     * @param array  $event
     * @return void
     * @since 1.1
     */
    public function handle($tracking_number, $event) {
        $tracking_number = sanitize_text_field((string) $tracking_number);
        $code            = strtoupper(sanitize_text_field($event['eventType'] ?? ($event['statusCode'] ?? '')));
        if (empty($tracking_number) || empty($code)) {
            return;
        }

        $is_blocking = in_array($code, self::BLOCKING_CODES, true);
        $is_info     = in_array($code, self::INFO_CODES,     true);

        if (!$is_blocking && !$is_info) {
            return;
        }

        $order = $this->find_order_by_tracking_number($tracking_number);
        if (empty($order)) {
            return;
        }

        $description = sanitize_text_field($event['eventDescription'] ?? ($event['description'] ?? ''));
        $at          = sanitize_text_field($event['eventDateTime']    ?? current_time('c'));

        // Mark the shipment as customs-flagged so the UI can render a
        // distinct badge on the Shipments list.
        $shipment_id = $this->find_shipment_id_by_tracking_number($tracking_number);
        if (!empty($shipment_id)) {
            update_post_meta($shipment_id, '_fshipping_customs_state', $is_blocking ? 'hold' : 'in_progress');
            update_post_meta($shipment_id, '_fshipping_customs_code',  $code);
            update_post_meta($shipment_id, '_fshipping_customs_at',    $at);
        }

        // Order note for the timeline.
        $order->add_order_note(
            sprintf(
                /* translators: 1: event code, 2: description */
                __('FedEx customs event %1$s: %2$s', 'teamzlab-fedex'),
                $code,
                $description ?: __('no description', 'teamzlab-fedex')
            ),
            false
        );

        if ($is_blocking) {
            $this->send_merchant_alert($order, $tracking_number, $code, $description);
        }
    }

    /**
     * Email the configured customs-alert recipient.
     *
     * @param \WC_Order $order
     * @param string    $tracking_number
     * @param string    $code
     * @param string    $description
     * @return void
     * @since 1.1
     */
    private function send_merchant_alert($order, string $tracking_number, string $code, string $description): void {
        $settings   = get_option('fshipping_options');
        $enabled    = !isset($settings['fshipping_customs_alerts_enabled']) || !empty($settings['fshipping_customs_alerts_enabled']);
        if (!$enabled) {
            return;
        }

        $recipient = !empty($settings['fshipping_customs_alert_email'])
            ? sanitize_email($settings['fshipping_customs_alert_email'])
            : sanitize_email((string) get_option('admin_email'));

        if (empty($recipient)) {
            return;
        }

        $order_id       = $order->get_id();
        $order_number   = $order->get_order_number();
        $edit_url       = admin_url('post.php?post=' . $order_id . '&action=edit');
        $dest_country   = $order->get_shipping_country() ?: $order->get_billing_country();

        $subject = sprintf(
            /* translators: 1: order number, 2: destination country */
            __('[Customs hold] Order #%1$s stuck at customs in %2$s', 'teamzlab-fedex'),
            $order_number,
            $dest_country
        );

        ob_start();
        ?>
        <p><?php echo esc_html(sprintf(
            /* translators: 1: order number, 2: tracking number */
            __('Order #%1$s (tracking %2$s) has been flagged by customs and is currently held.', 'teamzlab-fedex'),
            $order_number,
            $tracking_number
        )); ?></p>

        <table cellpadding="6" cellspacing="0" border="0" style="border-collapse:collapse;font-family:Arial,sans-serif;">
            <tr><td><strong><?php esc_html_e('Event code', 'teamzlab-fedex'); ?></strong></td><td><?php echo esc_html($code); ?></td></tr>
            <tr><td><strong><?php esc_html_e('Description', 'teamzlab-fedex'); ?></strong></td><td><?php echo esc_html($description ?: '—'); ?></td></tr>
            <tr><td><strong><?php esc_html_e('Destination', 'teamzlab-fedex'); ?></strong></td><td><?php echo esc_html($dest_country); ?></td></tr>
            <tr><td><strong><?php esc_html_e('Tracking', 'teamzlab-fedex'); ?></strong></td><td><?php echo esc_html($tracking_number); ?></td></tr>
        </table>

        <h3><?php esc_html_e('What to do next', 'teamzlab-fedex'); ?></h3>
        <ol>
            <li><?php esc_html_e('Check the FedEx dashboard for the exact reason (missing commercial invoice, declared value issue, prohibited item).', 'teamzlab-fedex'); ?></li>
            <li><?php esc_html_e('Upload any missing customs documents via the Trade Documents Upload feature.', 'teamzlab-fedex'); ?></li>
            <li><?php esc_html_e('Review the order and notify the customer if an action on their side is needed.', 'teamzlab-fedex'); ?></li>
        </ol>

        <p><a href="<?php echo esc_url($edit_url); ?>" style="background:#4f46e5;color:#fff;padding:10px 16px;border-radius:4px;text-decoration:none;">
            <?php esc_html_e('Open order in admin', 'teamzlab-fedex'); ?>
        </a></p>

        <p style="color:#666;font-size:12px;">
            <?php esc_html_e('You are receiving this because the Fedex Shipping plugin detected a customs hold event on a shipment attached to this order. Contact your store administrator to change or disable these alerts.', 'teamzlab-fedex'); ?>
        </p>
        <?php
        $html = ob_get_clean();

        $headers = ['Content-Type: text/html; charset=UTF-8'];
        wp_mail($recipient, $subject, $html, $headers);

        $order->add_order_note(
            sprintf(
                /* translators: %s is the recipient email */
                __('Customs-hold alert email sent to %s.', 'teamzlab-fedex'),
                $recipient
            ),
            false
        );
    }

    /**
     * @param string $tracking_number
     * @return int
     * @since 1.1
     */
    private function find_shipment_id_by_tracking_number(string $tracking_number): int {
        if (empty($tracking_number)) {
            return 0;
        }
        $ids = get_posts([
            'post_type'      => 'fedex_shipping',
            'post_status'    => 'any',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Exact-match lookup on this plugin's fedex_shipping CPT by its _tracking_number meta to route the customs-hold alert to the right order; single post, hard-limited to 1.
            'meta_query'     => [[
                'key'     => '_tracking_number',
                'value'   => $tracking_number,
                'compare' => '=',
            ]],
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ]);
        return !empty($ids) ? (int) reset($ids) : 0;
    }

    /**
     * @param string $tracking_number
     * @return \WC_Order|null
     * @since 1.1
     */
    private function find_order_by_tracking_number(string $tracking_number) {
        $shipment_id = $this->find_shipment_id_by_tracking_number($tracking_number);
        if (empty($shipment_id)) {
            return null;
        }
        $order_id = get_post_meta($shipment_id, '_fedex_shipment_order_id', true);
        if (empty($order_id)) {
            return null;
        }
        return function_exists('wc_get_order') ? wc_get_order((int) $order_id) : null;
    }
}
