<?php
namespace FSHIPPING\Events;

use FSHIPPING\Admin\FreightLTLExtras;
use FSHIPPING\Shipping\DangerousGoods;
use FSHIPPING\Shipping\ServicePreferences;
use FSHIPPING\SingletonTrait;

/**
 * Overlays the richer, spec-compliant payload fragments produced by the
 * new `Shipping\*` + `Admin\FreightLTLExtras` classes onto ship + rate
 * requests. Runs AFTER SpecialServicesInjector (priority 30 vs 10) so
 * it supplements rather than replaces the legacy meta-key flow.
 *
 * Reads three additive per-order meta inputs:
 *   _fshipping_dg_spec          — validated DangerousGoods::validate() data[]
 *   _fshipping_svc_preferences  — ServicePreferences::normalize() output
 *   _fshipping_ltl_extras       — FreightLTLExtras::normalize() output
 *
 * Never clobbers `specialServicesRequested.specialServiceTypes[]` — merges.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class AdvancedServicesInjector {
    use SingletonTrait;

    /** Priority 30 — after SpecialServicesInjector (10) and ETDOrchestrator (20). */
    public const SHIP_PRIORITY = 30;

    /**
     * @return void
     * @since 1.2
     */
    public function init() {
        add_filter('fshipping_ship_payload',  [$this, 'enrich_ship_payload'],  self::SHIP_PRIORITY, 3);
        add_filter('fshipping_rates_payload', [$this, 'enrich_rates_payload'], self::SHIP_PRIORITY, 2);
    }

    /**
     * Hook on the Ship API payload filter.
     *
     * @param array $payload
     * @param \WC_Order|null $order
     * @param array $current_shipment
     * @return array
     * @since 1.2
     */
    public function enrich_ship_payload(array $payload, $order, array $current_shipment): array {
        if (!isset($payload['requestedShipment']) || !$order) {
            return $payload;
        }
        $order_id = (int) $order->get_id();

        $payload = $this->apply_dangerous_goods($payload, $order_id);
        $payload = $this->apply_service_preferences($payload, $order_id);
        $payload = $this->apply_ltl_extras($payload, $order_id);

        return $payload;
    }

    /**
     * Hook on the Rates API payload filter — same overlay, different context.
     *
     * @param array $payload
     * @param array $args Programmatic rate args.
     * @return array
     * @since 1.2
     */
    public function enrich_rates_payload(array $payload, array $args): array {
        if (!isset($payload['requestedShipment'])) {
            return $payload;
        }
        $order_id = (int) ($args['order_id'] ?? 0);
        if ($order_id <= 0) {
            return $payload;
        }

        $payload = $this->apply_dangerous_goods($payload, $order_id);
        $payload = $this->apply_service_preferences($payload, $order_id);
        $payload = $this->apply_ltl_extras($payload, $order_id);
        return $payload;
    }

    /**
     * Merge DangerousGoods fragment when a validated DG spec is set.
     *
     * @param array $payload
     * @param int   $order_id
     * @return array
     * @since 1.2
     */
    private function apply_dangerous_goods(array $payload, int $order_id): array {
        $spec = get_post_meta($order_id, '_fshipping_dg_spec', true);
        if (!is_array($spec) || empty($spec['kind'])) {
            return $payload;
        }
        $fragment = DangerousGoods::instance()->payload_fragment($spec);
        return $this->merge_shipment_fragment($payload, $fragment);
    }

    /**
     * Merge ServicePreferences fragment (Saturday / Evening / signatures / date-certain).
     *
     * @param array $payload
     * @param int   $order_id
     * @return array
     * @since 1.2
     */
    private function apply_service_preferences(array $payload, int $order_id): array {
        $normalized = get_post_meta($order_id, '_fshipping_svc_preferences', true);
        if (!is_array($normalized) || empty($normalized['codes'])) {
            return $payload;
        }
        $fragment = ServicePreferences::instance()->payload_fragment($normalized);
        return $this->merge_shipment_fragment($payload, $fragment);
    }

    /**
     * Merge FreightLTLExtras fragment (liftgate / inside / appointment / limited-access).
     *
     * @param array $payload
     * @param int   $order_id
     * @return array
     * @since 1.2
     */
    private function apply_ltl_extras(array $payload, int $order_id): array {
        $normalized = get_post_meta($order_id, '_fshipping_ltl_extras', true);
        if (!is_array($normalized) || empty($normalized['codes'])) {
            return $payload;
        }
        $fragment = FreightLTLExtras::instance()->payload_fragment($normalized['codes']);
        return $this->merge_shipment_fragment($payload, $fragment);
    }

    /**
     * Additive merge: adds to specialServiceTypes[], fills missing keys,
     * never overwrites non-empty values already on the payload.
     *
     * @param array $payload
     * @param array $fragment
     * @return array
     * @since 1.2
     */
    private function merge_shipment_fragment(array $payload, array $fragment): array {
        if (empty($fragment)) {
            return $payload;
        }

        // 1) merge specialServicesRequested.specialServiceTypes[] additively.
        if (!empty($fragment['specialServicesRequested']['specialServiceTypes'])) {
            $existing_path = 'shipmentSpecialServiceDetail';
            $payload['requestedShipment'][$existing_path]['specialServiceTypes']
                = array_values(array_unique(array_merge(
                    (array) ($payload['requestedShipment'][$existing_path]['specialServiceTypes'] ?? []),
                    (array) $fragment['specialServicesRequested']['specialServiceTypes']
                )));
            unset($fragment['specialServicesRequested']);
        }

        // 2) remaining top-level keys in the fragment map onto requestedShipment
        //    — keeping existing payload values when both sides specify.
        foreach ($fragment as $key => $value) {
            if (!isset($payload['requestedShipment'][$key]) || empty($payload['requestedShipment'][$key])) {
                $payload['requestedShipment'][$key] = $value;
            }
        }

        return $payload;
    }
}
