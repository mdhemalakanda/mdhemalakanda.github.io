<?php
namespace FSHIPPING\Events;

use FSHIPPING\Frontend\TrackingTimeline;
use FSHIPPING\SingletonTrait;

/**
 * Mirrors the single-event cache the webhook receiver writes into an
 * append-only timeline on the matching fedex_shipping CPT post.
 *
 * Hooks the `fshipping_aiv_event_received` action (already fired by
 * Ajax\TrackingWebhookReceiver) so we don't need to touch the receiver.
 *
 * The timeline powers:
 *  - `[fshipping_tracking_timeline]` customer shortcode
 *  - Future admin order-detail timeline widget
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class TrackingTimelineRecorder {
    use SingletonTrait;

    /**
     * @return void
     * @since 1.2
     */
    public function init() {
        add_action('fshipping_aiv_event_received', [$this, 'record'], 10, 2);
    }

    /**
     * @param string $tracking_number
     * @param array  $event Raw event from FedEx AIV webhook.
     * @return void
     * @since 1.2
     */
    public function record($tracking_number, $event) {
        $shipment_id = $this->find_shipment_id_by_tracking_number((string) $tracking_number);
        if ($shipment_id <= 0 || !is_array($event)) {
            return;
        }
        TrackingTimeline::instance()->append($shipment_id, $event);
    }

    /**
     * Duplicate of the receiver's lookup — intentional, to keep this
     * class self-contained and testable without reaching into a private
     * method on the receiver.
     *
     * @param string $tracking_number
     * @return int
     * @since 1.2
     */
    private function find_shipment_id_by_tracking_number(string $tracking_number): int {
        if ($tracking_number === '') {
            return 0;
        }
        $ids = get_posts([
            'post_type'      => 'fedex_shipping',
            'post_status'    => 'any',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Required for webhook routing; exact-match lookup on this plugin's fedex_shipping CPT by its _tracking_number meta, hard-limited to 1.
            'meta_query'     => [[
                'key'     => '_tracking_number',
                'value'   => $tracking_number,
                'compare' => '=',
            ]],
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ]);
        return !empty($ids) ? (int) reset($ids) : 0;
    }
}
