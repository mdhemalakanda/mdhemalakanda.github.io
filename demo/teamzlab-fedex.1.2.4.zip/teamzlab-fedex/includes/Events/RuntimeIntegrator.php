<?php
namespace FSHIPPING\Events;

use FSHIPPING\Frontend\SavingsMeter;
use FSHIPPING\Migration\SafetyNet;
use FSHIPPING\Migration\StagingMode;
use FSHIPPING\SingletonTrait;

/**
 * The single class that wires standalone service classes into the
 * WooCommerce + plugin runtime. Prevents hook-registration sprawl by
 * keeping all runtime glue auditable in one place.
 *
 * Wires previously-disconnected flows (see GAP_AUDIT §1.3):
 *
 *   1. StagingMode dry-run logging — records every rate call when staging
 *      mode is enabled (`fshipping_staging_mode` option).
 *   2. Checkout Safety Net — serves a merchant-configured fallback
 *      rate when the primary rate response is empty, so checkout never
 *      crashes on a FedEx 5xx.
 *   3. Savings Meter — records a residential→business reclassification
 *      event so the dashboard's "$X saved" counter has data.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class RuntimeIntegrator {
    use SingletonTrait;

    /**
     * @return void
     * @since 1.2
     */
    public function init() {
        add_action('fshipping_calculate_shipping_start',     [$this, 'log_staging_mode'],               10, 2);
        add_filter('fshipping_calculate_shipping_rates',     [$this, 'safety_net_fallback'],            10, 3);
        add_action('fshipping_address_classified',           [$this, 'record_reclassification'],        10, 2);
    }

    /**
     * Log the current rate call into the staging-mode debug buffer when
     * the merchant has the toggle on. The toggle does not alter the live
     * checkout — it only surfaces what FedEx would have been asked.
     *
     * @param mixed $method   The WC_Shipping_Method instance.
     * @param array $package  The current shipping package.
     * @return void
     * @since 1.2
     */
    public function log_staging_mode($method, $package) {
        $staging = StagingMode::instance();
        if (!$staging->is_enabled()) {
            return;
        }
        $staging->debug_log('rate_call:start', [
            'destination'  => isset($package['destination']) ? $package['destination'] : [],
            'item_count'   => isset($package['contents']) && is_array($package['contents']) ? count($package['contents']) : 0,
            'method_id'    => is_object($method) && isset($method->id) ? (string) $method->id : '',
        ]);
    }

    /**
     * If the primary rate response is empty, swap in the configured
     * Safety-Net fallback rate shape so checkout renders something
     * instead of crashing.
     *
     * The fallback is produced by the `fshipping_safety_net_fallback`
     * filter — merchants who haven't configured a fallback get the
     * unchanged empty response (same as old behavior).
     *
     * @param array $response
     * @param mixed $method
     * @param array $package
     * @return array
     * @since 1.2
     */
    public function safety_net_fallback($response, $method, $package) {
        if (is_array($response) && !empty($response)) {
            return $response;
        }
        $fallback = apply_filters('fshipping_safety_net_fallback', [], $method, $package);
        if (!is_array($fallback) || empty($fallback)) {
            return $response;
        }
        SafetyNet::instance()->with_fallback(
            static function () use ($response) { return $response; },
            $fallback,
            'rate_call_empty'
        );
        return $fallback;
    }

    /**
     * When an address reclassifies residential→business, record the
     * estimated residential-surcharge savings to the SavingsMeter log.
     *
     * @param array  $address Original address array; may carry hint keys
     *                        `_assumed_class`, `_order_id`, `_currency`.
     * @param string $class   Final classification returned by FedEx.
     * @return void
     * @since 1.2
     */
    public function record_reclassification($address, $class) {
        if (!is_array($address)) {
            return;
        }
        $assumed = isset($address['_assumed_class']) ? strtoupper((string) $address['_assumed_class']) : 'RESIDENTIAL';
        $final   = strtoupper((string) $class);
        if ($assumed !== 'RESIDENTIAL' || $final !== 'BUSINESS') {
            return;
        }
        $amount   = (float) apply_filters('fshipping_residential_surcharge_amount', 5.95);
        $order_id = isset($address['_order_id']) ? (int) $address['_order_id'] : 0;
        $currency = isset($address['_currency']) ? (string) $address['_currency'] : 'USD';
        SavingsMeter::instance()->record($order_id, $amount, 'residential_to_business_reclassification', $currency);
    }
}
