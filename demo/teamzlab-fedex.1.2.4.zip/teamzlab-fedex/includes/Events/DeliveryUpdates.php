<?php
namespace FSHIPPING\Events;

use FSHIPPING\HTTP\Locations;
use FSHIPPING\SingletonTrait;

/**
 * AIV event → WooCommerce order status + Hold-at-Location redirect.
 *
 * Listens on the `fshipping_aiv_event_received` action fired by the
 * webhook receiver and translates FedEx event codes into three
 * competitor-differentiating behaviors from the research brief:
 *
 *   1. DL   (Delivered)          → mark order "completed" + order note.
 *   2. OD   (Out For Delivery)   → order note (keeps status, doesn't
 *                                  change order lifecycle on its own).
 *   3. DE   (Delivery Exception) → email the customer with the nearest
 *                                  FedEx Office for a Hold-at-Location
 *                                  redirect — the "turn failed delivery
 *                                  into a free pickup" feature called
 *                                  out in Section 5.1 of the brief.
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class DeliveryUpdates {
    use SingletonTrait;

    /**
     * Attach event listener.
     *
     * @return void
     * @since 1.1
     */
    public function init() {
        add_action('fshipping_aiv_event_received', [$this, 'handle'], 10, 2);
    }

    /**
     * @param string $tracking_number
     * @param array  $event
     * @return void
     * @since 1.1
     */
    public function handle($tracking_number, $event) {
        $tracking_number = sanitize_text_field((string) $tracking_number);
        $code   = strtoupper(sanitize_text_field($event['eventType']    ?? ($event['statusCode']  ?? '')));
        $desc   = sanitize_text_field($event['eventDescription'] ?? ($event['description'] ?? ''));

        if (empty($tracking_number) || empty($code)) {
            return;
        }

        $order = $this->find_order_by_tracking_number($tracking_number);
        if (empty($order)) {
            return;
        }

        switch ($code) {
            case 'DL':
            case 'DELIVERED':
                $this->on_delivered($order, $desc);
                break;

            case 'OD':
            case 'OUT_FOR_DELIVERY':
                $this->on_out_for_delivery($order, $desc);
                break;

            case 'DE':
            case 'EX':
            case 'DELIVERY_EXCEPTION':
                $this->on_delivery_exception($order, $desc);
                break;
        }
    }

    /**
     * DL — mark order completed, note it, stamp the post-meta.
     *
     * @param \WC_Order $order
     * @param string    $description
     * @return void
     * @since 1.1
     */
    private function on_delivered($order, $description) {
        $order->add_order_note(
            sprintf(
                /* translators: %s: delivery confirmation description from the FedEx event. */
                __('FedEx confirmed delivery: %s', 'teamzlab-fedex'),
                $description ?: 'Delivered'
            ),
            true
        );
        if (!in_array($order->get_status(), ['completed', 'refunded', 'cancelled', 'failed'], true)) {
            $order->update_status('completed', __('Delivered per FedEx webhook.', 'teamzlab-fedex'));
        }
    }

    /**
     * OD — customer-visible note only.
     *
     * @param \WC_Order $order
     * @param string    $description
     * @return void
     * @since 1.1
     */
    private function on_out_for_delivery($order, $description) {
        $order->add_order_note(
            sprintf(
                /* translators: %s: out-for-delivery description from the FedEx event. */
                __('FedEx: out for delivery — %s', 'teamzlab-fedex'),
                $description ?: 'on the vehicle'
            ),
            true
        );
    }

    /**
     * DE — email the customer with the nearest FedEx Office for a
     * Hold-at-Location redirect. This is the "free loss-recovery"
     * feature in Section 5.1.
     *
     * @param \WC_Order $order
     * @param string    $description
     * @return void
     * @since 1.1
     */
    private function on_delivery_exception($order, $description) {
        $order->add_order_note(
            sprintf(
                /* translators: %s: delivery exception description from the FedEx event. */
                __('FedEx delivery exception: %s', 'teamzlab-fedex'),
                $description ?: 'exception'
            ),
            true
        );

        $postal_code  = $order->get_shipping_postcode() ?: $order->get_billing_postcode();
        $country_code = $order->get_shipping_country()  ?: $order->get_billing_country();
        if (empty($postal_code)) {
            return;
        }

        $locations = Locations::instance()->search([
            'postal_code' => $postal_code,
            'country'     => $country_code ?: 'US',
            'limit'       => 3,
            'sort_by'     => 'distance',
        ]);

        if (empty($locations)) {
            return;
        }

        $this->send_hold_at_location_email($order, $locations, $description);
    }

    /**
     * Send the Hold-at-Location suggestion email to the customer.
     *
     * @param \WC_Order $order
     * @param array     $locations
     * @param string    $reason
     * @return void
     * @since 1.1
     */
    private function send_hold_at_location_email($order, array $locations, $reason) {
        $customer_email = $order->get_billing_email();
        if (empty($customer_email)) {
            return;
        }

        $first_name = $order->get_billing_first_name();
        $subject    = sprintf(
            /* translators: %s: WooCommerce order number. */
            __('Action needed: pick up your order #%s at a nearby FedEx Office', 'teamzlab-fedex'),
            $order->get_order_number()
        );

        ob_start();
        ?>
        <p><?php echo esc_html(sprintf(
            /* translators: %s: customer billing first name. */
            __('Hello %s,', 'teamzlab-fedex'),
            $first_name
        )); ?></p>
        <p><?php echo esc_html(sprintf(
            /* translators: %s: delivery exception description from the FedEx event. */
            __('FedEx reported a delivery exception on your order (%s). The good news: we can redirect the package to any nearby FedEx Office and you can collect it on your own schedule.', 'teamzlab-fedex'),
            $reason ?: __('delivery issue', 'teamzlab-fedex')
        )); ?></p>
        <p><strong><?php esc_html_e('Nearest FedEx Office locations', 'teamzlab-fedex'); ?>:</strong></p>
        <ul>
        <?php foreach ($locations as $location) :
            $contact  = $location['contactAndAddress'] ?? $location;
            $name     = $contact['contact']['companyName'] ?? ($location['locationId'] ?? 'FedEx Office');
            $address  = $contact['address'] ?? [];
            $street   = implode(', ', array_filter((array) ($address['streetLines'] ?? [])));
            $city     = $address['city'] ?? '';
            $state    = $address['stateOrProvinceCode'] ?? '';
            $zip      = $address['postalCode'] ?? '';
        ?>
            <li>
                <strong><?php echo esc_html($name); ?></strong><br/>
                <?php echo esc_html(trim(sprintf('%s, %s %s %s', $street, $city, $state, $zip), ', ')); ?>
            </li>
        <?php endforeach; ?>
        </ul>
        <p><?php esc_html_e('Reply to this email within 48 hours if you would like us to redirect the package to one of these pickup locations.', 'teamzlab-fedex'); ?></p>
        <?php
        $message = ob_get_clean();

        $headers = ['Content-Type: text/html; charset=UTF-8'];
        wp_mail(sanitize_email($customer_email), $subject, $message, $headers);

        $order->add_order_note(
            __('Hold-at-Location suggestion email sent to customer with 3 nearest FedEx Offices.', 'teamzlab-fedex'),
            false
        );
    }

    /**
     * @param string $tracking_number
     * @return \WC_Order|null
     * @since 1.1
     */
    private function find_order_by_tracking_number($tracking_number) {
        $ids = get_posts([
            'post_type'      => 'fedex_shipping',
            'post_status'    => 'any',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Exact-match lookup on this plugin's fedex_shipping CPT by its _tracking_number meta to apply the AIV delivery event to its order; single post, hard-limited to 1.
            'meta_query'     => [[
                'key'     => '_tracking_number',
                'value'   => $tracking_number,
                'compare' => '=',
            ]],
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ]);
        if (empty($ids)) {
            return null;
        }
        $order_id = get_post_meta((int) reset($ids), '_fedex_shipment_order_id', true);
        if (empty($order_id)) {
            return null;
        }
        return function_exists('wc_get_order') ? wc_get_order((int) $order_id) : null;
    }
}
