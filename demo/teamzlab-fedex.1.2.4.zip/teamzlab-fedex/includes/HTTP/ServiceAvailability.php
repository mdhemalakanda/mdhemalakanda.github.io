<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Service Availability API client.
 *
 * FedEx endpoint: POST /availability/v1/services
 *  (TODO: verify against live sandbox)
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class ServiceAvailability extends BaseClient {
    protected string $log_source = 'fshipping_service_availability';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    /**
     * Get the list of services available between two points.
     *
     * @param array $args
     * @return array FedEx output.options[] or [] on failure.
     * @since 1.1
     */
    public function get_available_services(array $args): array {
        if (empty($args['origin']['postal_code']) || empty($args['destination']['postal_code'])) {
            return [];
        }

        $cache_key = 'fshipping_service_avail_' . md5(wp_json_encode($args));
        $cached    = get_transient($cache_key);
        if (false !== $cached) {
            return $cached;
        }

        $decoded = $this->post('/availability/v1/services', $this->prepare_payload($args));
        $options = $decoded['output']['options'] ?? [];

        set_transient($cache_key, $options, DAY_IN_SECONDS);
        return $options;
    }

    /**
     * @param array $args
     * @return array
     * @since 1.1
     */
    private function prepare_payload(array $args): array {
        $settings    = get_option('fshipping_options');
        $origin      = $args['origin']      ?? [];
        $destination = $args['destination'] ?? [];
        $ship_date   = sanitize_text_field($args['ship_date']      ?? gmdate('Y-m-d'));
        $pickup_type = sanitize_text_field($args['pickup_type']    ?? ($settings['fshipping_pickup_type']  ?? 'USE_SCHEDULED_PICKUP'));
        $packaging   = sanitize_text_field($args['packaging_type'] ?? ($settings['fshipping_labeling_packaging_type'] ?? 'YOUR_PACKAGING'));

        $packages = !empty($args['packages']) && is_array($args['packages']) ? $args['packages'] : [[
            'weight' => 1, 'weight_unit' => 'LB', 'length' => 10, 'width' => 10, 'height' => 10, 'dimension_unit' => 'IN',
        ]];

        $requested_packages = [];
        foreach ($packages as $package) {
            $raw_weight_unit    = strtoupper((string) ($package['weight_unit'] ?? 'LB'));
            $raw_dimension_unit = strtoupper((string) ($package['dimension_unit'] ?? 'IN'));
            $requested_packages[] = [
                'weight' => [
                    'units' => in_array($raw_weight_unit, ['LB', 'KG'], true) ? $raw_weight_unit : 'LB',
                    'value' => (string) (float) ($package['weight'] ?? 1),
                ],
                'dimensions' => [
                    'length' => (int) ($package['length'] ?? 10),
                    'width'  => (int) ($package['width']  ?? 10),
                    'height' => (int) ($package['height'] ?? 10),
                    'units'  => in_array($raw_dimension_unit, ['IN', 'CM'], true) ? $raw_dimension_unit : 'IN',
                ],
            ];
        }

        return [
            'requestedShipment' => [
                'shipper'   => ['address' => [
                    'postalCode'          => sanitize_text_field($origin['postal_code'] ?? ''),
                    'countryCode'         => sanitize_text_field($origin['country']     ?? 'US'),
                    'stateOrProvinceCode' => sanitize_text_field($origin['state']       ?? ''),
                ]],
                'recipient' => ['address' => [
                    'postalCode'          => sanitize_text_field($destination['postal_code'] ?? ''),
                    'countryCode'         => sanitize_text_field($destination['country']     ?? 'US'),
                    'stateOrProvinceCode' => sanitize_text_field($destination['state']       ?? ''),
                ]],
                'pickupType'                => $pickup_type,
                'packagingType'             => $packaging,
                'shipDateStamp'             => $ship_date,
                'requestedPackageLineItems' => $requested_packages,
            ],
        ];
    }
}
