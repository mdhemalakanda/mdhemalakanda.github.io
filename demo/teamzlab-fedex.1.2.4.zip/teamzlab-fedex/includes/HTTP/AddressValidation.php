<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\AddressNormalizer;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Address Validation API client.
 *
 * Validates and classifies up to 100 addresses per request. Returns a
 * standardized / corrected form, a residential-vs-commercial classification,
 * and attribute flags such as DPV and Resolved.
 *
 * FedEx endpoint: POST /address/v1/addresses/resolve
 *
 * Migrated onto Teamz\Wp\Kit\Http\BaseClient — the shared base handles
 * wp_remote_post + auth header + error handling + logging.
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class AddressValidation extends BaseClient {
    protected string $log_source = 'fshipping_address_validation';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    /**
     * Add FedEx's X-locale header on top of the kit's default set.
     */
    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    /**
     * Validate one or many addresses.
     *
     * @param array $addresses Array of address arrays. Each entry:
     *   [ 'street_lines' => array|string, 'city' => string,
     *     'state' => string, 'postal_code' => string,
     *     'country' => string ]
     * @return array FedEx resolvedAddresses[*] or [] on failure.
     * @since 1.1
     */
    public function validate(array $addresses): array {
        if (empty($addresses)) {
            return [];
        }
        if (empty($this->auth_header())) {
            return [];
        }

        $payload = $this->prepare_payload($addresses);
        $payload = apply_filters('fshipping_address_validation_payload', $payload, $addresses);

        $decoded = $this->post('/address/v1/addresses/resolve', $payload);

        $resolved = $decoded['output']['resolvedAddresses'] ?? [];

        return is_array($resolved) ? $resolved : [];
    }

    /**
     * Convenience: classify a single address as residential / commercial.
     *
     * @param array $address
     * @return string One of 'RESIDENTIAL', 'BUSINESS', 'MIXED', 'UNKNOWN'.
     * @since 1.1
     */
    public function classify(array $address): string {
        $resolved = $this->validate([$address]);
        $first    = !empty($resolved[0]) ? $resolved[0] : [];
        $class    = isset($first['classification']) ? sanitize_text_field($first['classification']) : 'UNKNOWN';
        $class    = $class ?: 'UNKNOWN';
        do_action('fshipping_address_classified', $address, $class);
        return $class;
    }

    /**
     * Build FedEx addressesToValidate payload.
     *
     * @param array $addresses
     * @return array
     * @since 1.1
     */
    private function prepare_payload(array $addresses): array {
        $entries = [];
        foreach ($addresses as $address) {
            $norm = AddressNormalizer::normalize_for_fedex([
                'street_lines' => $address['street_lines'] ?? [],
                'city'         => (string) ($address['city'] ?? ''),
                'state'        => (string) ($address['state'] ?? ''),
                'postal_code'  => (string) ($address['postal_code'] ?? ''),
                'country'      => (string) ($address['country'] ?? 'US'),
            ]);

            $street_lines = array_values(array_map('sanitize_text_field', $norm['street_lines']));
            $addr = [
                'streetLines'  => $street_lines,
                'city'         => sanitize_text_field($norm['city']),
                'postalCode'   => sanitize_text_field($norm['postal_code']),
                'countryCode'  => sanitize_text_field($norm['country']),
            ];
            if ($norm['state'] !== '') {
                $addr['stateOrProvinceCode'] = sanitize_text_field($norm['state']);
            }

            $entries[] = ['address' => $addr];
        }

        return [
            'addressesToValidate' => array_slice($entries, 0, 100),
        ];
    }
}
