<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Locations Search API client.
 *
 * FedEx endpoint: POST /location/v1/locations (Locations Search / find).
 * Result cap: 75 locations within 50 miles.
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class Locations extends BaseClient {
    protected string $log_source = 'fshipping_locations';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    /**
     * Search for nearby FedEx locations.
     *
     * @param array $args
     * @return array FedEx output.locationDetailList[] or [] on failure.
     * @since 1.1
     */
    public function search(array $args): array {
        $payload = $this->prepare_payload($args);
        $this->debug_log_locations('request_payload', $payload);

        $decoded = $this->post('/location/v1/locations', $payload);
        $this->debug_log_locations('response_body', $decoded);

        return $decoded['output']['locationDetailList'] ?? [];
    }

    /**
     * Write Locations Search payload/response to PHP's error log (typically
     * `wp-content/debug.log` when `WP_DEBUG_LOG` is enabled), regardless of
     * `WP_DEBUG`, so merchants can diagnose empty shortcode results without
     * relying on WooCommerce logger alone.
     *
     * @param string $phase
     * @param mixed  $data
     * @return void
     * @since 1.2
     */
    private function debug_log_locations(string $phase, $data): void {
        unset($phase, $data);
    }

    /**
     * @param array $args
     * @return array
     * @since 1.1
     */
    private function prepare_payload(array $args): array {
        $location = [];
        if (!empty($args['latitude']) && !empty($args['longitude'])) {
            $location['geographicCoordinates'] = sprintf('%s,%s', (float) $args['latitude'], (float) $args['longitude']);
        } elseif (!empty($args['phone'])) {
            $location['phoneNumber'] = sanitize_text_field($args['phone']);
        } else {
            $location['address'] = [
                'postalCode'  => sanitize_text_field($args['postal_code'] ?? ''),
                'countryCode' => sanitize_text_field($args['country']     ?? 'US'),
            ];
        }

        $payload = [
            'locationsSearchCriterion' => sanitize_text_field($args['criterion'] ?? 'ADDRESS'),
            'location'                 => $location,
            'sortDetail'               => [
                'criteria'   => strtoupper(sanitize_text_field($args['sort_by'] ?? 'distance')),
                'maxResults' => max(1, min(75, (int) ($args['limit'] ?? 10))),
            ],
        ];

        if (!empty($args['capabilities']) && is_array($args['capabilities'])) {
            $payload['constraints'] = [
                'resultsFilters' => array_values(array_map('sanitize_text_field', $args['capabilities'])),
            ];
        }

        return apply_filters('fshipping_locations_payload', $payload, $args);
    }
}
