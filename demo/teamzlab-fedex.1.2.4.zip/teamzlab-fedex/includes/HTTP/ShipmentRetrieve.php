<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Retrieve a previously-created FedEx shipment by transaction ID.
 *
 * FedEx endpoint (TODO: verify): GET /ship/v1/shipments/results/{transactionId}
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class ShipmentRetrieve extends BaseClient {
    protected string $log_source = 'fshipping_ship_retrieve';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    public function by_transaction_id(string $transaction_id): array {
        $transaction_id = sanitize_text_field($transaction_id);
        if (empty($transaction_id)) {
            return [];
        }
        if (empty($this->auth_header())) {
            return [];
        }
        $decoded = $this->get('/ship/v1/shipments/results/' . rawurlencode($transaction_id));
        return $decoded['output'] ?? [];
    }
}
