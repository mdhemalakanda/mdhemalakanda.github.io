<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Advanced Integrated Visibility (AIV) webhook subscription client.
 *
 * Uses tracking-scope OAuth (get_track_secret_token, not
 * get_secret_token).
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class TrackingWebhook extends BaseClient {
    protected string $log_source = 'fshipping_aiv';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    /**
     * AIV uses the tracking-scope OAuth credentials.
     */
    protected function auth_header(): string {
        $token = Authorization::instance()->get_track_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    /**
     * @param string[] $tracking_numbers Up to 1000.
     * @param array    $opts
     * @return array
     * @since 1.1
     */
    public function subscribe_tracking_numbers(array $tracking_numbers, array $opts = []): array {
        $tracking_numbers = array_values(array_filter(array_map('sanitize_text_field', $tracking_numbers)));
        if (empty($tracking_numbers)) {
            return [];
        }
        $tracking_numbers = array_slice($tracking_numbers, 0, 1000);

        $settings    = get_option('fshipping_options');
        $webhook_url = esc_url_raw($opts['webhook_url'] ?? ($settings['fshipping_aiv_webhook_url'] ?? ''));
        $events      = !empty($opts['events']) ? array_map('sanitize_text_field', (array) $opts['events']) : ['OC', 'IT', 'DL', 'DE', 'EX'];
        $ship_date   = sanitize_text_field($opts['ship_date'] ?? gmdate('Y-m-d'));

        $subscriptions = [];
        foreach ($tracking_numbers as $tn) {
            $subscriptions[] = [
                'trackingNumber'  => $tn,
                'shipDate'        => $ship_date,
                'notificationUrl' => $webhook_url,
                'eventTypes'      => $events,
            ];
        }

        return $this->post('/trck-sub/v2/trackingnumbers', ['notificationSubscriptions' => $subscriptions]);
    }

    /**
     * @param string[] $account_numbers
     * @param array    $opts
     * @return array
     * @since 1.1
     */
    public function subscribe_account_numbers(array $account_numbers, array $opts = []): array {
        $account_numbers = array_values(array_filter(array_map('sanitize_text_field', $account_numbers)));
        if (empty($account_numbers)) {
            return [];
        }

        $settings    = get_option('fshipping_options');
        $webhook_url = esc_url_raw($opts['webhook_url'] ?? ($settings['fshipping_aiv_webhook_url'] ?? ''));
        $events      = !empty($opts['events']) ? array_map('sanitize_text_field', (array) $opts['events']) : ['OC', 'IT', 'DL', 'DE', 'EX'];

        $payload = [
            'subscriptions' => [[
                'accountNumbers'  => $account_numbers,
                'notificationUrl' => $webhook_url,
                'eventTypes'      => $events,
            ]],
        ];

        return $this->post('/trck-sub/v2/accountnumbers', $payload);
    }

    /**
     * @return array
     * @since 1.2
     */
    public function list_subscriptions(): array {
        $decoded = $this->get('/trck-sub/v2/trackingnumbers');
        return $decoded['output'] ?? [];
    }

    /**
     * @param string   $subscription_id
     * @param string[] $event_types
     * @return bool
     * @since 1.2
     */
    public function modify_subscription(string $subscription_id, array $event_types): bool {
        $subscription_id = sanitize_text_field($subscription_id);
        if (empty($subscription_id) || empty($event_types)) {
            return false;
        }

        if (empty($this->auth_header())) {
            return false;
        }

        $payload  = ['eventTypes' => array_values(array_map('sanitize_text_field', $event_types))];
        $response = wp_remote_request(
            $this->base_url() . '/trck-sub/v2/trackingnumbers/' . rawurlencode($subscription_id),
            [
                'method'  => 'PUT',
                'timeout' => 60,
                'headers' => $this->build_headers($this->auth_header()),
                'body'    => wp_json_encode($payload),
            ]
        );

        if (is_wp_error($response)) {
            return false;
        }
        return 200 === (int) wp_remote_retrieve_response_code($response);
    }

    /**
     * @param string $subscription_id
     * @return bool
     * @since 1.1
     */
    public function unsubscribe($subscription_id): bool {
        $subscription_id = sanitize_text_field($subscription_id);
        if (empty($subscription_id)) {
            return false;
        }
        if (empty($this->auth_header())) {
            return false;
        }

        $response = wp_remote_post($this->base_url() . '/trck-sub/v2/trackingnumbers/cancel', [
            'method'  => 'PUT',
            'timeout' => 60,
            'headers' => $this->build_headers($this->auth_header()),
            'body'    => wp_json_encode(['subscriptionId' => $subscription_id]),
        ]);

        if (is_wp_error($response)) {
            return false;
        }
        return 200 === (int) wp_remote_retrieve_response_code($response);
    }
}
