<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Pickup Request API client.
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class Pickup extends BaseClient {
    protected string $log_source = 'fshipping_pickup';
    private string $last_error_message = '';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    public function check_availability(array $args): array {
        $settings = get_option('fshipping_options');
        $payload  = [
            'associatedAccountNumber' => ['value' => sanitize_text_field($settings['fshipping_acc_number'] ?? '')],
            'pickupAddress' => [
                'streetLines'         => isset($args['street_lines']) ? array_map('sanitize_text_field', (array) $args['street_lines']) : [],
                'city'                => sanitize_text_field($args['city']         ?? ''),
                'stateOrProvinceCode' => sanitize_text_field($args['state']        ?? ''),
                'postalCode'          => sanitize_text_field($args['postal_code']  ?? ''),
                'countryCode'         => sanitize_text_field($args['country']      ?? 'US'),
                'residential'         => !empty($args['residential']),
            ],
            'carriers'          => $args['carriers'] ?? ['FDXE', 'FDXG'],
            'dispatchDate'      => sanitize_text_field($args['dispatch_date']      ?? gmdate('Y-m-d', strtotime('+1 day'))),
            'packageReadyTime'  => sanitize_text_field($args['package_ready_time'] ?? '10:00:00'),
            'customerCloseTime' => sanitize_text_field($args['customer_close_time'] ?? '17:00:00'),
        ];

        $decoded = $this->post('/pickup/v1/pickups/availabilities', $payload);
        return $decoded['output'] ?? [];
    }

    public function create_pickup(array $args): array {
        $this->last_error_message = '';
        $settings = get_option('fshipping_options');
        $default_street_lines = [];
        if (!empty($settings['fshipping_labeling_streetline'])) {
            $default_street_lines = array_values(
                array_filter(
                    array_map(
                        'trim',
                        preg_split('/\r\n|\r|\n/', (string) $settings['fshipping_labeling_streetline'])
                    )
                )
            );
        }

        $street_lines = isset($args['street_lines'])
            ? array_map('sanitize_text_field', (array) $args['street_lines'])
            : $default_street_lines;

        $payload  = [
            'associatedAccountNumber' => ['value' => sanitize_text_field($settings['fshipping_acc_number'] ?? '')],
            'originDetail' => [
                'pickupLocation' => [
                    'contact' => [
                        'personName'  => sanitize_text_field($args['person_name']  ?? ($settings['fshipping_person_name']  ?? '')),
                        'phoneNumber' => sanitize_text_field($args['phone_number'] ?? ($settings['fshipping_phone_number'] ?? '')),
                        'companyName' => sanitize_text_field($args['company_name'] ?? ''),
                    ],
                    'address' => [
                        'streetLines'         => $street_lines,
                        'city'                => sanitize_text_field($args['city']         ?? ($settings['fshipping_city']         ?? '')),
                        'stateOrProvinceCode' => sanitize_text_field($args['state']        ?? ($settings['state_provincecod']     ?? '')),
                        'postalCode'          => sanitize_text_field($args['postal_code']  ?? ($settings['fshipping_postal_code']  ?? '')),
                        'countryCode'         => sanitize_text_field($args['country']      ?? ($settings['fshipping_country_code'] ?? 'US')),
                        'residential'         => !empty($args['residential']),
                    ],
                ],
                'readyDateTimestamp' => $this->iso8601_ready_timestamp($args['ready_datetime'] ?? ''),
                'customerCloseTime'  => sanitize_text_field($args['customer_close_time'] ?? '17:00:00'),
            ],
            'totalWeight' => [
                'units' => strtoupper($args['weight_unit'] ?? 'LB') === 'KG' ? 'KG' : 'LB',
                'value' => (string) (float) ($args['weight'] ?? 1),
            ],
            'packageCount' => (int) ($args['package_count'] ?? 1),
            'carrierCode'  => sanitize_text_field($args['carrier_code'] ?? 'FDXE'),
            'remarks'      => sanitize_text_field($args['remarks']      ?? ''),
        ];

        $this->debug_log('FedEx pickup create request payload', $payload);
        $this->debug_log('FedEx pickup create request summary', [
            'endpoint'             => '/pickup/v1/pickups',
            'readyDateTimestamp'   => (string) ($payload['originDetail']['readyDateTimestamp'] ?? ''),
            'customerCloseTime'    => (string) ($payload['originDetail']['customerCloseTime'] ?? ''),
            'packageCount'         => (int) ($payload['packageCount'] ?? 0),
            'carrierCode'          => (string) ($payload['carrierCode'] ?? ''),
        ]);
        $decoded = $this->post('/pickup/v1/pickups', $payload);
        $this->debug_log('FedEx pickup create response decoded', $decoded);
        if ( empty( $decoded['output'] ) ) {
            $error = $this->extract_fedex_error_message($decoded);

            $this->last_error_message = $error;
            $this->debug_log('FedEx pickup create response has no output', [
                'fedex_error' => $error,
                'errors'      => $decoded['errors'] ?? [],
                'alerts'      => $decoded['alerts'] ?? [],
                'message'     => $decoded['message'] ?? '',
            ]);
            return [];
        }

        return $decoded['output'] ?? [];
    }

    /**
     * Last create_pickup() error message.
     *
     * @return string
     */
    public function get_last_error_message(): string {
        return $this->last_error_message;
    }

    /**
     * Normalize a ready datetime to the ISO 8601 offset format the FedEx
     * Pickup API requires (e.g. 2026-10-22T10:00:00-05:00). Naive local
     * strings are interpreted in the site timezone; offset-qualified values
     * pass through unchanged.
     *
     * @param mixed $value Raw ready datetime.
     * @return string
     */
    private function iso8601_ready_timestamp($value): string {
        $value = trim((string) $value);
        if ('' === $value) {
            return gmdate('c', strtotime('+1 day 10:00'));
        }
        if (preg_match('/(?:Z|[+-]\d{2}:?\d{2})$/i', $value)) {
            $ts = strtotime($value);
            return false !== $ts ? gmdate('c', $ts) : gmdate('c', strtotime('+1 day 10:00'));
        }
        $tz = function_exists('wp_timezone') ? wp_timezone() : new \DateTimeZone('UTC');
        foreach (['Y-m-d\TH:i:s', 'Y-m-d\TH:i', 'Y-m-d H:i:s', 'Y-m-d H:i'] as $format) {
            $dt = \DateTimeImmutable::createFromFormat($format, $value, $tz);
            if ($dt instanceof \DateTimeImmutable && $dt->format($format) === $value) {
                return $dt->format('c');
            }
        }
        $ts = strtotime($value);
        if (false === $ts) {
            return gmdate('c', strtotime('+1 day 10:00'));
        }
        return (new \DateTimeImmutable('@' . $ts))->setTimezone($tz)->format('c');
    }

    /**
     * Extract readable error details from varied FedEx response shapes.
     *
     * @param array $decoded
     * @return string
     */
    private function extract_fedex_error_message(array $decoded): string {
        if ( ! empty( $decoded['errors'][0]['message'] ) ) {
            return sanitize_text_field( (string) $decoded['errors'][0]['message'] );
        }

        if ( ! empty( $decoded['alerts'][0]['message'] ) ) {
            return sanitize_text_field( (string) $decoded['alerts'][0]['message'] );
        }

        if ( ! empty( $decoded['message'] ) ) {
            return sanitize_text_field( (string) $decoded['message'] );
        }

        if ( ! empty( $decoded['error_description'] ) ) {
            return sanitize_text_field( (string) $decoded['error_description'] );
        }

        return 'FedEx returned no pickup output.';
    }

    public function retrieve(string $confirmation_code): array {
        $confirmation_code = sanitize_text_field($confirmation_code);
        if (empty($confirmation_code)) {
            return [];
        }
        $decoded = $this->get('/pickup/v1/pickups/' . rawurlencode($confirmation_code));
        return $decoded['output'] ?? [];
    }

    public function cancel_pickup($confirmation_code, array $extra = []): bool {
        $this->last_error_message = '';
        $confirmation_code = sanitize_text_field($confirmation_code);
        $this->debug_log('FedEx pickup cancel start', [
            'confirmation_code' => $confirmation_code,
            'extra'             => $extra,
        ]);
        if (empty($confirmation_code)) {
            $this->last_error_message = 'Missing pickup confirmation code.';
            return false;
        }
        if (empty($this->auth_header())) {
            $this->last_error_message = 'FedEx auth token missing.';
            return false;
        }

        $settings = get_option('fshipping_options');
        $retrieved_context = $this->get_cancel_context_from_retrieve($confirmation_code);
        $this->debug_log('FedEx pickup cancel retrieved context', $retrieved_context);

        $scheduled_date = sanitize_text_field($extra['scheduled_date'] ?? '');
        if ('' === $scheduled_date && !empty($retrieved_context['scheduled_date'])) {
            $scheduled_date = sanitize_text_field((string) $retrieved_context['scheduled_date']);
        }
        if ('' === $scheduled_date) {
            $scheduled_date = gmdate('Y-m-d', strtotime('+1 day'));
        }

        $location = sanitize_text_field($extra['location'] ?? '');
        if ('' === $location && !empty($retrieved_context['location'])) {
            $location = sanitize_text_field((string) $retrieved_context['location']);
        }

        $carrier = sanitize_text_field($extra['carrier_code'] ?? '');
        if ('' === $carrier && !empty($retrieved_context['carrier_code'])) {
            $carrier = sanitize_text_field((string) $retrieved_context['carrier_code']);
        }

        $base_payload  = [
            'associatedAccountNumber' => ['value' => sanitize_text_field($settings['fshipping_acc_number'] ?? '')],
            'pickupConfirmationCode'  => $confirmation_code,
            'scheduledDate'           => $scheduled_date,
            'remarks'                 => sanitize_text_field($extra['remarks']        ?? ''),
        ];

        // FedEx cancel payload validation is strict and can vary by account.
        // Retry with progressively simpler payloads to avoid hard failures on
        // optional field mismatches.
        $payload_variants = [];

        $with_optional = $base_payload;
        if ('' !== $carrier) {
            $with_optional['carrierCode'] = $carrier;
        }
        if ('' !== $location) {
            $with_optional['location'] = $location;
        }
        $payload_variants[] = $with_optional;

        $with_carrier_only = $base_payload;
        if ('' !== $carrier) {
            $with_carrier_only['carrierCode'] = $carrier;
            $payload_variants[] = $with_carrier_only;
        }

        $payload_variants[] = $base_payload;

        foreach ($payload_variants as $payload) {
            $this->debug_log('FedEx pickup cancel request payload', $payload);
            $response = wp_remote_post($this->base_url() . '/pickup/v1/pickups/cancel', [
                'method'  => 'PUT',
                'timeout' => 60,
                'headers' => $this->build_headers($this->auth_header()),
                'body'    => wp_json_encode($payload),
            ]);

            if (is_wp_error($response)) {
                $this->last_error_message = $response->get_error_message();
                $this->debug_log('FedEx pickup cancel wp_error', $this->last_error_message);
                continue;
            }

            $status = (int) wp_remote_retrieve_response_code($response);
            $body   = (string) wp_remote_retrieve_body($response);
            $this->debug_log('FedEx pickup cancel response', [
                'http_status' => $status,
                'body'        => $body,
            ]);
            if ($status >= 200 && $status < 300) {
                return true;
            }

            $decoded = json_decode($body, true);
            if (is_array($decoded)) {
                $this->last_error_message = $this->extract_fedex_error_message($decoded);
            }
        }

        if ('' === $this->last_error_message) {
            $this->last_error_message = 'FedEx pickup cancel failed. Invalid field value in request payload.';
        }
        return false;
    }

    /**
     * Retrieve pickup details and derive cancel fields.
     *
     * @param string $confirmation_code
     * @return array{scheduled_date:string,location:string,carrier_code:string}
     */
    private function get_cancel_context_from_retrieve($confirmation_code): array {
        $out = [
            'scheduled_date' => '',
            'location'       => '',
            'carrier_code'   => '',
        ];

        $details = $this->retrieve((string) $confirmation_code);
        if (empty($details) || !is_array($details)) {
            return $out;
        }

        if (!empty($details['scheduledDate'])) {
            $out['scheduled_date'] = (string) $details['scheduledDate'];
        } elseif (!empty($details['pickupDate'])) {
            $out['scheduled_date'] = (string) $details['pickupDate'];
        } elseif (!empty($details['readyDateTimestamp'])) {
            $ts = strtotime((string) $details['readyDateTimestamp']);
            if (false !== $ts) {
                $out['scheduled_date'] = gmdate('Y-m-d', $ts);
            }
        }

        if (!empty($details['location'])) {
            $out['location'] = (string) $details['location'];
        } elseif (!empty($details['pickupLocation'])) {
            $out['location'] = (string) $details['pickupLocation'];
        }

        if (!empty($details['carrierCode'])) {
            $out['carrier_code'] = (string) $details['carrierCode'];
        }

        return $out;
    }

    /**
     * Write temporary pickup debugging details into debug.log.
     *
     * @param string $title
     * @param mixed  $data
     * @return void
     */
    private function debug_log($title, $data = null): void {
        unset($title, $data);
    }
}
