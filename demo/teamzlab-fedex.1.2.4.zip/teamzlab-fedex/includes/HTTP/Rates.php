<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Programmatic wrapper around the Rates & Transit Times API.
 *
 * HTTP\Shipping is a WooCommerce shipping method; this class exposes the
 * same REST capability to shortcodes, REST routes, and Ajax endpoints —
 * without requiring a WooCommerce package structure on input.
 *
 * FedEx endpoint: POST /rate/v1/rates/quotes
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class Rates extends BaseClient {
    protected string $log_source = 'fshipping_rates';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    /**
     * Request rate quotes for an arbitrary shipment.
     *
     * @param array $args
     * @return array Rate reply details or [] on failure.
     * @since 1.1
     */
    public function get_rates(array $args): array {
        if (empty($this->auth_header())) {
            return [];
        }
        $decoded = $this->post('/rate/v1/rates/quotes', $this->prepare_payload($args));
        return $decoded['output']['rateReplyDetails'] ?? [];
    }

    /**
     * Build the /rate/v1/rates/quotes payload.
     *
     * @param array $args
     * @return array
     * @since 1.1
     */
    private function prepare_payload(array $args): array {
        $settings = get_option('fshipping_options');
        $acc      = !empty($settings['fshipping_acc_number']) ? sanitize_text_field($settings['fshipping_acc_number']) : '';

        $origin_postcode      = sanitize_text_field($args['origin_postcode']     ?? ($settings['fshipping_postal_code']  ?? ''));
        $origin_country       = sanitize_text_field($args['origin_country']      ?? ($settings['fshipping_country_code'] ?? 'US'));
        $destination_postcode = sanitize_text_field($args['destination_postcode']?? '');
        $destination_country  = sanitize_text_field($args['destination_country'] ?? 'US');

        $weight              = (float) ($args['weight'] ?? 1);
        $raw_weight_unit     = strtoupper((string) ($args['weight_unit'] ?? 'LB'));
        $weight_unit         = in_array($raw_weight_unit, ['LB', 'KG'], true) ? $raw_weight_unit : 'LB';
        $length              = (int) ($args['length'] ?? 10);
        $width               = (int) ($args['width']  ?? 10);
        $height              = (int) ($args['height'] ?? 10);
        $raw_dimension_unit  = strtoupper((string) ($args['dimension_unit'] ?? 'IN'));
        $dimension_unit      = in_array($raw_dimension_unit, ['IN', 'CM'], true) ? $raw_dimension_unit : 'IN';
        $pickup_type         = sanitize_text_field($args['pickup_type'] ?? ($settings['fshipping_pickup_type'] ?? 'USE_SCHEDULED_PICKUP'));
        $rate_request_type   = !empty($args['rate_request_type']) ? wc_clean($args['rate_request_type']) : (!empty($settings['fshipping_rate_request_type']) ? wc_clean($settings['fshipping_rate_request_type']) : ['LIST']);

        $packaging_type = !empty($args['packaging_type']) ? sanitize_text_field((string) $args['packaging_type']) : '';

        $requested_shipment = [
            'shipper'   => ['address' => ['postalCode' => $origin_postcode,      'countryCode' => $origin_country]],
            'recipient' => ['address' => ['postalCode' => $destination_postcode, 'countryCode' => $destination_country]],
            'pickupType'      => $pickup_type,
            'rateRequestType' => $rate_request_type,
            'requestedPackageLineItems' => [[
                'weight'     => ['units' => $weight_unit,    'value' => (string) $weight],
                'dimensions' => ['length' => $length, 'width' => $width, 'height' => $height, 'units' => $dimension_unit],
            ]],
        ];
        if ($packaging_type !== '') {
            $requested_shipment['packagingType'] = $packaging_type;
        }

        $payload = [
            'accountNumber'     => ['value' => $acc],
            'requestedShipment' => $requested_shipment,
        ];

        return apply_filters('fshipping_rates_payload', $payload, $args);
    }
}
