<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use FSHIPPING\Utils\SecureUploads;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Modern Basic Integrated Visibility (Track) client.
 *
 * Batching (≤ 30 per call), SPOD extraction, EDTW extraction, scan
 * timeline, 10-minute per-number cache, retry on NOTFOUND, + lookup
 * by reference / TCN / door tag, + SPOD PDF download.
 *
 * Uses tracking-scope OAuth (get_track_secret_token).
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class Tracking extends BaseClient {
    public const BATCH_LIMIT = 30;
    public const CACHE_TTL   = 600;

    protected string $log_source = 'fshipping_tracking';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_track_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    public function batch(array $tracking_numbers, bool $force_fresh = false): array {
        $tracking_numbers = array_values(array_unique(array_filter(array_map('sanitize_text_field', $tracking_numbers))));
        if (empty($tracking_numbers)) {
            return [];
        }
        $tracking_numbers = array_slice($tracking_numbers, 0, self::BATCH_LIMIT);

        $results  = [];
        $to_fetch = [];
        foreach ($tracking_numbers as $tn) {
            if (!$force_fresh) {
                $cached = get_transient($this->cache_key($tn));
                if (false !== $cached) {
                    $results[$tn] = $cached;
                    continue;
                }
            }
            $to_fetch[] = $tn;
        }

        if (!empty($to_fetch)) {
            $live = $this->fetch($to_fetch);
            foreach ($live as $tn => $parsed) {
                $results[$tn] = $parsed;
                set_transient($this->cache_key($tn), $parsed, self::CACHE_TTL);
                $this->persist_to_shipment($tn, $parsed);
            }
        }

        foreach ($tracking_numbers as $tn) {
            if (!isset($results[$tn])) {
                $results[$tn] = [];
            }
        }
        return $results;
    }

    /**
     * Single-tracking-number convenience wrapper. Renamed from get()
     * to avoid colliding with BaseClient::get() (HTTP GET).
     *
     * @param string $tracking_number
     * @param bool   $force_fresh
     * @return array
     * @since 1.2
     */
    public function get_one(string $tracking_number, bool $force_fresh = false): array {
        $tracking_number = sanitize_text_field($tracking_number);
        if (empty($tracking_number)) {
            return [];
        }
        $result = $this->batch([$tracking_number], $force_fresh);
        return $result[$tracking_number] ?? [];
    }

    public function by_reference(string $reference, string $account_number = ''): array {
        $reference = sanitize_text_field($reference);
        if (empty($reference)) {
            return [];
        }
        $settings = get_option('fshipping_options');
        $account_number = $account_number ?: sanitize_text_field((string) ($settings['fshipping_acc_number'] ?? ''));

        return $this->call_with_info([[
            'trackingNumberInfo' => [
                'trackingNumberUniqueId' => '',
                'referenceNumberInfo'    => [
                    'referenceNumber' => $reference,
                    'accountNumber'   => $account_number,
                ],
            ],
        ]]);
    }

    public function by_tcn(string $tcn): array {
        $tcn = sanitize_text_field($tcn);
        if (empty($tcn)) {
            return [];
        }
        return $this->call_with_info([[
            'trackingNumberInfo' => ['trackingNumber' => $tcn, 'carrierCode' => 'FDXG'],
        ]]);
    }

    public function by_door_tag(string $door_tag, string $postal_code, string $country = 'US'): array {
        $door_tag    = sanitize_text_field($door_tag);
        $postal_code = sanitize_text_field($postal_code);
        if (empty($door_tag) || empty($postal_code)) {
            return [];
        }
        return $this->call_with_info([[
            'trackingNumberInfo' => [
                'trackingNumber' => $door_tag,
                'shipDateBegin'  => gmdate('Y-m-d', strtotime('-14 days')),
                'shipDateEnd'    => gmdate('Y-m-d'),
            ],
            'shipmentAddress' => [
                'postalCode'  => $postal_code,
                'countryCode' => sanitize_text_field($country),
            ],
        ]]);
    }

    public function download_spod(string $tracking_number): string {
        $tracking_number = sanitize_text_field($tracking_number);
        if (empty($tracking_number)) {
            return '';
        }

        $payload = [
            'trackDocumentDetail' => [
                'documentType'   => 'SIGNATURE_PROOF_OF_DELIVERY',
                'documentFormat' => 'PDF',
            ],
            'trackDocumentSpecification' => [[
                'trackingNumberInfo' => ['trackingNumber' => $tracking_number],
                'shipDateBegin' => gmdate('Y-m-d', strtotime('-60 days')),
                'shipDateEnd'   => gmdate('Y-m-d'),
            ]],
        ];

        $decoded = $this->request('POST', '/track/v1/trackingdocuments/retrievalshipsignatures', $payload);

        $encoded_pdf = '';
        $remote_url  = '';
        foreach ((array) ($decoded['output']['documents'] ?? []) as $doc) {
            if (!empty($doc['content'])) {
                $encoded_pdf = (string) $doc['content'];
                break;
            }
            if (!empty($doc['url'])) {
                $remote_url = (string) $doc['url'];
                break;
            }
        }

        if (empty($encoded_pdf) && empty($remote_url)) {
            return '';
        }

        if (!empty($remote_url)) {
            $pdf_response = wp_remote_get($remote_url, ['timeout' => 120]);
            if (is_wp_error($pdf_response)) {
                return '';
            }
            $pdf_bytes = (string) wp_remote_retrieve_body($pdf_response);
            if ('' === $pdf_bytes) {
                return '';
            }
            return $this->save_spod_pdf($tracking_number, $pdf_bytes);
        }

        $decoded_pdf = base64_decode($encoded_pdf, true);
        if (false === $decoded_pdf || '' === $decoded_pdf) {
            return '';
        }

        return $this->save_spod_pdf($tracking_number, $decoded_pdf);
    }

    /**
     * @param array $tracking_info
     * @return array
     * @since 1.1
     */
    private function fetch(array $tracking_numbers): array {
        $payload = $this->prepare_payload($tracking_numbers);
        $decoded = $this->post('/track/v1/trackingnumbers', $payload);
        $parsed  = $this->parse_response($decoded);

        // Retry once on TRACK.TRACKINGNUMBER.NOTFOUND for any missing number.
        $missing = array_diff($tracking_numbers, array_keys(array_filter($parsed)));
        if (!empty($missing) && !empty($decoded)) {
            $retried = false;
            foreach ((array) ($decoded['output']['completeTrackResults'] ?? []) as $result) {
                foreach ((array) ($result['trackResults'] ?? []) as $track) {
                    $code = strtoupper((string) ($track['error']['code'] ?? ''));
                    if ($code === 'TRACK.TRACKINGNUMBER.NOTFOUND') {
                        $retried = true;
                        break 2;
                    }
                }
            }
            if ($retried) {
                sleep(2);
                $retry_decoded = $this->post('/track/v1/trackingnumbers', $this->prepare_payload(array_values($missing)));
                $retry_parsed  = $this->parse_response($retry_decoded);
                $parsed        = array_merge($parsed, $retry_parsed);
            }
        }

        return $parsed;
    }

    private function call_with_info(array $tracking_info): array {
        $payload = ['trackingInfo' => $tracking_info, 'includeDetailedScans' => true];
        $decoded = $this->post('/track/v1/trackingnumbers', $payload);
        $parsed  = $this->parse_response($decoded);
        return array_values($parsed)[0] ?? [];
    }

    private function prepare_payload(array $tracking_numbers): array {
        $info = [];
        foreach ($tracking_numbers as $tn) {
            $info[] = ['trackingNumberInfo' => ['trackingNumber' => $tn]];
        }
        return ['trackingInfo' => $info, 'includeDetailedScans' => true];
    }

    private function parse_response(array $decoded): array {
        $out = [];
        foreach ((array) ($decoded['output']['completeTrackResults'] ?? []) as $result) {
            foreach ((array) ($result['trackResults'] ?? []) as $track) {
                $tn = sanitize_text_field((string) ($track['trackingNumberInfo']['trackingNumber'] ?? ''));
                if (empty($tn)) continue;
                if (!empty($track['error'])) {
                    $out[$tn] = [];
                    continue;
                }
                $out[$tn] = $this->flatten_track($track);
            }
        }
        return $out;
    }

    private function flatten_track(array $track): array {
        $spod_url = '';
        foreach ((array) ($track['availableImages'] ?? []) as $image) {
            if (strtoupper((string) ($image['type'] ?? '')) === 'SIGNATURE_PROOF_OF_DELIVERY') {
                $spod_url = esc_url_raw((string) ($image['url'] ?? ''));
                break;
            }
        }
        if (empty($spod_url) && !empty($track['deliveryDetails']['signatureImageUrl'])) {
            $spod_url = esc_url_raw((string) $track['deliveryDetails']['signatureImageUrl']);
        }

        $window = $track['estimatedDeliveryTimeWindow'] ?? [];
        $edtw_start = sanitize_text_field((string) ($window['window']['begins'] ?? ($window['begin'] ?? '')));
        $edtw_end   = sanitize_text_field((string) ($window['window']['ends']   ?? ($window['end']   ?? '')));

        $scan_events = [];
        foreach ((array) ($track['scanEvents'] ?? []) as $event) {
            $scan_events[] = [
                'code' => sanitize_text_field((string) ($event['eventType']        ?? '')),
                'desc' => sanitize_text_field((string) ($event['eventDescription'] ?? '')),
                'at'   => sanitize_text_field((string) ($event['date']             ?? '')),
                'city' => sanitize_text_field((string) ($event['scanLocation']['city'] ?? '')),
            ];
        }

        $is_master   = !empty($track['packageDetails']['count']) && (int) $track['packageDetails']['count'] > 1;
        $piece_count = (int) ($track['packageDetails']['count'] ?? 1);
        $piece_seq   = (int) ($track['packageDetails']['packageSequenceNumber'] ?? 1);
        $master_tn   = sanitize_text_field((string) ($track['additionalTrackingInfo']['nickname']
            ?? ($track['packageDetails']['masterTrackingNumber'] ?? '')));

        return [
            'tracking_number'  => sanitize_text_field((string) ($track['trackingNumberInfo']['trackingNumber'] ?? '')),
            'status'           => sanitize_text_field((string) ($track['latestStatusDetail']['statusByLocale']  ?? '')),
            'description'      => sanitize_text_field((string) ($track['latestStatusDetail']['description']     ?? '')),
            'at'               => sanitize_text_field((string) ($track['dateAndTimes'][0]['dateTime']           ?? '')),
            'service'          => sanitize_text_field((string) ($track['serviceDetail']['description']          ?? '')),
            'shipper_city'     => sanitize_text_field((string) ($track['shipperInformation']['address']['city']   ?? '')),
            'recipient_city'   => sanitize_text_field((string) ($track['recipientInformation']['address']['city'] ?? '')),
            'spod_url'         => $spod_url,
            'edtw_start'       => $edtw_start,
            'edtw_end'         => $edtw_end,
            'scan_events'      => $scan_events,
            'mps_is_master'    => $is_master,
            'mps_piece_count'  => $piece_count,
            'mps_piece_seq'    => $piece_seq,
            'mps_master_tn'    => $master_tn,
        ];
    }

    private function persist_to_shipment(string $tracking_number, array $parsed): void {
        if (empty($parsed)) return;
        $shipment_id = $this->find_shipment_id($tracking_number);
        if (empty($shipment_id)) return;

        if (!empty($parsed['spod_url'])) {
            update_post_meta($shipment_id, '_fshipping_spod_url', esc_url_raw($parsed['spod_url']));
        }
        if (!empty($parsed['edtw_start']) || !empty($parsed['edtw_end'])) {
            update_post_meta($shipment_id, '_fshipping_edtw', [
                'start' => $parsed['edtw_start'],
                'end'   => $parsed['edtw_end'],
            ]);
        }
        update_post_meta($shipment_id, '_fshipping_tracking_state', [
            'status'      => $parsed['status'],
            'description' => $parsed['description'],
            'at'          => $parsed['at'],
        ]);
    }

    private function save_spod_pdf(string $tracking_number, string $pdf_bytes): string {
        if (empty($pdf_bytes)) return '';
        // Signature proof-of-delivery PDFs carry recipient names/addresses —
        // store them in the per-install random subdirectory (SecureUploads)
        // so the tracking-named files stay unguessable.
        $folder = SecureUploads::get_dir('spod');
        if ('' === $folder) return '';
        $filename  = 'spod-' . sanitize_file_name($tracking_number) . '.pdf';
        $file_path = $folder . '/' . $filename;
        $file_url  = SecureUploads::get_url('spod') . '/' . $filename;
        if (false === file_put_contents($file_path, $pdf_bytes)) {
            return '';
        }
        $sid = $this->find_shipment_id($tracking_number);
        if ($sid) {
            update_post_meta($sid, '_fshipping_spod_pdf_url', esc_url_raw($file_url));
        }
        return $file_url;
    }

    private function find_shipment_id(string $tracking_number): int {
        $ids = get_posts([
            'post_type'      => 'fedex_shipping',
            'post_status'    => 'any',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Exact-match lookup on this plugin's fedex_shipping CPT by its _tracking_number meta to attach the cached SPOD PDF; single post, hard-limited to 1.
            'meta_query'     => [[
                'key' => '_tracking_number', 'value' => $tracking_number, 'compare' => '=',
            ]],
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ]);
        return !empty($ids) ? (int) reset($ids) : 0;
    }

    private function cache_key(string $tracking_number): string {
        return 'fshipping_track_' . md5($tracking_number);
    }
}
