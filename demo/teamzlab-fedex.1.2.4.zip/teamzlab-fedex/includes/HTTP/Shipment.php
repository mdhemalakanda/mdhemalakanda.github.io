<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\OpenShip\Draft;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\AddressNormalizer;
use FSHIPPING\Utils\Helper;
use FSHIPPING\Utils\OrderMeta;
use FSHIPPING\Utils\SecureUploads;
use FSHIPPING\Utils\Shipment as ShipmentHelper;

/**
 * This class will create shipment for fedex.
 * 
 * @since 1.0
 */
defined('ABSPATH') || exit;

class Shipment {
    use SingletonTrait;
    private const MIN_ITEM_WEIGHT_KG = 0.1;
    private const FREIGHT_MIN_PACKAGE_WEIGHT_LB = 150.01;
    private const FREIGHT_MIN_PACKAGE_WEIGHT_KG = 68.05;
    private const WC_LOG_SOURCE_SHIPMENT_CREATE = 'teamz_shipment_create';
    private const DOMESTIC_EXPRESS_SERVICE_TYPES = [
        'FIRST_OVERNIGHT',
        'PRIORITY_OVERNIGHT',
        'STANDARD_OVERNIGHT',
        'FEDEX_2_DAY',
        'FEDEX_2_DAY_AM',
        'FEDEX_EXPRESS_SAVER',
        'SAME_DAY',
        'SAME_DAY_CITY',
        'FEDEX_FIRST_FREIGHT',
        'FEDEX_1_DAY_FREIGHT',
        'FEDEX_2_DAY_FREIGHT',
        'FEDEX_3_DAY_FREIGHT',
    ];

    // track shipment.
    public function track_shipment($tracking_id) {
        // The shortcode and the AJAX tracking widget both funnel through this
        // method unauthenticated, so throttle per IP before spending FedEx
        // quota. Over the limit, answer with a FedEx-style error envelope —
        // both callers already escape and render that path, so the widget
        // shows a "try again later" notice without a live API call.
        if (class_exists('\FSHIPPING\Utils\RateLimiter') && !\FSHIPPING\Utils\RateLimiter::check('fedex_track')) {
            return [
                'errors' => [
                    [
                        'message' => __('Too many tracking requests. Please try again later.', 'teamzlab-fedex'),
                    ],
                ],
            ];
        }
        $tracking_id = $this->resolve_tracking_number($tracking_id);
        $track_token = Authorization::instance()->get_track_secret_token();
        if( empty( $track_token ) ) {
            return '';
        }
        $payload = $this->prepare_track_payload($tracking_id);
        $endpoint = Helper::instance()->get_base_url(). '/track/v1/trackingnumbers';
        $response = $this->send_tracking_request($endpoint, $payload, $track_token);
        if ( is_wp_error($response) ) {
            return [];
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );
        return $data;
    }

    /**
     * Send tracking API request with a given token.
     *
     * @param string $endpoint
     * @param array  $payload
     * @param string $token
     * @return array|\WP_Error
     */
    private function send_tracking_request($endpoint, $payload, $token) {
        return wp_remote_post( $endpoint, [
            'method'  => 'POST',
            'timeout' => 60,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'X-locale'      => 'en_US',
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( $payload ),
        ] );
    }

    // tracking payload.
    public function prepare_track_payload($tracking_id) {
        return [
            'trackingInfo' => [
                [
                    'trackingNumberInfo' => [
                        'trackingNumber' => $tracking_id,
                    ],
                ],
            ],
            'includeDetailedScans' => true
        ];
    }

    // create shipment.
    public function create_shipment($current_shipment, $order) {
        $token = Authorization::instance()->get_secret_token();
        if (empty($token)) {
            throw new \Exception(
                esc_html__('FedEx shipment failed: could not obtain an API token. Check FedEx credentials and environment in settings.', 'teamzlab-fedex')
            );
        }

        $endpoint = Helper::instance()->get_base_url(). '/ship/v1/shipments';
        $payload = $this->prepare_shipment_payload($current_shipment, $order);
        $effective_units = $this->resolve_effective_ship_units($order, $current_shipment);
        $target_weight_unit = $effective_units['weight_unit'];
        $target_dimension_unit = $effective_units['dimension_unit'];
        $payload = Helper::instance()->normalize_fedex_payload_weight_units($payload, $target_weight_unit);
        $payload = Helper::instance()->normalize_fedex_payload_dimension_units($payload, $target_dimension_unit);
        $payload = $this->enforce_minimum_package_weight_for_freight_service($payload, $order);
        $payload = Helper::instance()->normalize_declared_value($payload);
        $payload = $this->sanitize_label_and_document_payload($payload);
        $this->warn_if_mixed_weight_units($payload, $target_weight_unit);
        $this->warn_if_mixed_system_units($payload, $target_weight_unit, $target_dimension_unit);
        $this->log_shipment_create_payload($payload);
        $response = wp_remote_post( $endpoint, [
            'method'  => 'POST',
            'timeout' => 60,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'X-locale'      => 'en_US',
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( $payload ),
        ] );

        if (is_wp_error($response)) {
            $this->log_shipment_create_response([
                'wp_error' => $response->get_error_message(),
                'code'     => $response->get_error_code(),
            ]);
            throw new \Exception(esc_html(__('Shipping request failed: ', 'teamzlab-fedex') . $response->get_error_message()));
        }

        $status_code = (int) wp_remote_retrieve_response_code($response);
        $body        = wp_remote_retrieve_body( $response );
        $data        = json_decode($body, true);
        $this->log_shipment_create_response(
            is_array($data)
                ? $data
                : [
                    'http_status'        => $status_code,
                    '_non_json_preview'  => function_exists('mb_substr') ? mb_substr((string) $body, 0, 8000, 'UTF-8') : substr((string) $body, 0, 8000),
                ]
        );

        if ($status_code < 200 || $status_code >= 300) {
            $snippet = '';
            if (is_array($data) && !empty($data['errors'][0]['message'])) {
                $snippet = sanitize_text_field((string) $data['errors'][0]['message']);
            } elseif (is_array($data) && !empty($data['error']['error_description'])) {
                $snippet = sanitize_text_field((string) $data['error']['error_description']);
            } else {
                $snippet = wp_strip_all_tags((string) (function_exists('mb_substr') ? mb_substr($body, 0, 500) : substr($body, 0, 500)));
            }
            throw new \Exception(esc_html(__('FedEx Error: ', 'teamzlab-fedex') . ($snippet !== '' ? $snippet : __('HTTP error from FedEx.', 'teamzlab-fedex'))));
        }

        if (!is_array($data)) {
            throw new \Exception(esc_html__('FedEx Error: Invalid or empty response from FedEx.', 'teamzlab-fedex'));
        }

        if (!empty($data['errors'])) {
            $error   = reset($data['errors']);
            $message = !empty($error['message']) ? sanitize_text_field($error['message']) : __('Unknown shipping error occurred.', 'teamzlab-fedex');

            throw new \Exception(esc_html(__('FedEx Error: ', 'teamzlab-fedex') . $message));
        } elseif( !empty($data['error']) ) {
            $error = $data['error'];
            $error_description = !empty($error['error_description']) ? sanitize_text_field($error['error_description']) : __('Unknown shipping error occurred.', 'teamzlab-fedex');
            throw new \Exception(esc_html(__('FedEx Error: ', 'teamzlab-fedex') . $error_description));
        }

        $this->persist_shipment_from_api_response($order, $data);
    }

    /**
     * Log shipment create to WooCommerce logs.
     *
     * Full request JSON carries customer PII (name, phone, street), so it is
     * only written when WP_DEBUG is on. Otherwise a single info line with
     * non-PII essentials is logged instead.
     *
     * @param array<string,mixed> $payload
     * @return void
     */
    private function log_shipment_create_payload(array $payload): void {
        if (!function_exists('wc_get_logger')) {
            return;
        }
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $encoded = wp_json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            if (false === $encoded) {
                $encoded = '{}';
            }
            wc_get_logger()->info('Payload: ' . $encoded, ['source' => self::WC_LOG_SOURCE_SHIPMENT_CREATE]);
            return;
        }
        wc_get_logger()->info(
            'Payload: service=' . $this->shipment_payload_service_type($payload)
                . ' packages=' . $this->shipment_payload_package_count($payload),
            ['source' => self::WC_LOG_SOURCE_SHIPMENT_CREATE]
        );
    }

    /**
     * Log shipment create response to WooCommerce logs.
     *
     * Full response JSON carries recipient contact data, so it is only written
     * when WP_DEBUG is on. Otherwise a single info line with non-PII
     * essentials (tracking, service, HTTP/error codes) is logged instead.
     *
     * @param array<string,mixed> $response_data
     * @return void
     */
    private function log_shipment_create_response(array $response_data): void {
        if (!function_exists('wc_get_logger')) {
            return;
        }
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $encoded = wp_json_encode($response_data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            if (false === $encoded) {
                $encoded = '{}';
            }
            wc_get_logger()->info('Response: ' . $encoded, ['source' => self::WC_LOG_SOURCE_SHIPMENT_CREATE]);
            return;
        }
        $parts   = ['Response:'];
        $parts[] = 'tracking=' . $this->shipment_response_tracking_number($response_data);
        $service = '';
        if (!empty($response_data['output']['transactionShipments'][0]['serviceType'])) {
            $service = sanitize_text_field((string) $response_data['output']['transactionShipments'][0]['serviceType']);
        }
        if ($service !== '') {
            $parts[] = 'service=' . $service;
        }
        if (isset($response_data['http_status'])) {
            $parts[] = 'http_status=' . (int) $response_data['http_status'];
        }
        $error_code = '';
        if (!empty($response_data['errors'][0]['code'])) {
            $error_code = sanitize_text_field((string) $response_data['errors'][0]['code']);
        } elseif (!empty($response_data['error']['code'])) {
            $error_code = sanitize_text_field((string) $response_data['error']['code']);
        } elseif (isset($response_data['code'])) {
            $error_code = sanitize_text_field((string) $response_data['code']);
        }
        if ($error_code !== '') {
            $parts[] = 'error_code=' . $error_code;
        }
        wc_get_logger()->info(implode(' ', $parts), ['source' => self::WC_LOG_SOURCE_SHIPMENT_CREATE]);
    }

    /**
     * Non-PII service type from a Ship payload, for summary logging.
     *
     * @param array<string,mixed> $payload
     * @return string
     */
    private function shipment_payload_service_type(array $payload): string {
        if (empty($payload['requestedShipment']['serviceType'])) {
            return 'unknown';
        }

        return sanitize_text_field((string) $payload['requestedShipment']['serviceType']);
    }

    /**
     * Non-PII package count from a Ship payload, for summary logging.
     *
     * @param array<string,mixed> $payload
     * @return int
     */
    private function shipment_payload_package_count(array $payload): int {
        $lines = $payload['requestedShipment']['requestedPackageLineItems'] ?? null;

        return is_array($lines) ? count($lines) : 0;
    }

    /**
     * Non-PII tracking number from a Ship response, for summary logging.
     *
     * @param array<string,mixed> $response_data
     * @return string
     */
    private function shipment_response_tracking_number(array $response_data): string {
        $ts = $response_data['output']['transactionShipments'][0] ?? null;
        if (!is_array($ts)) {
            return 'none';
        }
        $tracking = (string) ($ts['masterTrackingNumber'] ?? '');
        if ($tracking === '' && !empty($ts['pieceResponses'][0]['trackingNumber'])) {
            $tracking = (string) $ts['pieceResponses'][0]['trackingNumber'];
        }

        return $tracking !== '' ? sanitize_text_field($tracking) : 'none';
    }

    /**
     * Build the same normalized Ship API payload used at checkout (filters, commercial
     * invoice / shippingDocumentSpecification, sanitizers) for reuse where the HTTP call
     * is not Ship create — e.g. Open Ship **confirm** must repeat document requests stripped
     * from the Open Ship **start** payload.
     *
     * @param \WC_Order $order WooCommerce order with a FedEx shipping method line.
     * @return array<string, mixed> Full top-level payload (`labelResponseOptions`, `requestedShipment`, …) or [] if no FedEx line.
     * @since 1.8
     */
    public function build_processed_ship_payload_for_order($order): array {
        if (!is_object($order) || !method_exists($order, 'get_id')) {
            return [];
        }
        $current = Draft::get_fedex_shipping_line($order);
        if ($current === null) {
            return [];
        }

        $payload = $this->prepare_shipment_payload($current, $order);
        $effective_units       = $this->resolve_effective_ship_units($order, $current);
        $target_weight_unit    = $effective_units['weight_unit'];
        $target_dimension_unit = $effective_units['dimension_unit'];
        $payload               = Helper::instance()->normalize_fedex_payload_weight_units($payload, $target_weight_unit);
        $payload               = Helper::instance()->normalize_fedex_payload_dimension_units($payload, $target_dimension_unit);
        $payload               = $this->enforce_minimum_package_weight_for_freight_service($payload, $order);
        $payload               = Helper::instance()->normalize_declared_value($payload);
        $payload               = $this->sanitize_label_and_document_payload($payload);

        return is_array($payload) ? $payload : [];
    }

    /**
     * Download label PDF to uploads, save tracking on order, create fedex_shipping CPT.
     * Used by Ship API create and Open Ship confirm.
     *
     * @param \WC_Order $order
     * @param array     $data Full FedEx JSON body (output.transactionShipments, …).
     * @return void
     * @since 1.3
     */
    public function persist_shipment_from_api_response($order, array $data) {
        $order_id = (int) $order->get_id();
        $ts       = isset($data['output']['transactionShipments'][0]) && is_array($data['output']['transactionShipments'][0])
            ? $data['output']['transactionShipments'][0]
            : [];
        $master = !empty($ts['masterTrackingNumber']) ? (string) $ts['masterTrackingNumber'] : '';
        if ($master === '' && !empty($ts['pieceResponses'][0]['trackingNumber'])) {
            $master = (string) $ts['pieceResponses'][0]['trackingNumber'];
        }

        $sources = $this->collect_shipment_label_urls($ts);
        $box_name_map = $this->get_order_box_name_sequence_map($order_id);
        $merged_local = '';
        if ($sources['merged'] !== '' && $master !== '') {
            $merged_local = $this->download_fedex_label_to_uploads($sources['merged'], $master . '_merged', $order_id);
            if ($merged_local !== '') {
                // Order meta (not post meta) so the value survives HPOS,
                // where get_post_meta() on an order id hits a stub post.
                OrderMeta::update($order_id, Draft::META_MERGED_LABEL_FILE, $merged_local);
            }
        } else {
            OrderMeta::delete($order_id, Draft::META_MERGED_LABEL_FILE);
        }

        $piece_rows = [];
        foreach ($sources['pieces'] as $row) {
            $url   = $row['url'];
            $track = $row['tracking'];
            if ($url === '' || $track === '') {
                continue;
            }
            $stem = preg_replace('/[^A-Za-z0-9_-]+/', '', $track);
            if ($stem === '') {
                $stem = 'pkg' . (string) (count($piece_rows) + 1);
            }
            $local = $this->download_fedex_label_to_uploads($url, $stem, $order_id);
            if ($local !== '') {
                $entry = [
                    'sequence' => (int) $row['sequence'],
                    'tracking' => $track,
                    'file_url' => $local,
                ];
                $sequence_key = (string) ((int) ($row['sequence'] ?? 0));
                if ($sequence_key !== '0' && isset($box_name_map[$sequence_key]) && $box_name_map[$sequence_key] !== '') {
                    $entry['box_name'] = $box_name_map[$sequence_key];
                }
                if (!empty($row['content_type'])) {
                    $entry['content_type'] = (string) $row['content_type'];
                }
                $piece_rows[] = $entry;
            }
        }

        if ($piece_rows !== []) {
            OrderMeta::update($order_id, Draft::META_PACKAGE_LABEL_FILES, wp_json_encode($piece_rows));
        } else {
            OrderMeta::delete($order_id, Draft::META_PACKAGE_LABEL_FILES);
        }

        $primary_local = $merged_local !== '' ? $merged_local : ($piece_rows[0]['file_url'] ?? '');
        if ($primary_local === '' && $master !== '') {
            $fallback_remote = $sources['merged'] !== '' ? $sources['merged'] : ($sources['pieces'][0]['url'] ?? '');
            if ($fallback_remote !== '') {
                $response = wp_remote_get($fallback_remote, ['timeout' => 60]);
                if (!is_wp_error($response)) {
                    $pdf = wp_remote_retrieve_body($response);
                    $this->save_pdf($pdf, $master, $order_id);
                    $primary_local = (string) OrderMeta::get($order_id, '_fedex_label_url');
                }
            }
        }
        if ($primary_local !== '') {
            OrderMeta::update($order_id, '_fedex_label_url', $primary_local);
        }
        if ($master !== '') {
            OrderMeta::update($order_id, '_fedex_tracking', $master);
        }

        ShipmentHelper::instance()->create_shipment_post($order, $data);
    }

    /**
     * @param int $order_id
     * @return array<string,string>
     */
    private function get_order_box_name_sequence_map(int $order_id): array {
        if ($order_id <= 0) {
            return [];
        }
        $raw = (string) OrderMeta::get($order_id, Draft::META_PACKAGE_BOX_NAME_MAP);
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return [];
        }
        $out = [];
        foreach ($decoded as $sequence => $box_name) {
            $key = trim((string) $sequence);
            $name = sanitize_text_field((string) $box_name);
            if ($key === '' || $name === '') {
                continue;
            }
            $out[$key] = $name;
        }
        return $out;
    }

    /**
     * FedEx Ship / Open Ship: merged document URL plus per-piece label URLs.
     *
     * @param array<string, mixed> $ts First element of output.transactionShipments.
     * @return array{merged: string, pieces: array<int, array{url: string, tracking: string, sequence: int, content_type?: string}>}
     */
    private function collect_shipment_label_urls(array $ts): array {
        $out = ['merged' => '', 'pieces' => []];
        if (!empty($ts['shipmentDocuments']) && is_array($ts['shipmentDocuments'])) {
            foreach ($ts['shipmentDocuments'] as $doc) {
                if (!is_array($doc)) {
                    continue;
                }
                $url = isset($doc['url']) ? (string) $doc['url'] : '';
                if ($url === '') {
                    continue;
                }
                $ct = strtoupper((string) ($doc['contentType'] ?? ''));
                if (strpos($ct, 'MERGED') !== false || strpos($ct, 'MERGE') !== false) {
                    $out['merged'] = $url;
                    break;
                }
            }
            if ($out['merged'] === '' && isset($ts['shipmentDocuments'][0]) && is_array($ts['shipmentDocuments'][0])) {
                $u0 = isset($ts['shipmentDocuments'][0]['url']) ? (string) $ts['shipmentDocuments'][0]['url'] : '';
                if ($u0 !== '') {
                    $out['merged'] = $u0;
                }
            }
        }
        if (empty($ts['pieceResponses']) || !is_array($ts['pieceResponses'])) {
            return $out;
        }
        foreach ($ts['pieceResponses'] as $pr) {
            if (!is_array($pr)) {
                continue;
            }
            $track = (string) ($pr['trackingNumber'] ?? '');
            if ($track === '' && !empty($pr['trackingIds'][0]) && is_array($pr['trackingIds'][0])) {
                $track = (string) ($pr['trackingIds'][0]['trackingNumber'] ?? '');
            }
            $seq = isset($pr['packageSequenceNumber']) ? (int) $pr['packageSequenceNumber'] : 0;
            $pdocs = $pr['packageDocuments'] ?? [];
            if (!is_array($pdocs)) {
                continue;
            }
            $doc_i = 0;
            foreach ($pdocs as $pdoc) {
                if (!is_array($pdoc) || empty($pdoc['url'])) {
                    continue;
                }
                $url = (string) $pdoc['url'];
                if ($url === '') {
                    continue;
                }
                $ct = strtoupper((string) ($pdoc['contentType'] ?? $pdoc['documentType'] ?? ''));
                $stem_track = $track;
                if ($doc_i > 0) {
                    $stem_track = $track . '_doc' . (string) ($doc_i + 1);
                }
                $out['pieces'][] = [
                    'url'          => $url,
                    'tracking'     => $stem_track,
                    'sequence'     => $seq,
                    'content_type' => $ct,
                ];
                $doc_i++;
            }
        }

        return $out;
    }

    /**
     * GET FedEx label URL and write PDF under the randomized
     * uploads/fedex-labels/<per-install subdirectory>/.
     *
     * @param string $remote_url FedEx document retrieve URL.
     * @param string $file_stem  Filename stem (sanitized tracking or master_merge).
     * @param int    $order_id   WooCommerce order id (for traceability only).
     * @return string Local file URL or empty string on failure.
     */
    private function download_fedex_label_to_uploads(string $remote_url, string $file_stem, int $order_id): string {
        unset($order_id);
        $response = wp_remote_get($remote_url, ['timeout' => 60]);
        if (is_wp_error($response)) {
            return '';
        }
        $pdf = wp_remote_retrieve_body($response);

        return $this->write_fedex_label_pdf_to_uploads($pdf, $file_stem);
    }

    /**
     * @param string $pdf      Raw PDF bytes.
     * @param string $file_stem Safe filename stem (no extension).
     * @return string Public URL to saved file, or empty string.
     */
    private function write_fedex_label_pdf_to_uploads(string $pdf, string $file_stem): string {
        if ($pdf === '') {
            return '';
        }
        // Labels are customer documents, so they live in a per-install random
        // subdirectory: tracking-number filenames stay guessable, the folder
        // segment is not. SecureUploads also writes the .htaccess / index.php
        // guards for both the public root and the random folder.
        $folder = SecureUploads::get_dir('labels');
        if ($folder === '') {
            return '';
        }
        $stem     = preg_replace('/[^A-Za-z0-9_-]+/', '', $file_stem);
        if ($stem === '') {
            $stem = 'label';
        }
        $filename  = 'fedex-' . $stem . '.pdf';
        $file_path = $folder . '/' . $filename;
        $file_url  = SecureUploads::get_url('labels') . '/' . $filename;
        if (false === file_put_contents($file_path, $pdf)) {
            return '';
        }

        return $file_url;
    }

    private function save_pdf($pdf, $tracking, $order_id) {
        if (empty($pdf)) {
            return false;
        }
        $stem = preg_replace('/[^A-Za-z0-9_-]+/', '', (string) $tracking);
        if ($stem === '') {
            $stem = 'label';
        }
        $file_url = $this->write_fedex_label_pdf_to_uploads($pdf, $stem);
        if ($file_url === '') {
            return false;
        }
        OrderMeta::update($order_id, '_fedex_label_url', $file_url);
        OrderMeta::update($order_id, '_fedex_tracking', (string) $tracking);

        return $file_url;
    }
    /**
     * Create shipment payload.
     */
    public function prepare_shipment_payload($current_shipment, $order) {
        $service_type = !empty($current_shipment['meta']['service_type']) ? sanitize_text_field($current_shipment['meta']['service_type']) : '';
        // Get shipping address (normalized for FedEx: UK state omitted, postcode formatted, etc.).
        $dest = AddressNormalizer::normalize_from_order($order);
        $recept_street_lines = array_values(array_filter($dest['street_lines']));

        // labeling informations.
        $settings = get_option('fshipping_options');
        $acc_number = !empty($settings['fshipping_acc_number']) ? sanitize_text_field($settings['fshipping_acc_number']): '';
        $normalized_service_type = strtoupper(trim((string) $service_type));
        $is_residential_delivery = (
            strpos($normalized_service_type, 'HOME_DELIVERY') !== false ||
            strpos($normalized_service_type, 'HOME DELIVERY') !== false
        );
        // EXTR_SKIP keeps settings from clobbering locals defined above
        // ($settings, $acc_number, $service_type, $order, …). Registered
        // option keys are the fshipping_* fields plus state_provincecod —
        // none collide with those locals, so payload behavior is unchanged.
        extract( is_array( $settings ) ? $settings : [], EXTR_SKIP ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract -- legacy bare-variable payload builder; skip-only extraction prevents local clobbering.

        $street_lines = [];
        if (!empty($fshipping_labeling_streetline)) {
            $street_lines = array_filter(
                array_map('trim', preg_split('/\r\n|\r|\n/', $fshipping_labeling_streetline))
            );
        }

        $order_total    = $order->get_total();
        $order_currency = $order->get_currency();

        $weight_total = 0;
        $target_weight_unit = Helper::instance()->fedex_weight_unit();

        foreach ( $order->get_items() as $item_id => $item ) {
            $product = $item->get_product();
            if ( $product ) {
                $product_weight = 0.0;
                if ($product->has_weight()) {
                    $product_weight = Helper::instance()->normalize_store_weight($product->get_weight(), $target_weight_unit);
                }
                if ($product_weight <= 0) {
                    // Keep package-level weight consistent with commodity fallback behavior.
                    $product_weight = Helper::instance()->normalize_fedex_weight(
                        self::MIN_ITEM_WEIGHT_KG,
                        'KG',
                        $target_weight_unit
                    );
                }
                
                $qty = $item->get_quantity();
                $weight_total += $product_weight * $qty;
            }
        }

        $weight_total = max(1, (float) $weight_total);
        $weight_array = [
            "units" => $target_weight_unit,
            "value" => $weight_total
        ];

       $length_total = 0;
        $width_total  = 0;
        $height_total = 0;

        // Single-package packing heuristic: stack each line's quantity along
        // that line's smallest dimension and take the largest footprint per
        // axis across lines. Multiplying every dimension by qty (previous
        // behavior) built absurd boxes — 6x(10x8x6 in) became 60x48x36 in —
        // which FedEx rejects with DIMENSIONS.EXCEEDS.LIMITS, so no label
        // could ever be bought for a multi-quantity instant-mode order.
        foreach ( $order->get_items() as $item_id => $item ) {
            $product = $item->get_product();
            if ( $product ) {
                $qty   = max(1, (int) $item->get_quantity());
                $dims  = [
                    (float) $product->get_length(),
                    (float) $product->get_width(),
                    (float) $product->get_height(),
                ];
                sort($dims); // ascending — smallest side first
                $dims[0] *= $qty; // stack the qty along the smallest axis

                $length_total = max($length_total, $dims[2]);
                $width_total  = max($width_total, $dims[1]);
                $height_total = max($height_total, $dims[0]);
            }
        }

        $target_dimension_unit = Helper::instance()->fedex_dimension_unit();
        $length_total_out = max(1.0, Helper::instance()->normalize_store_dimension($length_total, $target_dimension_unit));
        $width_total_out  = max(1.0, Helper::instance()->normalize_store_dimension($width_total, $target_dimension_unit));
        $height_total_out = max(1.0, Helper::instance()->normalize_store_dimension($height_total, $target_dimension_unit));

        // Final dimensions array in the global unit system (CM or IN).
        $dimensions = [
            "length" => $length_total_out,
            "width"  => $width_total_out,
            "height" => $height_total_out,
            "units"  => $target_dimension_unit
        ];


        $recipient_address = [
            "streetLines" => $recept_street_lines,
            "city"        => $dest['city'],
            "postalCode"  => $dest['postal'],
            "countryCode" => $dest['country'],
            "residential" => $is_residential_delivery,
        ];
        if ($dest['state'] !== '') {
            $recipient_address['stateOrProvinceCode'] = $dest['state'];
        }

        $payload =  [
            "labelResponseOptions" => "URL_ONLY",
            "requestedShipment" => [
                "shipTimestamp" => gmdate('c'),
                "totalDeclaredValue" => [
                    "amount"   => (float) $order_total,
                    "currency" => $order_currency
                ],
                "shipper" => [
                    "contact" => [
                        "personName"  => $fshipping_person_name,
                        "phoneNumber" => $fshipping_phone_number,
                    ],
                    "address" => [
                        "streetLines" => $street_lines,
                        "city" => $fshipping_city,
                        "stateOrProvinceCode" => $state_provincecod,
                        "postalCode" => $fshipping_postal_code,
                        "countryCode" => $fshipping_country_code
                    ]
                ],
                "recipients" => [
                    [
                        "address" => $recipient_address,
                        "contact" => [
                            "personName" => trim(
                                ($order->get_shipping_first_name() ?: $order->get_billing_first_name()) . ' ' .
                                ($order->get_shipping_last_name() ?: $order->get_billing_last_name())
                            ),
                            "phoneNumber" => $order->get_billing_phone(),
                        ]
                    ]
                ],
                "serviceType" => $service_type,
                "packagingType" => $fshipping_labeling_packaging_type,
                "pickupType" => $fshipping_labeling_pickup_type,
                "shippingChargesPayment" => [
                    "paymentType" => $fshipping_labeling_payment_type,
                    "payor" => [
                        "responsibleParty" => [
                            "accountNumber" => [
                                "value" => $acc_number
                            ]
                        ],
                        "address" => [
                            "streetLines" => $street_lines,
                            "city" => $fshipping_city,
                            "stateOrProvinceCode" => $state_provincecod,
                            "postalCode" => $fshipping_postal_code,
                            "countryCode" => $fshipping_country_code
                        ]
                    ]
                ],
                "labelSpecification" => [
                    'labelFormatType' => $fshipping_labeling_label_format_type,
                    'labelOrder' => $fshipping_labeling_label_order,
                    'labelStockType' => $fshipping_labeling_stock_type,
                    'labelRotation' => $fshipping_labeling_rotation,
                    'imageType' => $fshipping_labeling_image_type,
                    'labelPrintingOrientation' => $fshipping_labeling_bottom_orientation
                ],
                "requestedPackageLineItems" => [
                    [
                        "weight" => $weight_array,
                        'dimensions' => $dimensions
                    ]
                ]
            ],
            "accountNumber" => [
                "value" => $acc_number
            ]
        ];

        /**
         * Filter the outbound FedEx Ship payload before the HTTP call.
         *
         * Used by FSHIPPING\Events\SpecialServicesInjector to add
         * specialServicesRequested blocks (Saturday delivery, signature
         * required, adult signature, hazardous materials, dry ice, COD,
         * alcohol) and third-party billing without modifying this
         * grandfathered file further.
         *
         * @since 1.2
         * @param array     $payload           The full Ship API payload.
         * @param \WC_Order $order             The WC order.
         * @param array     $current_shipment  The selected shipping method + meta.
         */
        $payload = apply_filters('fshipping_ship_payload', $payload, $order, $current_shipment);
        $payload = Helper::instance()->normalize_fedex_payload_weight_units($payload, $target_weight_unit);

        return $payload;
    }

    /**
     * Resolve final outbound unit system for Ship API payloads.
     *
     * Default behavior follows global helper units. Domestic parcel Express lanes
     * are forced to imperial (`LB` + `IN`) because FedEx rejects metric dimensions
     * for these services with dimension/weight unit mismatch errors.
     *
     * @param \WC_Order $order
     * @param array     $current_shipment
     * @return array{weight_unit:string,dimension_unit:string}
     */
    private function resolve_effective_ship_units($order, array $current_shipment): array {
        $default_weight_unit = Helper::instance()->fedex_weight_unit();
        $default_dimension_unit = Helper::instance()->fedex_dimension_unit();
        $effective = [
            'weight_unit'    => $default_weight_unit,
            'dimension_unit' => $default_dimension_unit,
        ];

        $settings = get_option('fshipping_options');
        $origin_country = !empty($settings['fshipping_country_code']) ? sanitize_text_field((string) $settings['fshipping_country_code']) : 'US';
        $dest_country = '';
        if (is_object($order) && method_exists($order, 'get_shipping_country')) {
            $dest_country = (string) $order->get_shipping_country();
            if ($dest_country === '' && method_exists($order, 'get_billing_country')) {
                $dest_country = (string) $order->get_billing_country();
            }
        }
        $origin_country = strtoupper(trim($origin_country));
        $dest_country = strtoupper(trim($dest_country));
        $service_type = strtoupper(trim((string) ($current_shipment['meta']['service_type'] ?? '')));
        $is_domestic = ($origin_country !== '' && $dest_country !== '' && $origin_country === $dest_country);
        $is_domestic_express = $is_domestic && $this->is_domestic_express_service_type($service_type);

        if ($is_domestic_express) {
            $effective = [
                'weight_unit'    => 'LB',
                'dimension_unit' => 'IN',
            ];
        }

        $effective = apply_filters(
            'fshipping_ship_effective_units',
            $effective,
            $order,
            $current_shipment,
            [
                'origin_country'      => $origin_country,
                'dest_country'        => $dest_country,
                'service_type'        => $service_type,
                'is_domestic'         => $is_domestic,
                'is_domestic_express' => $is_domestic_express,
            ]
        );

        $weight = strtoupper((string) ($effective['weight_unit'] ?? $default_weight_unit));
        $dimension = strtoupper((string) ($effective['dimension_unit'] ?? $default_dimension_unit));
        if (!in_array($weight, ['KG', 'LB'], true)) {
            $weight = $default_weight_unit;
        }
        if (!in_array($dimension, ['CM', 'IN'], true)) {
            $dimension = $default_dimension_unit;
        }

        return [
            'weight_unit'    => $weight,
            'dimension_unit' => $dimension,
        ];
    }

    /**
     * Domestic parcel Express services that require imperial package dimensions.
     *
     * @param string $service_type
     * @return bool
     */
    private function is_domestic_express_service_type(string $service_type): bool {
        return in_array(strtoupper(trim($service_type)), self::DOMESTIC_EXPRESS_SERVICE_TYPES, true);
    }

    /**
     * Freight Express package services reject line weights below service minimums.
     * Clamp each package line weight to FedEx floor before send.
     *
     * @param array $payload
     * @param mixed $order
     * @return array
     */
    private function enforce_minimum_package_weight_for_freight_service(array $payload, $order = null): array {
        if (empty($payload['requestedShipment']) || !is_array($payload['requestedShipment'])) {
            return $payload;
        }
        if ($this->should_skip_freight_minimum_for_product_boxes($order, $payload)) {
            return $payload;
        }
        $requested = $payload['requestedShipment'];
        $service_type = strtoupper(trim((string) ($requested['serviceType'] ?? '')));
        if (!$this->service_requires_freight_minimum_package_weight($service_type)) {
            return $payload;
        }
        if (empty($requested['requestedPackageLineItems']) || !is_array($requested['requestedPackageLineItems'])) {
            return $payload;
        }

        $configured_lb = (float) apply_filters(
            'fshipping_ship_freight_min_package_weight_lb',
            self::FREIGHT_MIN_PACKAGE_WEIGHT_LB,
            $service_type,
            $payload
        );
        $min_lb = $configured_lb > 0 ? $configured_lb : self::FREIGHT_MIN_PACKAGE_WEIGHT_LB;
        $min_kg = (float) apply_filters(
            'fshipping_ship_freight_min_package_weight_kg',
            self::FREIGHT_MIN_PACKAGE_WEIGHT_KG,
            $service_type,
            $payload
        );
        if ($min_kg <= 0) {
            $min_kg = self::FREIGHT_MIN_PACKAGE_WEIGHT_KG;
        }

        foreach ($requested['requestedPackageLineItems'] as $i => $line) {
            if (!is_array($line) || empty($line['weight']) || !is_array($line['weight'])) {
                continue;
            }
            $weight = $line['weight'];
            $units = strtoupper(trim((string) ($weight['units'] ?? 'LB')));
            if (!in_array($units, ['LB', 'KG'], true)) {
                $units = 'LB';
            }
            $value = isset($weight['value']) && is_numeric($weight['value']) ? (float) $weight['value'] : 0.0;
            $min_for_unit = ($units === 'KG') ? $min_kg : $min_lb;
            if ($value >= $min_for_unit) {
                continue;
            }
            $requested['requestedPackageLineItems'][$i]['weight']['units'] = $units;
            $requested['requestedPackageLineItems'][$i]['weight']['value'] = round($min_for_unit, 2);
        }

        $payload['requestedShipment'] = $requested;
        return $payload;
    }

    /**
     * Product Box packing already computes exact per-package weights; do not
     * overwrite those with freight floor clamps unless explicitly requested.
     *
     * @param mixed $order
     * @param array $payload
     * @return bool
     */
    private function should_skip_freight_minimum_for_product_boxes($order, array $payload): bool {
        $default_skip = false;
        return (bool) apply_filters(
            'fshipping_ship_freight_min_package_weight_skip_for_product_boxes',
            $default_skip,
            $order,
            $payload
        );
    }

    /**
     * @param string $service_type
     * @return bool
     */
    private function service_requires_freight_minimum_package_weight(string $service_type): bool {
        if ($service_type === '') {
            return false;
        }
        $is_freight = strpos($service_type, 'FREIGHT') !== false;
        return (bool) apply_filters(
            'fshipping_ship_freight_min_package_weight_enabled',
            $is_freight,
            $service_type
        );
    }

    /**
     * Log warning when mixed weight units are detected in outbound payload.
     *
     * @param array  $payload
     * @param string $expected_unit
     * @return void
     */
    private function warn_if_mixed_weight_units(array $payload, string $expected_unit): void {
        unset($payload, $expected_unit);
    }

    /**
     * Formerly logged weight/dimension inconsistencies; payload is still normalized elsewhere.
     *
     * @param array  $payload
     * @param string $expected_weight
     * @param string $expected_dimension
     * @return void
     */
    private function warn_if_mixed_system_units(array $payload, string $expected_weight, string $expected_dimension): void {
        unset($payload, $expected_weight, $expected_dimension);
    }

    /**
     * Keep label settings isolated from shipping/invoice document settings.
     *
     * Rules:
     * - imageType is valid only in requestedShipment.labelSpecification
     * - shippingDocumentSpecification and commercialInvoice must not carry imageType
     * - invalid label imageType falls back to PDF
     *
     * @param array $payload
     * @return array
     */
    private function sanitize_label_and_document_payload(array $payload): array {
        if (empty($payload['requestedShipment']) || !is_array($payload['requestedShipment'])) {
            return $payload;
        }

        $requested = $payload['requestedShipment'];

        if (!empty($requested['labelSpecification']) && is_array($requested['labelSpecification'])) {
            $requested['labelSpecification'] = $this->sanitize_label_specification($requested['labelSpecification']);
        }

        if (!empty($requested['shippingDocumentSpecification']) && is_array($requested['shippingDocumentSpecification'])) {
            $requested['shippingDocumentSpecification'] = $this->remove_image_type_recursively($requested['shippingDocumentSpecification']);
            $requested['shippingDocumentSpecification'] = $this->normalize_shipping_document_specification(
                $requested['shippingDocumentSpecification']
            );
        }

        if (!empty($requested['customsClearanceDetail']) && is_array($requested['customsClearanceDetail'])) {
            if (!empty($requested['customsClearanceDetail']['commercialInvoice']) && is_array($requested['customsClearanceDetail']['commercialInvoice'])) {
                $requested['customsClearanceDetail']['commercialInvoice'] = $this->remove_image_type_recursively(
                    $requested['customsClearanceDetail']['commercialInvoice']
                );
            }
        }

        $payload['requestedShipment'] = $requested;
        return $payload;
    }

    /**
     * Normalize invoice document config so it never inherits label image settings.
     *
     * @param array $spec
     * @return array
     */
    private function normalize_shipping_document_specification(array $spec): array {
        $types = isset($spec['shippingDocumentTypes']) && is_array($spec['shippingDocumentTypes'])
            ? array_values(array_unique(array_map('sanitize_text_field', $spec['shippingDocumentTypes'])))
            : [];

        if (!in_array('COMMERCIAL_INVOICE', $types, true)) {
            return $spec;
        }

        $detail = isset($spec['commercialInvoiceDetail']) && is_array($spec['commercialInvoiceDetail'])
            ? $spec['commercialInvoiceDetail']
            : [];
        $format = isset($detail['documentFormat']) && is_array($detail['documentFormat'])
            ? $detail['documentFormat']
            : [];

        // Explicitly set invoice output type/stock without using imageType.
        // FedEx rejects thermal label stock (e.g. STOCK_4X675) for COMMERCIAL_INVOICE docs.
        $format['docType'] = 'PDF';
        $format['stockType'] = 'PAPER_LETTER';
        unset($format['imageType']);
        $detail['documentFormat'] = $format;
        $spec['commercialInvoiceDetail'] = $detail;

        return $spec;
    }

    /**
     * @param array $label_spec
     * @return array
     */
    private function sanitize_label_specification(array $label_spec): array {
        $label_spec['imageType'] = 'PDF';
        return $label_spec;
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    private function remove_image_type_recursively($value) {
        if (!is_array($value)) {
            return $value;
        }
        foreach ($value as $key => $item) {
            if (is_string($key) && strtolower($key) === 'imagetype') {
                unset($value[$key]);
                continue;
            }
            $value[$key] = $this->remove_image_type_recursively($item);
        }
        return $value;
    }

    /**
     * Cancel shipment.
     * 
     * @param string tracking_id
     * @since 1.0
     */
    public function cancel_shipment($tracking_number) {
        $tracking_number = $this->resolve_tracking_number($tracking_number);
        if (empty($tracking_number)) {
            return false;
        }
        $token = Authorization::instance()->get_secret_token();
        if( empty( $token ) ) {
            return '';
        }

        $endpoint = Helper::instance()->get_base_url(). '/ship/v1/shipments/cancel';
        $payload = $this->prepare_cancel_shipment_payload($tracking_number);
        $response = wp_remote_post( $endpoint, [
            'method'  => 'PUT',
            'timeout' => 60,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'X-locale'      => 'en_US',
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( $payload ),
        ] );

        if (is_wp_error($response)) {
            throw new \Exception(esc_html(__('Shipping request failed: ', 'teamzlab-fedex') . $response->get_error_message()));
        }
        $status_code = (int)wp_remote_retrieve_response_code($response);
        $body        = wp_remote_retrieve_body( $response );
        $data        = json_decode( $body, true );

        if( 200 === $status_code ) {
            $shipment_id = $this->find_shipment_id_by_tracking_number($tracking_number);
            $order = $this->find_order_by_tracking_number($tracking_number);
            update_post_meta($shipment_id, 'order_status', 'canceled');
            // FedEx already voided the shipment — never fatal on missing order
            // data after that point.
            if($order instanceof \WC_Order) {
                $order->update_status(
                    'cancelled',
                    __('Shipment canceled', 'teamzlab-fedex'),
                    true
                );
                if(!empty($data['output']) && !empty($data['output']['message'])) {
                    $order->add_order_note( $data['output']['message'], false );
                }
            }
            return true;
        }
        return false;
    }

    /**
     * Resolve legacy transaction IDs to actual tracking numbers.
     *
     * Older shipments stored FedEx transactionId in _tracking_number. If the
     * incoming value matches a shipment's saved _tracking_number and the linked
     * order has _fedex_tracking, prefer that real tracking number.
     *
     * @param string $tracking_number
     * @return string
     */
    private function resolve_tracking_number($tracking_number) {
        $tracking_number = sanitize_text_field((string) $tracking_number);
        if (empty($tracking_number)) {
            return '';
        }

        $shipment_id = $this->find_shipment_id_by_tracking_number($tracking_number);
        if (empty($shipment_id)) {
            return $tracking_number;
        }

        $order_id = get_post_meta($shipment_id, '_fedex_shipment_order_id', true);
        if (empty($order_id)) {
            return $tracking_number;
        }

        $actual_tracking_number = OrderMeta::get($order_id, '_fedex_tracking');
        return !empty($actual_tracking_number)
            ? sanitize_text_field($actual_tracking_number)
            : $tracking_number;
    }

    /**
     * Find order id by tracking id.
     * 
     * @param mixed $tracking_number
     */
    private function find_order_by_tracking_number($tracking_number) {
        $shipment_id = $this->find_shipment_id_by_tracking_number($tracking_number);
        if(empty($shipment_id)) return '';
        $order_id = get_post_meta($shipment_id, '_fedex_shipment_order_id', true);
        if(empty($order_id)) return '';
        $order = wc_get_order($order_id);
        return $order;
    }

    /**
     * Find shipment id by tracking id.
     * @return int
     */
    public function find_shipment_id_by_tracking_number($tracking_number) {
        if ( ! $tracking_number ) {
            return 0;
        }

        $args = [
            'post_type'   => 'fedex_shipping',
            'post_status' => 'any',
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Exact-match lookup on this plugin's fedex_shipping CPT by its _tracking_number meta; single shipment, hard-limited to 1.
            'meta_query'  => [
                [
                    'key'     => '_tracking_number',
                    'value'   => $tracking_number,
                    'compare' => '=', 
                ]
            ],
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ];

        $shipment_ids = get_posts( $args );
        $shipment_id = reset($shipment_ids);

        return $shipment_id;
    }
    


    /**
     * Cancel shipment.
     * 
     * @since 1.0
     */
    public function prepare_cancel_shipment_payload( $tracking_id ) {
        $settings = get_option('fshipping_options');
        $acc_number = !empty($settings['fshipping_acc_number']) ? sanitize_text_field($settings['fshipping_acc_number']): '';
        $shipping_options = get_option('fshipping_options');
        $store_country = !empty($shipping_options['fshipping_country_code']) ? sanitize_text_field($shipping_options['fshipping_country_code']): '';


        $payload = array(
            'accountNumber' => array(
                'value' => $acc_number
            ),
            'emailShipment'    => 'true',
            'senderCountryCode'=> $store_country,
            'deletionControl'  => 'DELETE_ALL_PACKAGES',
            'trackingNumber'   => $tracking_id,
        );
        return $payload;
    }

}