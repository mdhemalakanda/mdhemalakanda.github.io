<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use FSHIPPING\Utils\OrderMeta;
use FSHIPPING\Utils\SecureUploads;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Return Tag / RMA label client.
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class ReturnTag extends BaseClient {
    protected string $log_source = 'fshipping_return_tag';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    /**
     * @param int   $order_id
     * @param array $opts
     * @return array
     * @since 1.1
     */
    public function create_tag($order_id, array $opts = []): array {
        $order_id = (int) $order_id;
        $order    = function_exists('wc_get_order') ? wc_get_order($order_id) : null;
        if (empty($order)) {
            return [];
        }

        $decoded = $this->post('/ship/v1/shipments', $this->prepare_payload($order, $opts));
        if (empty($decoded['output'])) {
            return [];
        }

        $label_url = $decoded['output']['transactionShipments'][0]
            ['pieceResponses'][0]
            ['packageDocuments'][0]['url'] ?? '';
        $tracking  = $decoded['output']['transactionShipments'][0]['masterTrackingNumber'] ?? '';

        if (!empty($label_url)) {
            $stable_label_url = $this->cache_return_label_pdf($label_url, (string) $tracking, $order_id);
            if (empty($stable_label_url)) {
                $stable_label_url = esc_url_raw($label_url);
            }
            OrderMeta::update($order_id, '_fshipping_return_label_url', $stable_label_url);
            OrderMeta::update($order_id, '_fshipping_return_label_remote_url', esc_url_raw($label_url));
            OrderMeta::update($order_id, '_fshipping_return_tracking',  sanitize_text_field($tracking));
            $order->add_order_note(
                /* translators: %s: return-label tracking number. */
                sprintf(__('FedEx return label created — tracking %s.', 'teamzlab-fedex'), $tracking),
                false
            );
        }

        return $decoded['output'];
    }

    /**
     * Build the requestedShipment payload for a return.
     *
     * @param \WC_Order $order
     * @param array     $opts
     * @return array
     * @since 1.1
     */
    private function prepare_payload($order, array $opts): array {
        $settings = get_option('fshipping_options');
        $acc      = sanitize_text_field($settings['fshipping_acc_number'] ?? '');

        $store_streets = [];
        if (!empty($settings['fshipping_labeling_streetline'])) {
            $store_streets = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $settings['fshipping_labeling_streetline'])));
        }

        $customer_street_lines = array_values(array_filter([
            $order->get_shipping_address_1() ?: $order->get_billing_address_1(),
            $order->get_shipping_address_2() ?: $order->get_billing_address_2(),
        ]));

        $weight = (float) ($opts['weight'] ?? 1);
        $length = (int)   ($opts['length'] ?? 10);
        $width  = (int)   ($opts['width']  ?? 10);
        $height = (int)   ($opts['height'] ?? 10);

        $service_type = sanitize_text_field($opts['service_type'] ?? 'FEDEX_GROUND');
        $reason       = sanitize_text_field($opts['reason']       ?? __('Customer return', 'teamzlab-fedex'));

        return [
            'labelResponseOptions' => 'URL_ONLY',
            'requestedShipment' => [
                'shipTimestamp' => gmdate('c'),
                'shipper' => [
                    'contact' => [
                        'personName'  => trim(($order->get_shipping_first_name() ?: $order->get_billing_first_name()) . ' ' . ($order->get_shipping_last_name() ?: $order->get_billing_last_name())),
                        'phoneNumber' => $order->get_billing_phone() ?: '0000000000',
                    ],
                    'address' => [
                        'streetLines'         => $customer_street_lines,
                        'city'                => $order->get_shipping_city()    ?: $order->get_billing_city(),
                        'stateOrProvinceCode' => $order->get_shipping_state()   ?: $order->get_billing_state(),
                        'postalCode'          => $order->get_shipping_postcode() ?: $order->get_billing_postcode(),
                        'countryCode'         => $order->get_shipping_country() ?: $order->get_billing_country(),
                        'residential'         => true,
                    ],
                ],
                'recipients' => [[
                    'contact' => [
                        'personName'  => sanitize_text_field($settings['fshipping_person_name']  ?? ''),
                        'phoneNumber' => sanitize_text_field($settings['fshipping_phone_number'] ?? '0000000000'),
                    ],
                    'address' => [
                        'streetLines'         => $store_streets,
                        'city'                => sanitize_text_field($settings['fshipping_city']         ?? ''),
                        'stateOrProvinceCode' => sanitize_text_field($settings['state_provincecod']     ?? ''),
                        'postalCode'          => sanitize_text_field($settings['fshipping_postal_code'] ?? ''),
                        'countryCode'         => sanitize_text_field($settings['fshipping_country_code'] ?? 'US'),
                    ],
                ]],
                'pickupType'    => 'CONTACT_FEDEX_TO_SCHEDULE',
                'serviceType'   => $service_type,
                'packagingType' => sanitize_text_field($settings['fshipping_labeling_packaging_type'] ?? 'YOUR_PACKAGING'),
                'shippingChargesPayment' => [
                    'paymentType' => 'SENDER',
                    'payor' => ['responsibleParty' => ['accountNumber' => ['value' => $acc]]],
                ],
                'labelSpecification' => [
                    'labelFormatType'          => sanitize_text_field($settings['fshipping_labeling_label_format_type'] ?? 'COMMON2D'),
                    'labelStockType'           => sanitize_text_field($settings['fshipping_labeling_stock_type']        ?? 'PAPER_4X6'),
                    'imageType'                => sanitize_text_field($settings['fshipping_labeling_image_type']        ?? 'PDF'),
                    'labelPrintingOrientation' => sanitize_text_field($settings['fshipping_labeling_bottom_orientation'] ?? 'BOTTOM_EDGE_OF_TEXT_FIRST'),
                ],
                'requestedPackageLineItems' => [[
                    'weight'     => ['units' => 'LB', 'value' => (string) $weight],
                    'dimensions' => ['length' => $length, 'width' => $width, 'height' => $height, 'units' => 'IN'],
                    'customerReferences' => [
                        ['customerReferenceType' => 'CUSTOMER_REFERENCE', 'value' => $reason],
                        ['customerReferenceType' => 'INVOICE_NUMBER',     'value' => (string) $order->get_id()],
                    ],
                ]],
                'returnShipmentDetail' => ['returnType' => 'PRINT_RETURN_LABEL'],
            ],
            'accountNumber' => ['value' => $acc],
        ];
    }

    /**
     * Download FedEx-hosted return label and store local stable PDF.
     *
     * @param string $remote_url
     * @param string $tracking
     * @param int    $order_id
     * @return string Local file URL or empty string on failure.
     */
    private function cache_return_label_pdf($remote_url, $tracking, $order_id) {
        $remote_url = esc_url_raw((string) $remote_url);
        $tracking   = sanitize_text_field((string) $tracking);
        $order_id   = (int) $order_id;
        if (empty($remote_url) || empty($order_id) || !function_exists('wp_upload_dir')) {
            return '';
        }

        $response = wp_remote_get($remote_url, ['timeout' => 60]);
        if (is_wp_error($response)) {
            return '';
        }

        $pdf = wp_remote_retrieve_body($response);
        if (empty($pdf)) {
            return '';
        }

        $folder = SecureUploads::get_dir('returns');
        if ('' === $folder) {
            return '';
        }

        $suffix   = $tracking !== '' ? sanitize_file_name($tracking) : ('order-' . $order_id);
        $filename = 'fedex-return-' . $suffix . '.pdf';
        $path     = $folder . '/' . $filename;
        $url      = SecureUploads::get_url('returns') . '/' . $filename;

        $written = file_put_contents($path, $pdf);
        if (false === $written) {
            return '';
        }

        return esc_url_raw($url);
    }
}
