<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\AddressNormalizer;
use FSHIPPING\Utils\Helper;

/**
 * This class will use for all http request related to shipping.
 * 
 * @since 1.0
 */
class Shipping {
    use SingletonTrait;

    private $settings;
    private $last_error_message = '';
    private const SAFE_PACKAGING_TYPE = 'YOUR_PACKAGING';

    /** WooCommerce → Status → Logs source for checkout FedEx Rates API payload/response only. */
    private const WC_LOG_SOURCE = 'teamzlab_fedex_shippnig';

    public function __construct() {
        $this->settings = get_option('fshipping_options');
    }

    public function get_shipping_rates($package) {
        $this->last_error_message = '';
        $token = Authorization::instance()->get_secret_token();
        if( empty( $token ) ) {
            $this->last_error_message = 'FedEx auth token missing. Check API key/secret and selected environment.';
            return array();
        }

        $endpoint = Helper::instance()->get_base_url(). '/rate/v1/rates/quotes';
        $payload = $this->prepare_shipping_rates_payload( $package );

        // Stable-rates cache. WooCommerce recalculates the cart several times
        // per checkout (page render, rate selection, POST /checkout) and every
        // recalculation here is a fresh live FedEx quote. Live quotes drift —
        // surcharges and rate-type flips move prices between calls — and WC's
        // expected-total guard then rejects the order with "The order total
        // changed ... while you were checking out". Serving one quote per
        // (payload, environment) for a short window keeps every recalculation
        // within a checkout session consistent. Set the filter to 0 to disable.
        $cache_ttl = (int) apply_filters( 'fshipping_rates_cache_ttl', 10 * MINUTE_IN_SECONDS, $package );
        $cache_key = '';
        if ( $cache_ttl > 0 ) {
            $cache_key = 'fshipping_rates_' . md5( $endpoint . '|' . wp_json_encode( $payload ) );
            $cached_rates = get_transient( $cache_key );
            if ( is_array( $cached_rates ) ) {
                return $cached_rates;
            }
        }

        $response = $this->post_rates_request( $endpoint, $token, $payload );
        $this->log_rates_payload_response( 'initial', $payload, $response );

        if ( is_wp_error( $response ) ) {
            $this->last_error_message = 'FedEx rate request failed: ' . $response->get_error_message();
            return array();
        }

        $status_code = (int) wp_remote_retrieve_response_code( $response );
        $body        = wp_remote_retrieve_body( $response );
        $data        = json_decode( $body, true );
        $data        = is_array( $data ) ? $data : array();
        $rate_details = isset($data['output']) && isset($data['output']['rateReplyDetails']) ? wc_clean($data['output']['rateReplyDetails']): array();

        if ( empty( $rate_details ) && $this->is_invalid_service_packaging_error( $status_code, $data ) ) {
            $retry_payload = $this->prepare_safe_rates_payload( $payload );
            $retry_response = $this->post_rates_request( $endpoint, $token, $retry_payload );
            $this->log_rates_payload_response( 'safe_packaging_retry', $retry_payload, $retry_response );

            if ( ! is_wp_error( $retry_response ) ) {
                $status_code  = (int) wp_remote_retrieve_response_code( $retry_response );
                $body         = wp_remote_retrieve_body( $retry_response );
                $data         = json_decode( $body, true );
                $data         = is_array( $data ) ? $data : array();
                $rate_details = isset( $data['output']['rateReplyDetails'] ) ? wc_clean( $data['output']['rateReplyDetails'] ) : array();
            }
        }

        // FedEx Sandbox (and sometimes production) returns 502/503/504 during maintenance or load — one retry after a short pause.
        if ( empty( $rate_details ) && in_array( $status_code, array( 502, 503, 504 ), true ) ) {
            if ( apply_filters( 'fshipping_rates_retry_on_transient_http', true, $status_code, $data, $package ) ) {
                $delay_us = (int) apply_filters( 'fshipping_rates_transient_retry_delay_us', 500000 );
                if ( $delay_us > 0 && $delay_us <= 2000000 ) {
                    usleep( $delay_us );
                }
                $retry_http = $this->post_rates_request( $endpoint, $token, $payload );
                $this->log_rates_payload_response( 'transient_http_retry', $payload, $retry_http );
                if ( ! is_wp_error( $retry_http ) ) {
                    $status_code  = (int) wp_remote_retrieve_response_code( $retry_http );
                    $body         = wp_remote_retrieve_body( $retry_http );
                    $data         = json_decode( $body, true );
                    $data         = is_array( $data ) ? $data : array();
                    $rate_details = isset( $data['output']['rateReplyDetails'] ) ? wc_clean( $data['output']['rateReplyDetails'] ) : array();
                }
            }
        }

        if ( empty( $rate_details ) ) {
            $first_error = '';
            if ( ! empty( $data['errors'][0]['message'] ) ) {
                $first_error = sanitize_text_field( (string) $data['errors'][0]['message'] );
            } elseif ( ! empty( $data['transactionId'] ) ) {
                $first_error = 'No rate details returned. transactionId=' . sanitize_text_field( (string) $data['transactionId'] );
            }
            $this->last_error_message = sprintf(
                'FedEx rate API returned no rates (HTTP %d). %s',
                $status_code,
                $first_error
            );
        }

        // Only successful quotes are cached; failures stay uncached so error
        // surfacing and the retry paths above keep their current semantics.
        if ( $cache_key !== '' && ! empty( $rate_details ) ) {
            set_transient( $cache_key, $rate_details, $cache_ttl );
        }

        return $rate_details;
    }

    /**
     * Last error from FedEx rate call, if any.
     *
     * @return string
     */
    public function get_last_error_message() {
        return (string) $this->last_error_message;
    }

    /**
     * Ship-from address for /rate/v1/rates/quotes when the Woo package carries
     * optional `_fshipping_origin` (e.g. set by custom code on the package).
     *
     * @param array $current_package WooCommerce shipping package.
     * @param array $shipping_options Plugin `fshipping_options`.
     * @return array<string, string> FedEx `shipper.address` keys (postalCode, countryCode; optional stateOrProvinceCode).
     */
    private function build_rates_shipper_address(array $current_package, array $shipping_options): array {
        $global_postal  = ! empty( $shipping_options['fshipping_postal_code'] ) ? sanitize_text_field( (string) $shipping_options['fshipping_postal_code'] ) : '';
        $global_country = ! empty( $shipping_options['fshipping_country_code'] ) ? sanitize_text_field( (string) $shipping_options['fshipping_country_code'] ) : 'US';

        $origin = isset( $current_package['_fshipping_origin'] ) && is_array( $current_package['_fshipping_origin'] )
            ? $current_package['_fshipping_origin']
            : null;

        $postal  = $global_postal;
        $country = $global_country;
        $state   = '';

        if ( $origin !== null ) {
            $o_postal = isset( $origin['postal_code'] ) ? sanitize_text_field( (string) $origin['postal_code'] ) : '';
            if ( $o_postal !== '' ) {
                $postal = $o_postal;
                if ( isset( $origin['country'] ) && (string) $origin['country'] !== '' ) {
                    $country = strtoupper( sanitize_text_field( (string) $origin['country'] ) );
                }
                if ( isset( $origin['state'] ) && (string) $origin['state'] !== '' ) {
                    $state = strtoupper( sanitize_text_field( (string) $origin['state'] ) );
                }
            }
        }

        $address = [
            'postalCode'  => $postal,
            'countryCode' => $country,
        ];
        if ( $state !== '' ) {
            $address['stateOrProvinceCode'] = $state;
        }

        return $address;
    }

    /**
     * This function will prepare rates.
     * @return array
     */
    private function prepare_shipping_rates_payload($package) {
        $shipping_options = get_option('fshipping_options');
        $current_package = isset($package['contents']) ? $package : (isset($package[0]['contents']) ? $package[0] : array());
        $acc_number = !empty($this->settings['fshipping_acc_number']) ? sanitize_text_field($this->settings['fshipping_acc_number']): '';
        $recipient_postcode = isset($current_package['destination']['postcode']) ? $current_package['destination']['postcode'] : '';
        $recipient_country  = isset($current_package['destination']['country']) ? $current_package['destination']['country'] : '';
        $recipient_postcode = AddressNormalizer::normalize_postal_for_country($recipient_country, (string) $recipient_postcode);
        $shipper_address = $this->build_rates_shipper_address(
            $current_package,
            is_array( $shipping_options ) ? $shipping_options : []
        );
        $store_postcode = $shipper_address['postalCode'];
        $store_country  = $shipper_address['countryCode'];
        $fshipping_pickup_type = !empty($shipping_options['fshipping_pickup_type']) ? sanitize_text_field($shipping_options['fshipping_pickup_type']): 'USE_SCHEDULED_PICKUP';
        $fshipping_rate_request_type = !empty($shipping_options['fshipping_rate_request_type']) ? wc_clean($shipping_options['fshipping_rate_request_type']): array( 'LIST' );

        if (empty($current_package['contents'])) {
            return array();
        }

         // weight, height, dimention.
        $total_weight = 0;
        $max_length   = 0;
        $max_width    = 0;
        $total_height = 0;

        foreach ( $current_package['contents'] as $cart_item ) {
            $product  = $cart_item['data'];
            $quantity = $cart_item['quantity'];

            // get weight.
            if ( $product->has_weight() ) {
                $total_weight += (float) $product->get_weight() * $quantity;
            }

            // get dimention.
            if ( $product->has_dimensions() ) {
                $l = (float) $product->get_length();
                $w = (float) $product->get_width();
                $h = (float) $product->get_height();

                if ( $l > $max_length ) $max_length = $l;
                if ( $w > $max_width ) $max_width = $w;

                $total_height += ($h * $quantity);
            }
        }

        $max_length = $max_length ? $max_length : 10;
        $max_width  = $max_width ? $max_width : 10;
        $total_height = $total_height ? $total_height : 10;
        $total_weight = $total_weight ? $total_weight : 1;

        $target_weight_unit = Helper::instance()->fedex_weight_unit();
        $target_dimension_unit = Helper::instance()->fedex_dimension_unit();
        $total_weight = max(1.0, Helper::instance()->normalize_store_weight($total_weight, $target_weight_unit));
        $max_length = max(1.0, Helper::instance()->normalize_store_dimension($max_length, $target_dimension_unit));
        $max_width = max(1.0, Helper::instance()->normalize_store_dimension($max_width, $target_dimension_unit));
        $total_height = max(1.0, Helper::instance()->normalize_store_dimension($total_height, $target_dimension_unit));

        $line_items = apply_filters(
            'fshipping_rates_package_line_items',
            [
                [
                    'weight' => [
                        'units' => $target_weight_unit,
                        'value' => (string) $total_weight,
                    ],
                    "dimensions" => [
                        'width'  => (int) $max_length,
                        'length' => (int) $max_width,
                        'height' => (int) $total_height,
                        'units'  => $target_dimension_unit,
                    ],
                ],
            ],
            $current_package
        );

        $packaging_type = ! empty( $shipping_options['fshipping_labeling_packaging_type'] )
            ? sanitize_text_field( $shipping_options['fshipping_labeling_packaging_type'] )
            : self::SAFE_PACKAGING_TYPE;

        $payload = [
            "accountNumber" => [
                "value" => $acc_number,
            ],
            "requestedShipment" => [
                "shipper" => [
                    "address" => $shipper_address,
                ],
                "recipient" => [
                    "address" => [
                        "postalCode"  => $recipient_postcode,
                        "countryCode" => $recipient_country,
                    ],
                ],
                "pickupType" => $fshipping_pickup_type,
                "rateRequestType" => $fshipping_rate_request_type,
                "packagingType" => $packaging_type,
                "requestedPackageLineItems" => $line_items,
            ],
        ];

        /**
         * Filter checkout rate payload before POST /rate/v1/rates/quotes.
         *
         * Second parameter is the normalized WooCommerce package (may include
         * `_fshipping_origin` if supplied by custom code). Callbacks
         * registered with one argument still work.
         *
         * @param array $payload
         * @param array $current_package
         */
        return apply_filters( 'fshipping_rates_payload', $payload, $current_package );
    }

    /**
     * Detect FedEx error that often comes from bad service/packaging combos.
     *
     * @param int   $status_code
     * @param array $decoded
     * @return bool
     */
    private function is_invalid_service_packaging_error( $status_code, $decoded ) {
        if ( 400 !== (int) $status_code || empty( $decoded['errors'][0]['message'] ) ) {
            return false;
        }

        $message = strtolower( (string) $decoded['errors'][0]['message'] );
        return false !== strpos( $message, 'invalid service and packaging combination' );
    }

    /**
     * Build a conservative payload for retry when FedEx rejects
     * service/packaging combinations.
     *
     * @param array $payload
     * @return array
     */
    private function prepare_safe_rates_payload( $payload ) {
        if ( empty( $payload['requestedShipment'] ) || ! is_array( $payload['requestedShipment'] ) ) {
            return $payload;
        }

        $payload['requestedShipment']['packagingType']   = self::SAFE_PACKAGING_TYPE;
        $payload['requestedShipment']['rateRequestType'] = array( 'LIST' );
        unset( $payload['requestedShipment']['serviceType'] );

        return $payload;
    }

    /**
     * POST /rate/v1/rates/quotes (shared by checkout rates + WooCommerce log).
     *
     * @param string $endpoint Full URL.
     * @param string $token    Bearer token (never logged).
     * @param array  $payload  JSON body.
     * @return \WP_Error|array wp_remote_post return value.
     */
    private function post_rates_request( $endpoint, $token, array $payload ) {
        return wp_remote_post(
            $endpoint,
            [
                'method'  => 'POST',
                'timeout' => 60,
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'X-locale'      => 'en_US',
                    'Content-Type'  => 'application/json',
                ],
                'body'    => wp_json_encode( $payload ),
            ]
        );
    }

    /**
     * Log rate request/response to WooCommerce logger (WooCommerce → Status → Logs).
     * Bearer token is never logged. Phases: initial, safe_packaging_retry, transient_http_retry.
     *
     * Full JSON carries customer address PII (destination postcode, package
     * contents), so it is only written when WP_DEBUG is on. Otherwise a single
     * info line with non-PII essentials is logged per phase.
     *
     * @param string               $phase    initial | safe_packaging_retry | transient_http_retry
     * @param array<string, mixed> $payload  Request JSON body.
     * @param \WP_Error|array      $response wp_remote_post result.
     */
    private function log_rates_payload_response( $phase, array $payload, $response ) {
        if ( ! function_exists( 'wc_get_logger' ) ) {
            return;
        }
        $phase_key = sanitize_key( (string) $phase );
        $decoded   = $this->decode_rates_http_response( $response );
        $ctx       = [ 'source' => self::WC_LOG_SOURCE ];
        $logger    = wc_get_logger();

        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            $opts      = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
            $payload_json   = wp_json_encode( $payload, $opts );
            $response_json  = wp_json_encode( $decoded, $opts );
            if ( false === $payload_json ) {
                $payload_json = '{}';
            }
            if ( false === $response_json ) {
                $response_json = '{}';
            }
            $logger->info( 'Payload [' . $phase_key . ']: ' . $payload_json, $ctx );
            $logger->info( 'Response [' . $phase_key . ']: ' . $response_json, $ctx );
            return;
        }

        // Non-debug: one non-PII summary line per phase (no addresses, no items).
        $status_code = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
        $rate_count  = 0;
        if ( isset( $decoded['output']['rateReplyDetails'] ) && is_array( $decoded['output']['rateReplyDetails'] ) ) {
            $rate_count = count( $decoded['output']['rateReplyDetails'] );
        }
        $service = '';
        if ( ! empty( $payload['requestedShipment']['serviceType'] ) && is_string( $payload['requestedShipment']['serviceType'] ) ) {
            $service = sanitize_text_field( $payload['requestedShipment']['serviceType'] );
        }
        $error_code = '';
        if ( ! empty( $decoded['errors'][0]['code'] ) ) {
            $error_code = sanitize_text_field( (string) $decoded['errors'][0]['code'] );
        } elseif ( ! empty( $decoded['wp_error'] ) && isset( $decoded['code'] ) ) {
            $error_code = sanitize_text_field( (string) $decoded['code'] );
        }
        $summary = 'Rates [' . $phase_key . ']: http=' . $status_code . ' rates=' . $rate_count;
        if ( '' !== $service ) {
            $summary .= ' service=' . $service;
        }
        if ( '' !== $error_code ) {
            $summary .= ' error_code=' . $error_code;
        }
        $logger->info( $summary, $ctx );
    }

    /**
     * @param \WP_Error|array $response
     * @return array<string, mixed>
     */
    private function decode_rates_http_response( $response ) {
        if ( is_wp_error( $response ) ) {
            return [
                'wp_error' => $response->get_error_message(),
                'code'     => $response->get_error_code(),
            ];
        }
        $raw    = wp_remote_retrieve_body( $response );
        $parsed = json_decode( $raw, true );
        if ( is_array( $parsed ) ) {
            return $parsed;
        }
        return [
            '_non_json_preview' => function_exists( 'mb_substr' )
                ? mb_substr( $raw, 0, 8000, 'UTF-8' )
                : substr( $raw, 0, 8000 ),
        ];
    }
}
