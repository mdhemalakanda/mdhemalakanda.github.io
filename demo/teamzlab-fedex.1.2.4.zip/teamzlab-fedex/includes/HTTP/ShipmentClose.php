<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * End-of-Day Close — generate the daily Ground manifest.
 *
 * FedEx endpoint: POST /ship/v1/shipments/close
 *  (TODO: verify against live sandbox)
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class ShipmentClose extends BaseClient {
    protected string $log_source = 'fshipping_ship_close';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    public function close_day(array $args = []): array {
        $settings = get_option('fshipping_options');
        $acc      = sanitize_text_field($settings['fshipping_acc_number'] ?? '');
        if (empty($acc)) {
            return [];
        }

        $payload = [
            'accountNumber' => ['value' => $acc],
            'closeInput' => [
                'carrierCode' => sanitize_text_field($args['carrier_code'] ?? 'FDXG'),
                'closeTime'   => sanitize_text_field($args['close_time']   ?? '17:00:00'),
                'closeDate'   => sanitize_text_field($args['close_date']   ?? gmdate('Y-m-d')),
                'locationId'  => sanitize_text_field($args['location_id']  ?? ''),
            ],
        ];

        $decoded = $this->post('/ship/v1/shipments/close', $payload);
        $out     = $decoded['output'] ?? [];
        if (!empty($out['manifest']['url'])) {
            update_option('fshipping_last_close_manifest', [
                'url'       => esc_url_raw((string) $out['manifest']['url']),
                'closed_at' => current_time('mysql'),
                'carrier'   => $args['carrier_code'] ?? 'FDXG',
                'count'     => (int) ($out['totalPackageCount'] ?? 0),
            ]);
        }
        return $out;
    }

    public function get_last_manifest(): array {
        $manifest = get_option('fshipping_last_close_manifest');
        return is_array($manifest) ? $manifest : [];
    }
}
