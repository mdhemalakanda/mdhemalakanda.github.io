<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\OpenShip\Draft;
use FSHIPPING\OpenShip\PackageLineExtras;
use FSHIPPING\Utils\FedExMoneyUsd;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Open Ship API client — incremental multi-package shipments over a
 * 5-day window (up to 999 packages per shipment).
 *
 * FedEx endpoints (verify paths in [FedEx Ship API — Open Ship](https://developer.fedex.com/api/en-us/catalog/ship/v1/docs.html) and [Open Ship v1](https://developer.fedex.com/api/en-us/catalog/open-ship/v1/docs.html)):
 *   POST   /ship/v1/openshipments/create  (root **`openShipmentAction`**: enum includes **CREATE_PACKAGE**, STRONG_VALIDATION, WEAK_VALIDATION, PROVIDE_DOCUMENTS_INCREMENTALLY — default **CREATE_PACKAGE**; override via `fshipping_openship_start_open_shipment_action`)
 *   POST   /ship/v1/openshipments/packages
 *   PUT    /ship/v1/openshipments/packages — modify existing package (same body family as POST add)
 *   PUT /ship/v1/openshipments/packages/delete
 *   PUT    /ship/v1/openshipments         — update open shipment (session-level requestedShipment)
 *   PUT    /ship/v1/openshipments/delete   — delete whole Open Ship session (before confirm)
 *   POST   /ship/v1/openshipments/confirm
 *   POST   /ship/v1/openshipments/async/start
 *   GET    /ship/v1/openshipments/async/results/{jobId}
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class OpenShip extends BaseClient {
    /**
     * Create Open Ship session — FedEx REST path (production: `https://apis.fedex.com/ship/v1/openshipments/create`).
     *
     * @see https://developer.fedex.com/api/en-us/catalog/ship/v1/docs.html
     */
    private const OPENSHIPMENTS_CREATE_PATH = '/ship/v1/openshipments/create';

    protected string $log_source = 'fshipping_openship';

    /** Full JSON body from the last POST {@see self::OPENSHIPMENTS_CREATE_PATH} (null if create was not called). */
    private ?array $last_openship_start_full = null;

    /** Last JSON request body sent to {@see self::OPENSHIPMENTS_CREATE_PATH} (for `index` + session extraction). */
    private ?array $last_openship_create_request_payload = null;

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    /**
     * Root `accountNumber` object for Open Ship POST bodies (matches Ship API and
     * [Open Ship v1 — operations](https://developer.fedex.com/api/en-us/catalog/open-ship/v1/docs.html)).
     *
     * @return array{value: string}
     */
    private function openship_account_number_object(): array {
        $settings = get_option('fshipping_options');
        $acc      = sanitize_text_field($settings['fshipping_acc_number'] ?? '');

        return ['value' => $acc];
    }

    /**
     * Label specification for Open Ship confirm from FedEx -> Settings -> Labeling.
     *
     * @return array{labelStockType: string, imageType: string}
     */
    private function openship_confirm_label_specification_from_settings(): array {
        $settings = get_option('fshipping_options');
        $spec = [
            'labelStockType' => sanitize_text_field($settings['fshipping_labeling_stock_type'] ?? 'PAPER_85X11_TOP_HALF_LABEL'),
            'imageType'      => sanitize_text_field($settings['fshipping_labeling_image_type'] ?? 'PDF'),
        ];

        return [
            'labelStockType' => $spec['labelStockType'] !== '' ? $spec['labelStockType'] : 'PAPER_85X11_TOP_HALF_LABEL',
            'imageType'      => $spec['imageType'] !== '' ? $spec['imageType'] : 'PDF',
        ];
    }

    /**
     * POST /ship/v1/openshipments/create — full decoded body (output and/or errors).
     *
     * @param array<string, mixed> $args Same shape as {@see start()}.
     * @return array<string, mixed>
     */
    protected function post_openshipments_start(array $args): array {
        $this->last_openship_start_full              = null;
        $this->last_openship_create_request_payload = null;
        $payload                                     = $this->prepare_start_payload($args);
        $payload                                     = $this->ensure_openship_create_payload_has_root_index($payload, $args);
        if (!$this->openship_create_root_index_is_valid($payload)) {
            $decoded = $this->openship_create_rejected_missing_index($payload, $args);
            $this->last_openship_start_full              = $decoded;
            $this->last_openship_create_request_payload = $payload;

            return $decoded;
        }
        $this->log_openship_create_index_line('initial POST', (string) $payload['index'], null, $args);
        $this->log_openship_create_exact_wire_json_before_http($payload, $args, null);

        $decoded                         = $this->post(self::OPENSHIPMENTS_CREATE_PATH, $payload);
        if (!is_array($decoded)) {
            $decoded = [];
        }

        if (
            $this->response_has_fedex_error_code($decoded, 'SHIPMENT.INDEX.REQUIRED')
            && empty($args['_teamz_retried_openship_after_index_required'])
        ) {
            $failed_index = isset($payload['index']) ? (string) $payload['index'] : '';
            $oid          = !empty($args['order_id']) ? (int) $args['order_id'] : 0;
            $fresh_index  = Draft::allocate_unique_openship_index_for_order_id($oid);
            if ($fresh_index === $failed_index) {
                $fresh_index = Draft::allocate_unique_openship_index_for_order_id($oid);
            }
            $this->last_openship_start_full              = null;
            $this->last_openship_create_request_payload = null;

            $req_args = $args;
            $req_args['_teamz_retried_openship_after_index_required'] = true;
            $req_args['openship_index']                               = $fresh_index;
            $req_args['_teamz_force_openship_root_index']             = $fresh_index;

            $payload_retry = $this->prepare_start_payload($req_args);
            $payload_retry = $this->ensure_openship_create_payload_has_root_index($payload_retry, $req_args);
            $payload_retry['index'] = sanitize_text_field((string) ($payload_retry['index'] ?? $fresh_index));

            if (!$this->openship_create_root_index_is_valid($payload_retry)) {
                self::debug_log_push_message(
                    '[teamzlab-fedex Open Ship] openshipments/create: SHIPMENT.INDEX.REQUIRED retry aborted — could not set root index after rebuild.',
                    true
                );
            } else {
                $this->log_openship_create_index_line(
                    'retry after SHIPMENT.INDEX.REQUIRED',
                    (string) $payload_retry['index'],
                    $failed_index !== '' ? $failed_index : null,
                    $req_args
                );
                $this->log_openship_create_exact_wire_json_before_http($payload_retry, $req_args, 'retry after SHIPMENT.INDEX.REQUIRED');
                $decoded_retry = $this->post(self::OPENSHIPMENTS_CREATE_PATH, $payload_retry);
                if (is_array($decoded_retry)) {
                    $decoded = $decoded_retry;
                    $payload = $payload_retry;
                }
                if (self::should_log_openship_push_debug()) {
                    self::debug_log_push_message(
                        '[teamzlab-fedex Open Ship] openshipments/create: FedEx returned SHIPMENT.INDEX.REQUIRED; retried once with full rebuild and new root `index`.'
                    );
                }
            }
        }

        $retried = false;
        if ($this->should_retry_openship_start_with_fedex_sandbox_account($decoded, $args)) {
            $retry_args              = $args;
            if (!empty($payload['index'])) {
                $retry_args['openship_index'] = (string) $payload['index'];
            }
            $retry_args['account_number_override'] = self::fedex_shared_sandbox_test_account_number();
            $payload2                = $this->prepare_start_payload($retry_args);
            $payload2                = $this->ensure_openship_create_payload_has_root_index($payload2, $retry_args);
            if (!$this->openship_create_root_index_is_valid($payload2)) {
                $decoded2 = $this->openship_create_rejected_missing_index($payload2, $retry_args);
            } else {
                $decoded2 = $this->post(self::OPENSHIPMENTS_CREATE_PATH, $payload2);
            }
            if (!is_array($decoded2)) {
                $decoded2 = [];
            }
            if (empty($decoded2['errors'])) {
                $payload = $payload2;
                $decoded = $decoded2;
                $retried = true;
                if (self::should_log_openship_push_debug()) {
                    self::debug_log_push_message(
                        '[teamzlab-fedex Open Ship] openshipments/create: first attempt returned NOT.FOUND.ERROR with the configured account; retry succeeded using FedEx sandbox test account '
                        . self::fedex_shared_sandbox_test_account_number()
                        . '. For Sandbox API use that account in Fedex → Settings → Account.'
                    );
                }
            } else {
                $payload = $payload2;
                $decoded = $decoded2;
            }
        } elseif (
            empty($args['account_number_override'])
            && $this->response_has_fedex_error_code($decoded, 'NOT.FOUND.ERROR')
        ) {
            $skip = $this->openship_start_sandbox_retry_skip_reason_for_not_found($decoded, $args);
            if ($skip !== '') {
                self::debug_log_push_message(
                    '[teamzlab-fedex Open Ship] openshipments/create: NOT.FOUND.ERROR — sandbox test-account retry skipped: ' . $skip,
                    true
                );
            }
        }

        $this->last_openship_start_full              = $decoded;
        $this->last_openship_create_request_payload = $payload;

        return $decoded;
    }

    /**
     * Full FedEx REST URL for logging (matches {@see BaseClient} URL construction).
     */
    private function openship_absolute_url(string $path): string {
        return rtrim($this->base_url(), '/') . '/' . ltrim($path, '/');
    }

    /**
     * One line for debug.log: method + URL + plugin environment label.
     *
     * @param string $method HTTP verb, e.g. POST
     */
    public static function format_openship_debug_api_line(string $method, string $absolute_url): string {
        $parsed = wp_parse_url($absolute_url);
        $host   = is_array($parsed) && !empty($parsed['host']) ? (string) $parsed['host'] : '';
        $mode = Helper::instance()->is_sandbox_environment()
            ? __('sandbox (Fedex → Settings → environment)', 'teamzlab-fedex')
            : __('production (Fedex → Settings → environment)', 'teamzlab-fedex');
        return sprintf(
            '%s %s | %s | FedEx API host: %s',
            strtoupper($method),
            $absolute_url,
            $mode,
            $host !== '' ? $host : $absolute_url
        );
    }

    /**
     * FedEx documents a shared sandbox billing account for Ship/Open Ship (see RUNBOOK_CREDENTIALS.md).
     */
    public static function fedex_shared_sandbox_test_account_number(): string {
        return (string) apply_filters('fshipping_fedex_shared_sandbox_account_number', '510087100');
    }

    /**
     * @param array<string, mixed> $decoded
     * @param array<string, mixed> $args
     */
    private function should_retry_openship_start_with_fedex_sandbox_account(array $decoded, array $args): bool {
        if (!empty($args['account_number_override'])) {
            return false;
        }
        // Retry when sandbox host or settings say sandbox (covers filtered base URLs vs option drift).
        if (!Helper::instance()->hits_sandbox_fedex_api_host() && !Helper::instance()->is_sandbox_environment()) {
            return false;
        }
        if (!apply_filters('fshipping_openship_retry_start_with_doc_sandbox_account', true, $decoded, $args)) {
            return false;
        }
        if (!$this->response_has_fedex_error_code($decoded, 'NOT.FOUND.ERROR')) {
            return false;
        }
        $settings = get_option('fshipping_options');
        $current  = sanitize_text_field($settings['fshipping_acc_number'] ?? '');
        $doc      = self::fedex_shared_sandbox_test_account_number();
        return $current !== $doc;
    }

    /**
     * Why we did not retry Open Ship start with the documented sandbox billing account (debug only).
     *
     * @param array<string, mixed> $decoded
     * @param array<string, mixed> $args
     */
    private function openship_start_sandbox_retry_skip_reason_for_not_found(array $decoded, array $args): string {
        if (!Helper::instance()->hits_sandbox_fedex_api_host() && !Helper::instance()->is_sandbox_environment()) {
            return __(
                'Sandbox test-account retry not used (Settings → environment is Production). Use your production FedEx account; if NOT.FOUND persists, confirm Open Ship is enabled for that account in FedEx Developer / account services.',
                'teamzlab-fedex'
            );
        }
        if (!apply_filters('fshipping_openship_retry_start_with_doc_sandbox_account', true, $decoded, $args)) {
            return 'Filter fshipping_openship_retry_start_with_doc_sandbox_account returned false.';
        }
        $settings = get_option('fshipping_options');
        $current  = sanitize_text_field($settings['fshipping_acc_number'] ?? '');
        if ($current === self::fedex_shared_sandbox_test_account_number()) {
            return __(
                'Configured account already matches the documented sandbox test account; FedEx still returned NOT.FOUND (check service, addresses, or API catalog).',
                'teamzlab-fedex'
            );
        }
        return '';
    }

    /**
     * @param array<string, mixed> $decoded
     */
    /**
     * Whether FedEx JSON body contains an error with the given code (e.g. SHIPMENT.INDEX.REQUIRED).
     *
     * @param array<string, mixed> $decoded
     */
    public static function response_has_fedex_error_code(array $decoded, string $code): bool {
        if (empty($decoded['errors']) || !is_array($decoded['errors'])) {
            return false;
        }
        foreach ($decoded['errors'] as $err) {
            if (is_array($err) && isset($err['code']) && (string) $err['code'] === $code) {
                return true;
            }
        }
        return false;
    }

    /**
     * After {@see prepare_start_payload()} and filters, guarantee a non-empty root **`index`** for
     * `openshipments/create` (FedEx **`SHIPMENT.INDEX.REQUIRED`** when missing).
     *
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $args
     * @return array<string, mixed>
     */
    private function ensure_openship_create_payload_has_root_index(array $payload, array $args): array {
        if (!empty($args['_teamz_force_openship_root_index']) && is_string($args['_teamz_force_openship_root_index'])) {
            $forced = trim((string) $args['_teamz_force_openship_root_index']);
            if ($forced !== '') {
                $payload['index'] = sanitize_text_field($forced);

                return $this->openship_create_apply_shipment_index_alias($payload, $args);
            }
        }

        $idx = isset($payload['index']) ? trim((string) $payload['index']) : '';
        $oid = !empty($args['order_id']) ? (int) $args['order_id'] : 0;
        if ($idx !== '' && $oid > 0) {
            // Legacy bare defaults (no entropy) — replace with {@see Draft::allocate_unique_openship_index_for_order_id()}.
            if ($idx === 'wc-os-' . $oid || $idx === 'wc_order_' . $oid) {
                $idx = '';
            }
        }
        if ($idx !== '') {
            $payload['index'] = sanitize_text_field($idx);

            return $this->openship_create_apply_shipment_index_alias($payload, $args);
        }
        if ($oid > 0) {
            $payload['index'] = Draft::allocate_unique_openship_index_for_order_id($oid);

            return $this->openship_create_apply_shipment_index_alias($payload, $args);
        }
        if (!empty($args['openship_index']) && is_string($args['openship_index'])) {
            $try = trim((string) $args['openship_index']);
            if ($try !== '') {
                $payload['index'] = sanitize_text_field($try);

                return $this->openship_create_apply_shipment_index_alias($payload, $args);
            }
        }
        $payload['index'] = Draft::allocate_unique_openship_index_for_order_id(0);

        return $this->openship_create_apply_shipment_index_alias($payload, $args);
    }

    /**
     * FedEx Open Ship create request should send the open-shipment key as root `index`.
     * Do not send `shipmentIndex` or `requestedShipment.index` on create.
     *
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $args
     * @return array<string, mixed>
     */
    private function openship_create_apply_shipment_index_alias(array $payload, array $args): array {
        unset($args);
        unset($payload['shipmentIndex']);
        if (isset($payload['requestedShipment']) && is_array($payload['requestedShipment'])) {
            unset($payload['requestedShipment']['index']);
        }

        return $payload;
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function openship_create_root_index_is_valid(array $payload): bool {
        return isset($payload['index']) && trim((string) $payload['index']) !== '';
    }

    /**
     * Local failure — no HTTP call (see {@see post_openshipments_start()}).
     *
     * @param array<string, mixed> $payload
     * @param array<string, mixed> $args
     * @return array<string, mixed>
     */
    private function openship_create_rejected_missing_index(array $payload, array $args): array {
        self::debug_log_push_message(
            'Missing FedEx Open Ship index — openshipments/create not sent (order_id='
            . (!empty($args['order_id']) ? (string) (int) $args['order_id'] : '0') . ').',
            true
        );

        return [
            'errors' => [
                [
                    'code'    => 'TEAMZ.OPENSHIP.INDEX.MISSING',
                    'message' => 'Missing FedEx Open Ship index',
                ],
            ],
        ];
    }

    /**
     * Debug: log the root `index` sent on openshipments/create (and whether retry differs from failed attempt).
     *
     * @param array<string, mixed> $args
     */
    /**
     * Log the **exact** JSON bytes sent on the wire (same as {@see \Teamz\Wp\Kit\Http\BaseClient}:
     * `wp_json_encode($payload)` with default flags). Plugin `debug_log_push_json_blocks` pretty-prints
     * from the PHP array and can differ slightly (pretty print, `JSON_UNESCAPED_UNICODE`); use this block
     * when comparing to proxies or FedEx support.
     *
     * @param array<string, mixed> $payload Same array passed to `post(openshipments/create)`.
     * @param array<string, mixed> $args    Start args (order-scoped logging uses `order_id` + filter).
     * @param string|null          $phase Extra title suffix, e.g. retry phase; null for initial create.
     */
    private function log_openship_create_exact_wire_json_before_http(array $payload, array $args, ?string $phase): void {
        $force_order = !empty($args['order_id'])
            && (bool) apply_filters('fshipping_openship_log_create_for_order', true, $args, $payload, null);
        $extra = (bool) apply_filters('fshipping_openship_log_exact_wire_json_before_create', false, $args, $payload);
        if (!$force_order && !self::should_log_openship_push_debug() && !$extra) {
            return;
        }
        $wire = wp_json_encode($payload);
        if (false === $wire) {
            self::debug_log_push_message(
                '[teamzlab-fedex Open Ship] openshipments/create: wp_json_encode(payload) failed before HTTP (json_last_error='
                . (function_exists('json_last_error_msg') ? json_last_error_msg() : (string) json_last_error()) . ').',
                true
            );

            return;
        }
        $url   = $this->openship_absolute_url(self::OPENSHIPMENTS_CREATE_PATH);
        $title = 'openshipments/create (exact wire JSON before HTTP)';
        if ($phase !== null && $phase !== '') {
            $title .= ' — ' . $phase;
        }
        if (!empty($args['order_id'])) {
            $title .= ' (order_id=' . (string) (int) $args['order_id'] . ')';
        }
        self::debug_log_push_json_blocks(
            $title,
            [
                'FedEx REST URL'      => $url,
                'API (requested)'     => self::format_openship_debug_api_line('POST', $url),
                'request (wire body)' => $wire,
            ],
            $force_order
        );
    }

    private function log_openship_create_index_line(string $phase, string $index, ?string $previous_failed_index, array $args): void {
        $index = trim($index);
        if ($index === '') {
            self::debug_log_push_message(
                '[teamzlab-fedex Open Ship] openshipments/create [' . $phase . '] root index is EMPTY — check filters.',
                true
            );

            return;
        }
        if (!self::should_log_openship_push_debug() && empty($args['order_id'])) {
            return;
        }
        $oid = !empty($args['order_id']) ? (string) (int) $args['order_id'] : '—';
        $diff = '';
        if ($previous_failed_index !== null && $previous_failed_index !== '') {
            $diff = $index !== $previous_failed_index
                ? ' differs_from_failed=1'
                : ' differs_from_failed=0';
        }
        self::debug_log_push_message(
            '[teamzlab-fedex Open Ship] openshipments/create [' . $phase . '] root index=' . $index . ' order_id=' . $oid . $diff,
            true
        );
    }

    /**
     * POST openshipments/create and return the **full** decoded JSON body (not only `output`).
     * FedEx sometimes places session fields at the root or under `output`; returning only `output`
     * caused empty results and false “start failed” when `output` was missing but the root had data.
     *
     * @return array<string, mixed>
     */
    public function start(array $args): array {
        $decoded = $this->post_openshipments_start($args);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * Full JSON from the last Open Ship start call (for admin errors and logging).
     *
     * @return array<string, mixed>|null Null if {@see start_from_order()} returned before POST (e.g. missing requestedShipment).
     */
    public function get_last_openship_start_full(): ?array {
        return $this->last_openship_start_full;
    }

    /**
     * Last create request body (includes root **`index`** when set).
     *
     * @return array<string, mixed>|null
     */
    public function get_last_openship_create_request_payload(): ?array {
        return $this->last_openship_create_request_payload;
    }

    /**
     * Human-readable reason Open Ship start failed (FedEx errors or local build failure).
     *
     * @param array<string, mixed>|null $decoded Full API body, or null if HTTP/build never produced JSON.
     */
    public static function summarize_fedex_start_failure(?array $decoded): string {
        if (null === $decoded) {
            return __('Could not build a FedEx Open Ship request from this order (missing requestedShipment — check shipper and recipient addresses).', 'teamzlab-fedex');
        }
        if (!empty($decoded['errors']) && is_array($decoded['errors'])) {
            foreach ($decoded['errors'] as $err) {
                if (is_array($err) && (string) ($err['code'] ?? '') === 'TEAMZ.OPENSHIP.INDEX.MISSING') {
                    return __(
                        'Missing FedEx Open Ship index — the create request was not sent. See debug.log (search: Missing FedEx Open Ship index).',
                        'teamzlab-fedex'
                    );
                }
            }
            $parts = [];
            foreach ($decoded['errors'] as $err) {
                if (!is_array($err)) {
                    continue;
                }
                $code = isset($err['code']) ? (string) $err['code'] : '';
                $msg  = isset($err['message']) ? (string) $err['message'] : '';
                if (isset($err['errorDetail']) && is_array($err['errorDetail'])) {
                    $d = $err['errorDetail'];
                    if ($msg === '' && !empty($d['message'])) {
                        $msg = (string) $d['message'];
                    }
                    if ($code === '' && !empty($d['code'])) {
                        $code = (string) $d['code'];
                    }
                }
                $one = trim($code . ($code !== '' && $msg !== '' ? ': ' : '') . $msg);
                if ($one !== '') {
                    $parts[] = $one;
                }
            }
            if (!empty($parts)) {
                $msg = implode(' ', $parts);
                foreach ($decoded['errors'] as $err) {
                    if (!is_array($err) || !isset($err['code']) || (string) $err['code'] !== 'NOT.FOUND.ERROR') {
                        continue;
                    }
                    if (Helper::instance()->hits_sandbox_fedex_api_host() || Helper::instance()->is_sandbox_environment()) {
                        $msg .= ' ' . __(
                            'FedEx Sandbox: use the test account from developer.fedex.com in Fedex → Settings → Account. Production account numbers are not valid on apis-sandbox.fedex.com.',
                            'teamzlab-fedex'
                        );
                    } else {
                        $msg .= ' ' . __(
                            'FedEx Production: confirm the Ship account number is valid for Open Ship / Ground, OAuth credentials match this environment, and Create Open Shipment uses POST /ship/v1/openshipments/create with openShipmentAction CREATE_PACKAGE (or another allowed enum value — see FedEx Ship API — Open Ship).',
                            'teamzlab-fedex'
                        );
                    }
                    break;
                }
                foreach ($decoded['errors'] as $err) {
                    if (!is_array($err) || (string) ($err['code'] ?? '') !== 'SHIPMENT.INDEX.INUSE') {
                        continue;
                    }
                    $msg .= ' ' . __(
                        'SHIPMENT.INDEX.INUSE: FedEx already has an active Open Ship for this index. The plugin retries create with a new unique index and can attach to an existing session when local order meta matches. If this persists, use Cancel on FedEx (order screen or drafts list) or filter `fshipping_openship_create_index`.',
                        'teamzlab-fedex'
                    );
                    break;
                }
                foreach ($decoded['errors'] as $err) {
                    if (!is_array($err) || (string) ($err['code'] ?? '') !== 'SHIPMENT.INDEX.REQUIRED') {
                        continue;
                    }
                    $msg .= ' ' . __(
                        'SHIPMENT.INDEX.REQUIRED: confirm root `index` in the logged create JSON; the plugin also retries once with a new unique index and defaults `groupPackageCount` on package lines. If the error persists, verify Open Ship entitlement or contact FedEx support.',
                        'teamzlab-fedex'
                    );
                    break;
                }
                return $msg;
            }
        }
        if (!empty($decoded['output']) && is_array($decoded['output'])) {
            return __('FedEx responded but did not return a session index in output. Check debug.log for the full response.', 'teamzlab-fedex');
        }
        if ($decoded === []) {
            return __('FedEx returned an empty or non-JSON response (check OAuth token, API base URL, and network).', 'teamzlab-fedex');
        }
        return __('FedEx could not start Open Ship. See debug.log for request and response.', 'teamzlab-fedex');
    }

    /**
     * Whether **`openshipments/create`** returned a real session (master tracking from FedEx).
     * Bodies with only **`errors`** or **`transactionId`** must not be treated as checkout success.
     *
     * @param array<string, mixed> $decoded Full decoded create response.
     */
    public static function openship_create_response_body_indicates_success(array $decoded): bool {
        if (!empty($decoded['errors']) && is_array($decoded['errors'])) {
            return (bool) apply_filters('fshipping_openship_treat_errors_as_create_success', false, $decoded);
        }
        $out = $decoded['output'] ?? [];
        if (!is_array($out)) {
            return false;
        }
        $rows = $out['transactionShipments'] ?? null;
        if (!is_array($rows) || !isset($rows[0]) || !is_array($rows[0])) {
            return (bool) apply_filters('fshipping_openship_create_success_without_transaction_shipments', false, $decoded, $out);
        }
        $first = $rows[0];
        if (!empty($first['masterTrackingNumber'])) {
            return true;
        }
        $csd = $first['completedShipmentDetail'] ?? [];
        if (is_array($csd)) {
            $mtid = $csd['masterTrackingId'] ?? [];
            if (is_array($mtid) && !empty($mtid['trackingNumber'])) {
                return true;
            }
        }

        return false;
    }

    /**
     * Remove Ship API create-shipment fields that are not valid for POST openshipments/create.
     *
     * The checkout Ship payload includes labelSpecification (stock type, rotation, etc.). FedEx may
     * resolve those as catalog resources and respond with NOT.FOUND.ERROR for Open Ship start.
     * Labels are produced at confirm, not at session start.
     *
     * When `fshipping_openship_use_minimal_start_payload` is true (default), the request is replaced
     * with a minimal Open Ship shape: no shipTimestamp/totalDeclaredValue; billing keeps the payor
     * **account** plus **address/contact** when present on the Ship payload (including legacy
     * `payor.address` beside `responsibleParty`); adds **`shipDatestamp`**, **`totalWeight`** (LB sum of
     * package lines), and `DROPOFF_AT_FEDEX_LOCATION` mapped to `USE_SCHEDULED_PICKUP` because
     * drop-off pickup often fails NOT.FOUND on `/openshipments/create`.
     *
     * Filters: `fshipping_openship_start_strip_special_services`, `fshipping_openship_use_minimal_start_payload`,
     * `fshipping_openship_start_requested_shipment`.
     *
     * @param array<string, mixed> $requested_shipment
     * @param \WC_Order              $order
     * @return array<string, mixed>
     */
    private function finalize_requested_shipment_for_openship_start(array $requested_shipment, $order): array {
        if ($this->should_keep_full_requested_shipment_on_start($requested_shipment, $order)) {
            $requested_shipment = apply_filters('fshipping_openship_start_requested_shipment', $requested_shipment, $order);

            return $this->apply_openship_create_default_group_package_count($requested_shipment);
        }

        $label_spec = isset($requested_shipment['labelSpecification']) && is_array($requested_shipment['labelSpecification'])
            ? $this->sanitize_openship_label_spec($requested_shipment['labelSpecification'])
            : [];

        $strip = [
            'shippingDocumentSpecification',
            'emailNotificationDetail',
            'documentRequirements',
        ];
        foreach ($strip as $key) {
            unset($requested_shipment[$key]);
        }
        if (apply_filters('fshipping_openship_start_strip_special_services', true, $requested_shipment, $order)) {
            unset($requested_shipment['specialServicesRequested']);
        }
        if (!empty($label_spec)) {
            $requested_shipment['labelSpecification'] = $label_spec;
        }

        $use_minimal = apply_filters('fshipping_openship_use_minimal_start_payload', true, $requested_shipment, $order);
        if ($use_minimal) {
            $requested_shipment = $this->build_minimal_openship_requested_shipment($requested_shipment, $order);
        }

        $requested_shipment = apply_filters('fshipping_openship_start_requested_shipment', $requested_shipment, $order);

        return $this->apply_openship_create_default_group_package_count($requested_shipment);
    }

    /**
     * Opt-in passthrough for full Open Ship create payloads.
     *
     * Default flow intentionally strips/reduces the Ship payload for compatibility.
     * Return true via filter to keep the richer `requestedShipment` shape.
     *
     * Filter: `fshipping_openship_start_keep_full_requested_shipment`
     *
     * @param array<string, mixed> $requested_shipment
     * @param \WC_Order            $order
     */
    private function should_keep_full_requested_shipment_on_start(array $requested_shipment, $order): bool {
        return (bool) apply_filters(
            'fshipping_openship_start_keep_full_requested_shipment',
            false,
            $requested_shipment,
            $order
        );
    }

    /**
     * FedEx Open Ship create often expects **`groupPackageCount`** on master package line items; without it
     * some accounts return **`SHIPMENT.INDEX.REQUIRED`** even when root **`index`** is present.
     *
     * @param array<string, mixed> $requested_shipment
     * @return array<string, mixed>
     */
    private function apply_openship_create_default_group_package_count(array $requested_shipment): array {
        if (empty($requested_shipment['requestedPackageLineItems']) || !is_array($requested_shipment['requestedPackageLineItems'])) {
            return $requested_shipment;
        }
        foreach ($requested_shipment['requestedPackageLineItems'] as $i => $line) {
            if (!is_array($line)) {
                continue;
            }
            if (!array_key_exists('groupPackageCount', $line)) {
                $requested_shipment['requestedPackageLineItems'][ $i ]['groupPackageCount'] = 1;
            }
        }

        return $requested_shipment;
    }

    /**
     * FedEx Open Ship `/start` expects at least one master requested package line item (sequence 1).
     * `fshipping_openship_requested_shipment`, intl JSON patches, or `array_replace_recursive` can leave
     * `requestedPackageLineItems` empty — that matches minimal bodies in debug.log and often yields NOT.FOUND.
     *
     * @param array<string, mixed> $requested_shipment
     * @param \WC_Order              $order
     * @return array<string, mixed>
     */
    private function ensure_master_requested_package_line_for_openship_start(array $requested_shipment, $order): array {
        $lines = $requested_shipment['requestedPackageLineItems'] ?? null;
        $weight_ok = is_array($lines)
            && isset($lines[0])
            && is_array($lines[0])
            && !empty($lines[0]['weight'])
            && is_array($lines[0]['weight'])
            && isset($lines[0]['weight']['value'])
            && trim((string) $lines[0]['weight']['value']) !== '';

        if ($weight_ok) {
            return $requested_shipment;
        }

        $stored = Draft::get_packages($order);
        $pkg    = (isset($stored[0]) && is_array($stored[0])) ? $stored[0] : null;
        if (is_array($pkg)) {
            $wu = strtoupper((string) ($pkg['weight_unit'] ?? 'LB'));
            $du = strtoupper((string) ($pkg['dimension_unit'] ?? 'IN'));
            $line = [
                'weight' => [
                    'units' => $wu === 'KG' ? 'KG' : 'LB',
                    'value' => (string) max(0.01, (float) ($pkg['weight'] ?? 1)),
                ],
                'dimensions' => [
                    'length' => max(1, (int) ($pkg['length'] ?? 10)),
                    'width'  => max(1, (int) ($pkg['width'] ?? 10)),
                    'height' => max(1, (int) ($pkg['height'] ?? 10)),
                    'units'  => $du === 'CM' ? 'CM' : 'IN',
                ],
            ];
        } else {
            $line = [
                'weight'       => ['units' => 'LB', 'value' => '1'],
                'dimensions' => ['length' => 10, 'width' => 10, 'height' => 10, 'units' => 'IN'],
            ];
        }
        $line['groupPackageCount']    = 1;
        $requested_shipment['requestedPackageLineItems'] = [$line];

        return $requested_shipment;
    }

    /**
     * FedEx Open Ship `/start` accepts a smaller `requestedShipment` than Create Shipment. Extra
     * fields (shipTimestamp, declared value, payor physical address, drop-off pickup) often trigger
     * NOT.FOUND.ERROR in practice.
     *
     * @param array<string, mixed> $rs
     * @param \WC_Order              $order
     * @return array<string, mixed>
     */
    private function build_minimal_openship_requested_shipment(array $rs, $order): array {
        $settings = get_option('fshipping_options');
        $acc      = sanitize_text_field($settings['fshipping_acc_number'] ?? '');

        $pickup = isset($rs['pickupType']) ? (string) $rs['pickupType'] : 'USE_SCHEDULED_PICKUP';
        if ('DROPOFF_AT_FEDEX_LOCATION' === $pickup) {
            $pickup = 'USE_SCHEDULED_PICKUP';
        }

        $pay_type = 'SENDER';
        if (!empty($rs['shippingChargesPayment']['paymentType'])) {
            $pay_type = sanitize_text_field((string) $rs['shippingChargesPayment']['paymentType']);
        }

        $rp = [
            'accountNumber' => ['value' => $acc],
        ];
        $payor_src = $rs['shippingChargesPayment']['payor'] ?? [];
        if (is_array($payor_src)) {
            $rp_src = $payor_src['responsibleParty'] ?? [];
            if (is_array($rp_src)) {
                foreach (['address', 'contact'] as $k) {
                    if (!empty($rp_src[$k]) && is_array($rp_src[$k])) {
                        $rp[ $k ] = $rp_src[ $k ];
                    }
                }
            }
            if (empty($rp['address']) && !empty($payor_src['address']) && is_array($payor_src['address'])) {
                $rp['address'] = $payor_src['address'];
            }
        }

        $default_stamp = '';
        if (is_object($order) && method_exists($order, 'get_date_created') && $order->get_date_created()) {
            $default_stamp = wp_date('Y-m-d', $order->get_date_created()->getTimestamp(), wp_timezone());
        } else {
            $default_stamp = wp_date('Y-m-d', time(), wp_timezone());
        }
        $ship_datestamp = (string) apply_filters('fshipping_openship_ship_datestamp', $default_stamp, $rs, $order);

        $out = [
            'shipper'                 => $rs['shipper'] ?? [],
            'recipients'              => $rs['recipients'] ?? [],
            'serviceType'           => isset($rs['serviceType']) ? sanitize_text_field((string) $rs['serviceType']) : 'FEDEX_GROUND',
            'packagingType'         => isset($rs['packagingType']) ? sanitize_text_field((string) $rs['packagingType']) : 'YOUR_PACKAGING',
            'pickupType'            => $pickup,
            'totalPackageCount'     => isset($rs['totalPackageCount']) ? max(1, (int) $rs['totalPackageCount']) : 1,
            'shipDatestamp'         => sanitize_text_field($ship_datestamp),
            'shippingChargesPayment' => [
                'paymentType' => $pay_type,
                'payor'       => [
                    'responsibleParty' => $rp,
                ],
            ],
        ];

        if (!empty($rs['requestedPackageLineItems']) && is_array($rs['requestedPackageLineItems'])) {
            $out['requestedPackageLineItems'] = self::normalize_openship_package_line_dimensions($rs['requestedPackageLineItems']);
        }

        if (!empty($rs['shipmentSpecialServices']) && is_array($rs['shipmentSpecialServices'])) {
            // Keep shipment-level special services in minimal create payload (e.g. shipmentDryIceDetail.totalWeight).
            $out['shipmentSpecialServices'] = $rs['shipmentSpecialServices'];
        }
        $has_dry_ice_total_weight = !empty($rs['shipmentSpecialServices'])
            && is_array($rs['shipmentSpecialServices'])
            && !empty($rs['shipmentSpecialServices']['shipmentDryIceDetail'])
            && is_array($rs['shipmentSpecialServices']['shipmentDryIceDetail'])
            && !empty($rs['shipmentSpecialServices']['shipmentDryIceDetail']['totalWeight'])
            && is_array($rs['shipmentSpecialServices']['shipmentDryIceDetail']['totalWeight']);

        $tw_lb = self::compute_total_weight_lb_from_requested_lines($out['requestedPackageLineItems'] ?? []);
        if ($tw_lb !== null && !$has_dry_ice_total_weight) {
            // Requested by integration: send scalar totalWeight in requestedShipment.
            $out['totalWeight'] = round($tw_lb, 2);
        }

        if (!empty($rs['customsClearanceDetail']) && is_array($rs['customsClearanceDetail'])) {
            $out['customsClearanceDetail'] = $rs['customsClearanceDetail'];
        }
        if (!empty($rs['labelSpecification']) && is_array($rs['labelSpecification'])) {
            $ls = $this->sanitize_openship_label_spec($rs['labelSpecification']);
            if (!empty($ls)) {
                $out['labelSpecification'] = $ls;
            }
        }

        return $out;
    }

    /**
     * Keep only labelSpecification fields supported in Open Ship start overrides.
     *
     * @param array<string, mixed> $label_spec
     * @return array<string, string>
     */
    private function sanitize_openship_label_spec(array $label_spec): array {
        $allowed_stock = [
            'PAPER_4X6', 'PAPER_4X675', 'PAPER_4X8', 'PAPER_4X9', 'PAPER_7X475',
            'PAPER_85X11_BOTTOM_HALF_LABEL', 'PAPER_85X11_TOP_HALF_LABEL', 'PAPER_LETTER',
            'STOCK_4X85_TRAILING_DOC_TAB', 'STOCK_4X105_TRAILING_DOC_TAB', 'STOCK_4X675_LEADING_DOC_TAB',
            'STOCK_4X8', 'STOCK_4X9_LEADING_DOC_TAB', 'STOCK_4X6', 'STOCK_4X675_TRAILING_DOC_TAB',
            'STOCK_4X9_TRAILING_DOC_TAB', 'STOCK_4X675', 'STOCK_4X9',
        ];
        $allowed_image = ['ZPLII', 'EPL2', 'PDF', 'PNG'];
        $allowed_orientation = ['BOTTOM_EDGE_OF_TEXT_FIRST', 'TOP_EDGE_OF_TEXT_FIRST'];
        $out = [];

        $stock = isset($label_spec['labelStockType']) ? sanitize_text_field((string) $label_spec['labelStockType']) : '';
        if ($stock !== '' && in_array($stock, $allowed_stock, true)) {
            $out['labelStockType'] = $stock;
        }

        $image = isset($label_spec['imageType']) ? sanitize_text_field((string) $label_spec['imageType']) : '';
        if ($image !== '' && in_array($image, $allowed_image, true)) {
            $out['imageType'] = $image;
        }

        $orientation = isset($label_spec['labelPrintingOrientation']) ? sanitize_text_field((string) $label_spec['labelPrintingOrientation']) : '';
        if ($orientation !== '' && in_array($orientation, $allowed_orientation, true)) {
            $out['labelPrintingOrientation'] = $orientation;
        }

        return $out;
    }

    /**
     * Sum of package line weights in LB.
     *
     * @param array<int, array<string, mixed>> $lines
     */
    private static function compute_total_weight_lb_from_requested_lines(array $lines): ?float {
        $sum = 0.0;
        $any = false;
        foreach ($lines as $line) {
            if (!is_array($line) || empty($line['weight']) || !is_array($line['weight'])) {
                continue;
            }
            $w = isset($line['weight']['value']) ? (float) $line['weight']['value'] : 0.0;
            $u = strtoupper((string) ($line['weight']['units'] ?? 'LB'));
            if ($u === 'KG') {
                $w *= 2.20462;
            }
            $sum += $w;
            $any = true;
        }
        return $any ? round($sum, 2) : null;
    }

    /**
     * FedEx expects integer length/width/height for package dimensions; floats from WC can confuse validation.
     *
     * @param array<int, array<string, mixed>> $items
     * @return array<int, array<string, mixed>>
     */
    private static function normalize_openship_package_line_dimensions(array $items): array {
        foreach ($items as $i => $line) {
            if (!is_array($line) || empty($line['dimensions']) || !is_array($line['dimensions'])) {
                continue;
            }
            $d = $line['dimensions'];
            foreach (['length', 'width', 'height'] as $k) {
                if (array_key_exists($k, $d)) {
                    $d[$k] = max(1, (int) round((float) $d[$k]));
                }
            }
            $line['dimensions'] = $d;
            $items[$i]          = $line;
        }
        return $items;
    }

    /**
     * Build `requestedShipment` for Open Ship create/update from order + checkout FedEx line (same pipeline as create).
     *
     * @param \WC_Order $order
     * @param array     $current_shipping Same shape as {@see start_from_order()}.
     * @return array{rs_clean: array<string, mixed>, service: string, pkg_count: int}|array{}
     * @since 1.4
     */
    public function build_openship_requested_shipment_from_order($order, array $current_shipping): array {
        if (!is_object($order) || !method_exists($order, 'get_id')) {
            return [];
        }
        $full = Shipment::instance()->prepare_shipment_payload($current_shipping, $order);
        $rs   = $full['requestedShipment'] ?? [];
        if (empty($rs) || !is_array($rs)) {
            return [];
        }
        $rs = Draft::merge_overrides_into_requested_shipment($order, $rs);
        $rs = $this->ensure_master_requested_package_line_for_openship_start($rs, $order);

        $pkg_count = 1;
        $stored_pkgs = Draft::get_packages($order);
        if (!empty($stored_pkgs)) {
            $pkg_count = max(1, count($stored_pkgs));
        } elseif (!empty($rs['requestedPackageLineItems']) && is_array($rs['requestedPackageLineItems'])) {
            $pkg_count = max(1, count($rs['requestedPackageLineItems']));
        }
        $rs_clean = $rs;
        if ($this->should_keep_full_requested_shipment_on_start($rs_clean, $order)) {
            if (!empty($rs_clean['requestedPackageLineItems']) && is_array($rs_clean['requestedPackageLineItems'])) {
                $rs_clean['requestedPackageLineItems'] = self::normalize_openship_package_line_dimensions($rs_clean['requestedPackageLineItems']);
            }
        } else {
            // Open Ship /start: keep a single master line (sequence 1). Stripping all lines triggers NOT.FOUND on some accounts/services.
            if (!empty($rs_clean['requestedPackageLineItems']) && is_array($rs_clean['requestedPackageLineItems'])) {
                $first = $rs_clean['requestedPackageLineItems'][0];
                if (is_array($first)) {
                    $rs_clean['requestedPackageLineItems'] = self::normalize_openship_package_line_dimensions([$first]);
                }
            } else {
                unset($rs_clean['requestedPackageLineItems']);
            }
        }
        $rs_clean = $this->finalize_requested_shipment_for_openship_start($rs_clean, $order);
        $service = !empty($rs['serviceType'])
            ? sanitize_text_field((string) $rs['serviceType'])
            : sanitize_text_field((string) ($current_shipping['meta']['service_type'] ?? 'FEDEX_GROUND'));

        return [
            'rs_clean'   => $rs_clean,
            'service'    => $service,
            'pkg_count'  => $pkg_count,
        ];
    }

    /**
     * Start an Open Ship session using the same requestedShipment shape as the Ship API.
     *
     * @param \WC_Order $order
     * @param array     $current_shipping Checkout FedEx line meta (service_type, …).
     * @return array<string, mixed> Full FedEx create JSON body on success; empty array on failure (no POST, validation error, or FedEx `errors` in body).
     * @since 1.3
     */
    public function start_from_order($order, array $current_shipping): array {
        $built = $this->build_openship_requested_shipment_from_order($order, $current_shipping);
        if (empty($built['rs_clean'])) {
            return [];
        }
        $rs_clean   = $built['rs_clean'];
        $service    = $built['service'];
        $pkg_count  = $built['pkg_count'];

        $order_id     = (int) $order->get_id();
        $max_attempts = (int) apply_filters('fshipping_openship_create_max_attempts_on_index_error', 2, $order, $current_shipping);
        $max_attempts = max(1, min(5, $max_attempts));

        $decoded = [];
        for ($attempt = 0; $attempt < $max_attempts; $attempt++) {
            $create_index = Draft::allocate_unique_openship_index($order);
            $decoded      = $this->start([
                'service_type'        => $service,
                'total_package_count' => $pkg_count,
                'requested_shipment'  => $rs_clean,
                'order_id'            => $order_id,
                'openship_index'      => $create_index,
            ]);
            if ($decoded === []) {
                return [];
            }
            if ($this->response_has_fedex_error_code($decoded, 'TEAMZ.OPENSHIP.INDEX.MISSING')) {
                return [];
            }
            if (empty($decoded['errors']) || !is_array($decoded['errors'])) {
                if (!self::openship_create_response_body_indicates_success($decoded)) {
                    return [];
                }

                return $decoded;
            }
            if ($this->response_has_fedex_error_code($decoded, 'SHIPMENT.INDEX.INUSE')) {
                $recovered = $this->try_recover_openship_create_after_index_inuse($order);
                if ($recovered !== []) {
                    $this->last_openship_start_full = $recovered;

                    return $recovered;
                }
                continue;
            }
            if ($this->response_has_fedex_error_code($decoded, 'SHIPMENT.INDEX.REQUIRED')) {
                if (self::should_log_openship_push_debug()) {
                    self::debug_log_push_message(
                        '[teamzlab-fedex Open Ship] SHIPMENT.INDEX.REQUIRED — retrying openshipments/create with a new index (attempt '
                        . (string) ($attempt + 1) . '/' . (string) $max_attempts . ').'
                    );
                }
                continue;
            }
            return [];
        }

        return [];
    }

    /**
     * When FedEx returns SHIPMENT.INDEX.INUSE but order meta already holds the same index + master id, treat create as satisfied.
     *
     * @param \WC_Order $order
     * @return array<string, mixed> Synthetic success body for {@see extract_openship_session_from_create_output()}, or [] if no local match.
     */
    private function try_recover_openship_create_after_index_inuse($order): array {
        if (!is_object($order) || !method_exists($order, 'get_meta')) {
            return [];
        }
        $payload = $this->last_openship_create_request_payload ?? [];
        $req_idx = isset($payload['index']) ? sanitize_text_field((string) $payload['index']) : '';
        $local   = Draft::get_openship_session_for_fedex($order);
        if ($req_idx === '' || $local['shipmentIndex'] !== $req_idx || $local['shipmentIdIndex'] === '') {
            return [];
        }

        return [
            'output' => [
                'transactionShipments' => [
                    [
                        'shipmentIndex'        => $local['shipmentIndex'],
                        'masterTrackingNumber' => $local['shipmentIdIndex'],
                    ],
                ],
            ],
        ];
    }

    /**
     * Session pair from **Create** (stored on the order; see `extract_openship_session_from_create_output()`):
     * - Open-shipment key — root **`index`** on **Create** (e.g. `wc_order_*`); **`add_package()`** sends it as JSON **`index`**, not **`shipmentIndex`**.
     * - **`shipmentIdIndex`** — master **tracking** (`transactionShipments[0].masterTrackingNumber`); sent on **`add_package()`** as **`shipmentIdIndex`** alongside **`index`**.
     *
     * Sending only the tracking id without the open-shipment **`index`** yields **`SHIPMENT.INDEX.REQUIRED`**.
     *
     * @param array<string, mixed>              $start_output Decoded **`output`** from create (or full body with nested **`output`**).
     * @param array<string, mixed>|null       $create_request Root create JSON (for echo **`index`**); defaults to last create request on this client.
     * @return array{shipmentIndex: string, shipmentIdIndex: string}
     */
    public function extract_openship_session_from_create_output(array $start_output, ?array $create_request = null): array {
        if ($create_request === null) {
            $create_request = $this->last_openship_create_request_payload ?? [];
        }
        if (!empty($start_output['errors']) && is_array($start_output['errors'])) {
            return [
                'shipmentIndex'   => '',
                'shipmentIdIndex' => '',
            ];
        }
        if (!empty($start_output['output']) && is_array($start_output['output'])) {
            return $this->extract_openship_session_from_create_output($start_output['output'], $create_request);
        }

        $master = '';
        $rows   = $start_output['transactionShipments'] ?? null;
        if (is_array($rows) && isset($rows[0]) && is_array($rows[0])) {
            $first = $rows[0];
            if (!empty($first['masterTrackingNumber'])) {
                $master = sanitize_text_field((string) $first['masterTrackingNumber']);
            }
            if ($master === '') {
                $csd = $first['completedShipmentDetail'] ?? [];
                if (is_array($csd)) {
                    $mtid = $csd['masterTrackingId'] ?? [];
                    if (is_array($mtid) && !empty($mtid['trackingNumber'])) {
                        $master = sanitize_text_field((string) $mtid['trackingNumber']);
                    }
                }
            }
        }

        $ship_idx = '';
        foreach (['shipmentIndex', 'index'] as $key) {
            if (!empty($start_output[ $key ])) {
                $ship_idx = sanitize_text_field((string) $start_output[ $key ]);
                break;
            }
        }
        if ($ship_idx === '' && is_array($rows) && isset($rows[0]) && is_array($rows[0])) {
            $first = $rows[0];
            foreach (['shipmentIndex', 'index'] as $key) {
                if (!empty($first[ $key ])) {
                    $ship_idx = sanitize_text_field((string) $first[ $key ]);
                    break;
                }
            }
        }
        if ($ship_idx === '' && $master !== '' && !empty($create_request['index'])) {
            $ship_idx = sanitize_text_field((string) $create_request['index']);
        }
        if ($ship_idx === '') {
            $ship_idx = $master;
        }

        $id_idx = $master;
        if (!empty($start_output['shipmentIdIndex'])) {
            $id_idx = sanitize_text_field((string) $start_output['shipmentIdIndex']);
        } elseif (is_array($rows) && isset($rows[0]) && is_array($rows[0]) && !empty($rows[0]['shipmentIdIndex'])) {
            $id_idx = sanitize_text_field((string) $rows[0]['shipmentIdIndex']);
        }
        if ($id_idx === '') {
            $id_idx = $ship_idx;
        }

        return [
            'shipmentIndex'   => $ship_idx,
            'shipmentIdIndex' => $id_idx,
        ];
    }

    /**
     * Back-compat: primary open-shipment key (**`shipmentIndex`**) for order meta.
     *
     * @param array<string, mixed> $start_output
     */
    public function extract_shipment_id_index(array $start_output): string {
        $s = $this->extract_openship_session_from_create_output($start_output);

        return $s['shipmentIndex'];
    }

    /**
     * Normalize Open Ship /confirm JSON so persist_shipment_from_api_response can consume it.
     *
     * @param array<string, mixed> $decoded Full API JSON body.
     * @return array<string, mixed>
     * @since 1.3
     */
    public function normalize_confirm_body_for_persist(array $decoded): array {
        if (!empty($decoded['output']['transactionShipments'])) {
            return $decoded;
        }
        $out = $decoded['output'] ?? $decoded;
        if (!is_array($out)) {
            return ['output' => ['transactionShipments' => []]];
        }
        if (!empty($out['transactionShipments'])) {
            return ['output' => $out];
        }
        if (!empty($out['completedShipmentDetail'])) {
            $shipment_documents = [];
            if (!empty($out['shipmentDocuments']) && is_array($out['shipmentDocuments'])) {
                $shipment_documents = $out['shipmentDocuments'];
            } elseif (!empty($out['completedShipmentDetail']['shipmentDocuments']) && is_array($out['completedShipmentDetail']['shipmentDocuments'])) {
                $shipment_documents = $out['completedShipmentDetail']['shipmentDocuments'];
            }
            $piece_responses = [];
            if (!empty($out['pieceResponses']) && is_array($out['pieceResponses'])) {
                $piece_responses = $out['pieceResponses'];
            }
            return [
                'output' => [
                    'transactionShipments' => [
                        [
                            'masterTrackingNumber' => $out['masterTrackingNumber'] ?? ($out['completedShipmentDetail']['masterTrackingNumber'] ?? ''),
                            'serviceType'          => $out['serviceType'] ?? '',
                            'pieceResponses'       => $piece_responses !== [] ? $piece_responses : [
                                [
                                    'trackingNumber'     => $out['trackingNumber'] ?? '',
                                    'packageDocuments'   => $out['packageDocuments'] ?? [],
                                ],
                            ],
                            'shipmentDocuments'    => $shipment_documents,
                            'completedShipmentDetail' => $out['completedShipmentDetail'],
                        ],
                    ],
                ],
                'transactionId' => $decoded['transactionId'] ?? ($out['transactionId'] ?? ''),
            ];
        }
        return $decoded;
    }

    /**
     * @param \WC_Order|null $order                 Used for shipment **service type** (Ground vs Express) when truncating `extraCustomerReferences`; does not inject `ORDER_NUMBER`.
     * @param int            $package_sequence_1based Default `sequenceNumber` when not set in extras.
     */
    public function add_package(string $shipment_index, array $package, string $shipment_id_index = '', $order = null, int $package_sequence_1based = 0): array {
        $decoded = $this->add_or_modify_package_full($shipment_index, $package, $shipment_id_index, $order, $package_sequence_1based, false);

        return $decoded['output'] ?? [];
    }

    /**
     * Full FedEx JSON for Add Package (POST …/openshipments/packages) — includes `errors`, `transactionId`, `output`.
     *
     * @return array<string, mixed>
     */
    public function add_package_full(string $shipment_index, array $package, string $shipment_id_index = '', $order = null, int $package_sequence_1based = 0): array {
        return $this->add_or_modify_package_full($shipment_index, $package, $shipment_id_index, $order, $package_sequence_1based, false);
    }

    /**
     * Full FedEx JSON for Modify Package (PUT …/openshipments/packages).
     *
     * @return array<string, mixed>
     */
    public function put_modify_package_full(string $shipment_index, array $package, string $shipment_id_index = '', $order = null, int $package_sequence_1based = 0): array {
        return $this->add_or_modify_package_full($shipment_index, $package, $shipment_id_index, $order, $package_sequence_1based, true);
    }

    /**
     * @return array<string, mixed>
     */
    private function add_or_modify_package_full(
        string $shipment_index,
        array $package,
        string $shipment_id_index,
        $order,
        int $package_sequence_1based,
        bool $modify
    ): array {
        $shipment_index = sanitize_text_field($shipment_index);
        if ($shipment_index === '') {
            return [];
        }
        $shipment_id_index = sanitize_text_field($shipment_id_index);
        if ($shipment_id_index === '') {
            $shipment_id_index = $shipment_index;
        }

        $line_item = [
            'weight' => [
                'units' => strtoupper($package['weight_unit'] ?? 'LB') === 'KG' ? 'KG' : 'LB',
                'value' => (string) (float) ($package['weight'] ?? 1),
            ],
            'dimensions' => [
                'length' => (int) ($package['length'] ?? 10),
                'width'  => (int) ($package['width']  ?? 10),
                'height' => (int) ($package['height'] ?? 10),
                'units'  => strtoupper($package['dimension_unit'] ?? 'IN') === 'CM' ? 'CM' : 'IN',
            ],
        ];

        $decl_amt = isset($package['declared_value_amount']) ? (float) $package['declared_value_amount'] : 0.0;
        if ($decl_amt > 0) {
            $decl_cur = !empty($package['declared_value_currency'])
                ? strtoupper(sanitize_text_field((string) $package['declared_value_currency']))
                : ($order instanceof \WC_Order
                    ? strtoupper((string) ($order->get_currency() ?: 'USD'))
                    : 'USD');
            $line_item['declaredValue'] = [
                'amount'   => (string) $decl_amt,
                'currency' => $decl_cur,
            ];
        }

        $openship_service_type = '';
        if ($order instanceof \WC_Order) {
            $ov = Draft::get_shipment_overrides($order);
            $openship_service_type = isset($ov['serviceType']) ? (string) $ov['serviceType'] : '';
        }
        $line_item = $this->apply_openship_package_extras_to_line_item(
            $line_item,
            $package,
            $package_sequence_1based,
            $openship_service_type !== '' ? $openship_service_type : null,
            $order instanceof \WC_Order ? $order : null
        );
        $line_item = FedExMoneyUsd::normalize_requested_package_line_item(
            $line_item,
            $order instanceof \WC_Order ? $order : null,
            $package
        );

        /**
         * Single Open Ship add_package line item (FedEx RequestedPackageLineItem shape).
         *
         * @param array<string, mixed> $line_item
         * @param array<string, mixed> $package Raw package row from admin.
         */
        $line_item = apply_filters('fshipping_openship_package_line_item', $line_item, $package, $order);
        $line_item = self::ensure_group_package_count_for_customer_references($line_item);

        if ($modify) {
            $tid = isset($package['fedex_package_id']) ? sanitize_text_field((string) $package['fedex_package_id']) : '';
            if ($tid !== '') {
                $line_item['trackingIds'] = [
                    ['trackingNumber' => $tid],
                ];
            }
        }

        /**
         * Add Open Shipment Packages (FedEx Ship API): root **`index`** (string) = open-shipment key from
         * **Create** (e.g. `wc_order_{order_id}_…` — same as create request root `index`), **`shipmentIdIndex`** =
         * master **tracking** from **`transactionShipments[0]`**, plus `accountNumber` and package line(s).
         * Do **not** send **`shipmentIndex`** on this endpoint — use **`index`** for the session id.
         *
         * @see https://developer.fedex.com/api/en-us/catalog/open-ship/v1/docs.html
         */
        $payload = [
            'accountNumber'             => $this->openship_account_number_object(),
            'index'                     => $shipment_index,
            'shipmentIdIndex'           => $shipment_id_index,
            'requestedPackageLineItems' => [$line_item],
        ];
        /** @var array<string, mixed> $payload */
        $payload = apply_filters('fshipping_openship_add_package_payload', $payload, $shipment_index, $package, $shipment_id_index);
        if ($modify) {
            /** @var array<string, mixed> $payload */
            $payload = apply_filters('fshipping_openship_modify_package_payload', $payload, $shipment_index, $package, $shipment_id_index);
        }

        $path    = '/ship/v1/openshipments/packages';
        $decoded = $modify
            ? $this->request_with_index_retry_once('PUT', $path, $payload, (int) ($order instanceof \WC_Order ? $order->get_id() : 0))
            : $this->post($path, $payload);
        $this->log_openship_add_package(
            $shipment_index,
            $shipment_id_index,
            $payload,
            is_array($decoded) ? $decoded : [],
            $openship_service_type,
            $modify ? 'PUT' : 'POST'
        );

        return is_array($decoded) ? $decoded : [];
    }

    /**
     * PUT `/ship/v1/openshipments` — update session-level shipment (addresses, service, totals) for an existing index.
     *
     * @return array<string, mixed> Full FedEx JSON body.
     */
    public function put_update_open_shipment_from_order($order, string $shipment_index, string $shipment_id_index, int $package_row_count = 1): array {
        $shipment_index = sanitize_text_field($shipment_index);
        $shipment_id_index = sanitize_text_field($shipment_id_index);
        if ($shipment_index === '' || !($order instanceof \WC_Order)) {
            return [];
        }
        if ($shipment_id_index === '') {
            $shipment_id_index = $shipment_index;
        }
        $line = Draft::get_fedex_shipping_line($order);
        if (null === $line) {
            return [];
        }
        $built = $this->build_openship_requested_shipment_from_order($order, $line);
        if (empty($built['rs_clean'])) {
            return [];
        }
        $rs = $built['rs_clean'];
        $rs['totalPackageCount'] = max(1, $package_row_count);
        $rs = $this->align_customs_values_with_declared_package_values($rs, $order);

        $payload = [
            'accountNumber'     => $this->openship_account_number_object(),
            'index'             => $shipment_index,
            'shipmentIdIndex'   => $shipment_id_index,
            'requestedShipment' => $rs,
        ];
        /** @var array<string, mixed> $payload */
        $payload = apply_filters('fshipping_openship_put_update_payload', $payload, $order, $shipment_index, $shipment_id_index);

        $decoded = $this->request_with_index_retry_once(
            'PUT',
            '/ship/v1/openshipments',
            $payload,
            (int) $order->get_id()
        );
        $url = $this->openship_absolute_url('/ship/v1/openshipments');
        $force = self::should_force_openship_error_diagnostic_log(is_array($decoded) ? $decoded : []);
        self::debug_log_push_json_blocks(
            'openshipments (PUT update) index=' . $shipment_index,
            [
                'FedEx REST URL'       => $url,
                'API (requested)'      => self::format_openship_debug_api_line('PUT', $url),
                'request (JSON body)'  => $payload,
                'response (full body)' => is_array($decoded) ? $decoded : [],
            ],
            $force
        );

        return is_array($decoded) ? $decoded : [];
    }

    /**
     * Prevent Open Ship confirm validation errors where package declared totals exceed customs value.
     *
     * FedEx validates carriage/declared values against customs values at confirm time. In Advanced mode,
     * admin box rows can carry declared values larger than the stale checkout customs value snapshot.
     * This aligns session-level customs totals (and commodity customs breakdown) before PUT update.
     *
     * @param array<string, mixed> $requested_shipment
     * @param \WC_Order            $order
     * @return array<string, mixed>
     */
    private function align_customs_values_with_declared_package_values(array $requested_shipment, \WC_Order $order): array {
        $packages = Draft::get_packages($order);
        if ($packages === []) {
            return $requested_shipment;
        }

        $declared_sum = 0.0;
        $currency     = '';
        foreach ($packages as $pkg) {
            if (!is_array($pkg)) {
                continue;
            }
            $amount = isset($pkg['declared_value_amount']) ? (float) $pkg['declared_value_amount'] : 0.0;
            if ($amount <= 0) {
                continue;
            }
            $declared_sum += $amount;
            if ($currency === '' && !empty($pkg['declared_value_currency'])) {
                $currency = strtoupper(sanitize_text_field((string) $pkg['declared_value_currency']));
            }
        }
        if ($declared_sum <= 0) {
            return $requested_shipment;
        }

        $customs = isset($requested_shipment['customsClearanceDetail']) && is_array($requested_shipment['customsClearanceDetail'])
            ? $requested_shipment['customsClearanceDetail']
            : [];
        $current_total = isset($customs['totalCustomsValue']) && is_array($customs['totalCustomsValue'])
            ? $customs['totalCustomsValue']
            : [];
        $current_amount = isset($current_total['amount']) && is_numeric($current_total['amount']) ? (float) $current_total['amount'] : 0.0;
        if ($currency === '' && !empty($current_total['currency'])) {
            $currency = strtoupper(sanitize_text_field((string) $current_total['currency']));
        }
        if ($currency === '') {
            $currency = strtoupper((string) ($order->get_currency() ?: 'USD'));
        }

        // Keep customs >= package declared total; never lower a higher valid customs figure.
        $aligned_total = round(max($current_amount, $declared_sum), 2);
        $customs['totalCustomsValue'] = [
            'amount'   => $aligned_total,
            'currency' => $currency,
        ];

        if (!empty($customs['commodities']) && is_array($customs['commodities'])) {
            $customs['commodities'] = $this->align_commodity_customs_values($customs['commodities'], $aligned_total, $currency);
        }

        $requested_shipment['customsClearanceDetail'] = $customs;
        return $requested_shipment;
    }

    /**
     * Distribute aligned customs total across commodities to keep totals internally consistent.
     *
     * @param array<int, mixed> $commodities
     * @param float             $total_amount
     * @param string            $currency
     * @return array<int, mixed>
     */
    private function align_commodity_customs_values(array $commodities, float $total_amount, string $currency): array {
        $rows = [];
        $total_qty = 0.0;
        foreach ($commodities as $row) {
            if (!is_array($row)) {
                $rows[] = $row;
                continue;
            }
            $qty = isset($row['quantity']) && is_numeric($row['quantity']) ? (float) $row['quantity'] : 1.0;
            if ($qty <= 0) {
                $qty = 1.0;
            }
            $row['_tmp_qty'] = $qty;
            $total_qty += $qty;
            $rows[] = $row;
        }
        if ($total_qty <= 0) {
            return $commodities;
        }

        $assigned = 0.0;
        $last_idx = -1;
        foreach ($rows as $idx => $row) {
            if (is_array($row)) {
                $last_idx = $idx;
            }
        }
        if ($last_idx < 0) {
            return $commodities;
        }

        foreach ($rows as $idx => $row) {
            if (!is_array($row)) {
                continue;
            }
            $qty = isset($row['_tmp_qty']) ? (float) $row['_tmp_qty'] : 1.0;
            unset($row['_tmp_qty']);

            $row_amount = $idx === $last_idx
                ? round(max(0.0, $total_amount - $assigned), 2)
                : round(($total_amount * $qty) / $total_qty, 2);
            $assigned += $row_amount;

            $row['customsValue'] = [
                'amount'   => $row_amount,
                'currency' => $currency,
            ];
            if ($qty > 0) {
                $row['unitPrice'] = [
                    'amount'   => round($row_amount / $qty, 2),
                    'currency' => $currency,
                ];
            }
            $rows[$idx] = $row;
        }

        return $rows;
    }

    /**
     * Retry once when FedEx returns SHIPMENT.INDEX.REQUIRED (re-read order index meta before retry).
     *
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function request_with_index_retry_once(string $method, string $path, array $payload, int $order_id): array {
        $decoded = $this->request($method, $path, $payload);
        if (!is_array($decoded)) {
            $decoded = [];
        }
        if (!self::response_has_fedex_error_code($decoded, 'SHIPMENT.INDEX.REQUIRED')) {
            return $decoded;
        }
        if ($order_id < 1) {
            return $decoded;
        }
        $order = wc_get_order($order_id);
        if (!$order) {
            return $decoded;
        }
        $session = Draft::get_openship_session_for_fedex($order);
        if ($session['shipmentIndex'] === '') {
            return $decoded;
        }
        $payload['index'] = $session['shipmentIndex'];
        if (isset($payload['shipmentIdIndex'])) {
            $payload['shipmentIdIndex'] = $session['shipmentIdIndex'];
        }
        self::debug_log_push_message(
            '[teamzlab-fedex Open Ship] ' . $method . ' ' . $path . ': FedEx returned SHIPMENT.INDEX.REQUIRED; retrying once with index from order meta.',
            true
        );

        $decoded2 = $this->request($method, $path, $payload);

        return is_array($decoded2) ? $decoded2 : [];
    }

    /**
     * Transaction id and package rows from FedEx `output` (shapes vary by endpoint).
     *
     * @param array<string, mixed> $decoded Full FedEx body.
     * @return array{transaction_id: string, packages: array<int, array{trackingNumber: string, sequenceNumber: string}>}
     */
    public static function extract_transaction_and_packages_from_response(array $decoded): array {
        $out = $decoded['output'] ?? [];
        if (!is_array($out)) {
            $out = [];
        }
        $tid = '';
        if (!empty($out['transactionId'])) {
            $tid = (string) $out['transactionId'];
        } elseif (!empty($decoded['transactionId'])) {
            $tid = (string) $decoded['transactionId'];
        }
        $pkgs = [];
        if (!empty($out['packages']) && is_array($out['packages'])) {
            foreach ($out['packages'] as $p) {
                if (!is_array($p)) {
                    continue;
                }
                $pkgs[] = [
                    'trackingNumber' => isset($p['trackingNumber']) ? (string) $p['trackingNumber'] : '',
                    'sequenceNumber' => isset($p['sequenceNumber'])
                        ? (string) $p['sequenceNumber']
                        : (isset($p['packageSequenceNumber']) ? (string) $p['packageSequenceNumber'] : ''),
                ];
            }
        }

        return [
            'transaction_id' => $tid,
            'packages'       => $pkgs,
        ];
    }

    /**
     * First human-readable FedEx error message from a decoded body.
     *
     * @param array<string, mixed> $decoded
     */
    public static function first_fedex_error_message(array $decoded): string {
        if (empty($decoded['errors']) || !is_array($decoded['errors'])) {
            return '';
        }
        $err = reset($decoded['errors']);
        if (!is_array($err)) {
            return '';
        }
        $msg = isset($err['message']) ? (string) $err['message'] : '';
        if ($msg === '' && !empty($err['errorDetail']) && is_array($err['errorDetail']) && !empty($err['errorDetail']['message'])) {
            $msg = (string) $err['errorDetail']['message'];
        }

        return $msg;
    }

    /**
     * Whether a FedEx error message indicates the **PUT modify** call used a piece tracking id FedEx does not accept
     * (stale id, session master/index mistaken for piece id, etc.) — safe to retry as **POST add** after clearing ids.
     */
    public static function is_likely_invalid_piece_tracking_for_modify(string $message): bool {
        if ($message === '') {
            return false;
        }
        $m = strtolower($message);

        return strpos($m, 'package tracking number') !== false && strpos($m, 'verify') !== false;
    }

    /**
     * FedEx documents that **`groupPackageCount` must be specified** on the line item to **retrieve** (echo)
     * `customerReferences` in some responses. When references are present and the line has no group count yet,
     * send **`1`** (single piece) so behavior matches single-package adds and responses can include references.
     *
     * @param array<string, mixed> $line_item
     * @return array<string, mixed>
     */
    private static function ensure_group_package_count_for_customer_references(array $line_item): array {
        if (empty($line_item['customerReferences']) || ! is_array($line_item['customerReferences'])) {
            return $line_item;
        }
        if (array_key_exists('groupPackageCount', $line_item)) {
            return $line_item;
        }
        $line_item['groupPackageCount'] = 1;

        return $line_item;
    }

    /**
     * Merge optional `package_line_extras` into FedEx RequestedPackageLineItem (`customerReferences` only from `extraCustomerReferences`).
     *
     * @param array<string, mixed> $line_item
     * @param array<string, mixed> $package
     * @param string|null            $service_type Open Ship session service (Ground vs Express for `CUSTOMER_REFERENCE` length).
     * @return array<string, mixed>
     */
    private function apply_openship_package_extras_to_line_item(
        array $line_item,
        array $package,
        int $package_sequence_1based,
        ?string $service_type = null,
        ?\WC_Order $order = null
    ): array {
        $refs = [];
        $extras = isset($package['package_line_extras']) && is_array($package['package_line_extras'])
            ? $package['package_line_extras'] : [];
        if (!empty($extras['extraCustomerReferences']) && is_array($extras['extraCustomerReferences'])) {
            foreach ($extras['extraCustomerReferences'] as $row) {
                if (!is_array($row) || empty($row['customerReferenceType'])) {
                    continue;
                }
                $t = strtoupper((string) $row['customerReferenceType']);
                $v = isset($row['value']) ? (string) $row['value'] : '';
                if ($v === '' || ! in_array($t, PackageLineExtras::CUSTOMER_REFERENCE_TYPES, true)) {
                    continue;
                }
                $refs[] = [
                    'customerReferenceType' => $t,
                    'value'                 => PackageLineExtras::truncate_customer_reference_value($t, $v, $service_type),
                ];
            }
        }
        if ($refs !== []) {
            $line_item['customerReferences'] = $refs;
        }

        if (!empty($extras['sequenceNumber'])) {
            $line_item['sequenceNumber'] = (string) $extras['sequenceNumber'];
        } elseif ($package_sequence_1based > 0) {
            $line_item['sequenceNumber'] = (string) $package_sequence_1based;
        }

        foreach (
            [
                'subPackagingType',
                'itemDescriptionForClearance',
                'itemDescription',
            ] as $strKey
        ) {
            if (!empty($extras[ $strKey ])) {
                $line_item[ $strKey ] = $extras[ $strKey ];
            }
        }
        if (!empty($extras['groupPackageCount'])) {
            $line_item['groupPackageCount'] = (int) $extras['groupPackageCount'];
        }
        if (!empty($extras['contentRecord']) && is_array($extras['contentRecord'])) {
            $line_item['contentRecord'] = $extras['contentRecord'];
        }
        if (!empty($extras['variableHandlingChargeDetail']) && is_array($extras['variableHandlingChargeDetail'])) {
            $line_item['variableHandlingChargeDetail'] = $extras['variableHandlingChargeDetail'];
        }
        if (!empty($extras['packageSpecialServices']) && is_array($extras['packageSpecialServices'])) {
            $pss = $extras['packageSpecialServices'];
            if ($service_type !== null && $service_type !== '') {
                $service_type = strtoupper(trim($service_type));
                $dest_country = '';
                if (!empty($package['destinationCountryCode']) && is_string($package['destinationCountryCode'])) {
                    $dest_country = strtoupper(trim($package['destinationCountryCode']));
                }
                if ($dest_country === '' && !empty($package['destination_country']) && is_string($package['destination_country'])) {
                    $dest_country = strtoupper(trim($package['destination_country']));
                }
                if ($dest_country === '' && $order instanceof \WC_Order) {
                    $dest_country = $this->openship_destination_country_from_order($order);
                }
                $sts = isset($pss['specialServiceTypes']) && is_array($pss['specialServiceTypes'])
                    ? $pss['specialServiceTypes']
                    : [];
                $has_cod = in_array('COD', $sts, true);
                $cod_supported = $this->canUseCOD($service_type, $dest_country);
                $legacy_allow = apply_filters(
                    'fshipping_openship_allow_cod_for_service_type',
                    $cod_supported,
                    $service_type,
                    $pss,
                    $package
                );
                if (is_bool($legacy_allow)) {
                    $cod_supported = $legacy_allow;
                }
                if ($has_cod && !$cod_supported) {
                    // FedEx rejects COD on many non-ground services at confirm time.
                    $pss['specialServiceTypes'] = array_values(array_filter($sts, static function ($code) {
                        return strtoupper((string) $code) !== 'COD';
                    }));
                    if (isset($pss['packageCODDetail'])) {
                        unset($pss['packageCODDetail']);
                    }
                    self::debug_log_push_message(
                        '[teamzlab-fedex Open Ship] add_package: removed COD from packageSpecialServices for serviceType='
                        . $service_type . ' destinationCountry=' . ($dest_country !== '' ? $dest_country : '—')
                        . ' (non-COD-eligible combination).',
                        true
                    );
                    if (empty($pss['specialServiceTypes'])) {
                        unset($pss['specialServiceTypes']);
                    }
                }
            }
            if ($pss !== []) {
                $line_item['packageSpecialServices'] = $pss;
            }
        }

        return $line_item;
    }

    /**
     * FedEx Open Ship COD capability check by service + destination country.
     *
     * Known non-COD examples: INTERNATIONAL_PRIORITY, INTERNATIONAL_ECONOMY, FIRST_OVERNIGHT.
     * Defaults to US domestic + ground-like services only; filter can expand or narrow this.
     */
    private function canUseCOD(string $serviceType, string $destinationCountry): bool {
        $service = strtoupper(trim($serviceType));
        $country = strtoupper(trim($destinationCountry));
        if ($service === '') {
            return false;
        }
        if ($country === '') {
            $country = 'US';
        }

        $known_non_cod_services = [
            'INTERNATIONAL_PRIORITY',
            'INTERNATIONAL_ECONOMY',
            'INTERNATIONAL_FIRST',
            'FEDEX_INTERNATIONAL_PRIORITY',
            'FEDEX_INTERNATIONAL_ECONOMY',
            'FEDEX_INTERNATIONAL_PRIORITY_EXPRESS',
            'FEDEX_INTERNATIONAL_CONNECT_PLUS',
            'FIRST_OVERNIGHT',
            'PRIORITY_OVERNIGHT',
            'STANDARD_OVERNIGHT',
            'FEDEX_2_DAY_AM',
            'EUROPE_FIRST_INTERNATIONAL_PRIORITY',
        ];
        if (in_array($service, $known_non_cod_services, true)) {
            return false;
        }

        $base_allow = PackageLineExtras::is_ground_like_service_type($service) && $country === 'US';

        $filtered = apply_filters(
            'fshipping_openship_can_use_cod',
            $base_allow,
            $service,
            $country
        );
        if (is_bool($filtered)) {
            return $filtered;
        }

        return $base_allow;
    }

    /**
     * Destination country for Open Ship package checks.
     */
    private function openship_destination_country_from_order(\WC_Order $order): string {
        $country = '';
        if (method_exists($order, 'get_shipping_country')) {
            $country = strtoupper(trim((string) $order->get_shipping_country()));
        }
        if ($country === '' && method_exists($order, 'get_billing_country')) {
            $country = strtoupper(trim((string) $order->get_billing_country()));
        }

        return $country;
    }

    /**
     * Log Add Package request/response to PHP error log (typically wp-content/debug.log when WP_DEBUG_LOG is on).
     *
     * Enable with `WP_DEBUG` + `WP_DEBUG_LOG`, or `FSHIPPING_OPENSHIP_LOG_PUSH` in wp-config.php.
     * Filter: `fshipping_openship_debug_log_push`.
     *
     * @param array<string, mixed> $payload  Body sent to FedEx.
     * @param array<string, mixed> $decoded Full JSON response body from FedEx (includes output/errors).
     * @param string                 $openship_service_type From order shipment overrides (debug context).
     */
    private function log_openship_add_package(string $shipment_index, string $shipment_id_index, array $payload, array $decoded, string $openship_service_type = '', string $http_method = 'POST'): void {
        $force = self::should_force_openship_error_diagnostic_log($decoded);
        if (!$force && !self::should_log_openship_push_debug()) {
            return;
        }
        $line = isset($payload['requestedPackageLineItems'][0]) && is_array($payload['requestedPackageLineItems'][0])
            ? $payload['requestedPackageLineItems'][0]
            : [];
        $refs = isset($line['customerReferences']) && is_array($line['customerReferences']) ? $line['customerReferences'] : [];
        $ref_debug = [
            'order_serviceType'   => $openship_service_type !== '' ? $openship_service_type : null,
            'ground_like'         => $openship_service_type !== '' && PackageLineExtras::is_ground_like_service_type($openship_service_type),
            'groupPackageCount'   => $line['groupPackageCount'] ?? null,
            'customerReferences'  => $refs,
            'reference_value_max' => [
                'CUSTOMER_REFERENCE' => PackageLineExtras::customer_reference_value_max_length(
                    'CUSTOMER_REFERENCE',
                    $openship_service_type !== '' ? $openship_service_type : null
                ),
            ],
        ];
        $packages_url = $this->openship_absolute_url('/ship/v1/openshipments/packages');
        $method       = strtoupper($http_method) === 'PUT' ? 'PUT' : 'POST';
        $label        = $method === 'PUT'
            ? 'openshipments/packages (modify_package) index=' . $shipment_index . ' shipmentIdIndex=' . $shipment_id_index
            : 'openshipments/packages (add_package) index=' . $shipment_index . ' shipmentIdIndex=' . $shipment_id_index;
        self::debug_log_push_json_blocks(
            $label,
            [
                'FedEx REST URL'       => $packages_url,
                'API (requested)'      => self::format_openship_debug_api_line($method, $packages_url),
                'customerReferences (debug)' => $ref_debug,
                'request (JSON body)'  => $payload,
                'response (full body)' => $decoded,
            ],
            $force
        );
    }

    /**
     * When FedEx returns an `errors` array, always write diagnostics (unless filtered off) so
     * `wp-content/debug.log` gets request/response even if `WP_DEBUG_LOG` is off.
     *
     * @param array<string, mixed> $decoded Full FedEx JSON body.
     */
    private static function should_force_openship_error_diagnostic_log(array $decoded): bool {
        if (empty($decoded['errors']) || !is_array($decoded['errors'])) {
            return false;
        }
        return (bool) apply_filters('fshipping_openship_force_log_on_fedex_errors', true, $decoded);
    }

    /**
     * Write multiline Open Ship log output to PHP error_log or `wp-content/debug.log`.
     *
     * @param bool $force_error_diag When true, append to `WP_CONTENT_DIR/debug.log` even without `WP_DEBUG` / `FSHIPPING_OPENSHIP_LOG_PUSH`.
     */
    private static function emit_openship_log_output(string $out, bool $force_error_diag): void {
        unset($out, $force_error_diag);
    }

    /**
     * Append a titled block with pretty-printed JSON sections to debug.log.
     *
     * @param array<string, array<string, mixed>|string> $sections Label => array (encoded as JSON) or raw string.
     * @param bool                                         $force_when_fedex_error If true, skip {@see should_log_openship_push_debug()} (FedEx returned `errors`).
     */
    public static function debug_log_push_json_blocks(string $batch_title, array $sections, bool $force_when_fedex_error = false): void {
        unset($batch_title, $sections, $force_when_fedex_error);
    }

    /**
     * Legacy one-line notifier (writes disabled — see HTTP\Shipping for checkout Rates WC log teamzlab_fedex_shippnig).
     *
     * @param string $message Full line (no trailing newline).
     * @param bool   $force   Retained for signature compatibility.
     */
    public static function debug_log_push_message(string $message, bool $force = false): void {
        unset($message, $force);
    }

    /**
     * @return bool
     */
    public static function should_log_openship_push_debug(): bool {
        if (defined('FSHIPPING_OPENSHIP_LOG_PUSH') && FSHIPPING_OPENSHIP_LOG_PUSH) {
            return (bool) apply_filters('fshipping_openship_debug_log_push', true);
        }
        $default = defined('WP_DEBUG') && WP_DEBUG && defined('WP_DEBUG_LOG') && WP_DEBUG_LOG;
        return (bool) apply_filters('fshipping_openship_debug_log_push', $default);
    }

    public function confirm(string $shipment_index, string $shipment_id_index = '', $order = null): array {
        $full = $this->confirm_full($shipment_index, $shipment_id_index, $order);
        return $full['output'] ?? [];
    }

    /**
     * Full JSON body from Open Ship confirm (for label extraction).
     *
     * Confirm request shape used here:
     * - `accountNumber`
     * - `index` (Open Ship session index)
     * - `labelResponseOptions`
     * - `labelSpecification` (`labelStockType` + `imageType`, from labeling settings)
     *
     * @param string      $shipment_index
     * @param string      $shipment_id_index Legacy id; confirm body uses root `index` only.
     * @param \WC_Order|null $order When set, merges `shippingDocumentSpecification` (and optional
     *                              `documentRequirements`) from the same processed Ship payload as checkout
     *                              so FedEx returns commercial invoice / trade forms that Open Ship start strips.
     * @return array<string, mixed>
     * @since 1.3
     */
    public function confirm_full(string $shipment_index, string $shipment_id_index = '', $order = null): array {
        $shipment_index = sanitize_text_field($shipment_index);
        if ($shipment_index === '') {
            return [];
        }

        $payload = [
            'accountNumber'        => $this->openship_account_number_object(),
            'index'                => $shipment_index,
            'labelResponseOptions' => (string) apply_filters(
                'fshipping_openship_confirm_label_response_options',
                'URL_ONLY',
                $shipment_index,
                $shipment_id_index
            ),
            'labelSpecification'   => $this->openship_confirm_label_specification_from_settings(),
        ];

        if (is_object($order) && method_exists($order, 'get_id')
            && apply_filters('fshipping_openship_confirm_merge_ship_document_spec', true, $order, $shipment_index, $shipment_id_index)) {
            $processed = Shipment::instance()->build_processed_ship_payload_for_order($order);
            $rs        = isset($processed['requestedShipment']) && is_array($processed['requestedShipment'])
                ? $processed['requestedShipment']
                : [];
            if (!empty($rs['shippingDocumentSpecification']) && is_array($rs['shippingDocumentSpecification'])) {
                $payload['shippingDocumentSpecification'] = $rs['shippingDocumentSpecification'];
            }
            if (!empty($rs['documentRequirements']) && is_array($rs['documentRequirements'])) {
                $payload['documentRequirements'] = $rs['documentRequirements'];
            }
        }

        /** @var array<string, mixed> $payload */
        $payload = apply_filters('fshipping_openship_confirm_payload', $payload, $shipment_index, $shipment_id_index, $order);

        $decoded = $this->post('/ship/v1/openshipments/', $payload);
        if (!is_array($decoded)) {
            $decoded = [];
        }

        $confirm_url = $this->openship_absolute_url('/ship/v1/openshipments/');
        $title       = 'openshipments (confirm) index=' . $shipment_index;
        $force_error_log = self::should_force_openship_error_diagnostic_log($decoded);
        $force_confirm_log = (bool) apply_filters(
            'fshipping_openship_log_confirm_request_response',
            true,
            $shipment_index,
            $shipment_id_index,
            $payload,
            $decoded
        );
        self::debug_log_push_json_blocks(
            $title,
            [
                'FedEx REST URL'       => $confirm_url,
                'API (requested)'      => self::format_openship_debug_api_line('POST', $confirm_url),
                'request (JSON body)'  => $payload,
                'response (full body)' => $decoded,
            ],
            $force_error_log || $force_confirm_log
        );

        return $decoded;
    }

    /**
     * Delete an entire Open Ship session on FedEx (whole shipment index), before confirm.
     *
     * Request body: `accountNumber` + root **`index`** (Open Ship session key from create — same value
     * as stored in `_fshipping_openship_shipment_index`). FedEx expects **PUT** (not POST).
     * Filter `fshipping_openship_delete_payload` can adjust the payload if your FedEx
     * project uses alternate field names (verify in the Developer Portal).
     *
     * @param string $shipment_index Session id from /start (same as create root **`index`**).
     * @param int    $context_order_id Optional WooCommerce order id for `debug.log` titles (bulk delete).
     * @param bool   $force_audit_log When true, always write URL/payload/response to `debug.log` (same path as
     *                                 forced FedEx-error diagnostics), e.g. bulk **Delete permanently** so each
     *                                 selected order’s FedEx PUT is auditable without `WP_DEBUG_LOG`.
     * @return array<string, mixed> Full JSON body; `[]` on failure or empty decode.
     * @since 1.4
     */
    public function delete_open_shipment(string $shipment_index, int $context_order_id = 0, bool $force_audit_log = false): array {
        $shipment_index = sanitize_text_field($shipment_index);
        if ($shipment_index === '') {
            return [];
        }
        $context_order_id = max(0, $context_order_id);
        $payload = [
            'accountNumber' => $this->openship_account_number_object(),
            'index'         => $shipment_index,
        ];
        /** @var array<string, mixed> $payload */
        $payload = apply_filters('fshipping_openship_delete_payload', $payload, $shipment_index);
        $decoded = $this->request('PUT', '/ship/v1/openshipments/delete', $payload);
        if (!is_array($decoded)) {
            $decoded = [];
        }

        $delete_url = $this->openship_absolute_url('/ship/v1/openshipments/delete');
        $title      = 'openshipments/delete index=' . $shipment_index;
        if ($context_order_id > 0) {
            $title .= ' (order_id=' . $context_order_id . ')';
        }
        if ($force_audit_log) {
            $title .= ' (bulk_audit)';
        }
        $force_error_log = self::should_force_openship_error_diagnostic_log($decoded);
        $force_delete_log = (bool) apply_filters(
            'fshipping_openship_log_delete_request_response',
            self::should_log_openship_push_debug(),
            $shipment_index,
            $payload,
            $decoded,
            $context_order_id,
            $force_audit_log
        );
        $sections = [
            'FedEx REST URL'       => $delete_url,
            'API (requested)'      => self::format_openship_debug_api_line('PUT', $delete_url),
            'request (JSON body)'  => $payload,
            'response (full body)' => $decoded,
        ];
        if ($context_order_id > 0) {
            $sections['WooCommerce order_id'] = (string) $context_order_id;
        }
        $write_log = $force_error_log || $force_delete_log || $force_audit_log;
        self::debug_log_push_json_blocks(
            $title,
            $sections,
            $write_log
        );

        return $decoded;
    }

    /**
     * Bulk **Delete permanently** audit: order has no FedEx Open Ship session, so **PUT …/openshipments/delete**
     * is **not** called — there is no remote session to remove. WooCommerce still permanently deletes the order
     * after {@see Draft::cancel_fedex_open_shipment_and_clear()} returns success.
     *
     * Writes the same **`debug.log`** section layout as {@see delete_open_shipment()} so you get one block per
     * selected row (clear request/response-shaped JSON even when FedEx was not hit).
     *
     * @param int $order_id WooCommerce order id.
     * @return void
     */
    public function log_bulk_audit_openship_delete_not_applicable(int $order_id): void {
        $order_id = max(0, $order_id);
        if ($order_id < 1) {
            return;
        }
        $delete_url = $this->openship_absolute_url('/ship/v1/openshipments/delete');
        $title      = 'openshipments/delete (bulk_audit) order_id=' . $order_id . ' — FedEx PUT not sent (no session index on this order)';
        $payload    = [
            'fedex_delete_invoked' => false,
            'reason'               => 'no_stored_openship_session_index',
            'would_be_endpoint'    => $delete_url,
            'note'                 => 'Meta _fshipping_openship_shipment_index is empty. FedEx has no Open Ship session to delete for this order. WooCommerce permanent delete still runs for this row when bulk delete completes.',
        ];
        $response = [
            'fedex_http_invoked'     => false,
            'fedex_delete_result'    => 'not_applicable_no_remote_session',
            'woocommerce_order_id'   => $order_id,
            'woocommerce_next_step'  => 'WC_Order::delete( true ) runs after this cancel step if cancel returned ok.',
        ];
        self::debug_log_push_json_blocks(
            $title,
            [
                'FedEx REST URL'       => $delete_url . "\n(not invoked — no `_fshipping_openship_shipment_index` on order)",
                'API (requested)'      => self::format_openship_debug_api_line('PUT', $delete_url) . "\n(HTTP request not sent)",
                'request (JSON body)'  => $payload,
                'response (full body)' => $response,
                'WooCommerce order_id'   => (string) $order_id,
            ],
            true
        );
    }

    /**
     * Delete one package from an Open Ship session (before confirm) using
     * **PUT `/ship/v1/openshipments/packages/delete`** with `trackingIds`.
     *
     * @param string $shipment_index Open Ship session index (payload `index`).
     * @param string $package_id     Piece tracking number to remove (`trackingIds[0].trackingNumber`).
     * @param string $shipment_id_index Back-compat arg; currently unused by FedEx delete payload.
     */
    public function delete_package(string $shipment_index, string $package_id, string $shipment_id_index = ''): bool {
        $shipment_index = sanitize_text_field($shipment_index);
        $package_id     = sanitize_text_field($package_id);
        if (empty($shipment_index) || empty($package_id)) {
            return false;
        }
        // Keep legacy hook name for compatibility; now maps to tracking number in payload, not path id.
        $package_id = (string) apply_filters(
            'fshipping_openship_delete_package_path_id',
            $package_id,
            $shipment_index,
            sanitize_text_field($shipment_id_index)
        );
        $tracking_id = $this->build_openship_delete_tracking_id($package_id);
        if ($tracking_id === []) {
            return false;
        }
        $payload = [
            'index'         => $shipment_index,
            'trackingIds'   => [$tracking_id],
            'accountNumber' => $this->openship_account_number_object(),
        ];
        $decoded = $this->request('PUT', '/ship/v1/openshipments/packages/delete', $payload);
        if (!is_array($decoded)) {
            return false;
        }

        return empty($decoded['errors']);
    }

    /**
     * Same as {@see delete_package()} but returns decoded JSON (and logs failures to debug.log).
     *
     * @return array<string, mixed>
     */
    public function delete_package_with_response(string $shipment_index, string $package_id, string $shipment_id_index = ''): array {
        $shipment_index = sanitize_text_field($shipment_index);
        $package_id     = sanitize_text_field($package_id);
        if ($shipment_index === '' || $package_id === '') {
            return ['errors' => [['code' => 'TEAMZ.MISSING.INDEX', 'message' => 'Missing shipment index or package id.']]];
        }
        $package_id = (string) apply_filters(
            'fshipping_openship_delete_package_path_id',
            $package_id,
            $shipment_index,
            sanitize_text_field($shipment_id_index)
        );
        $tracking_id = $this->build_openship_delete_tracking_id($package_id);
        if ($tracking_id === []) {
            return ['errors' => [['code' => 'TEAMZ.MISSING.TRACKING', 'message' => 'Missing package tracking number for delete.']]];
        }
        $payload = [
            'index'         => $shipment_index,
            'trackingIds'   => [$tracking_id],
            'accountNumber' => $this->openship_account_number_object(),
        ];
        $url = $this->openship_absolute_url('/ship/v1/openshipments/packages/delete');
        $decoded = $this->request('PUT', '/ship/v1/openshipments/packages/delete', $payload);
        if (!is_array($decoded)) {
            $decoded = ['errors' => [['code' => 'TEAMZ.HTTP', 'message' => 'Delete package request failed.']]];
        }
        $force = self::should_force_openship_error_diagnostic_log($decoded);
        self::debug_log_push_json_blocks(
            'openshipments/packages/delete (delete_package) index=' . $shipment_index . ' tracking_number=' . $package_id,
            [
                'FedEx REST URL'       => $url,
                'API (requested)'      => self::format_openship_debug_api_line('PUT', $url),
                'request (JSON body)'  => $payload,
                'response (full body)' => $decoded,
            ],
            $force
        );

        return $decoded;
    }

    /**
     * Build one FedEx `trackingIds[]` entry for Open Ship package delete payload.
     *
     * @return array<string, string>
     */
    private function build_openship_delete_tracking_id(string $tracking_number): array {
        $tracking_number = sanitize_text_field(trim($tracking_number));
        if ($tracking_number === '') {
            return [];
        }

        $tracking_id = [
            'trackingIdType' => 'FEDEX',
            'formId'         => '0263',
            'trackingNumber' => $tracking_number,
        ];

        /** @var array<string, string> $tracking_id */
        $tracking_id = apply_filters('fshipping_openship_delete_tracking_id_payload', $tracking_id, $tracking_number);

        return $tracking_id;
    }

    public function start_async(array $args): array {
        $payload = $this->prepare_start_payload($args);
        $payload = $this->ensure_openship_create_payload_has_root_index($payload, $args);
        if (!$this->openship_create_root_index_is_valid($payload)) {
            return [];
        }
        $payload['requestedShipment']['processingOptionType'] = 'ALLOW_ASYNCHRONOUS';
        $decoded = $this->post('/ship/v1/openshipments/async/start', $payload);
        return $decoded['output'] ?? [];
    }

    public function retrieve_async_status(string $job_id): array {
        $job_id = sanitize_text_field($job_id);
        if (empty($job_id)) {
            return [];
        }
        $decoded = $this->get('/ship/v1/openshipments/async/results/' . rawurlencode($job_id));
        return $decoded['output'] ?? [];
    }

    private function prepare_start_payload(array $args): array {
        $settings = get_option('fshipping_options');
        if (!empty($args['account_number_override'])) {
            $acc = sanitize_text_field((string) $args['account_number_override']);
        } else {
            $acc = sanitize_text_field($settings['fshipping_acc_number'] ?? '');
        }
        /** @var string $acc */
        $acc = (string) apply_filters('fshipping_openship_start_account_number', $acc, $args);

        $requested = $args['requested_shipment'] ?? [];
        $defaults  = [
            'pickupType'        => sanitize_text_field($settings['fshipping_labeling_pickup_type'] ?? 'USE_SCHEDULED_PICKUP'),
            'serviceType'       => sanitize_text_field($args['service_type'] ?? 'FEDEX_GROUND'),
            'packagingType'     => sanitize_text_field($settings['fshipping_labeling_packaging_type'] ?? 'YOUR_PACKAGING'),
            'totalPackageCount' => (int) ($args['total_package_count'] ?? 1),
        ];
        $requested = array_merge($defaults, $requested);
        $requested = $this->sync_account_number_in_requested_shipment($requested, $acc);

        /**
         * FedEx Ship API — `openShipmentAction` enum (string): STRONG_VALIDATION | WEAK_VALIDATION | CREATE_PACKAGE |
         * PROVIDE_DOCUMENTS_INCREMENTALLY. Standard Open Ship create flow uses **CREATE_PACKAGE**.
         */
        $payload = [
            'accountNumber'      => ['value' => $acc],
            'openShipmentAction' => (string) apply_filters('fshipping_openship_start_open_shipment_action', 'CREATE_PACKAGE', $args),
            'requestedShipment'  => $requested,
        ];

        $default_idx = '';
        if (!empty($args['openship_index']) && is_string($args['openship_index'])) {
            $default_idx = sanitize_text_field($args['openship_index']);
        } elseif (!empty($args['order_id'])) {
            $default_idx = 'wc_order_' . (int) $args['order_id'];
        }
        $idx = apply_filters('fshipping_openship_create_index', $default_idx, $args);
        if (is_string($idx) && $idx !== '') {
            $payload['index'] = sanitize_text_field($idx);
        }

        $ver = apply_filters('fshipping_openship_create_version', null, $args);
        if (is_array($ver) && $ver !== []) {
            $payload['version'] = $ver;
        }

        return apply_filters('fshipping_openship_start_payload', $payload, $args);
    }

    /**
     * Root `accountNumber` and `shippingChargesPayment.payor.responsibleParty.accountNumber` must match.
     *
     * @param array<string, mixed> $requested
     * @return array<string, mixed>
     */
    private function sync_account_number_in_requested_shipment(array $requested, string $acc): array {
        if ($acc === '') {
            return $requested;
        }
        if (!isset($requested['shippingChargesPayment']) || !is_array($requested['shippingChargesPayment'])) {
            $requested['shippingChargesPayment'] = [
                'paymentType' => 'SENDER',
                'payor'       => [
                    'responsibleParty' => [
                        'accountNumber' => ['value' => $acc],
                    ],
                ],
            ];
            return $requested;
        }
        if (!isset($requested['shippingChargesPayment']['payor']) || !is_array($requested['shippingChargesPayment']['payor'])) {
            $requested['shippingChargesPayment']['payor'] = [];
        }
        if (!isset($requested['shippingChargesPayment']['payor']['responsibleParty']) || !is_array($requested['shippingChargesPayment']['payor']['responsibleParty'])) {
            $requested['shippingChargesPayment']['payor']['responsibleParty'] = [];
        }
        $requested['shippingChargesPayment']['payor']['responsibleParty']['accountNumber'] = ['value' => $acc];
        return $requested;
    }
}
