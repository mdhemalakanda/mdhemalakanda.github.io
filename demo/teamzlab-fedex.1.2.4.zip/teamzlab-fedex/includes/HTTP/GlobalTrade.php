<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\AddressNormalizer;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Global Trade API client.
 *
 * FedEx endpoint: POST /globaltrade/v1/shipments/regulatorydetails/retrieve
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class GlobalTrade extends BaseClient {
    protected string $log_source = 'fshipping_global_trade';
    private const REGULATORY_ENDPOINT = '/globaltrade/v1/shipments/regulatorydetails/retrieve';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    /**
     * Check compliance for a shipment before printing a label.
     *
     * @param array $args
     * @return array FedEx output or [] on failure.
     * @since 1.1
     */
    public function check_compliance(array $args): array {
        $order_id = (int) ($args['order_id'] ?? 0);
        $payload  = $this->prepare_payload($args);
        if (!$this->has_valid_commodities($payload)) {
            $this->trace(
                3,
                $order_id,
                'GLOBAL_TRADE_VALIDATION_BLOCKED',
                [
                    'reason'  => 'invalid_or_empty_commodities',
                    'payload' => $payload,
                ]
            );
            return [];
        }

        $this->trace(
            3,
            $order_id,
            'GLOBAL_TRADE_REQUEST',
            [
                'endpoint' => self::REGULATORY_ENDPOINT,
                'payload'  => $payload,
            ]
        );

        $decoded = $this->post(self::REGULATORY_ENDPOINT, $payload);
        if ($this->response_has_not_found_error($decoded)) {
            $retry_payload = $this->sanitize_payload_for_retry($payload);
            $this->trace(
                3,
                $order_id,
                'GLOBAL_TRADE_RETRY_NOT_FOUND',
                [
                    'reason'        => 'NOT.FOUND.ERROR',
                    'retry_payload' => $retry_payload,
                    'note'          => 'Confirm FedEx account entitlement for Regulatory Details API in the active environment.',
                ]
            );
            $decoded = $this->post(self::REGULATORY_ENDPOINT, $retry_payload);
        }

        $output = $this->map_regulatory_response($decoded);
        $this->trace(
            4,
            $order_id,
            'GLOBAL_TRADE_RESPONSE',
            [
                'response' => $decoded,
                'decision' => empty($output) ? 'FAIL-OPEN' : 'API_RESPONSE_RECEIVED',
            ]
        );

        return $output;
    }

    /**
     * @param array $output GlobalTrade output block.
     * @return bool True if the output contains any hard prohibition.
     * @since 1.1
     */
    public function has_prohibitions(array $output): bool {
        return !empty($output['prohibitions']) && is_array($output['prohibitions']);
    }

    /**
     * @param array $args
     * @return array
     * @since 1.1
     */
    private function prepare_payload(array $args): array {
        $origin      = $this->normalize_address_block($args['origin'] ?? [], 'US');
        $destination = $this->normalize_address_block($args['destination'] ?? [], '');
        $commodities = !empty($args['commodities']) && is_array($args['commodities']) ? $args['commodities'] : [];
        $currency    = sanitize_text_field($args['currency'] ?? 'USD');

        $items = [];
        foreach ($commodities as $commodity) {
            $row = $this->normalize_commodity($commodity, $origin['countryCode'], $currency);
            if (empty($row)) {
                continue;
            }
            $items[] = [
                'name'                 => $row['description'],
                'description'          => $row['description'],
                'quantity'             => (string) $row['quantity'],
                'quantityUOM'          => $row['quantityUnits'],
                'customsValue'         => ['amount' => $row['unitPrice'], 'currency' => $currency],
                'weight'               => [
                    'units' => $row['weightUnits'],
                    'value' => (float) $row['weightValue'],
                ],
                'countryOfManufacture' => $row['countryOfManufacture'],
                'harmonizedCode'       => $row['harmonizedCode'],
            ];
        }

        $payload = [
            'originAddress'      => $this->fedex_regulatory_address_slice($origin),
            'destinationAddress' => $this->fedex_regulatory_address_slice($destination),
            'customsClearanceDetail' => [
                'customsValue' => ['amount' => (float) ($args['customs_value'] ?? 0), 'currency' => $currency],
                'commodities'  => $items,
            ],
        ];
        $carrier_code = strtoupper(trim((string) ($args['carrier_code'] ?? '')));
        if ($carrier_code !== '') {
            $payload['carrierCode'] = sanitize_text_field($carrier_code);
        }
        if (!empty($args['service_type'])) {
            $payload['serviceType'] = sanitize_text_field((string) $args['service_type']);
        }
        $target_weight_unit = Helper::instance()->fedex_weight_unit();
        $payload = Helper::instance()->normalize_fedex_payload_weight_units($payload, $target_weight_unit);
        $this->warn_if_mixed_weight_units($payload, (int) ($args['order_id'] ?? 0), $target_weight_unit);
        $this->trace(
            2,
            (int) ($args['order_id'] ?? 0),
            'GLOBAL_TRADE_NORMALIZED_PAYLOAD',
            ['payload' => $payload]
        );

        return $payload;
    }

    /**
     * Regulatory Details response mapper. FedEx can return advisory/doc/prohibition
     * arrays under multiple keys depending on environment/version.
     *
     * @param array $decoded
     * @return array{documentsRequired:array,advisories:array,prohibitions:array}
     */
    private function map_regulatory_response(array $decoded): array {
        $candidates = [
            $decoded['output'] ?? [],
            $decoded['regulatoryDetails'] ?? [],
            $decoded['regulatoryDetailsOutput'] ?? [],
            $decoded['transactionShipments'][0]['regulatoryDetails'] ?? [],
            $decoded['customsClearanceDetail'] ?? [],
        ];
        $documents = [];
        $advisories = [];
        $prohibitions = [];
        foreach ($candidates as $node) {
            if (!is_array($node)) {
                continue;
            }
            $documents = $this->first_non_empty_array($documents, $node, ['documentsRequired', 'requiredDocuments', 'documentRequirements']);
            $advisories = $this->first_non_empty_array($advisories, $node, ['advisories', 'regulatoryAdvisories']);
            $prohibitions = $this->first_non_empty_array($prohibitions, $node, ['prohibitions', 'regulatoryProhibitions', 'prohibitedCommodities']);
        }
        return [
            'documentsRequired' => is_array($documents) ? $documents : [],
            'advisories'        => is_array($advisories) ? $advisories : [],
            'prohibitions'      => is_array($prohibitions) ? $prohibitions : [],
        ];
    }

    /**
     * @param array $current
     * @param array $node
     * @param array<int,string> $keys
     * @return array
     */
    /**
     * @param array<string,string> $block From normalize_address_block()
     * @return array<string,string>
     */
    private function fedex_regulatory_address_slice(array $block): array {
        $out = [
            'countryCode' => $block['countryCode'],
            'postalCode'  => $block['postalCode'],
        ];
        if (!empty($block['stateOrProvinceCode'])) {
            $out['stateOrProvinceCode'] = $block['stateOrProvinceCode'];
        }
        return $out;
    }

    private function first_non_empty_array(array $current, array $node, array $keys): array {
        if (!empty($current)) {
            return $current;
        }
        foreach ($keys as $key) {
            if (!empty($node[$key]) && is_array($node[$key])) {
                return $node[$key];
            }
        }
        return $current;
    }

    private function normalize_address_block(array $raw, string $default_country): array {
        $norm = AddressNormalizer::normalize_for_fedex([
            'street_lines' => [],
            'city'         => (string) ($raw['city'] ?? ''),
            'state'        => (string) ($raw['state'] ?? ''),
            'postal_code'  => (string) ($raw['postal_code'] ?? ''),
            'country'      => (string) ($raw['country'] ?? $default_country),
        ]);
        $country = $norm['country'] !== '' ? $norm['country'] : $default_country;
        $postal  = $norm['postal_code'];
        $postal_compact = strtoupper(preg_replace('/\s+/', '', (string) $postal));
        $state = $norm['state'];

        $out = [
            'countryCode'         => sanitize_text_field($country),
            'postalCode'          => sanitize_text_field(substr((string) $postal_compact, 0, 12)),
            'stateOrProvinceCode' => sanitize_text_field($state),
        ];
        if ($out['stateOrProvinceCode'] === '') {
            unset($out['stateOrProvinceCode']);
        }
        return $out;
    }

    private function normalize_commodity(array $commodity, string $origin_country, string $currency): array {
        $description = $this->normalize_description((string) ($commodity['description'] ?? ''));
        $hs_code     = $this->normalize_hs_code((string) ($commodity['harmonized_code'] ?? ''));
        if ($description === '' || $hs_code === '') {
            return [];
        }

        return [
            'description'         => $description,
            'quantity'            => max(1, (int) ($commodity['quantity'] ?? 1)),
            'quantityUnits'       => sanitize_text_field((string) ($commodity['quantity_units'] ?? 'EA')),
            'unitPrice'           => (float) ($commodity['unit_price'] ?? 0),
            'weightUnits'         => Helper::instance()->fedex_weight_unit(),
            'weightValue'         => Helper::instance()->normalize_fedex_weight(
                (float) ($commodity['weight'] ?? 0),
                strtoupper((string) ($commodity['weight_unit'] ?? Helper::instance()->fedex_weight_unit())),
                Helper::instance()->fedex_weight_unit()
            ),
            'countryOfManufacture'=> sanitize_text_field(
                strtoupper(trim((string) ($commodity['country_of_manufacture'] ?? $origin_country)))
            ),
            'harmonizedCode'      => $hs_code,
            'currency'            => sanitize_text_field($currency),
        ];
    }

    private function normalize_description(string $description): string {
        $clean = sanitize_text_field(trim($description));
        if ($clean === '') {
            return '';
        }
        $generic = ['item', 'product', 'goods', 'merchandise', 'sample'];
        if (in_array(strtolower($clean), $generic, true)) {
            return '';
        }
        return substr($clean, 0, 80);
    }

    private function normalize_hs_code(string $hs_code): string {
        $clean = preg_replace('/[^0-9.]/', '', (string) $hs_code);
        $digits = preg_replace('/[^0-9]/', '', (string) $clean);
        if ($digits === '' || strlen((string) $digits) < 6) {
            return '';
        }
        return sanitize_text_field(substr((string) $clean, 0, 12));
    }

    private function has_valid_commodities(array $payload): bool {
        $rows = $payload['customsClearanceDetail']['commodities'] ?? [];
        if (empty($rows) || !is_array($rows)) {
            return false;
        }
        foreach ($rows as $row) {
            if (empty($row['description']) || empty($row['harmonizedCode'])) {
                return false;
            }
        }
        return true;
    }

    private function response_has_not_found_error(array $decoded): bool {
        $errors = $decoded['errors'] ?? [];
        if (!is_array($errors)) {
            return false;
        }
        foreach ($errors as $error) {
            $code = strtoupper((string) ($error['code'] ?? ''));
            $message = strtoupper((string) ($error['message'] ?? ''));
            if ($code === 'NOT.FOUND.ERROR' || strpos($message, 'NOT.FOUND.ERROR') !== false) {
                return true;
            }
        }
        return false;
    }

    private function sanitize_payload_for_retry(array $payload): array {
        return $this->remove_empty_fields($payload);
    }

    private function remove_empty_fields($value) {
        if (!is_array($value)) {
            return $value;
        }
        $clean = [];
        foreach ($value as $key => $item) {
            $normalized = $this->remove_empty_fields($item);
            if ($normalized === null) {
                continue;
            }
            if ($normalized === '' || $normalized === []) {
                continue;
            }
            $clean[$key] = $normalized;
        }
        return $clean;
    }

    /**
     * Write Global Trade execution trace to wp-content/debug.log.
     *
     * @param int    $step
     * @param int    $order_id
     * @param string $stage
     * @param array  $context
     * @return void
     */
    private function trace(int $step, int $order_id, string $stage, array $context = []): void {
        unset($step, $order_id, $stage, $context);
    }

    private function warn_if_mixed_weight_units(array $payload, int $order_id, string $expected_unit): void {
        $units = Helper::instance()->collect_fedex_payload_weight_units($payload);
        if (empty($units)) {
            return;
        }
        if (count($units) > 1 || !in_array(strtoupper($expected_unit), $units, true)) {
            $this->trace(
                2,
                $order_id,
                'GLOBAL_TRADE_WEIGHT_UNIT_WARNING',
                [
                    'expected_unit' => strtoupper($expected_unit),
                    'units_found'   => $units,
                ]
            );
        }
    }
}
