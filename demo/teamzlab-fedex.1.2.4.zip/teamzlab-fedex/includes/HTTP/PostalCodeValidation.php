<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Postal Code Validation API client.
 *
 * FedEx endpoint: POST /country/v1/postalcodes
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class PostalCodeValidation extends BaseClient {
    protected string $log_source = 'fshipping_postal_code';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    /**
     * Validate a single postal code.
     *
     * @param string $postal_code
     * @param string $country_code Two-letter country code.
     * @param array  $extra
     * @return array FedEx output or [] on failure.
     * @since 1.1
     */
    public function validate($postal_code, $country_code = 'US', array $extra = []): array {
        $postal_code  = sanitize_text_field((string) $postal_code);
        $country_code = sanitize_text_field((string) $country_code);
        if (empty($postal_code) || empty($country_code)) {
            return [];
        }

        $cache_key = 'fshipping_postalcode_' . md5($postal_code . '|' . $country_code);
        $cached    = get_transient($cache_key);
        if (false !== $cached) {
            return $cached;
        }

        $payload = [
            'carrierCode'         => sanitize_text_field($extra['carrier_code'] ?? 'FDXE'),
            'countryCode'         => $country_code,
            'postalCode'          => $postal_code,
            'stateOrProvinceCode' => sanitize_text_field($extra['state']     ?? ''),
            'shipDate'            => sanitize_text_field($extra['ship_date'] ?? gmdate('Y-m-d')),
        ];

        $decoded = $this->post('/country/v1/postalcodes', $payload);
        $out     = $decoded['output'] ?? [];

        // Cache misses too (short TTL): the sandbox endpoint is retired and
        // re-hitting it on every lookup adds pure latency. A short window
        // lets the cache self-heal if FedEx restores the endpoint — matching
        // ServiceAvailability's miss-caching behaviour.
        set_transient($cache_key, $out, !empty($out) ? WEEK_IN_SECONDS : HOUR_IN_SECONDS);
        return $out;
    }
}
