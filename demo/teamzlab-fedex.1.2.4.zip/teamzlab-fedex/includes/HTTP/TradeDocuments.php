<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Traits\LogsHttp;

/**
 * Trade Documents Upload API client.
 *
 * Electronically submits customs documents — commercial invoice,
 * certificate of origin, permits — up to 5 per call in PDF/PNG/JPG/DOC/XLS
 * and similar formats.
 *
 * FedEx endpoint:
 *  - Sandbox:    https://documentapitest.prod.fedex.com/sandbox/documents/v1/etds/upload
 *  - Production: https://documentapi.prod.fedex.com/documents/v1/etds/upload
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class TradeDocuments {
    use SingletonTrait;
    use LogsHttp;
    private string $last_error_message = '';

    protected function __construct() {
        $this->log_source = 'fshipping_trade_docs';
    }

    /**
     * Backward-compatible trade-doc upload wrapper (binary files).
     *
     * @param array $documents
     * @param array $meta
     * @return array
     */
    public function upload(array $documents, array $meta = []) {
        return $this->upload_documents($documents, $meta, false);
    }

    /**
     * Upload one or more documents using the new Documents API.
     * For reliability across account configurations, this client sends
     * one API call per document and aggregates the returned meta rows.
     *
     * @param array $documents
     * @param array $meta
     * @param bool  $encoded
     * @return array
     */
    public function upload_documents(array $documents, array $meta = [], bool $encoded = false): array {
        if (empty($documents)) {
            return [];
        }
        $documents = array_slice($documents, 0, 5);

        $token = Authorization::instance()->get_secret_token();
        if (empty($token)) {
            $this->last_error_message = 'Missing FedEx OAuth token.';
            return [];
        }
        $this->last_error_message = '';

        $endpoint = $this->documents_upload_endpoint($meta);
        $this->log('TradeDocuments upload', [
            'count'       => count($documents),
            'destination' => $meta['destination_country'] ?? '',
            'workflow'    => $this->normalize_workflow_name((string) ($meta['workflow_name'] ?? '')),
            'tracking'    => $meta['tracking_number'] ?? '',
            'encoded'     => $encoded ? 'yes' : 'no',
        ]);

        $meta_rows = [];
        foreach ($documents as $document) {
            $row = $this->upload_single_document($endpoint, $token, $document, $meta, $encoded);
            if (!empty($row)) {
                $meta_rows[] = $row;
            }
        }

        return !empty($meta_rows) ? ['meta' => $meta_rows] : [];
    }

    /**
     * Upload image(s) for ETD artwork (logo/signature).
     *
     * @param array $images Each entry: [path, image_type, description]
     * @param array $meta
     * @return array
     */
    public function upload_images(array $images, array $meta = []): array {
        if (empty($images)) {
            return [];
        }
        $images = array_slice($images, 0, 5);

        $token = Authorization::instance()->get_secret_token();
        if (empty($token)) {
            $this->last_error_message = 'Missing FedEx OAuth token.';
            return [];
        }
        $this->last_error_message = '';

        $endpoint = $this->documents_upload_endpoint($meta);
        $meta_rows = [];
        foreach ($images as $image) {
            $path = (string) ($image['path'] ?? '');
            if ('' === $path || !file_exists($path)) {
                continue;
            }
            $name = basename($path);
            $mime = $this->guess_mime($path);
            $payload = [
                'workflowName' => $this->normalize_workflow_name((string) ($meta['workflow_name'] ?? 'ETDPreshipment')),
                'carrierCode'  => sanitize_text_field((string) ($meta['carrier_code'] ?? 'FDXE')),
                'name'         => $name,
                'contentType'  => $mime,
                'meta'         => [
                    'imageType'              => sanitize_text_field((string) ($image['image_type'] ?? 'LETTER_HEAD')),
                    // FedEx Document API still validates document context for image uploads.
                    'shipDocumentType'       => sanitize_text_field((string) ($image['type'] ?? 'COMMERCIAL_INVOICE')),
                    'originCountryCode'      => sanitize_text_field((string) ($meta['origin_country'] ?? '')),
                    'destinationCountryCode' => sanitize_text_field((string) ($meta['destination_country'] ?? '')),
                ],
            ];
            if (!empty($meta['tracking_number'])) {
                $payload['meta']['trackingNumber'] = sanitize_text_field((string) $meta['tracking_number']);
            }
            if (!empty($meta['shipment_date'])) {
                $payload['meta']['shipmentDate'] = sanitize_text_field((string) $meta['shipment_date']);
            }
            $decoded = $this->dispatch_upload_request($endpoint, $token, $payload, [
                'path' => $path,
                'name' => $name,
                'mime' => $mime,
            ]);
            $row = $this->extract_meta_row_from_response($decoded);
            if (!empty($row)) {
                $meta_rows[] = $row;
            }
        }

        return !empty($meta_rows) ? ['meta' => $meta_rows] : [];
    }

    /**
     * @param string $endpoint
     * @param string $token
     * @param array  $document
     * @param array  $meta
     * @param bool   $encoded
     * @return array<string,mixed>
     */
    private function upload_single_document(string $endpoint, string $token, array $document, array $meta, bool $encoded): array {
        $path = (string) ($document['path'] ?? '');
        if (!$encoded && ('' === $path || !file_exists($path))) {
            return [];
        }

        $name = sanitize_text_field((string) ($document['name'] ?? ($path !== '' ? basename($path) : 'encoded.txt')));
        $mime = sanitize_text_field((string) ($document['content_type'] ?? ($path !== '' ? $this->guess_mime($path) : 'text/plain')));
        $payload = [
            'workflowName' => $this->normalize_workflow_name((string) ($meta['workflow_name'] ?? '')),
            'carrierCode'  => sanitize_text_field((string) ($meta['carrier_code'] ?? 'FDXE')),
            'name'         => $name,
            'contentType'  => $mime,
            'meta'         => $this->build_document_meta($document, $meta, $encoded),
        ];
        $attachment = null;
        if (!$encoded) {
            $attachment = [
                'path' => $path,
                'name' => $name,
                'mime' => $mime,
            ];
        }
        $decoded = $this->dispatch_upload_request($endpoint, $token, $payload, $attachment);
        return $this->extract_meta_row_from_response($decoded);
    }

    /**
     * @param array $document
     * @param array $meta
     * @param bool  $encoded
     * @return array<string,string>
     */
    private function build_document_meta(array $document, array $meta, bool $encoded): array {
        $out = [
            'shipDocumentType'       => sanitize_text_field((string) ($document['type'] ?? 'COMMERCIAL_INVOICE')),
            'originCountryCode'      => sanitize_text_field((string) ($meta['origin_country'] ?? '')),
            'destinationCountryCode' => sanitize_text_field((string) ($meta['destination_country'] ?? '')),
        ];
        $optional = [
            'formCode'                => (string) ($meta['form_code'] ?? ''),
            'trackingNumber'          => (string) ($meta['tracking_number'] ?? ''),
            'shipmentDate'            => (string) ($meta['shipment_date'] ?? ''),
            'originLocationCode'      => (string) ($meta['origin_location_code'] ?? ''),
            'destinationLocationCode' => (string) ($meta['destination_location_code'] ?? ''),
            'description'             => (string) ($document['description'] ?? ''),
        ];
        foreach ($optional as $key => $value) {
            $value = sanitize_text_field($value);
            if ('' !== $value) {
                $out[$key] = $value;
            }
        }
        if ($encoded) {
            $base64 = (string) ($document['file_base64'] ?? '');
            if ('' !== $base64) {
                $out['fileContentBase64'] = preg_replace('/\s+/', '', $base64);
            }
        }
        return $out;
    }

    /**
     * @param string $endpoint
     * @param string $token
     * @param array  $document_payload
     * @param array|null $attachment
     * @return array
     */
    private function dispatch_upload_request(string $endpoint, string $token, array $document_payload, ?array $attachment = null): array {
        $boundary = 'fshippingDocApi' . bin2hex(random_bytes(8));
        $body = $this->build_new_multipart_body($boundary, $document_payload, $attachment);
        if ('' === $body) {
            return [];
        }
        $this->debug_log_exchange('request', [
            'url'       => $endpoint,
            'document'  => $document_payload,
            'attachment' => [
                'name' => sanitize_text_field((string) ($attachment['name'] ?? '')),
                'mime' => sanitize_text_field((string) ($attachment['mime'] ?? '')),
            ],
        ]);
        $response = wp_remote_post($endpoint, [
            'method'  => 'POST',
            'timeout' => 120,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'X-locale'      => 'en_US',
                'Content-Type'  => 'multipart/form-data; boundary=' . $boundary,
            ],
            'body'    => $body,
        ]);
        if (is_wp_error($response)) {
            $this->last_error_message = $response->get_error_message();
            return [];
        }
        $decoded = json_decode(wp_remote_retrieve_body($response), true);
        $this->last_error_message = $this->extract_error_message($decoded);
        $this->debug_log_exchange('response', [
            'url'          => $endpoint,
            'status_code'  => (int) wp_remote_retrieve_response_code($response),
            'status_text'  => sanitize_text_field((string) wp_remote_retrieve_response_message($response)),
            'body'         => $decoded,
        ]);
        $status_code = (int) wp_remote_retrieve_response_code($response);
        if (
            $status_code >= 400
            && apply_filters('fshipping_trade_documents_retry_singular_document_path', false, $endpoint, $decoded)
            && $this->should_retry_with_singular_document_path($endpoint, $decoded)
        ) {
            $retry_endpoint = str_replace('/documents/v1/etds/upload', '/document/v1/etds/upload', $endpoint);
            $this->debug_log_exchange('retry', [
                'from'   => $endpoint,
                'to'     => $retry_endpoint,
                'reason' => 'FedEx response path indicates singular /document endpoint.',
            ]);
            $retry_response = wp_remote_post($retry_endpoint, [
                'method'  => 'POST',
                'timeout' => 120,
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'X-locale'      => 'en_US',
                    'Content-Type'  => 'multipart/form-data; boundary=' . $boundary,
                ],
                'body'    => $body,
            ]);
            if (!is_wp_error($retry_response)) {
                $retry_decoded = json_decode(wp_remote_retrieve_body($retry_response), true);
                $this->last_error_message = $this->extract_error_message($retry_decoded);
                $this->debug_log_exchange('response_retry', [
                    'url'         => $retry_endpoint,
                    'status_code' => (int) wp_remote_retrieve_response_code($retry_response),
                    'status_text' => sanitize_text_field((string) wp_remote_retrieve_response_message($retry_response)),
                    'body'        => $retry_decoded,
                ]);
                $decoded = is_array($retry_decoded) ? $retry_decoded : $decoded;
            } else {
                $this->debug_log_exchange('response_retry_wp_error', [
                    'url'     => $retry_endpoint,
                    'message' => $retry_response->get_error_message(),
                ]);
            }
        }
        $this->log('TradeDocuments response', $decoded);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * @param string     $boundary
     * @param array      $document_payload
     * @param array|null $attachment
     * @return string
     */
    private function build_new_multipart_body(string $boundary, array $document_payload, ?array $attachment = null): string {
        $crlf = "\r\n";
        $segments = [];
        $segments[] = '--' . $boundary . $crlf
            . 'Content-Disposition: form-data; name="document"' . $crlf
            . 'Content-Type: application/json' . $crlf . $crlf
            . wp_json_encode($document_payload) . $crlf;

        if (!empty($attachment['path'])) {
            $contents = file_get_contents((string) $attachment['path']);
            if (false === $contents) {
                return '';
            }
            $name = sanitize_file_name((string) ($attachment['name'] ?? basename((string) $attachment['path'])));
            $mime = sanitize_text_field((string) ($attachment['mime'] ?? $this->guess_mime((string) $attachment['path'])));
            $segments[] = '--' . $boundary . $crlf
                . 'Content-Disposition: form-data; name="attachment"; filename="' . $name . '"' . $crlf
                . 'Content-Type: ' . $mime . $crlf . $crlf
                . $contents . $crlf;
        }
        $segments[] = '--' . $boundary . '--' . $crlf;
        return implode('', $segments);
    }

    /**
     * @param array $decoded
     * @return array<string,string>
     */
    private function extract_meta_row_from_response(array $decoded): array {
        $meta = $decoded['output']['meta'] ?? [];
        if (!is_array($meta)) {
            return [];
        }
        $doc_id = sanitize_text_field((string) ($meta['docId'] ?? $meta['uploadedDocumentId'] ?? ''));
        if ('' === $doc_id) {
            return [];
        }
        return [
            'docId'        => $doc_id,
            'documentType' => sanitize_text_field((string) ($meta['documentType'] ?? '')),
            'folderId'     => sanitize_text_field((string) ($meta['folderId'] ?? '')),
        ];
    }

    /**
     * @param array $meta
     * @return string
     */
    private function documents_upload_endpoint(array $meta = []): string {
        $default = Helper::instance()->is_sandbox_environment()
            ? 'https://documentapitest.prod.fedex.com/sandbox/documents/v1/etds/upload'
            : 'https://documentapi.prod.fedex.com/documents/v1/etds/upload';
        return (string) apply_filters('fshipping_trade_documents_endpoint', $default, $meta);
    }

    /**
     * @param string $raw
     * @return string
     */
    private function normalize_workflow_name(string $raw): string {
        $raw = strtolower(trim($raw));
        if (in_array($raw, ['etdpostshipment', 'etdpost_shipment', 'post', 'post_shipment'], true)) {
            return 'ETDPostshipment';
        }
        return 'ETDPreshipment';
    }

    /**
     * @param array $decoded
     * @return string
     */
    private function extract_error_message(array $decoded): string {
        $errors = $decoded['errors'] ?? null;
        if (is_array($errors)) {
            if (isset($errors['message'])) {
                return sanitize_text_field((string) $errors['message']);
            }
            if (!empty($errors[0]['message'])) {
                return sanitize_text_field((string) $errors[0]['message']);
            }
        }
        if (!empty($decoded['error'])) {
            return sanitize_text_field((string) $decoded['error']);
        }
        return '';
    }

    /**
     * @param string $endpoint
     * @param array  $decoded
     * @return bool
     */
    private function should_retry_with_singular_document_path(string $endpoint, array $decoded): bool {
        if (strpos($endpoint, '/documents/v1/etds/upload') === false) {
            return false;
        }
        $path = sanitize_text_field((string) ($decoded['path'] ?? ''));
        return $path === '/document/v1/etds/upload';
    }

    /**
     * @return string
     */
    public function get_last_error_message(): string {
        return $this->last_error_message;
    }

    /**
     * Write request/response markers to wp-content/debug.log.
     *
     * @param string $stage
     * @param array  $payload
     * @return void
     */
    private function debug_log_exchange(string $stage, array $payload): void {
        unset($stage, $payload);
    }

    /**
     * Retrieve endpoint is not documented in the new documents catalog.
     * Keep method for backward compatibility and return empty by default.
     *
     * @param string $document_id
     * @return array
     */
    public function retrieve(string $document_id): array {
        $document_id = sanitize_text_field($document_id);
        if ('' === $document_id) {
            return [];
        }
        $this->log('TradeDocuments retrieve unsupported', ['id' => $document_id]);
        return [];
    }

    /**
     * @param string $path
     * @return string
     * @since 1.1
     */
    private function guess_mime($path) {
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $map = [
            'pdf'  => 'application/pdf',
            'png'  => 'image/png',
            'jpg'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'gif'  => 'image/gif',
            'bmp'  => 'image/bmp',
            'tif'  => 'image/tiff',
            'tiff' => 'image/tiff',
            'txt'  => 'text/plain',
            'rtf'  => 'application/rtf',
            'doc'  => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls'  => 'application/vnd.ms-excel',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ];
        return $map[$ext] ?? 'application/octet-stream';
    }

    /**
     * @param string $title
     * @param mixed  $data
     * @return void
     *
     * Provided by LogsHttp trait; this comment is kept for IDE hinting.
     */
}
