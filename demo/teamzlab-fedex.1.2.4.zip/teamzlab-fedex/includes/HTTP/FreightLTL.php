<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Freight LTL API client.
 *
 * Requires a separate 9-digit FedEx Freight account number.
 *
 * FedEx endpoints (TODO: verify exact paths):
 *   POST /rate/v1/freight/rates/quotes
 *   POST /ship/v1/shipments  (with freight service type)
 *   POST /pickup/v1/freight/pickups
 *
 * @since 1.1
 */
defined('ABSPATH') || exit;

class FreightLTL extends BaseClient {
    protected string $log_source = 'fshipping_freight_ltl';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    /**
     * Freight account gate — every public method short-circuits if
     * the merchant hasn't entered the 9-digit freight account number.
     *
     * @return string
     * @since 1.2
     */
    private function freight_account(): string {
        $settings = get_option('fshipping_options');
        $acc      = sanitize_text_field($settings['fshipping_freight_account_number'] ?? '');
        return $acc;
    }

    /**
     * @param array $args
     * @return array
     * @since 1.1
     */
    public function get_rates(array $args): array {
        $acc = $this->freight_account();
        if (empty($acc)) {
            return [];
        }

        $payload = [
            'accountNumber' => ['value' => $acc],
            'requestedShipment' => [
                'shipper'   => ['address' => [
                    'postalCode'          => sanitize_text_field($args['origin']['postal_code'] ?? ''),
                    'countryCode'         => sanitize_text_field($args['origin']['country']     ?? 'US'),
                    'stateOrProvinceCode' => sanitize_text_field($args['origin']['state']       ?? ''),
                ]],
                'recipient' => ['address' => [
                    'postalCode'          => sanitize_text_field($args['destination']['postal_code'] ?? ''),
                    'countryCode'         => sanitize_text_field($args['destination']['country']     ?? 'US'),
                    'stateOrProvinceCode' => sanitize_text_field($args['destination']['state']       ?? ''),
                ]],
                'serviceType'     => sanitize_text_field($args['service_type']  ?? 'FEDEX_FREIGHT_PRIORITY'),
                'pickupType'      => sanitize_text_field($args['pickup_type']   ?? 'USE_SCHEDULED_PICKUP'),
                'rateRequestType' => ['LIST'],
                'requestedPackageLineItems' => [[
                    'weight' => [
                        'units' => strtoupper($args['weight_unit'] ?? 'LB') === 'KG' ? 'KG' : 'LB',
                        'value' => (string) (float) ($args['weight'] ?? 0),
                    ],
                    'freightClass' => sanitize_text_field($args['freight_class'] ?? '100'),
                ]],
            ],
        ];

        $decoded = $this->post('/rate/v1/freight/rates/quotes', $payload);
        return $decoded['output']['rateReplyDetails'] ?? [];
    }

    /**
     * @param array $shipment
     * @return array
     * @since 1.1
     */
    public function create_shipment(array $shipment): array {
        $acc = $this->freight_account();
        if (empty($acc)) {
            return [];
        }

        $payload = [
            'labelResponseOptions' => 'URL_ONLY',
            'accountNumber'        => ['value' => $acc],
            'requestedShipment'    => $shipment,
        ];
        $decoded = $this->post('/ship/v1/shipments', $payload);
        return $decoded['output'] ?? [];
    }

    /**
     * @param array $args
     * @return array
     * @since 1.1
     */
    public function schedule_pickup(array $args): array {
        $acc = $this->freight_account();
        if (empty($acc)) {
            return [];
        }

        $settings = get_option('fshipping_options');
        $payload  = [
            'associatedAccountNumber' => ['value' => $acc],
            'originDetail' => [
                'pickupLocation' => [
                    'contact' => [
                        'personName'  => sanitize_text_field($args['person_name']  ?? ($settings['fshipping_person_name']  ?? '')),
                        'phoneNumber' => sanitize_text_field($args['phone_number'] ?? ($settings['fshipping_phone_number'] ?? '')),
                        'companyName' => sanitize_text_field($args['company_name'] ?? ''),
                    ],
                    'address' => [
                        'streetLines' => isset($args['street_lines']) ? array_map('sanitize_text_field', (array) $args['street_lines']) : [],
                        'city'                => sanitize_text_field($args['city']         ?? ''),
                        'stateOrProvinceCode' => sanitize_text_field($args['state']        ?? ''),
                        'postalCode'          => sanitize_text_field($args['postal_code']  ?? ''),
                        'countryCode'         => sanitize_text_field($args['country']      ?? 'US'),
                    ],
                ],
                'readyDateTimestamp' => $this->iso8601_ready_timestamp($args['ready_datetime'] ?? ''),
                'customerCloseTime'  => sanitize_text_field($args['customer_close_time'] ?? '17:00:00'),
            ],
            'totalWeight' => [
                'units' => strtoupper($args['weight_unit'] ?? 'LB') === 'KG' ? 'KG' : 'LB',
                'value' => (string) (float) ($args['weight'] ?? 0),
            ],
            'packageCount' => (int) ($args['package_count'] ?? 1),
            'carrierCode'  => sanitize_text_field($args['carrier_code'] ?? 'FXFR'),
        ];

        $decoded = $this->post('/pickup/v1/freight/pickups', $payload);
        return $decoded['output'] ?? [];
    }

    /**
     * Normalize a ready datetime to the ISO 8601 offset format the FedEx
     * Pickup API requires (e.g. 2026-10-22T10:00:00-05:00). Naive local
     * strings are interpreted in the site timezone; offset-qualified values
     * pass through unchanged.
     *
     * @param mixed $value Raw ready datetime.
     * @return string
     */
    private function iso8601_ready_timestamp($value): string {
        $value = trim((string) $value);
        if ('' === $value) {
            return gmdate('c', strtotime('+1 day 10:00'));
        }
        if (preg_match('/(?:Z|[+-]\d{2}:?\d{2})$/i', $value)) {
            $ts = strtotime($value);
            return false !== $ts ? gmdate('c', $ts) : gmdate('c', strtotime('+1 day 10:00'));
        }
        $tz = function_exists('wp_timezone') ? wp_timezone() : new \DateTimeZone('UTC');
        foreach (['Y-m-d\TH:i:s', 'Y-m-d\TH:i', 'Y-m-d H:i:s', 'Y-m-d H:i'] as $format) {
            $dt = \DateTimeImmutable::createFromFormat($format, $value, $tz);
            if ($dt instanceof \DateTimeImmutable && $dt->format($format) === $value) {
                return $dt->format('c');
            }
        }
        $ts = strtotime($value);
        if (false === $ts) {
            return gmdate('c', strtotime('+1 day 10:00'));
        }
        return (new \DateTimeImmutable('@' . $ts))->setTimezone($tz)->format('c');
    }
}
