<?php
namespace FSHIPPING\HTTP;

use FSHIPPING\Auth\Authorization;
use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Pre-flight shipment validation.
 *
 * FedEx endpoint: POST /ship/v1/shipments/packages/validate
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class ShipmentValidate extends BaseClient {
    protected string $log_source = 'fshipping_ship_validate';

    protected function base_url(): string {
        return Helper::instance()->get_base_url();
    }

    protected function auth_header(): string {
        $token = Authorization::instance()->get_secret_token();
        return !empty($token) ? 'Bearer ' . $token : '';
    }

    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    public function validate(array $requested_shipment): array {
        if (empty($this->auth_header())) {
            return $this->empty_result(['token_missing']);
        }

        $settings = get_option('fshipping_options');
        $payload  = [
            'accountNumber'     => ['value' => sanitize_text_field($settings['fshipping_acc_number'] ?? '')],
            'requestedShipment' => $requested_shipment,
        ];

        $decoded = $this->post('/ship/v1/shipments/packages/validate', $payload);
        if (empty($decoded)) {
            return $this->empty_result(['malformed_response']);
        }

        return $this->parse_response($decoded);
    }

    private function parse_response(array $decoded): array {
        $warnings = [];
        $errors   = [];

        foreach ((array) ($decoded['output']['alerts'] ?? []) as $alert) {
            $severity = strtoupper((string) ($alert['alertType'] ?? ''));
            $message  = sanitize_text_field((string) ($alert['message'] ?? ''));
            if (empty($message)) continue;
            if (in_array($severity, ['ERROR', 'FAILURE'], true)) {
                $errors[] = $message;
            } else {
                $warnings[] = $message;
            }
        }

        foreach ((array) ($decoded['errors'] ?? []) as $error) {
            $msg = sanitize_text_field((string) ($error['message'] ?? ''));
            if (!empty($msg)) $errors[] = $msg;
        }

        return ['valid' => empty($errors), 'warnings' => $warnings, 'errors' => $errors, 'raw' => $decoded];
    }

    private function empty_result(array $errors): array {
        return ['valid' => false, 'warnings' => [], 'errors' => $errors, 'raw' => []];
    }
}
