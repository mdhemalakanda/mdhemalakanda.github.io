<?php
namespace FSHIPPING\Shipping;

use FSHIPPING\HTTP\Rates;
use FSHIPPING\SingletonTrait;

/**
 * Surface FedEx One Rate flat-rate pricing alongside standard rates at
 * checkout.
 *
 * FedEx One Rate is flat-priced shipping for packages that fit in
 * FedEx-branded packaging. The merchant's rate call doesn't include it
 * by default because the Rates API needs `packagingType=FEDEX_ONE_RATE`
 * passed explicitly.
 *
 * This class runs a second rate call with that packaging type set and
 * merges the returned One Rate services into the rate list, labeled
 * with their flat-rate pricing so merchants can offer both options at
 * checkout.
 *
 * Opt-in via setting `fshipping_enable_one_rate` (off by default).
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class OneRateComparator {
    use SingletonTrait;

    /** After RuntimeIntegrator's safety net so we never comp-off an empty list. */
    public const FILTER_PRIORITY = 20;

    /**
     * @return void
     * @since 1.2
     */
    public function init() {
        add_filter('fshipping_calculate_shipping_rates', [$this, 'augment_with_one_rate'], self::FILTER_PRIORITY, 3);
    }

    /**
     * Merge One Rate options into the rate list.
     *
     * @param array $rates    Rate reply details from the primary call.
     * @param mixed $method   The WC_Shipping_Method instance.
     * @param array $package  WooCommerce shipping package.
     * @return array
     * @since 1.2
     */
    public function augment_with_one_rate($rates, $method, $package): array {
        if (!$this->is_enabled()) {
            return is_array($rates) ? $rates : [];
        }
        if (!is_array($rates) || empty($rates)) {
            return is_array($rates) ? $rates : [];
        }

        $args = $this->package_to_rate_args($package);
        if (empty($args)) {
            return $rates;
        }
        $args['packaging_type'] = 'FEDEX_ONE_RATE';

        $one_rate = $this->fetch_quotes($args);
        if (empty($one_rate)) {
            return $rates;
        }

        $base_lookup = $this->index_base_rates($rates);
        foreach ($one_rate as &$detail) {
            if (!is_array($detail)) {
                continue;
            }
            $service_type = sanitize_text_field((string) ($detail['serviceType'] ?? ''));
            $service_name = (string) ($detail['serviceName'] ?? '');
            $detail['serviceName'] = $service_name !== '' ? $service_name . ' (One Rate)' : 'FedEx One Rate';
            $detail['_one_rate']   = true;

            $one_rate_total = $this->final_net_charge($detail);
            $base_total     = isset($base_lookup[$service_type]) ? $base_lookup[$service_type] : null;
            if ($base_total !== null && $one_rate_total !== null && $base_total > $one_rate_total) {
                $detail['_one_rate_savings'] = round($base_total - $one_rate_total, 2);
            }
        }
        unset($detail);

        return array_merge($rates, array_values(array_filter($one_rate, 'is_array')));
    }

    /**
     * @return bool
     * @since 1.2
     */
    public function is_enabled(): bool {
        $settings = get_option('fshipping_options', []);
        return !empty($settings['fshipping_enable_one_rate']);
    }

    /**
     * Convert a WooCommerce shipping package into the args shape
     * `HTTP\Rates::get_rates()` expects.
     *
     * @param array $package
     * @return array
     * @since 1.2
     */
    public function package_to_rate_args(array $package): array {
        $pkg = isset($package['contents']) ? $package : (isset($package[0]['contents']) ? $package[0] : []);
        if (empty($pkg['contents']) || empty($pkg['destination']['country'])) {
            return [];
        }
        $settings = get_option('fshipping_options', []);
        $total_weight = 0.0;
        $max_length   = 0.0;
        $max_width    = 0.0;
        $total_height = 0.0;

        foreach ($pkg['contents'] as $cart_item) {
            $product  = isset($cart_item['data']) ? $cart_item['data'] : null;
            $quantity = isset($cart_item['quantity']) ? max(1, (int) $cart_item['quantity']) : 1;
            if (is_object($product)) {
                if ($product->has_weight()) {
                    $total_weight += (float) $product->get_weight() * $quantity;
                }
                if ($product->has_dimensions()) {
                    $l = (float) $product->get_length();
                    $w = (float) $product->get_width();
                    $h = (float) $product->get_height();
                    if ($l > $max_length) { $max_length = $l; }
                    if ($w > $max_width)  { $max_width  = $w; }
                    $total_height += $h * $quantity;
                }
            }
        }

        return [
            'origin_postcode'      => sanitize_text_field((string) ($settings['fshipping_postal_code']  ?? '')),
            'origin_country'       => sanitize_text_field((string) ($settings['fshipping_country_code'] ?? 'US')),
            'destination_postcode' => sanitize_text_field((string) ($pkg['destination']['postcode'] ?? '')),
            'destination_country'  => sanitize_text_field((string) ($pkg['destination']['country']  ?? 'US')),
            'weight'         => $total_weight > 0 ? $total_weight : 1,
            'weight_unit'    => strtoupper((string) get_option('woocommerce_weight_unit')) === 'KG' ? 'KG' : 'LB',
            'length'         => (int) ($max_length  ?: 10),
            'width'          => (int) ($max_width   ?: 10),
            'height'         => (int) ($total_height ?: 10),
            'dimension_unit' => strtoupper((string) get_option('woocommerce_dimension_unit')) === 'CM' ? 'CM' : 'IN',
        ];
    }

    /**
     * Extract the final net charge from a FedEx rateReplyDetails entry.
     * Null when no acceptable rate-detail is present.
     *
     * @param array $detail
     * @return float|null
     * @since 1.2
     */
    public function final_net_charge(array $detail): ?float {
        $rated = isset($detail['ratedShipmentDetails']) && is_array($detail['ratedShipmentDetails'])
            ? $detail['ratedShipmentDetails']
            : [];
        $priority = ['INCENTIVE', 'ACCOUNT', 'PREFERRED', 'LIST'];
        foreach ($priority as $type) {
            foreach ($rated as $row) {
                if (isset($row['rateType']) && $row['rateType'] === $type && isset($row['totalNetCharge'])) {
                    return (float) $row['totalNetCharge'];
                }
            }
        }
        return null;
    }

    /**
     * @param array $rates
     * @return array<string,float>
     * @since 1.2
     */
    private function index_base_rates(array $rates): array {
        $idx = [];
        foreach ($rates as $detail) {
            if (!is_array($detail)) { continue; }
            $service_type = sanitize_text_field((string) ($detail['serviceType'] ?? ''));
            if ($service_type === '') { continue; }
            $total = $this->final_net_charge($detail);
            if ($total !== null) {
                $idx[$service_type] = $total;
            }
        }
        return $idx;
    }

    /**
     * Call the Rates API. Separated so tests can override it cheaply.
     *
     * @param array $args
     * @return array
     * @since 1.2
     */
    protected function fetch_quotes(array $args): array {
        return Rates::instance()->get_rates($args);
    }
}
