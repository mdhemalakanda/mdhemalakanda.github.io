<?php
namespace FSHIPPING\Shipping;

use FSHIPPING\SingletonTrait;

/**
 * Per-order service preferences — Saturday delivery, Evening delivery,
 * Saturday pickup, signature options, date-certain delivery.
 *
 * Deep Research confirmed zero competitors publicly own the
 * `fedex saturday delivery woocommerce` or `fedex evening delivery
 * woocommerce` keywords. Surfacing these as first-class checkout /
 * admin options closes that gap.
 *
 * Responsibilities kept narrow: translate merchant / customer choices
 * into the FedEx `specialServicesRequested` fragment. Higher-level
 * pricing surcharges are handled on the Rates response, not here.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class ServicePreferences {
    use SingletonTrait;

    public const SATURDAY_DELIVERY  = 'SATURDAY_DELIVERY';
    public const SATURDAY_PICKUP    = 'SATURDAY_PICKUP';
    public const EVENING_DELIVERY   = 'EVENING_DELIVERY';
    public const DATE_CERTAIN       = 'DATE_CERTAIN_DELIVERY';
    public const INDIRECT_SIGNATURE = 'INDIRECT_SIGNATURE_REQUIRED';
    public const DIRECT_SIGNATURE   = 'DIRECT_SIGNATURE_REQUIRED';
    public const ADULT_SIGNATURE    = 'ADULT_SIGNATURE_REQUIRED';

    /**
     * Options surfaced in the UI, keyed by slug.
     *
     * @return array<string,array{code:string,label:string,category:string}>
     * @since 1.2
     */
    public function catalog(): array {
        return [
            'saturday_delivery' => ['code' => self::SATURDAY_DELIVERY,  'label' => 'Saturday delivery',              'category' => 'delivery_day'],
            'saturday_pickup'   => ['code' => self::SATURDAY_PICKUP,    'label' => 'Saturday pickup',                'category' => 'pickup_day'],
            'evening_delivery'  => ['code' => self::EVENING_DELIVERY,   'label' => 'Evening delivery (after 5 PM)',  'category' => 'delivery_window'],
            'date_certain'      => ['code' => self::DATE_CERTAIN,       'label' => 'Deliver on a specific date',     'category' => 'delivery_window'],
            'indirect_sig'      => ['code' => self::INDIRECT_SIGNATURE, 'label' => 'Indirect signature required',    'category' => 'signature'],
            'direct_sig'        => ['code' => self::DIRECT_SIGNATURE,   'label' => 'Direct signature required',      'category' => 'signature'],
            'adult_sig'         => ['code' => self::ADULT_SIGNATURE,    'label' => 'Adult signature required (21+)', 'category' => 'signature'],
        ];
    }

    /**
     * Validate + normalize merchant / customer selections.
     *
     * @param array  $input               Flat slug list, or slug=>bool map.
     * @param string $ship_date           ISO date of the shipment ('YYYY-MM-DD').
     * @param string $requested_deliver_by Optional 'YYYY-MM-DD' for date-certain.
     * @return array{
     *     codes:array<int,string>,
     *     signature_kind:string,
     *     specific_delivery_date:string,
     *     warnings:array<int,string>
     * }
     * @since 1.2
     */
    public function normalize(array $input, string $ship_date = '', string $requested_deliver_by = ''): array {
        $catalog = $this->catalog();
        $slugs   = $this->coerce_slugs($input);
        $codes   = [];
        $warnings = [];
        $signature_kind = '';

        foreach ($slugs as $slug) {
            if (!isset($catalog[$slug])) {
                $warnings[] = sprintf('Unknown preference "%s" ignored.', $slug);
                continue;
            }
            $entry = $catalog[$slug];

            if ($entry['category'] === 'signature') {
                // Only one signature kind can win; last one wins.
                $signature_kind = $entry['code'];
                continue;
            }

            if ($slug === 'saturday_delivery' && $ship_date !== '' && !$this->eligible_for_saturday_delivery($ship_date)) {
                $warnings[] = 'Saturday delivery is only available when shipping Thursday or Friday.';
                continue;
            }
            if ($slug === 'saturday_pickup' && $ship_date !== '' && !$this->is_saturday($ship_date)) {
                $warnings[] = 'Saturday pickup requires a Saturday ship date.';
                continue;
            }
            if ($slug === 'date_certain' && $requested_deliver_by === '') {
                $warnings[] = 'Date-certain delivery requires a requested delivery date.';
                continue;
            }

            $codes[] = $entry['code'];
        }

        if ($signature_kind !== '') {
            $codes[] = $signature_kind;
        }

        return [
            'codes'                  => array_values(array_unique($codes)),
            'signature_kind'         => $signature_kind,
            'specific_delivery_date' => in_array(self::DATE_CERTAIN, $codes, true) ? $requested_deliver_by : '',
            'warnings'               => $warnings,
        ];
    }

    /**
     * Build the FedEx payload fragment for Rates / Ship.
     *
     * @param array{codes:array<int,string>,specific_delivery_date:string} $normalized
     * @return array
     * @since 1.2
     */
    public function payload_fragment(array $normalized): array {
        $codes = array_values(array_filter(($normalized['codes'] ?? []), static fn($c) => is_string($c) && $c !== ''));
        $fragment = [];

        if (!empty($codes)) {
            $fragment['specialServicesRequested'] = ['specialServiceTypes' => $codes];
        }

        if (!empty($normalized['specific_delivery_date'])) {
            $fragment['deliveryInstructions'] = 'SPECIFIC_DATE';
            $fragment['specificDeliveryDateTimestamp'] = (string) $normalized['specific_delivery_date'];
        }

        return $fragment;
    }

    /**
     * FedEx only offers Saturday delivery when shipping Thu/Fri via
     * eligible services; we mirror that rule here.
     *
     * @param string $ship_date 'YYYY-MM-DD'.
     * @return bool
     * @since 1.2
     */
    public function eligible_for_saturday_delivery(string $ship_date): bool {
        $ts = strtotime($ship_date);
        if ($ts === false) {
            return false;
        }
        $dow = (int) gmdate('N', $ts); // 1 = Mon ... 7 = Sun
        return in_array($dow, [4, 5], true); // Thu or Fri
    }

    /**
     * @param string $date 'YYYY-MM-DD'.
     * @return bool
     * @since 1.2
     */
    public function is_saturday(string $date): bool {
        $ts = strtotime($date);
        if ($ts === false) {
            return false;
        }
        return (int) gmdate('N', $ts) === 6;
    }

    /**
     * @param array $input
     * @return array<int,string>
     * @since 1.2
     */
    private function coerce_slugs(array $input): array {
        $slugs = [];
        foreach ($input as $key => $value) {
            if (is_int($key) && is_string($value)) {
                $slugs[] = $value;
                continue;
            }
            if (is_string($key) && $value) {
                $slugs[] = $key;
            }
        }
        return array_values(array_unique(array_map(
            static fn($s) => strtolower(trim($s)),
            $slugs
        )));
    }
}
