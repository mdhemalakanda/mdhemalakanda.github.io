<?php
namespace FSHIPPING\Shipping;

use FSHIPPING\SingletonTrait;

/**
 * Dangerous Goods (hazmat, dry ice, batteries, alcohol) helper.
 *
 * Addresses the explicit Woo feature-request gap:
 *   "FedEx Shipping Method Plugin with capability for Dangerous Goods
 *    shipping" — and unlocks alcohol / dry-ice / lithium-battery niches
 *   that competitor plugins silently reject.
 *
 * Produces the payload fragments FedEx Ship expects for DG shipments,
 * plus lightweight validation of merchant-supplied DG fields.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class DangerousGoods {
    use SingletonTrait;

    public const KIND_HAZMAT    = 'hazmat';
    public const KIND_DRY_ICE   = 'dry_ice';
    public const KIND_BATTERY   = 'lithium_battery';
    public const KIND_ALCOHOL   = 'alcohol';

    public const REGULATION_IATA   = 'IATA';
    public const REGULATION_DOT    = 'DOT';
    public const REGULATION_ADR    = 'ADR';

    public const PACKING_I    = 'I';
    public const PACKING_II   = 'II';
    public const PACKING_III  = 'III';

    /**
     * Kinds we surface in the admin UI, with human labels.
     *
     * @return array<string,string>
     * @since 1.2
     */
    public function kinds(): array {
        return [
            self::KIND_HAZMAT  => 'Hazardous materials',
            self::KIND_DRY_ICE => 'Dry ice',
            self::KIND_BATTERY => 'Lithium batteries',
            self::KIND_ALCOHOL => 'Alcohol',
        ];
    }

    /**
     * Validate a merchant-submitted DG declaration.
     *
     * @param array $input Form values.
     * @return array{ok:bool,data:array,errors:array<string,string>}
     * @since 1.2
     */
    public function validate(array $input): array {
        $errors = [];
        $kind   = sanitize_text_field((string) ($input['kind'] ?? ''));
        $data   = [
            'kind'           => $kind,
            'un_number'      => strtoupper(sanitize_text_field((string) ($input['un_number']      ?? ''))),
            'proper_name'    => sanitize_text_field((string) ($input['proper_name']    ?? '')),
            'hazard_class'   => sanitize_text_field((string) ($input['hazard_class']   ?? '')),
            'packing_group'  => strtoupper(sanitize_text_field((string) ($input['packing_group']  ?? ''))),
            'regulation'     => strtoupper(sanitize_text_field((string) ($input['regulation']     ?? self::REGULATION_IATA))),
            'net_weight'     => (float)  ($input['net_weight'] ?? 0),
            'net_weight_unit' => strtoupper(sanitize_text_field((string) ($input['net_weight_unit'] ?? 'KG'))),
            'quantity'       => (int)    ($input['quantity']   ?? 1),
            'package_type'   => sanitize_text_field((string) ($input['package_type']   ?? '')),
        ];

        if (!array_key_exists($kind, $this->kinds())) {
            $errors['kind'] = 'Pick a dangerous-goods kind.';
        }

        if ($kind === self::KIND_HAZMAT || $kind === self::KIND_BATTERY) {
            if (!preg_match('/^UN\d{4}$/', $data['un_number'])) {
                $errors['un_number'] = 'UN number must be format UN#### (e.g. UN3480).';
            }
            if ($data['proper_name'] === '') {
                $errors['proper_name'] = 'Proper shipping name is required.';
            }
            if ($data['hazard_class'] === '') {
                $errors['hazard_class'] = 'Hazard class is required.';
            }
            if (!in_array($data['packing_group'], [self::PACKING_I, self::PACKING_II, self::PACKING_III, ''], true)) {
                $errors['packing_group'] = 'Packing group must be I, II, or III.';
            }
        }

        if ($kind === self::KIND_DRY_ICE) {
            if ($data['net_weight'] <= 0) {
                $errors['net_weight'] = 'Dry-ice net weight must be greater than zero.';
            }
            if (!in_array($data['net_weight_unit'], ['KG', 'LB'], true)) {
                $errors['net_weight_unit'] = 'Net-weight unit must be KG or LB.';
            }
        }

        if ($kind === self::KIND_ALCOHOL) {
            // FedEx requires a signed adult-signature service for alcohol.
            $data['requires_adult_signature'] = true;
        }

        if ($data['quantity'] <= 0) {
            $errors['quantity'] = 'Quantity must be at least 1.';
        }

        return [
            'ok'     => empty($errors),
            'data'   => $data,
            'errors' => $errors,
        ];
    }

    /**
     * Build the FedEx Ship API payload fragment for a validated declaration.
     *
     * @param array $data Output of validate()['data'].
     * @return array
     * @since 1.2
     */
    public function payload_fragment(array $data): array {
        $kind = $data['kind'] ?? '';

        if ($kind === self::KIND_DRY_ICE) {
            return [
                'dangerousGoodsDetail' => [
                    'accessibility' => 'ACCESSIBLE',
                    'options'       => ['DRY_ICE'],
                    'dryIceWeight'  => [
                        'units' => (string) ($data['net_weight_unit'] ?? 'KG'),
                        'value' => (float)  ($data['net_weight']      ?? 0),
                    ],
                ],
                'specialServicesRequested' => [
                    'specialServiceTypes' => ['DRY_ICE'],
                ],
            ];
        }

        if ($kind === self::KIND_BATTERY) {
            return [
                'batteryDetails' => [[
                    'batteryPackingType'    => 'CONTAINED_IN_EQUIPMENT',
                    'batteryRegulatoryType' => 'IATA_SECTION_II',
                    'batteryMaterialType'   => 'LITHIUM_ION',
                ]],
                'specialServicesRequested' => [
                    'specialServiceTypes' => ['BATTERY'],
                ],
            ];
        }

        if ($kind === self::KIND_ALCOHOL) {
            return [
                'specialServicesRequested' => [
                    'specialServiceTypes' => ['ALCOHOL', 'ADULT_SIGNATURE_REQUIRED'],
                ],
                'alcoholDetail' => [
                    'alcoholRecipientType' => 'CONSUMER',
                    'quantity'             => [
                        'quantity' => (float) ($data['net_weight'] ?? 0),
                        'units'    => (string) ($data['net_weight_unit'] ?? 'LB'),
                    ],
                ],
            ];
        }

        if ($kind === self::KIND_HAZMAT) {
            return [
                'dangerousGoodsDetail' => [
                    'accessibility' => 'INACCESSIBLE',
                    'regulation'    => (string) ($data['regulation'] ?? self::REGULATION_IATA),
                    'options'       => ['HAZARDOUS_MATERIALS'],
                    'packingDetails' => [
                        'cargoAircraftOnly' => false,
                    ],
                    'dangerousGoodsItems' => [[
                        'description' => [
                            'id'                      => (string) ($data['un_number']     ?? ''),
                            'properShippingName'      => (string) ($data['proper_name']   ?? ''),
                            'hazardClass'             => (string) ($data['hazard_class']  ?? ''),
                            'packingGroup'            => (string) ($data['packing_group'] ?? ''),
                        ],
                        'netWeight' => [
                            'units' => (string) ($data['net_weight_unit'] ?? 'KG'),
                            'value' => (float)  ($data['net_weight']      ?? 0),
                        ],
                        'quantity' => (int) ($data['quantity'] ?? 1),
                    ]],
                ],
                'specialServicesRequested' => [
                    'specialServiceTypes' => ['HAZARDOUS_MATERIALS'],
                ],
            ];
        }

        return [];
    }
}
