<?php
namespace FSHIPPING\Migration;

use FSHIPPING\SingletonTrait;

/**
 * Staging-mode flag + debug log.
 *
 * When staging mode is ON, the plugin continues to fire FedEx API calls
 * but rate/label results are NOT surfaced to the live checkout — they're
 * appended to a rolling debug log instead. Used during SOAP→REST
 * migration so merchants can verify everything works *before* flipping
 * the switch.
 *
 * Consumers:
 * - Set `fshipping_staging_mode` option to `yes` / `no` (e.g. WP-CLI, migration script).
 * - API client wrappers call `debug_log()` to record the what-would-have-happened.
 * - Front-end Shipping method checks `is_enabled()` and falls back to the
 *   configured flat rate when true.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class StagingMode {
    use SingletonTrait;

    private const OPTION_KEY     = 'fshipping_staging_mode';
    private const LOG_OPTION_KEY = 'fshipping_staging_log';
    private const LOG_LIMIT      = 100;

    /**
     * Whether staging mode is currently ON.
     *
     * @return bool
     * @since 1.2
     */
    public function is_enabled(): bool {
        $raw = get_option(self::OPTION_KEY, 'no');
        return $this->coerce_bool($raw);
    }

    /**
     * Flip the flag.
     *
     * @param bool $enabled
     * @return bool The new state.
     * @since 1.2
     */
    public function set(bool $enabled): bool {
        update_option(self::OPTION_KEY, $enabled ? 'yes' : 'no');
        return $enabled;
    }

    /**
     * Append a debug entry. No-op when staging mode is OFF, so callers can
     * sprinkle these without branching.
     *
     * @param string $channel  Short label — 'rates', 'ship', 'track', etc.
     * @param array  $context  Arbitrary structured context.
     * @return void
     * @since 1.2
     */
    public function debug_log(string $channel, array $context = []): void {
        if (!$this->is_enabled()) {
            return;
        }

        $entry = [
            'at'      => current_time('mysql'),
            'channel' => sanitize_text_field($channel),
            'context' => $context,
        ];

        $log = get_option(self::LOG_OPTION_KEY, []);
        $log = is_array($log) ? $log : [];
        $log[] = $entry;

        // Keep the last N entries only so the option row never balloons.
        if (count($log) > self::LOG_LIMIT) {
            $log = array_slice($log, -self::LOG_LIMIT);
        }

        update_option(self::LOG_OPTION_KEY, $log);
    }

    /**
     * Read the debug log.
     *
     * @return array
     * @since 1.2
     */
    public function get_log(): array {
        $log = get_option(self::LOG_OPTION_KEY, []);
        return is_array($log) ? $log : [];
    }

    /**
     * Wipe the debug log.
     *
     * @return void
     * @since 1.2
     */
    public function clear_log(): void {
        update_option(self::LOG_OPTION_KEY, []);
    }

    /**
     * @param mixed $raw
     * @return bool
     * @since 1.2
     */
    private function coerce_bool($raw): bool {
        if (is_bool($raw))   return $raw;
        if (is_string($raw)) return in_array(strtolower($raw), ['yes', '1', 'true', 'on'], true);
        if (is_int($raw))    return $raw === 1;
        return false;
    }
}
