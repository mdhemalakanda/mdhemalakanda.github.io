<?php
namespace FSHIPPING\Migration;

use FSHIPPING\SingletonTrait;

/**
 * Checkout safety net.
 *
 * Wraps any "talk to FedEx" call so a transient outage / bad credential /
 * unexpected exception doesn't take down the live checkout. If the
 * primary call throws or returns an empty sentinel, the configured
 * fallback is used instead and the incident is logged (plus surfaced in
 * the staging-mode debug log when staging is ON).
 *
 * Directly targets the most common 1-star review theme on competitor
 * plugins: "the plugin crashed my whole checkout".
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class SafetyNet {
    use SingletonTrait;

    /**
     * Run a primary callable and fall back on empty/throwing results.
     *
     * @template T
     * @param callable():T $primary   The risky operation.
     * @param T            $fallback  Value to use when the primary fails.
     * @param string       $label     Short channel label for logs.
     * @return T
     * @since 1.2
     */
    public function with_fallback(callable $primary, $fallback, string $label = 'unknown') {
        try {
            $result = $primary();
            if ($this->is_empty($result)) {
                $this->report($label, 'empty_result', ['result_type' => gettype($result)]);
                return $fallback;
            }
            return $result;
        } catch (\Throwable $e) {
            $this->report($label, 'exception', [
                'message' => $e->getMessage(),
                'class'   => get_class($e),
            ]);
            return $fallback;
        }
    }

    /**
     * Log a safety-net trigger to error_log + staging debug log (if enabled).
     *
     * @param string $label
     * @param string $reason
     * @param array  $context
     * @return void
     * @since 1.2
     */
    private function report(string $label, string $reason, array $context): void {
        $payload = array_merge(['reason' => $reason], $context);
        StagingMode::instance()->debug_log('safety_net:' . $label, $payload);
    }

    /**
     * True when the result should trigger a fallback.
     *
     * @param mixed $value
     * @return bool
     * @since 1.2
     */
    private function is_empty($value): bool {
        if ($value === null || $value === false || $value === '' || $value === 0 || $value === '0') {
            return true;
        }
        if (is_array($value) && count($value) === 0) {
            return true;
        }
        return false;
    }
}
