<?php
namespace FSHIPPING\Migration;

use FSHIPPING\Utils\Helper;
use Teamz\Wp\Kit\Http\BaseClient;

/**
 * Per-API health probe against FedEx sandbox.
 *
 * Consumes a caller-supplied access token (not Authorization::instance())
 * so callers (CLI probe, tests) can hit FedEx with a token that is not
 * the cached saved-credentials token. Extends the kit's BaseClient for consistent
 * JSON request handling, logging, and WP_Error guarding.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class SandboxPing extends BaseClient {
    protected string $log_source = 'fshipping_sandbox_ping';

    /** Caller-supplied bearer token for the current ping batch. */
    private string $current_token = '';

    /** Target environment for the current ping batch. */
    private string $current_environment = 'sandbox';

    /**
     * Run a set of probes against the token.
     *
     * @param string $access_token OAuth bearer token.
     * @param string $environment  'sandbox' or 'production'.
     * @param array<int,array{id:string,label:string,path:string,method?:string,body?:array}>|null $probes Override default probes.
     * @return array<int,array{
     *     id:string,label:string,ok:bool,http_status:int,latency_ms:int,error_code:string,error_desc:string
     * }>
     * @since 1.2
     */
    public function ping(string $access_token, string $environment = 'sandbox', ?array $probes = null): array {
        if ($access_token === '') {
            return [];
        }

        $this->current_token       = $access_token;
        $this->current_environment = $environment === 'production' ? 'production' : 'sandbox';

        $probes  = $probes ?? $this->default_probes();
        $results = [];
        foreach ($probes as $probe) {
            $results[] = $this->run_probe($probe);
        }

        $this->current_token       = '';
        $this->current_environment = 'sandbox';
        return $results;
    }

    /**
     * Cheap zero-state probes FedEx sandbox accepts without customer context.
     *
     * @return array<int,array{id:string,label:string,path:string,method:string,body:array}>
     * @since 1.2
     */
    public function default_probes(): array {
        return [
            [
                'id' => 'postal_validation', 'label' => 'Postal Code Validation',
                'path' => '/country/v1/postal/validate', 'method' => 'POST',
                'body' => ['carrierCode' => 'FDXE', 'countryCode' => 'US', 'postalCode' => '38116'],
            ],
            [
                'id' => 'address_validation', 'label' => 'Address Validation',
                'path' => '/address/v1/addresses/resolve', 'method' => 'POST',
                'body' => ['addressesToValidate' => [[
                    'address' => [
                        'streetLines'         => ['7372 PARKRIDGE BLVD'],
                        'city'                => 'IRVING',
                        'stateOrProvinceCode' => 'TX',
                        'postalCode'          => '75063-8659',
                        'countryCode'         => 'US',
                    ],
                ]]],
            ],
            [
                'id' => 'service_availability', 'label' => 'Service Availability',
                'path' => '/availability/v1/services', 'method' => 'POST',
                'body' => ['requestedShipment' => [
                    'shipper'       => ['address' => ['postalCode' => '38116', 'countryCode' => 'US']],
                    'recipient'     => ['address' => ['postalCode' => '10001', 'countryCode' => 'US']],
                    'pickupType'    => 'USE_SCHEDULED_PICKUP',
                    'shipDateStamp' => gmdate('Y-m-d'),
                    'requestedPackageLineItems' => [[
                        'weight'     => ['units' => 'LB', 'value' => '1'],
                        'dimensions' => ['length' => 10, 'width' => 10, 'height' => 10, 'units' => 'IN'],
                    ]],
                ]],
            ],
        ];
    }

    /**
     * Use the caller-supplied token for this batch instead of Authorization.
     *
     * @return string
     * @since 1.2
     */
    protected function auth_header(): string {
        return $this->current_token !== '' ? 'Bearer ' . $this->current_token : '';
    }

    /**
     * Allow production override; otherwise fall back to the saved env.
     *
     * @return string
     * @since 1.2
     */
    protected function base_url(): string {
        if ($this->current_environment === 'production') {
            return 'https://apis.fedex.com';
        }
        if ($this->current_environment === 'sandbox') {
            return 'https://apis-sandbox.fedex.com';
        }
        return Helper::instance()->get_base_url();
    }

    /**
     * Add X-locale (same pattern as other HTTP clients) and ensure JSON.
     *
     * @param string $auth
     * @return array
     * @since 1.2
     */
    protected function build_headers(string $auth): array {
        return parent::build_headers($auth) + ['X-locale' => 'en_US'];
    }

    /**
     * Fire one probe through the kit's raw request plumbing, capturing
     * latency + HTTP status so the UI can render a per-API traffic light.
     *
     * @param array{id:string,label:string,path:string,method?:string,body?:array} $probe
     * @return array{id:string,label:string,ok:bool,http_status:int,latency_ms:int,error_code:string,error_desc:string}
     * @since 1.2
     */
    private function run_probe(array $probe): array {
        $row = [
            'id'          => (string) ($probe['id']    ?? ''),
            'label'       => (string) ($probe['label'] ?? ''),
            'ok'          => false,
            'http_status' => 0,
            'latency_ms'  => 0,
            'error_code'  => '',
            'error_desc'  => '',
        ];

        $url = $this->base_url() . ($probe['path'] ?? '');
        $args = [
            'method'  => strtoupper($probe['method'] ?? 'POST'),
            'timeout' => 20,
            'headers' => $this->build_headers($this->auth_header()),
            'body'    => wp_json_encode($probe['body'] ?? []),
        ];

        $start    = microtime(true);
        $response = wp_remote_request($url, $args);
        $row['latency_ms'] = (int) round((microtime(true) - $start) * 1000);

        if (is_wp_error($response)) {
            $row['error_code'] = 'transport_error';
            $row['error_desc'] = $response->get_error_message();
            return $row;
        }

        $row['http_status'] = (int) wp_remote_retrieve_response_code($response);
        $decoded = json_decode(wp_remote_retrieve_body($response), true);
        $decoded = is_array($decoded) ? $decoded : [];

        if ($row['http_status'] >= 200 && $row['http_status'] < 300) {
            $row['ok'] = true;
            return $row;
        }

        $first_error = !empty($decoded['errors'][0]) && is_array($decoded['errors'][0]) ? $decoded['errors'][0] : [];
        $row['error_code'] = isset($first_error['code'])    ? (string) $first_error['code']    : 'http_' . $row['http_status'];
        $row['error_desc'] = isset($first_error['message']) ? (string) $first_error['message'] : '';
        return $row;
    }
}
