<?php
namespace FSHIPPING\Migration;

use FSHIPPING\SingletonTrait;

/**
 * Dry-run validator for a FedEx OAuth credential pair.
 *
 * Unlike Auth\Authorization (which reads saved options and caches tokens),
 * this class accepts an arbitrary client_id / client_secret / environment
 * triple and reports exactly what happened — without mutating any saved
 * settings or transients. Used by `scripts/fedex-api-probe.php`, PHPUnit,
 * and any custom tooling that needs a stateless OAuth check.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class CredentialValidator {
    use SingletonTrait;

    /**
     * Validate a credential pair against FedEx OAuth.
     *
     * @param array{client_id:string,client_secret:string,environment?:string} $creds
     * @return array{
     *     ok:bool,
     *     http_status:int,
     *     environment:string,
     *     access_token:string,
     *     expires_in:int,
     *     error_code:string,
     *     error_desc:string,
     *     transport_error:string
     * }
     * @since 1.2
     */
    public function validate(array $creds): array {
        $result = [
            'ok'              => false,
            'http_status'     => 0,
            'environment'     => 'sandbox',
            'access_token'    => '',
            'expires_in'      => 0,
            'error_code'      => '',
            'error_desc'      => '',
            'transport_error' => '',
        ];

        $client_id     = isset($creds['client_id'])     ? sanitize_text_field($creds['client_id'])     : '';
        $client_secret = isset($creds['client_secret']) ? sanitize_text_field($creds['client_secret']) : '';
        $environment   = !empty($creds['environment']) && $creds['environment'] === 'production'
            ? 'production'
            : 'sandbox';
        $result['environment'] = $environment;

        if ($client_id === '' || $client_secret === '') {
            $result['error_code'] = 'missing_credentials';
            $result['error_desc'] = 'client_id and client_secret are both required.';
            return $result;
        }

        $endpoint = $this->endpoint_for($environment);
        $response = wp_remote_post($endpoint, [
            'method'  => 'POST',
            'timeout' => 30,
            'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
            'body'    => [
                'grant_type'    => 'client_credentials',
                'client_id'     => $client_id,
                'client_secret' => $client_secret,
            ],
        ]);

        if (is_wp_error($response)) {
            $result['transport_error'] = $response->get_error_message();
            $result['error_code']      = 'transport_error';
            $result['error_desc']      = 'Could not reach FedEx OAuth endpoint.';
            return $result;
        }

        $result['http_status'] = (int) wp_remote_retrieve_response_code($response);
        $decoded = json_decode(wp_remote_retrieve_body($response), true);
        $decoded = is_array($decoded) ? $decoded : [];

        if (!empty($decoded['access_token'])) {
            $result['ok']           = true;
            $result['access_token'] = (string) $decoded['access_token'];
            $result['expires_in']   = isset($decoded['expires_in']) ? (int) $decoded['expires_in'] : 0;
            return $result;
        }

        // FedEx returns `errors[]` on auth failure; surface the first one.
        $first_error = !empty($decoded['errors'][0]) && is_array($decoded['errors'][0])
            ? $decoded['errors'][0]
            : [];
        $result['error_code'] = isset($first_error['code'])    ? (string) $first_error['code']    : 'unknown_error';
        $result['error_desc'] = isset($first_error['message']) ? (string) $first_error['message'] : 'FedEx rejected these credentials.';

        return $result;
    }

    /**
     * Resolve the OAuth endpoint for a given environment.
     *
     * @param string $environment Either 'sandbox' or 'production'.
     * @return string
     * @since 1.2
     */
    private function endpoint_for(string $environment): string {
        $base = $environment === 'production'
            ? 'https://apis.fedex.com'
            : 'https://apis-sandbox.fedex.com';
        return $base . '/oauth/token';
    }
}
