<?php
namespace FSHIPPING\CPT;

use FSHIPPING\OpenShip\Draft;
use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\OrderMeta;
/**
 * This CPT will use for manage all shipments.
 * 
 * @since 1.0
 */
class Shipments {
    use SingletonTrait;
    private const BULK_ACTION_CANCEL_AND_TRASH = 'fshipping_cancel_and_trash';
    private const BULK_ACTION_MARK_PRINTED = 'fshipping_mark_label_printed';
    private const BULK_ACTION_MARK_NOT_PRINTED = 'fshipping_mark_label_not_printed';

    public function init() {
        add_action('init', array($this, 'create_shipment_cpt'));
        add_action('pre_get_posts', array($this, 'search_shipments_by_tracking_id'));
        add_filter('manage_fedex_shipping_posts_columns', array($this, 'set_shipping_columns'));
        add_action('manage_fedex_shipping_posts_custom_column', array($this, 'display_shipping_columns_content'), 10, 2);
        add_action('admin_footer', array($this, 'display_track_popup'));
        add_action('admin_init', array($this, 'maybe_redirect_after_trash_or_restore'));
        add_filter('wp_untrash_post_status', array($this, 'force_untrash_publish_status'), 10, 3);
        add_filter('map_meta_cap', array($this, 'restrict_delete_for_active_shipments'), 10, 4);
        add_filter('bulk_actions-edit-fedex_shipping', array($this, 'register_bulk_actions'));
        add_filter('handle_bulk_actions-edit-fedex_shipping', array($this, 'handle_bulk_actions'), 10, 3);
        add_action('admin_notices', array($this, 'render_bulk_action_notice'));
        add_filter('post_class', array($this, 'add_row_state_classes'), 10, 3);
        add_action('before_delete_post', array($this, 'maybe_delete_linked_order'), 10, 2);
        add_filter('post_row_actions', function ($actions, $post) {
            if ($post->post_type === 'fedex_shipping') {
                $order_id = get_post_meta($post->ID, '_fedex_shipment_order_id', true);
                if ($order_id) {
                    $actions['view'] = '<a href="' . admin_url('post.php?post=' . $order_id . '&action=edit') . '">View Order</a>';
                }
            }
            return $actions;
        }, 10, 2);
    }

    public function display_track_popup() {
        ?>
        <div class="display-fedex-shipping-poup">
        </div>
        <?php
    }

    public function set_shipping_columns($columns) {
        $columns['tracking_number'] = esc_html__( 'Tracking ID', 'teamzlab-fedex' );
        $columns['service_type']    = esc_html__( 'Service', 'teamzlab-fedex' );
        $columns['fshipping_box_info'] = esc_html__( 'Box info', 'teamzlab-fedex' );
        $columns['total_charge']    = esc_html__( 'Total Charge', 'teamzlab-fedex' );
        $columns['shipping_label']  = esc_html__( 'Label', 'teamzlab-fedex' );
        $columns['label_printed']   = esc_html__( 'Label Printed', 'teamzlab-fedex' );
        $columns['cancel_shipment']  = esc_html__( 'Action', 'teamzlab-fedex' );
        $columns['track_shipment']  = esc_html__( 'Track Parcel', 'teamzlab-fedex' );
        $columns['pickup']          = esc_html__( 'Pickup', 'teamzlab-fedex' );
        $columns['return_label']    = esc_html__( 'Return', 'teamzlab-fedex' );
        $columns['trade_documents'] = esc_html__( 'Trade docs', 'teamzlab-fedex' );
        $columns['fshipping_status'] = esc_html__( 'Status', 'teamzlab-fedex' );
        $columns['spod']            = esc_html__( 'SPOD', 'teamzlab-fedex' );

        return $columns;
    }

    /**
     * Render a compact colored badge for the shipment's current
     * lifecycle state. Merges three meta sources:
     *   _fshipping_customs_state   → customs hold / in progress
     *   _fshipping_aiv_last_event  → the last AIV event code
     *   _fshipping_tracking_state  → cached Basic Track status
     *
     * @param int $post_id
     * @return string HTML snippet (already-escaped).
     * @since 1.1
     */
    public function render_status_badge($post_id) {
        $customs_state = get_post_meta($post_id, '_fshipping_customs_state', true);
        $aiv_event     = get_post_meta($post_id, '_fshipping_aiv_last_event', true);
        $track_state   = get_post_meta($post_id, '_fshipping_tracking_state', true);

        // Customs hold takes precedence — it's the most important
        // state for the merchant to act on.
        if ('hold' === $customs_state) {
            return $this->badge('danger', __('Customs hold', 'teamzlab-fedex'));
        }
        if ('in_progress' === $customs_state) {
            return $this->badge('warn', __('Customs', 'teamzlab-fedex'));
        }

        // Fall through to last AIV event.
        $code = '';
        $desc = '';
        if (is_array($aiv_event) && !empty($aiv_event['status'])) {
            $code = strtoupper((string) $aiv_event['status']);
            $desc = (string) ($aiv_event['description'] ?? '');
        } elseif (is_array($track_state) && !empty($track_state['status'])) {
            return $this->badge('info', (string) $track_state['status']);
        }

        switch ($code) {
            case 'DL':
            case 'DELIVERED':
                return $this->badge('ok', __('Delivered', 'teamzlab-fedex'));
            case 'OD':
            case 'OUT_FOR_DELIVERY':
                return $this->badge('info', __('Out for delivery', 'teamzlab-fedex'));
            case 'IT':
            case 'IN_TRANSIT':
                return $this->badge('info', __('In transit', 'teamzlab-fedex'));
            case 'DE':
            case 'EX':
            case 'DELIVERY_EXCEPTION':
                return $this->badge('danger', __('Exception', 'teamzlab-fedex'));
            case 'OC':
                return $this->badge('', __('Label created', 'teamzlab-fedex'));
            case '':
                return $this->badge('', __('Pending', 'teamzlab-fedex'));
        }
        return $this->badge('', esc_html($desc ?: $code));
    }

    /**
     * Status badge using the admin design system variants.
     *
     * @param string $variant ok|warn|danger|info|'' (neutral)
     * @param string $label
     * @return string
     * @since 1.1
     */
    private function badge($variant, $label) {
        $allowed = array('ok', 'warn', 'danger', 'info', '');
        if (!in_array((string) $variant, $allowed, true)) {
            $variant = '';
        }
        $class = 'fshipping-status-badge' . ($variant !== '' ? ' fshipping-status-badge--' . $variant : '');
        return sprintf(
            '<span class="%1$s">%2$s</span>',
            esc_attr($class),
            $label // Already escaped by callers / esc_html at the single dynamic call site.
        );
    }

    /**
     * Display the meta data in the CPT list table
     */
    public function display_shipping_columns_content($column, $post_id) {
        $tracking_number = get_post_meta($post_id, '_tracking_number', true);
        switch ($column) {
            case 'tracking_number':
                echo '<strong>' . esc_html($tracking_number ?: '–') . '</strong>';
                break;

            case 'service_type':
                $service = (string) get_post_meta($post_id, '_service_type', true);
                if ($service === '') {
                    echo '–';
                    break;
                }
                // Same human-readable labels the settings dropdowns use; fall
                // back to a prettified code for services missing from the map.
                $service_labels = \FSHIPPING\Utils\Helper::instance()->get_field_options('service_type');
                $service_label  = isset($service_labels[$service])
                    ? $service_labels[$service]
                    : ucwords(strtolower(str_replace('_', ' ', $service)));
                echo '<span class="fshipping-service-label">' . esc_html($service_label) . '</span>';
                break;

            case 'fshipping_box_info':
                $order_id = (int) get_post_meta($post_id, '_fedex_shipment_order_id', true);
                if ($order_id < 1) {
                    echo '–';
                    break;
                }
                $raw = (string) OrderMeta::get($order_id, Draft::META_PRODUCT_BOX_DISPLAY);
                $decoded = json_decode($raw, true);
                if (!is_array($decoded) || empty($decoded)) {
                    echo '–';
                    break;
                }
                echo '<div class="fshipping-box-info-column">';
                foreach ($decoded as $block) {
                    if (!is_array($block)) {
                        continue;
                    }
                    $box_title = isset($block['box']) ? sanitize_text_field((string) $block['box']) : '';
                    if ($box_title === '') {
                        continue;
                    }
                    echo '<div class="fshipping-box-info-item">';
                    echo '<strong>' . esc_html($box_title) . '</strong><br />';
                    $products = isset($block['products']) && is_array($block['products']) ? $block['products'] : [];
                    foreach ($products as $p) {
                        if (!is_array($p)) {
                            continue;
                        }
                        $pname = isset($p['name']) ? sanitize_text_field((string) $p['name']) : '';
                        $pqty = isset($p['qty']) ? absint($p['qty']) : 0;
                        if ($pname === '' || $pqty < 1) {
                            continue;
                        }
                        echo esc_html($pname) . ' * ' . esc_html($pqty) . '<br />';
                    }
                    echo '</div>';
                }
                echo '</div>';
                break;

            case 'ship_date':
                $date = get_post_meta($post_id, '_ship_date', true);
                echo $date ? esc_html(date_i18n(get_option('date_format'), strtotime($date))) : '–';
                break;

            case 'delivery_date':
                $date = get_post_meta($post_id, '_delivery_date', true);
                echo $date ? esc_html(date_i18n(get_option('date_format'), strtotime($date))) : '–';
                break;

            case 'total_charge':
                $order_id        = get_post_meta($post_id, '_fedex_shipment_order_id', true);
                if ($order_id) {
                    $order  = wc_get_order($order_id);
                    $charge = $order ? $order->get_total() : 0;
                } else {
                    $charge = 0;
                }
                echo wp_kses(
                    $charge ? wc_price( (float) $charge ) : 0,
                    [
                        'span'  => [ 'class' => true ],
                        'bdi'   => [],
                        'small' => [ 'class' => true ],
                    ]
                );
            break;

            case 'shipping_label':
                $order_id        = get_post_meta($post_id, '_fedex_shipment_order_id', true);
                $url = $order_id ? (string) OrderMeta::get($order_id, '_fedex_label_url') : '';
                if ($url === '') {
                    $url = (string) get_post_meta($post_id, '_shipping_label', true);
                }
                if ($url !== '') {
                    echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer" class="button button-small">'
                        . esc_html__('View Label', 'teamzlab-fedex')
                        . '</a>';
                }

                $piece_labels = $this->get_package_label_rows_for_shipment((int) $post_id, (int) $order_id);
                if (empty($piece_labels)) {
                    break;
                }

                $primary_normalized = $url !== '' ? untrailingslashit((string) $url) : '';
                $printed = 0;
                $box_name_counts = [];
                echo '<div class="fshipping-package-label-list">';
                foreach ($piece_labels as $idx => $row) {
                    $file_url = isset($row['file_url']) ? (string) $row['file_url'] : '';
                    if ($file_url === '') {
                        continue;
                    }
                    if ($primary_normalized !== '' && untrailingslashit($file_url) === $primary_normalized) {
                        continue;
                    }
                    $printed++;
                    $label_text = sprintf(
                        /* translators: %d: package row number */
                        __('Box %d label', 'teamzlab-fedex'),
                        $printed
                    );
                    $box_name = !empty($row['box_name']) ? sanitize_text_field((string) $row['box_name']) : '';
                    if ($box_name !== '') {
                        if (!isset($box_name_counts[$box_name])) {
                            $box_name_counts[$box_name] = 0;
                        }
                        $box_name_counts[$box_name]++;
                        $label_text = sprintf(
                            /* translators: 1: box name 2: sequence index for that box name */
                            __('%1$s %2$d label', 'teamzlab-fedex'),
                            $box_name,
                            (int) $box_name_counts[$box_name]
                        );
                    } elseif (!empty($row['sequence'])) {
                        $label_text = sprintf(
                            /* translators: %s: package sequence from FedEx */
                            __('Box %s label', 'teamzlab-fedex'),
                            (string) $row['sequence']
                        );
                    } elseif (!empty($row['tracking'])) {
                        $label_text = sprintf(
                            /* translators: %s: package tracking number */
                            __('Label %s', 'teamzlab-fedex'),
                            (string) $row['tracking']
                        );
                    }
                    echo '<a href="' . esc_url($file_url) . '" target="_blank" rel="noopener noreferrer" class="button button-small fshipping-package-label-link">'
                        . esc_html($label_text)
                        . '</a>';
                }
                echo '</div>';
                break;
            case 'label_printed':
                $printed = (string) get_post_meta($post_id, '_fshipping_label_printed', true);
                $checked = ('yes' === $printed);
                echo '<label class="fshipping-toggle-switch" title="' . esc_attr__('Mark label as printed', 'teamzlab-fedex') . '">';
                echo '<input type="checkbox" class="fshipping-label-printed-toggle" data-shipment_id="' . esc_attr($post_id) . '" ' . checked($checked, true, false) . ' />';
                echo '<span class="fshipping-toggle-slider" aria-hidden="true"></span>';
                echo '</label>';
                echo '<span class="fshipping-toggle-text">' . esc_html($checked ? __('Printed', 'teamzlab-fedex') : __('Not printed', 'teamzlab-fedex')) . '</span>';
                break;
            case 'cancel_shipment':
                $order_status = get_post_meta($post_id, 'order_status', true);
                if( 'canceled' === $order_status ) {
                    echo '<button type="button" class="button button-small button-danger disabled" data-tracking_id="' . esc_attr($tracking_number) . '">' . esc_html__('Canceled', 'teamzlab-fedex') . '</button>';
                } else {
                    echo '<button type="button" class="button button-small button-danger fedex-cancel-shipment" data-tracking_id="' . esc_attr($tracking_number) . '">' . esc_html__('Cancel', 'teamzlab-fedex') . '</button>';
                }
                break;
            case 'track_shipment':
                echo '<button type="button" class="button button-small fedex-shipping-track" data-tracking_id="' . esc_attr($tracking_number) . '">' . esc_html__('Track', 'teamzlab-fedex') . '</button>';
                break;
            case 'pickup':
                $confirmation = get_post_meta($post_id, '_fshipping_pickup_confirmation', true);
                if (!empty($confirmation)) {
                    echo '<span class="fshipping-pickup-confirmation" title="' . esc_attr__('Scheduled — click to cancel', 'teamzlab-fedex') . '">' . esc_html($confirmation) . '</span> ';
                    echo '<button type="button" class="button button-small fshipping-cancel-pickup" data-shipment_id="' . esc_attr($post_id) . '">' . esc_html__('Cancel', 'teamzlab-fedex') . '</button>';
                } else {
                    echo '<button type="button" class="button button-small fshipping-request-pickup" data-shipment_id="' . esc_attr($post_id) . '">' . esc_html__('Request pickup', 'teamzlab-fedex') . '</button>';
                }
                break;
            case 'fshipping_status':
                echo wp_kses_post( $this->render_status_badge( $post_id ) ); // badge() labels are escaped at their call sites.
                break;
            case 'spod':
                // Either an already-downloaded PDF on our disk, or the
                // raw FedEx-hosted URL extracted from a Track response.
                $pdf = get_post_meta($post_id, '_fshipping_spod_pdf_url', true);
                $url = get_post_meta($post_id, '_fshipping_spod_url',     true);
                if (!empty($pdf)) {
                    echo '<a href="' . esc_url($pdf) . '" target="_blank" class="button button-small">' . esc_html__('SPOD PDF', 'teamzlab-fedex') . '</a>';
                } elseif (!empty($tracking_number)) {
                    echo '<button type="button" class="button button-small fshipping-download-spod" data-tracking_id="' . esc_attr($tracking_number) . '">' . esc_html__('Download SPOD', 'teamzlab-fedex') . '</button>';
                } else {
                    echo '—';
                }
                break;
            case 'return_label':
                $order_id      = get_post_meta($post_id, '_fedex_shipment_order_id', true);
                $return_url    = $order_id ? OrderMeta::get($order_id, '_fshipping_return_label_url') : '';
                if (!empty($return_url)) {
                    echo '<a href="' . esc_url($return_url) . '" target="_blank" class="button button-small">' . esc_html__('Return label', 'teamzlab-fedex') . '</a>';
                } elseif (!empty($order_id)) {
                    echo '<button type="button" class="button button-small fshipping-create-return" data-shipment_id="' . esc_attr($post_id) . '" data-order_id="' . esc_attr($order_id) . '">' . esc_html__('Create return', 'teamzlab-fedex') . '</button>';
                } else {
                    echo '—';
                }
                break;
            case 'trade_documents':
                $tracking = (string) get_post_meta($post_id, '_tracking_number', true);
                $status = strtolower((string) get_post_meta($post_id, 'order_status', true));
                $uploads = $this->get_trade_document_upload_rows($post_id);
                $last_error = (string) get_post_meta($post_id, '_fshipping_trade_doc_last_error', true);
                $disabled = ('canceled' === $status || '' === $tracking) ? ' disabled' : '';
                echo '<button type="button" class="button button-small fshipping-toggle-trade-docs" data-shipment_id="' . esc_attr($post_id) . '" data-tracking="' . esc_attr($tracking) . '"' . esc_attr($disabled) . '>' . esc_html__('Upload docs', 'teamzlab-fedex') . '</button>';
                if (!empty($uploads)) {
                    /* translators: %d: number of uploaded trade documents. */
                    echo '<span class="fshipping-trade-docs-state fshipping-trade-docs-state-ok">' . esc_html(sprintf(__('Uploaded: %d', 'teamzlab-fedex'), count($uploads))) . '</span>';
                } elseif (!empty($last_error)) {
                    echo '<span class="fshipping-trade-docs-state fshipping-trade-docs-state-err">' . esc_html__('Failed', 'teamzlab-fedex') . '</span>';
                } else {
                    echo '<span class="fshipping-trade-docs-state">' . esc_html__('Not uploaded', 'teamzlab-fedex') . '</span>';
                }
                if (!empty($last_error)) {
                    echo '<div class="fshipping-trade-docs-inline-error">' . esc_html($last_error) . '</div>';
                }
                break;
        }
    }

    /**
     * @param int $post_id
     * @return array<int,array<string,mixed>>
     */
    private function get_trade_document_upload_rows($post_id) {
        $raw = get_post_meta($post_id, '_fshipping_trade_doc_upload_ids', true);
        if (is_array($raw)) {
            return $raw;
        }
        if (!is_string($raw) || '' === $raw) {
            return [];
        }
        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * Read saved per-package label files from shipment/order meta.
     *
     * @param int $post_id
     * @param int $order_id
     * @return array<int,array<string,mixed>>
     */
    private function get_package_label_rows_for_shipment($post_id, $order_id) {
        $raw = (string) get_post_meta($post_id, '_fshipping_package_label_files', true);
        if ($raw === '' && $order_id > 0) {
            $raw = (string) OrderMeta::get($order_id, '_fshipping_package_label_files');
        }
        if ($raw === '') {
            return [];
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return [];
        }
        $rows = [];
        foreach ($decoded as $row) {
            if (!is_array($row) || empty($row['file_url'])) {
                continue;
            }
            $rows[] = $row;
        }
        return $rows;
    }

    /**
     * Only allow trash/delete for canceled FedEx shipments (or already in trash).
     *
     * @param array  $caps
     * @param string $cap
     * @param int    $user_id
     * @param array  $args
     * @return array
     */
    public function restrict_delete_for_active_shipments($caps, $cap, $user_id, $args) {
        if ('delete_post' !== $cap || empty($args[0])) {
            return $caps;
        }

        $post_id = (int) $args[0];
        $post = get_post($post_id);
        if (!$post || 'fedex_shipping' !== $post->post_type) {
            return $caps;
        }

        if ('trash' === $post->post_status) {
            return $caps;
        }

        $shipment_status = (string) get_post_meta($post_id, 'order_status', true);
        if ('canceled' !== $shipment_status) {
            return ['do_not_allow'];
        }

        return $caps;
    }

    /**
     * Register FedEx shipment bulk actions.
     *
     * @param array $actions
     * @return array
     */
    public function register_bulk_actions($actions) {
        $actions[self::BULK_ACTION_CANCEL_AND_TRASH] = __('Cancel + Move to Trash', 'teamzlab-fedex');
        $actions[self::BULK_ACTION_MARK_PRINTED] = __('Mark as Label Printed', 'teamzlab-fedex');
        $actions[self::BULK_ACTION_MARK_NOT_PRINTED] = __('Mark as Label Not Printed', 'teamzlab-fedex');
        return $actions;
    }

    /**
     * Handle FedEx shipment bulk actions.
     *
     * @param string $redirect_to
     * @param string $doaction
     * @param array  $post_ids
     * @return string
     */
    public function handle_bulk_actions($redirect_to, $doaction, $post_ids) {
        if ('untrash' === $doaction) {
            return add_query_arg(
                [
                    'post_type'              => 'fedex_shipping',
                    'fshipping_restored'     => count((array) $post_ids),
                    'fshipping_notice_nonce' => wp_create_nonce('fshipping_bulk_action_notice'),
                ],
                admin_url('edit.php')
            );
        }

        if ('trash' === $doaction) {
            return add_query_arg(
                [
                    'post_type'              => 'fedex_shipping',
                    'post_status'            => 'trash',
                    'fshipping_trashed'      => count((array) $post_ids),
                    'fshipping_notice_nonce' => wp_create_nonce('fshipping_bulk_action_notice'),
                ],
                admin_url('edit.php')
            );
        }

        if (self::BULK_ACTION_CANCEL_AND_TRASH !== $doaction) {
            if (self::BULK_ACTION_MARK_PRINTED !== $doaction && self::BULK_ACTION_MARK_NOT_PRINTED !== $doaction) {
                return $redirect_to;
            }

            $post_ids = array_map('intval', (array) $post_ids);
            $updated = 0;
            $failed = 0;
            $mark_value = (self::BULK_ACTION_MARK_PRINTED === $doaction) ? 'yes' : 'no';

            foreach ($post_ids as $post_id) {
                $post = get_post($post_id);
                if (!$post || 'fedex_shipping' !== $post->post_type) {
                    continue;
                }

                $current = (string) get_post_meta($post_id, '_fshipping_label_printed', true);
                if ($current === $mark_value) {
                    $updated++;
                    continue;
                }

                $ok = update_post_meta($post_id, '_fshipping_label_printed', $mark_value);
                if (false !== $ok) {
                    $updated++;
                } else {
                    $failed++;
                }
            }

            return add_query_arg([
                'post_type'                => 'fedex_shipping',
                'fshipping_printed_done'   => $updated,
                'fshipping_printed_failed' => $failed,
                'fshipping_printed_mode'   => ('yes' === $mark_value ? 'printed' : 'not_printed'),
                'fshipping_notice_nonce'   => wp_create_nonce('fshipping_bulk_action_notice'),
            ], admin_url('edit.php'));
        }

        $post_ids = array_map('intval', (array) $post_ids);
        $processed = 0;
        $failed = 0;

        foreach ($post_ids as $post_id) {
            $post = get_post($post_id);
            if (!$post || 'fedex_shipping' !== $post->post_type) {
                continue;
            }

            $tracking = (string) get_post_meta($post_id, '_tracking_number', true);
            $status = (string) get_post_meta($post_id, 'order_status', true);

            if ('canceled' !== $status) {
                $canceled = false;
                if ($tracking !== '') {
                    $canceled = \FSHIPPING\HTTP\Shipment::instance()->cancel_shipment($tracking);
                }
                if (!$canceled) {
                    $failed++;
                    continue;
                }
            }

            if (wp_trash_post($post_id)) {
                $processed++;
            } else {
                $failed++;
            }
        }

        return add_query_arg([
            'post_type'                    => 'fedex_shipping',
            'post_status'                  => 'trash',
            'fshipping_bulk_trash_done'   => $processed,
            'fshipping_bulk_trash_failed' => $failed,
            'fshipping_notice_nonce'      => wp_create_nonce('fshipping_bulk_action_notice'),
        ], admin_url('edit.php'));
    }

    /**
     * Show result notice for bulk cancel+trash.
     *
     * @return void
     */
    public function render_bulk_action_notice() {
        if (!isset($_GET['fshipping_notice_nonce'])
            || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['fshipping_notice_nonce'])), 'fshipping_bulk_action_notice')
        ) {
            return;
        }
        if (!isset($_GET['post_type']) || 'fedex_shipping' !== sanitize_text_field(wp_unslash($_GET['post_type']))) {
            return;
        }
        if (!isset($_GET['fshipping_bulk_trash_done']) && !isset($_GET['fshipping_bulk_trash_failed']) && !isset($_GET['fshipping_printed_done']) && !isset($_GET['fshipping_printed_failed'])) {
            return;
        }

        $is_printed_notice = isset($_GET['fshipping_printed_done']) || isset($_GET['fshipping_printed_failed']);
        if ($is_printed_notice) {
            $done = isset($_GET['fshipping_printed_done']) ? (int) $_GET['fshipping_printed_done'] : 0;
            $failed = isset($_GET['fshipping_printed_failed']) ? (int) $_GET['fshipping_printed_failed'] : 0;
            $mode = isset($_GET['fshipping_printed_mode']) ? sanitize_text_field(wp_unslash($_GET['fshipping_printed_mode'])) : 'printed';
            $label = ('not_printed' === $mode) ? __('not printed', 'teamzlab-fedex') : __('printed', 'teamzlab-fedex');
            $class = $failed > 0 ? 'notice notice-warning' : 'notice notice-success';
            $message = sprintf(
                /* translators: 1: number of shipments updated 2: new label state (printed or not printed) 3: number of failures. */
                __('Label state updated. Marked %1$d shipment(s) as %2$s. Failed: %3$d.', 'teamzlab-fedex'),
                $done,
                $label,
                $failed
            );
        } else {
            $done = isset($_GET['fshipping_bulk_trash_done']) ? (int) $_GET['fshipping_bulk_trash_done'] : 0;
            $failed = isset($_GET['fshipping_bulk_trash_failed']) ? (int) $_GET['fshipping_bulk_trash_failed'] : 0;
            $class = $failed > 0 ? 'notice notice-warning' : 'notice notice-success';
            $message = sprintf(
                /* translators: 1: number of shipments moved to trash 2: number of failures. */
                __('FedEx bulk action complete. Moved to trash: %1$d. Failed: %2$d.', 'teamzlab-fedex'),
                $done,
                $failed
            );
        }

        echo '<div class="' . esc_attr($class) . '"><p>' . esc_html($message) . '</p></div>';
    }

    /**
     * Add visual state classes to shipment list rows.
     *
     * @param array        $classes
     * @param string|array $class
     * @param int          $post_id
     * @return array
     */
    public function add_row_state_classes($classes, $class, $post_id) {
        if (!is_admin()) {
            return $classes;
        }

        $post = get_post((int) $post_id);
        if (!$post || 'fedex_shipping' !== $post->post_type) {
            return $classes;
        }

        $order_status = (string) get_post_meta((int) $post_id, 'order_status', true);
        if ('canceled' === $order_status) {
            $classes[] = 'fshipping-row-canceled';
            return $classes;
        }

        $printed = (string) get_post_meta((int) $post_id, '_fshipping_label_printed', true);
        if ('yes' === $printed) {
            $classes[] = 'fshipping-row-printed';
        }

        return $classes;
    }

    /**
     * Auto-redirect UX:
     * - after trash action -> go to Trash view
     * - after restore action -> go to Published view
     *
     * @return void
     */
    public function maybe_redirect_after_trash_or_restore() {
        if (!is_admin()) {
            return;
        }

        // Nonce for the redirects generated by this plugin's own bulk actions
        // (see handle_bulk_actions()). Core list-table trash/restore redirects
        // carry no plugin nonce and keep working via the `trashed`/`untrashed`
        // checks below.
        $has_valid_nonce = isset($_GET['fshipping_notice_nonce'])
            && wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['fshipping_notice_nonce'])), 'fshipping_bulk_action_notice');

        $post_type = isset($_GET['post_type']) ? sanitize_text_field(wp_unslash($_GET['post_type'])) : '';
        if ('fedex_shipping' !== $post_type) {
            return;
        }

        $post_status = isset($_GET['post_status']) ? sanitize_text_field(wp_unslash($_GET['post_status'])) : '';
        $is_trash_view = ('trash' === $post_status);

        // On restore from Trash, jump back to Published.
        if ($is_trash_view && (isset($_GET['untrashed']) || ($has_valid_nonce && isset($_GET['fshipping_restored'])))) {
            wp_safe_redirect(add_query_arg(['post_type' => 'fedex_shipping'], admin_url('edit.php')));
            exit;
        }

        // On trash from Published, jump into Trash.
        if (!$is_trash_view && (isset($_GET['trashed']) || ($has_valid_nonce && (isset($_GET['fshipping_trashed']) || isset($_GET['fshipping_bulk_trash_done']))))) {
            wp_safe_redirect(add_query_arg(['post_type' => 'fedex_shipping', 'post_status' => 'trash'], admin_url('edit.php')));
            exit;
        }
    }

    /**
     * When FedEx shipment is permanently deleted, delete linked Woo order too.
     *
     * @param int     $post_id
     * @param WP_Post $post
     * @return void
     */
    public function maybe_delete_linked_order($post_id, $post) {
        if (!$post || 'fedex_shipping' !== $post->post_type) {
            return;
        }

        $order_id = (int) get_post_meta($post_id, '_fedex_shipment_order_id', true);
        if ($order_id <= 0) {
            return;
        }

        // Under HPOS the wp_posts row is only a `shop_order_placehold` stub:
        // wp_delete_post() would remove the stub while the real order row,
        // its addresses and its meta stay orphaned in wc_orders, and
        // WooCommerce's deletion cascade never runs. Delete through the
        // order API (HPOS-aware) and fall back to wp_delete_post() only for
        // a non-object legacy id.
        $order = function_exists('wc_get_order') ? wc_get_order($order_id) : false;
        if ($order) {
            $order->delete(true);
            return;
        }

        wp_delete_post($order_id, true);
    }

    /**
     * Restore FedEx shipments as published (never draft) from trash.
     *
     * @param string $new_status
     * @param int    $post_id
     * @param string $previous_status
     * @return string
     */
    public function force_untrash_publish_status($new_status, $post_id, $previous_status) {
        $post = get_post((int) $post_id);
        if (!$post || 'fedex_shipping' !== $post->post_type) {
            return $new_status;
        }

        return 'publish';
    }

    /**
     * Search FedEx shipments by tracking ID in admin list table.
     *
     * @param \WP_Query $query
     * @return void
     */
    public function search_shipments_by_tracking_id($query) {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }

        global $pagenow;
        if ('edit.php' !== $pagenow) {
            return;
        }

        $post_type = (string) $query->get('post_type');
        if ('fedex_shipping' !== $post_type) {
            return;
        }

        $search_term = (string) $query->get('s');
        if ('' === $search_term) {
            return;
        }

        $meta_query = (array) $query->get('meta_query');
        $meta_query[] = [
            'key'     => '_tracking_number',
            'value'   => $search_term,
            'compare' => 'LIKE',
        ];

        $query->set('meta_query', $meta_query);
        $query->set('s', '');
    }

    /**
     * Summary of create_shipment_cpt
     * 
     * @return void
     */
    public function create_shipment_cpt() {
        $label_name = esc_html__( 'Shipments & Labeling', 'teamzlab-fedex' );

        $labels = [
            'name'                  => $label_name,
            'singular_name'         => esc_html__( 'Shipment', 'teamzlab-fedex' ),
            'menu_name'             => $label_name,
            'name_admin_bar'        => esc_html__( 'Shipment', 'teamzlab-fedex' ),
            'new_item'              => esc_html__( 'New Shipment', 'teamzlab-fedex' ),
            'edit_item'             => esc_html__( 'Edit Shipment', 'teamzlab-fedex' ),
            'view_item'             => esc_html__( 'View Shipment', 'teamzlab-fedex' ),
            'all_items'             => esc_html__( 'All Shipments', 'teamzlab-fedex' ),
            'search_items'          => esc_html__( 'Search by Tracking ID', 'teamzlab-fedex' ),
            'not_found'             => esc_html__( 'No shipments found.', 'teamzlab-fedex' ),
        ];

        $args = [
            'labels'             => $labels,
            // Non-public: shipment rows expose tracking numbers, charges and order
            // ids. They are admin data — no frontend single pages, archive, sitemap
            // entry or REST exposure. Admin list table (show_ui) keeps working.
            'public'             => false,
            'publicly_queryable' => false,
            'show_ui'            => true,
            'show_in_menu'       => false,
            'query_var'          => false,
            'rewrite'            => false,
            'capability_type'    => 'post',
            'has_archive'        => false,
            'hierarchical'       => false,
            'menu_position'      => 25,
            'menu_icon'          => 'dashicons-id-alt',
            'supports'           => [ 'title', 'editor', 'custom-fields' ],
            'show_in_rest'       => false,
            'map_meta_cap' => true,
        ];

        register_post_type( 'fedex_shipping', $args );
    }
}