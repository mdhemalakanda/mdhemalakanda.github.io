<?php
namespace FSHIPPING\Trade;

use FSHIPPING\SingletonTrait;

/**
 * Lightweight HS (Harmonized System) code suggester for customs docs.
 *
 * Given a product name + description, matches keywords against a curated
 * dictionary of common HS chapters (textiles, electronics, books,
 * cosmetics, etc.) and returns ranked suggestions.
 *
 * Intentionally keyword-based, not an AI call — fast, deterministic,
 * and works offline. Covers the 80% of common e-commerce SKUs; complex
 * SKUs still need a human review. Suggestions are ranked by number of
 * keyword matches; ties broken by declaration order.
 *
 * Powers the ETD / paperless customs assistant in the admin shipment
 * editor.
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class HSCodeSuggester {
    use SingletonTrait;

    /**
     * Suggest HS codes for a product description.
     *
     * @param string $title
     * @param string $description
     * @param int    $limit
     * @return array<int,array{code:string,label:string,score:int,matched:array<int,string>}>
     * @since 1.2
     */
    public function suggest(string $title, string $description = '', int $limit = 5): array {
        $haystack = strtolower(trim($title . ' ' . $description));
        if ($haystack === '') {
            return [];
        }

        $results = [];
        foreach ($this->dictionary() as $entry) {
            $matched = [];
            foreach ($entry['keywords'] as $kw) {
                if ($this->contains_word($haystack, $kw)) {
                    $matched[] = $kw;
                }
            }
            if (empty($matched)) {
                continue;
            }
            $results[] = [
                'code'    => $entry['code'],
                'label'   => $entry['label'],
                'score'   => count($matched),
                'matched' => array_values(array_unique($matched)),
            ];
        }

        usort($results, static fn($a, $b) => $b['score'] <=> $a['score']);
        return array_slice($results, 0, max(0, $limit));
    }

    /**
     * Explain a specific HS code (returns empty when unknown).
     *
     * @param string $code
     * @return array{code:string,label:string,keywords:array<int,string>}|array{}
     * @since 1.2
     */
    public function explain(string $code): array {
        foreach ($this->dictionary() as $entry) {
            if ($entry['code'] === $code) {
                return $entry;
            }
        }
        return [];
    }

    /**
     * Curated dictionary. Minimal + extensible — add rows as merchant
     * feedback arrives.
     *
     * @return array<int,array{code:string,label:string,keywords:array<int,string>}>
     * @since 1.2
     */
    public function dictionary(): array {
        return [
            ['code' => '6109.10', 'label' => 'T-shirts and singlets, cotton knit',                   'keywords' => ['t-shirt', 'tshirt', 'tee', 'singlet']],
            ['code' => '6110.20', 'label' => 'Sweaters, cardigans, cotton knit',                     'keywords' => ['sweater', 'cardigan', 'pullover', 'jumper']],
            ['code' => '6203.42', 'label' => "Men's trousers, cotton",                               'keywords' => ['trouser', 'pants', 'chino', 'jeans', 'denim']],
            ['code' => '6204.62', 'label' => "Women's trousers, cotton",                             'keywords' => ['leggings', 'skirt', 'jegging']],
            ['code' => '6403.99', 'label' => 'Footwear with leather uppers',                         'keywords' => ['shoe', 'shoes', 'boot', 'boots', 'sneaker', 'loafer']],
            ['code' => '4202.22', 'label' => 'Handbags with outer surface of textile or plastic',    'keywords' => ['handbag', 'purse', 'tote', 'clutch', 'backpack']],
            ['code' => '4901.99', 'label' => 'Printed books, brochures, leaflets',                   'keywords' => ['book', 'books', 'novel', 'paperback', 'hardcover', 'journal']],
            ['code' => '4911.10', 'label' => 'Trade advertising material, catalogues',               'keywords' => ['catalogue', 'catalog', 'brochure', 'flyer']],
            ['code' => '8471.30', 'label' => 'Portable automatic data processing machines (laptops)', 'keywords' => ['laptop', 'notebook computer', 'macbook', 'chromebook']],
            ['code' => '8517.12', 'label' => 'Telephones for cellular networks (smartphones)',       'keywords' => ['phone', 'smartphone', 'iphone', 'android phone', 'mobile']],
            ['code' => '8518.30', 'label' => 'Headphones, earphones',                                'keywords' => ['headphone', 'earphone', 'earbud', 'airpod']],
            ['code' => '8528.72', 'label' => 'Television receivers, colour',                         'keywords' => ['television', 'tv set', 'monitor']],
            ['code' => '8544.42', 'label' => 'Electric cables with connectors, <1000V',              'keywords' => ['cable', 'cord', 'charger', 'usb cable', 'hdmi']],
            ['code' => '9004.90', 'label' => 'Spectacles, goggles, sunglasses',                      'keywords' => ['sunglasses', 'eyewear', 'glasses', 'goggle']],
            ['code' => '9102.11', 'label' => 'Wrist-watches, battery-powered',                       'keywords' => ['watch', 'wristwatch', 'smartwatch']],
            ['code' => '9404.29', 'label' => 'Mattresses and mattress supports',                     'keywords' => ['mattress']],
            ['code' => '9503.00', 'label' => 'Toys, scale models, puzzles',                          'keywords' => ['toy', 'toys', 'puzzle', 'doll', 'figurine', 'action figure']],
            ['code' => '3304.99', 'label' => 'Beauty / make-up / skin-care preparations',            'keywords' => ['cream', 'lotion', 'serum', 'moisturizer', 'cosmetic', 'makeup', 'lipstick']],
            ['code' => '3303.00', 'label' => 'Perfumes and toilet waters',                           'keywords' => ['perfume', 'cologne', 'fragrance', 'eau de toilette']],
            ['code' => '3305.10', 'label' => 'Shampoo',                                              'keywords' => ['shampoo', 'conditioner']],
            ['code' => '2208.70', 'label' => 'Liqueurs and cordials (alcohol — may require permit)', 'keywords' => ['liqueur', 'cordial', 'whisky', 'whiskey', 'vodka', 'rum', 'gin']],
            ['code' => '2101.11', 'label' => 'Coffee extracts, essences, concentrates',              'keywords' => ['coffee', 'espresso', 'cold brew']],
            ['code' => '2106.90', 'label' => 'Food preparations not elsewhere specified',            'keywords' => ['snack', 'protein bar', 'supplement', 'vitamin']],
            ['code' => '9506.62', 'label' => 'Inflated balls — football, basketball etc.',           'keywords' => ['football', 'basketball', 'soccer ball', 'volleyball']],
            ['code' => '9506.69', 'label' => 'Other sports balls and equipment',                     'keywords' => ['yoga mat', 'dumbbell', 'kettlebell', 'resistance band']],
            ['code' => '8712.00', 'label' => 'Bicycles and cycles (non-motorized)',                  'keywords' => ['bicycle', 'bike']],
            ['code' => '8713.90', 'label' => 'Carriages for disabled persons, not motorized',        'keywords' => ['wheelchair']],
            ['code' => '3924.90', 'label' => 'Household articles of plastic',                        'keywords' => ['plastic container', 'tupperware', 'storage bin']],
            ['code' => '7013.49', 'label' => 'Glassware for table / kitchen',                        'keywords' => ['glassware', 'wine glass', 'tumbler', 'mug']],
        ];
    }

    /**
     * Start-boundary aware contains check.
     *
     * The prefix is strict (keyword must start at a word boundary, so
     * "book" does NOT match "rebook"), but the suffix is loose so common
     * plurals / inflections still match ("headphone" matches "headphones",
     * "book" matches "books" and "bookshelf"). This is deliberate — for
     * HS-code suggestion we prefer recall over precision; a human still
     * reviews the final pick.
     *
     * @param string $haystack Lowercased string.
     * @param string $needle   Keyword (may include spaces, hyphens).
     * @return bool
     * @since 1.2
     */
    private function contains_word(string $haystack, string $needle): bool {
        $needle = strtolower(trim($needle));
        if ($needle === '') {
            return false;
        }
        $pattern = '/(^|[^a-z0-9])' . preg_quote($needle, '/') . '/i';
        return (bool) preg_match($pattern, $haystack);
    }
}
