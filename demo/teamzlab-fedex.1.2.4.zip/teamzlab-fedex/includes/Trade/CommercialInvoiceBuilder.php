<?php
namespace FSHIPPING\Trade;

use FSHIPPING\SingletonTrait;
use FSHIPPING\Utils\Helper;

/**
 * Map a WooCommerce order's line items into a FedEx-spec
 * `customsClearanceDetail.commercialInvoice` block so FedEx generates
 * the commercial invoice PDF for us instead of merchants uploading
 * their own.
 *
 * Fires on `fshipping_ship_payload` at priority 25 — AFTER
 * ETDOrchestrator (priority 20) so if paperwork was already uploaded
 * we still add the structured line-item data FedEx needs to validate
 * the declared values against customs.
 *
 * No-op when:
 *  - order origin country == destination country (domestic shipment)
 *  - merchant has disabled auto-generation via filter
 *    `fshipping_auto_commercial_invoice` (default: enabled)
 *
 * @since 1.2
 */
defined('ABSPATH') || exit;

class CommercialInvoiceBuilder {
    use SingletonTrait;

    /** Filter priority — must be > ETDOrchestrator (20) and < AdvancedServicesInjector (30). */
    public const SHIP_PRIORITY = 25;

    /**
     * @return void
     * @since 1.2
     */
    public function init() {
        add_filter('fshipping_ship_payload', [$this, 'inject'], self::SHIP_PRIORITY, 3);
    }

    /**
     * Build a commercialInvoice block from the order and merge it into
     * the ship payload's customsClearanceDetail.
     *
     * @param array          $payload
     * @param \WC_Order|null $order
     * @param array          $current_shipment
     * @return array
     * @since 1.2
     */
    public function inject(array $payload, $order, array $current_shipment): array {
        if (empty($order) || !is_object($order)) {
            return $payload;
        }
        if (!apply_filters('fshipping_auto_commercial_invoice', true, $order)) {
            return $payload;
        }

        $settings       = get_option('fshipping_options', []);
        $origin_country = strtoupper(sanitize_text_field((string) ($settings['fshipping_country_code'] ?? 'US')));
        $dest_country   = strtoupper(sanitize_text_field((string) ($order->get_shipping_country() ?: $order->get_billing_country())));
        if ($origin_country === '' || $dest_country === '' || $origin_country === $dest_country) {
            return $payload;
        }

        $commodities = $this->build_commodities($order, $origin_country);
        if (empty($commodities)) {
            return $payload;
        }

        $currency = strtoupper(sanitize_text_field((string) $order->get_currency()));
        $invoice  = [
            'customerReferences' => [[
                'customerReferenceType' => 'INVOICE_NUMBER',
                'value'                 => (string) $order->get_order_number(),
            ]],
            'termsOfSale'  => (string) apply_filters('fshipping_invoice_terms_of_sale', 'DDU', $order),
            'purpose'      => (string) apply_filters('fshipping_invoice_purpose',       'SOLD', $order),
            'freightCharge' => [
                'amount'   => (string) $this->safe_float($order->get_shipping_total()),
                'currency' => $currency,
            ],
        ];

        $clearance = isset($payload['requestedShipment']['customsClearanceDetail']) && is_array($payload['requestedShipment']['customsClearanceDetail'])
            ? $payload['requestedShipment']['customsClearanceDetail']
            : [];

        $existing_invoice = isset($clearance['commercialInvoice']) && is_array($clearance['commercialInvoice'])
            ? $clearance['commercialInvoice']
            : [];

        $clearance['commercialInvoice'] = $this->merge_invoices($existing_invoice, $invoice);
        $clearance['commodities']       = array_merge(
            isset($clearance['commodities']) && is_array($clearance['commodities']) ? $clearance['commodities'] : [],
            $commodities
        );
        $clearance['dutiesPayment']     = $clearance['dutiesPayment'] ?? [
            'paymentType' => (string) apply_filters('fshipping_duties_payment_type', 'SENDER', $order),
        ];
        $clearance['totalCustomsValue'] = [
            'amount'   => (string) $this->sum_commodity_value($commodities),
            'currency' => $currency,
        ];

        $payload['requestedShipment']['customsClearanceDetail'] = $clearance;
        $payload['requestedShipment']['shippingDocumentSpecification']['shippingDocumentTypes'][] = 'COMMERCIAL_INVOICE';
        $payload['requestedShipment']['shippingDocumentSpecification']['shippingDocumentTypes']   = array_values(array_unique(
            $payload['requestedShipment']['shippingDocumentSpecification']['shippingDocumentTypes']
        ));

        return $payload;
    }

    /**
     * @param \WC_Order $order
     * @param string    $origin_country
     * @return array<int,array<string,mixed>>
     * @since 1.2
     */
    public function build_commodities($order, string $origin_country): array {
        if (!is_object($order)) {
            return [];
        }
        $suggester = HSCodeSuggester::instance();
        $currency  = strtoupper(sanitize_text_field((string) $order->get_currency()));
        $target_weight_unit = Helper::instance()->fedex_weight_unit();
        $commodities = [];

        foreach ((array) $order->get_items() as $item) {
            if (!is_object($item)) {
                continue;
            }
            $product = $item->get_product();
            $name    = (string) $item->get_name();
            $qty     = max(1, (int) $item->get_quantity());
            $total   = $this->safe_float($item->get_total());
            $unit_price = $qty > 0 ? round($total / $qty, 2) : round($total, 2);

            $weight = 0.0;
            if (is_object($product) && $product->has_weight()) {
                $weight = Helper::instance()->normalize_store_weight($product->get_weight(), $target_weight_unit);
            }

            $hs_code = (string) get_post_meta(
                is_object($product) ? (int) $product->get_id() : 0,
                '_fshipping_hs_code',
                true
            );
            if ($hs_code === '') {
                $hs_code = $suggester->suggest($name) ?: '';
            }

            $commodities[] = [
                'description'         => substr($name, 0, 450),
                'numberOfPieces'      => $qty,
                'quantity'            => $qty,
                'quantityUnits'       => 'PCS',
                'countryOfManufacture' => strtoupper((string) apply_filters(
                    'fshipping_commodity_country_of_manufacture',
                    $origin_country,
                    $item,
                    $order
                )),
                'harmonizedCode'      => sanitize_text_field($hs_code),
                'weight'              => [
                    'units' => $target_weight_unit,
                    'value' => (string) ($weight > 0 ? $weight : 0.1),
                ],
                'unitPrice'           => ['amount' => (string) $unit_price, 'currency' => $currency],
                'customsValue'        => ['amount' => (string) round($unit_price * $qty, 2), 'currency' => $currency],
            ];
        }

        return $commodities;
    }

    /**
     * @param array $commodities
     * @return float
     * @since 1.2
     */
    public function sum_commodity_value(array $commodities): float {
        $total = 0.0;
        foreach ($commodities as $c) {
            $total += $this->safe_float($c['customsValue']['amount'] ?? 0);
        }
        return round($total, 2);
    }

    /**
     * @param array $existing
     * @param array $generated
     * @return array
     * @since 1.2
     */
    private function merge_invoices(array $existing, array $generated): array {
        $merged = array_merge($generated, $existing);
        $existing_refs  = isset($existing['customerReferences'])  && is_array($existing['customerReferences'])  ? $existing['customerReferences']  : [];
        $generated_refs = isset($generated['customerReferences']) && is_array($generated['customerReferences']) ? $generated['customerReferences'] : [];
        $merged['customerReferences'] = array_values(array_merge($generated_refs, $existing_refs));
        return $merged;
    }

    /**
     * @param mixed $v
     * @return float
     * @since 1.2
     */
    private function safe_float($v): float {
        if (is_numeric($v)) {
            return (float) $v;
        }
        return 0.0;
    }
}
