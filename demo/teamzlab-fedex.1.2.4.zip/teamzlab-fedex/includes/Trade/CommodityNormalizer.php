<?php
namespace FSHIPPING\Trade;

use FSHIPPING\SingletonTrait;

defined('ABSPATH') || exit;

/**
 * Normalizes commodities for Global Trade payloads.
 *
 * Ensures required fields are present, converts weight to KG, and auto-fills
 * HS code using product meta/suggester/category fallback/default fallback.
 */
class CommodityNormalizer {
    use SingletonTrait;

    /**
     * @param object $item WC order/cart line item-like object.
     * @param string $origin_country
     * @return array{
     *   description:string,
     *   quantity:int,
     *   quantity_units:string,
     *   unit_price:float,
     *   weight:float,
     *   weight_unit:string,
     *   country_of_manufacture:string,
     *   harmonized_code:string
     * }
     */
    public function normalize_item($item, string $origin_country): array {
        $product = method_exists($item, 'get_product') ? $item->get_product() : null;
        $qty = method_exists($item, 'get_quantity') ? (int) $item->get_quantity() : 1;
        $qty = max(1, $qty);
        $name = method_exists($item, 'get_name') ? sanitize_text_field((string) $item->get_name()) : '';
        $name = $name !== '' ? $name : 'Product Item';
        $line_total = method_exists($item, 'get_total') ? (float) $item->get_total() : 0.0;
        $unit_price = (float) ($line_total / max(1, $qty));

        $raw_weight = 0.1;
        if (is_object($product) && method_exists($product, 'has_weight') && method_exists($product, 'get_weight') && $product->has_weight()) {
            $raw_weight = max(0.0001, (float) $product->get_weight());
        }
        $weight_kg = $this->to_kg($raw_weight);

        $sku = (is_object($product) && method_exists($product, 'get_sku')) ? sanitize_text_field((string) $product->get_sku()) : '';
        $description = $this->description($name, $sku);
        $country = strtoupper(trim($origin_country)) !== '' ? strtoupper(trim($origin_country)) : 'US';
        $hs = $this->resolve_hs_code($product, $name);

        return [
            'description'            => $description,
            'quantity'               => $qty,
            'quantity_units'         => 'EA',
            'unit_price'             => $unit_price,
            'weight'                 => $weight_kg,
            'weight_unit'            => 'KG',
            'country_of_manufacture' => sanitize_text_field($country),
            'harmonized_code'        => $hs,
        ];
    }

    private function to_kg(float $weight): float {
        $store_unit = strtoupper((string) get_option('woocommerce_weight_unit'));
        if (function_exists('wc_get_weight')) {
            $kg = (float) wc_get_weight($weight, 'kg', $store_unit !== '' ? strtolower($store_unit) : 'kg');
            return max(0.001, round($kg, 3));
        }
        if ($store_unit === 'LBS' || $store_unit === 'LB') {
            return max(0.001, round($weight * 0.45359237, 3));
        }
        return max(0.001, round($weight, 3));
    }

    private function description(string $name, string $sku): string {
        $clean = trim($name);
        if ($clean === '') {
            $clean = 'Product Item';
        }
        $generic = ['item', 'product', 'goods', 'merchandise', 'sample'];
        if (in_array(strtolower($clean), $generic, true) && $sku !== '') {
            $clean .= ' SKU ' . $sku;
        }
        return sanitize_text_field(substr($clean, 0, 80));
    }

    private function resolve_hs_code($product, string $name): string {
        $hs = '';
        if (is_object($product) && method_exists($product, 'get_id')) {
            $hs = sanitize_text_field((string) get_post_meta((int) $product->get_id(), '_fshipping_hs_code', true));
        }
        if ($this->is_valid_hs($hs)) {
            return $hs;
        }

        $suggestions = HSCodeSuggester::instance()->suggest($name);
        if (!empty($suggestions[0]['code']) && $this->is_valid_hs((string) $suggestions[0]['code'])) {
            return sanitize_text_field((string) $suggestions[0]['code']);
        }

        $mapped = $this->hs_from_product_categories($product);
        if ($this->is_valid_hs($mapped)) {
            return $mapped;
        }

        // Last-resort fallback to avoid avoidable checkout blocks.
        return '999999';
    }

    private function hs_from_product_categories($product): string {
        if (!is_object($product) || !method_exists($product, 'get_id')) {
            return '';
        }
        $terms = get_the_terms((int) $product->get_id(), 'product_cat');
        if (empty($terms) || !is_array($terms)) {
            return '';
        }
        $map = [
            'clothing'    => '610910',
            'apparel'     => '610910',
            'electronics' => '847130',
            'books'       => '490199',
            'footwear'    => '640399',
            'shoes'       => '640399',
            'cosmetics'   => '330499',
            'toys'        => '950300',
        ];
        foreach ($terms as $term) {
            $slug = is_object($term) && isset($term->slug) ? strtolower((string) $term->slug) : '';
            $name = is_object($term) && isset($term->name) ? strtolower((string) $term->name) : '';
            if ($slug !== '' && isset($map[$slug])) {
                return $map[$slug];
            }
            if ($name !== '' && isset($map[$name])) {
                return $map[$name];
            }
        }
        return '';
    }

    private function is_valid_hs(string $hs): bool {
        $digits = preg_replace('/[^0-9]/', '', $hs);
        return is_string($digits) && strlen($digits) >= 6;
    }
}

