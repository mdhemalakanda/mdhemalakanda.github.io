<?php
/**
 * Plugin Name:          Teamzlab Fedex
 * Plugin URI:           https://teamzlab.com/fedex-shipping
 * Description:          All 15 FedEx REST APIs for WooCommerce: live rates, tracking webhooks, paperless ETD customs, Freight LTL with liftgate, and a self-serve Return Tag portal — REST-native for the 2026 SOAP shutdown.
 * Version:              1.2.4
 * Author:               Teamz Lab LTD
 * Author URI:           https://teamzlab.com
 * License:              GPL-2.0-or-later
 * License URI:          https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:          teamzlab-fedex
 * Domain Path:          /languages
 * Requires at least:    6.2
 * Requires PHP:         7.4
 * Requires Plugins:     woocommerce
 * WC requires at least: 7.0
 * WC tested up to:      11.2
 *
 * @package FSHIPPING
 */


use FSHIPPING\Main;

defined('ABSPATH') || exit;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// The bundled Freemius SDK disables TLS certificate verification unless the
// constant is already set (vendor/freemius/config.php defines it as false).
// Opt back into certificate verification before the SDK can ever load.
if ( ! defined( 'FS_SDK__SSLVERIFY' ) ) {
    define( 'FS_SDK__SSLVERIFY', true );
}

DEFINE('FSHIPPING_FILE', __FILE__);
DEFINE('FSHIPPING_DIR_PATH', plugin_dir_path(FSHIPPING_FILE));
DEFINE('FSHIPPING_NAMESPACE', 'FSHIPPING');

// Declare HPOS (custom order tables) compatibility to WooCommerce.
add_action('before_woocommerce_init', static function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

// Licensing / distro — wp-config.php overrides these at the release site.
// 'freemius' = direct-sale build (licensing + auto-update via Freemius).
// 'codecanyon' = Envato build (no Freemius — their ToS forbid third-party billing).
defined('FSHIPPING_DISTRO')              || define('FSHIPPING_DISTRO', 'freemius');
defined('FSHIPPING_FREEMIUS_ID')         || define('FSHIPPING_FREEMIUS_ID', 0);
defined('FSHIPPING_FREEMIUS_PUBLIC_KEY') || define('FSHIPPING_FREEMIUS_PUBLIC_KEY', 'pk_placeholder');
defined('FSHIPPING_FREEMIUS_SLUG')       || define('FSHIPPING_FREEMIUS_SLUG', 'teamzlab-fedex');

define( 'WP_FS__DEV_MODE', false );
define( 'WP_FS__SKIP_EMAIL_ACTIVATION', true );
// Freemius secret keys must never live in source control. Supply the secret
// key via wp-config.php on the licensing build if premium API access needs it.

// Load the Teamz WP MVP Kit autoloader (git submodule at ./kit).
// This lets `use Teamz\Wp\Kit\...` imports resolve inside this plugin.
// See docs/adr/ in the kit + MIGRATION_FROM_FEDEX.md for the plan to
// move existing HTTP clients onto the kit's base classes.
if ( file_exists( FSHIPPING_DIR_PATH . 'kit/src/autoload.php' ) ) {
    require_once FSHIPPING_DIR_PATH . 'kit/src/autoload.php';
}

// Fallback for distributions that do not include the Teamz kit submodule.
if ( ! class_exists( '\Teamz\Wp\Kit\Http\BaseClient' ) ) {
    require_once FSHIPPING_DIR_PATH . 'includes/Compat/BaseClient.php';
}

if ( ! trait_exists( '\Teamz\Wp\Kit\Traits\LogsHttp' ) ) {
    require_once FSHIPPING_DIR_PATH . 'includes/Compat/Traits/LogsHttp.php';
}

if ( ! class_exists( '\Teamz\Wp\Kit\Admin\StatusBadge' ) ) {
    require_once FSHIPPING_DIR_PATH . 'includes/Compat/Admin/StatusBadge.php';
}

if ( ! class_exists( '\Teamz\Wp\Kit\Admin\NoticeRenderer' ) ) {
    require_once FSHIPPING_DIR_PATH . 'includes/Compat/Admin/NoticeRenderer.php';
}

if ( ! function_exists( 'fshipping_fs' ) ) {
    // Create a helper function for easy SDK access.
    function fshipping_fs() {
        global $fshipping_fs;

        // CodeCanyon builds must not run Freemius (their ToS forbid
        // third-party billing) — the distro constant is the documented
        // switch. Without this gate the SDK booted on every build.
        if ( defined( 'FSHIPPING_DISTRO' ) && 'codecanyon' === FSHIPPING_DISTRO ) {
            return null;
        }

        if ( ! isset( $fshipping_fs ) ) {
            // Include Freemius SDK.
            require_once dirname( __FILE__ ) . '/vendor/freemius/start.php';

            $fshipping_fs = fs_dynamic_init( array(
                'id'                  => '28353',
                'slug'                => 'teamzlab-fedex',
                'type'                => 'plugin',
                'public_key'          => 'pk_5e5bf3ab5c06c5a9abc9ec9c87889',
                'is_premium'          => true,
                // If your plugin is a serviceware, set this option to false.
                'has_premium_version' => true,
                'has_addons'          => false,
                'has_paid_plans'      => true,
                'is_org_compliant'    => true,
                'trial'               => array(
                    'days'               => 10,
                    'is_require_payment' => true,
                ),
                'menu'                => array(
                    // Must match the plugin's real top-level menu slug
                    // (includes/Menu.php) — the SDK hangs its Account /
                    // Upgrade / What's New submenus off this parent.
                    'slug'           => 'fedex_shipping',
                    'first-path'     => 'admin.php?page=fedex_shipping',
                ),
            ) );
        }

        return $fshipping_fs;
    }

    // Init Freemius.
    fshipping_fs();
    // Signal that SDK was initiated.
    do_action( 'fshipping_fs_loaded' );
}
function fshipping_class_loader( $class_name ) {
    if ( ! class_exists( $class_name ) ) {
        $class_name = preg_replace(
            array( '/([a-z])([A-Z])/', '/\\\/' ),
            array( '$1$2', DIRECTORY_SEPARATOR ),
            $class_name
        );

        $class_name = str_replace( FSHIPPING_NAMESPACE . DIRECTORY_SEPARATOR, 'includes' . DIRECTORY_SEPARATOR, $class_name );
        $file_name  = FSHIPPING_DIR_PATH. $class_name . '.php';
        if ( file_exists( $file_name ) ) {
            require_once $file_name;
        }
    }
}
spl_autoload_register('fshipping_class_loader');

add_action('plugins_loaded', function() {
    // Rate freshness: WooCommerce hashes every shipping package (contents +
    // destination) and recalculates whenever the hash changes — on classic
    // checkout and the Store API alike — so address and cart edits never
    // serve stale FedEx rates. The package hash does NOT include this
    // plugin's rate configuration, however, so packages are tagged with a
    // config version that is bumped whenever fshipping_options is saved:
    // a settings change forces exactly one recalculation per cached package,
    // and nothing else forces extra FedEx API calls.
    add_filter( 'woocommerce_cart_shipping_packages', 'fshipping_tag_packages_with_config_version', 99 );
    add_action( 'update_option_fshipping_options', 'fshipping_bump_rates_config_version' );
    Main::instance()->init();
    add_filter( 'woocommerce_shipping_methods', 'fshipping_register_method' );
});

/**
 * Rate-configuration version included in the shipping package hash.
 *
 * @return string
 */
function fshipping_rates_config_version() {
    return (string) get_option( 'fshipping_rates_config_version', '1' );
}

/**
 * Tag cart shipping packages with the rate-configuration version.
 *
 * WooCommerce caches rates per package hash; making the plugin's rate
 * settings part of that hash means a settings change forces exactly one
 * recalculation, and previously cached rates are never served against a
 * changed configuration (allowed services, origin address, mode, …).
 *
 * @param array $packages Cart shipping packages.
 * @return array
 */
function fshipping_tag_packages_with_config_version( $packages ) {
    if ( empty( $packages ) || ! is_array( $packages ) ) {
        return $packages;
    }

    $version = fshipping_rates_config_version();

    foreach ( $packages as $index => $package ) {
        if ( is_array( $package ) ) {
            $packages[ $index ]['fshipping_config_ver'] = $version;
        }
    }

    return $packages;
}

/**
 * Bump the rate-configuration version after fshipping_options changes.
 *
 * @return void
 */
function fshipping_bump_rates_config_version() {
    update_option( 'fshipping_rates_config_version', (string) ( (int) fshipping_rates_config_version() + 1 ) );
}

/**
 * Determine if current request is a WooCommerce Store API request.
 *
 * @return bool
 */
function fshipping_is_store_api_request() {
    return function_exists( 'WC' ) && WC() && method_exists( WC(), 'is_store_api_request' ) && WC()->is_store_api_request();
}
function fshipping_register_method( $methods ) {
    $methods['fshipping_custom'] = 'FSHIPPING\Frontend\Shipping';
    return $methods;
}

register_deactivation_hook( __FILE__, 'fshipping_plugin_deactivate' );

function fshipping_plugin_deactivate() {

    if ( class_exists( '\WC_Cache_Helper' ) ) {
        \WC_Cache_Helper::invalidate_cache_group( 'shipping' );
    }

    if ( function_exists( 'wp_cache_flush' ) ) {
        wp_cache_flush();
    }

    // Pending shipment-confirmation emails must not fire while the plugin is
    // inactive (the send handler is idempotent, so re-scheduling on a later
    // activation cannot duplicate an email that already went out).
    wp_clear_scheduled_hook( 'fshipping_send_shipment_email' );

    // Deactivation must be reversible: merchants routinely deactivate to
    // troubleshoot (and some hosts do it during updates). Deleting the zone
    // bindings here silently destroyed the store's shipping configuration and
    // reactivation never restored it — checkout simply lost FedEx rates. Data
    // removal belongs to uninstall.php, which still wipes everything on delete.
}