<?php
/**
 * Plugin Name: TeamzLab FedEx Demo Data
 * Description: Seeds realistic display-only demo data (orders, shipments, pickup history, box catalog) for the TeamzLab FedEx Shipping live demo. Runs once on activation.
 * Version: 1.0.0
 * Author: TeamzLab
 * Requires Plugins: woocommerce, teamzlab-fedex
 * Text Domain: teamzlab-fedex-demo-data
 */

defined('ABSPATH') || exit;

final class FSH_Demo_Data_Seed {

	const SEEDED_KEY = 'fshipping_demo_data_seeded';

	const LABEL_BASE = 'https://mdhemalakanda.github.io/demo/labels';

	public static function activate() {
		if (get_option(self::SEEDED_KEY)) {
			return;
		}
		if (!class_exists('WooCommerce')) {
			return;
		}

		$products = self::product_ids_by_sku();
		if (empty($products)) {
			return;
		}

		$box_map = self::seed_box_catalog($products);
		$shipments = self::seed_orders_and_shipments($products, $box_map);
		self::seed_pickup_history($shipments);

		update_option(self::SEEDED_KEY, gmdate('c'));
	}

	private static function product_ids_by_sku() {
		$map = [];
		foreach (['DEMO-TSHIRT', 'DEMO-TOTE', 'DEMO-BEANIE'] as $sku) {
			$pid = wc_get_product_id_by_sku($sku);
			if ($pid) {
				$map[$sku] = wc_get_product($pid);
			}
		}
		return $map;
	}

	private static function seed_box_catalog($products) {
		$rules = [];
		$cap = ['DEMO-TSHIRT' => 12, 'DEMO-TOTE' => 8, 'DEMO-BEANIE' => 14];
		foreach ($products as $sku => $product) {
			$rules[] = [
				'product_id'  => (int) $product->get_id(),
				'capacity_qty' => isset($cap[$sku]) ? $cap[$sku] : 10,
			];
		}

		$catalog = [
			'weight_output_unit' => 'KG',
			'dimension_unit'     => 'CM',
			'boxes'              => [
				[
					'id' => 'demo-box-s', 'name' => 'Small Apparel Box', 'preset' => '',
					'dimensions' => ['length' => 25.0, 'width' => 18.0, 'height' => 10.0, 'units' => 'CM'],
					'empty_weight' => ['value' => 0.12, 'unit' => 'KG'],
					'product_rules' => [$rules[2]],
				],
				[
					'id' => 'demo-box-m', 'name' => 'Medium Apparel Box', 'preset' => '',
					'dimensions' => ['length' => 35.0, 'width' => 25.0, 'height' => 18.0, 'units' => 'CM'],
					'empty_weight' => ['value' => 0.24, 'unit' => 'KG'],
					'product_rules' => [$rules[0]],
				],
				[
					'id' => 'demo-box-l', 'name' => 'Large Multi-Item Box', 'preset' => '',
					'dimensions' => ['length' => 45.0, 'width' => 35.0, 'height' => 28.0, 'units' => 'CM'],
					'empty_weight' => ['value' => 0.45, 'unit' => 'KG'],
					'product_rules' => [$rules[1]],
				],
			],
		];
		update_option('fshipping_product_boxes', $catalog);

		// Map box id -> display title used in the Shipments "Box info" column.
		return [
			'demo-box-s' => 'Small Apparel Box (25×18×10 cm)',
			'demo-box-m' => 'Medium Apparel Box (35×25×18 cm)',
			'demo-box-l' => 'Large Multi-Item Box (45×35×28 cm)',
		];
	}

	private static function seed_orders_and_shipments($products, $box_map) {
		$tshirt = $products['DEMO-TSHIRT'];
		$tote   = $products['DEMO-TOTE'];
		$beanie = $products['DEMO-BEANIE'];

		// name, country, city, state, zip, addr1, addr2, items(sku=>qty), service,
		// days_ago, wc_status, lifecycle, box, charge
		$demo = [
			[
				'Sarah Mitchell', 'US', 'Austin', 'TX', '78701', '406 Congress Ave', 'Suite 4',
				['DEMO-TSHIRT' => 2], 'FEDEX_GROUND', 9, 'completed', 'delivered', 'demo-box-m', '9.42',
			],
			[
				'James Okafor', 'US', 'Brooklyn', 'NY', '11201', '88 Vanderbilt Ave', 'Apt 3B',
				['DEMO-TOTE' => 1, 'DEMO-BEANIE' => 2], 'FEDEX_2_DAY', 11, 'completed', 'delivered', 'demo-box-l', '12.86',
			],
			[
				'Emily Chen', 'US', 'Seattle', 'WA', '98101', '1200 Westlake Ave N', 'Floor 3',
				['DEMO-TSHIRT' => 1], 'FEDEX_EXPRESS_SAVER', 7, 'completed', 'in_transit', 'demo-box-m', '11.20',
			],
			[
				'Michael Rodriguez', 'US', 'Miami', 'FL', '33101', '2550 Biscayne Blvd', '',
				['DEMO-TOTE' => 3], 'GROUND_HOME_DELIVERY', 6, 'processing', 'out_for_delivery', 'demo-box-l', '8.75',
			],
			[
				'Priya Sharma', 'CA', 'Toronto', 'ON', 'M5H 2N2', '135 King Street West', '',
				['DEMO-TSHIRT' => 1, 'DEMO-TOTE' => 1], 'INTERNATIONAL_ECONOMY', 8, 'completed', 'in_transit', 'demo-box-l', '24.60',
			],
			[
				'Daniel Müller', 'DE', 'Berlin', '', '10115', 'Torstraße 118', '',
				['DEMO-TSHIRT' => 2, 'DEMO-BEANIE' => 1], 'PRIORITY_OVERNIGHT', 6, 'completed', 'delivered', 'demo-box-m', '38.15',
			],
			[
				'Olivia Bennett', 'GB', 'London', '', 'EC1A 1BB', '52 Fleet Street', '',
				['DEMO-TOTE' => 2, 'DEMO-BEANIE' => 3], 'FEDEX_INTERNATIONAL_PRIORITY', 4, 'processing', 'in_transit', 'demo-box-l', '31.90',
			],
			[
				'Lucas Silva', 'BR', 'São Paulo', 'SP', '01310-100', 'Av. Paulista 1578', '',
				['DEMO-TSHIRT' => 3], 'FEDEX_INTERNATIONAL_CONNECT_PLUS', 5, 'processing', 'exception', 'demo-box-m', '27.44',
			],
			[
				'Hannah Kim', 'KR', 'Seoul', '', '04524', '541 Eulji-ro, Jung-gu', '',
				['DEMO-BEANIE' => 4], 'FEDEX_INTERNATIONAL_PRIORITY_EXPRESS', 3, 'processing', 'customs_hold', 'demo-box-s', '22.08',
			],
			[
				'Ryan Thompson', 'US', 'Denver', 'CO', '80202', '1625 Broadway', 'Suite 250',
				['DEMO-TOTE' => 1], 'FEDEX_GROUND', 2, 'processing', 'canceled', 'demo-box-s', '7.35',
			],
			[
				'Aisha Mohammed', 'AE', 'Dubai', '', '00000', 'Sheikh Zayed Road, Downtown', '',
				['DEMO-TSHIRT' => 1, 'DEMO-BEANIE' => 2], 'INTERNATIONAL_FIRST', 1, 'processing', 'label_created', 'demo-box-m', '44.70',
			],
			[
				'Noah Williams', 'US', 'Chicago', 'IL', '60601', '233 S Wacker Dr', 'Unit 5104',
				['DEMO-TOTE' => 2, 'DEMO-TSHIRT' => 1], 'FEDEX_2_DAY', 0, 'processing', 'not_printed', 'demo-box-l', '10.95',
			],
		];

		$shipment_ids = [];
		$now = time();
		$box_names = [
			['Small Apparel Box', 1], ['Medium Apparel Box', 1], ['Large Multi-Item Box', 2],
		];

		foreach ($demo as $i => $row) {
			list($name, $country, $city, $state, $zip, $addr1, $addr2, $items, $service, $days, $wc_status, $lifecycle, $box, $charge) = $row;

			$order = wc_create_order(['status' => $wc_status, 'created_via' => 'checkout']);
			if (is_wp_error($order)) {
				continue;
			}
			foreach ($items as $sku => $qty) {
				if (isset($products[$sku])) {
					$order->add_product($products[$sku], $qty);
				}
			}
			$order->set_billing_first_name(explode(' ', $name)[0]);
			$order->set_billing_last_name(explode(' ', $name, 2)[1] ?? '');
			$order->set_billing_address_1($addr1);
			if ($addr2) { $order->set_billing_address_2($addr2); }
			$order->set_billing_city($city);
			$order->set_billing_state($state);
			$order->set_billing_postcode($zip);
			$order->set_billing_country($country);
			$order->set_billing_email(strtolower(str_replace(' ', '.', $name)) . '@example.com');
			$order->set_billing_phone('+1-555-01' . str_pad((string) ($i + 10), 2, '0', STR_PAD_LEFT));
			$order->set_shipping_first_name(explode(' ', $name)[0]);
			$order->set_shipping_last_name(explode(' ', $name, 2)[1] ?? '');
			$order->set_shipping_address_1($addr1);
			if ($addr2) { $order->set_shipping_address_2($addr2); }
			$order->set_shipping_city($city);
			$order->set_shipping_state($state);
			$order->set_shipping_postcode($zip);
			$order->set_shipping_country($country);
			$order->set_shipping_method('flat_rate', 'FedEx ' . ucwords(strtolower(str_replace('_', ' ', $service))));
			$order->set_date_created($now - $days * DAY_IN_SECONDS - ($i + 1) * HOUR_IN_SECONDS);
			$order->calculate_totals();
			$order->update_status($wc_status, 'Demo seed', false);

			// Box display payload read by the Shipments "Box info" column.
			$box_display = [[
				'box' => $box_map[$box],
				'products' => array_map(
					function ($sku, $qty) use ($products) {
						return ['name' => $products[$sku]->get_name(), 'qty' => (int) $qty];
					},
					array_keys($items),
					$items
				),
			]];
			$order->update_meta_data('_fshipping_product_box_display_json', wp_json_encode($box_display));

			$label_url = self::LABEL_BASE . '/' . ($country === 'US' ? 'label-ground.pdf' : 'label-intl.pdf');
			$order->update_meta_data('_fedex_label_url', $label_url);
			$order->save();

			$tracking = self::tracking_for($service, $i);
			$created  = $now - $days * DAY_IN_SECONDS - 2 * HOUR_IN_SECONDS;

			$shipment_id = wp_insert_post([
				'post_title'  => 'Shipment for Order #' . $order->get_id(),
				'post_type'   => 'fedex_shipping',
				'post_status' => 'publish',
				'post_date'   => gmdate('Y-m-d H:i:s', $created),
				'post_date_gmt' => gmdate('Y-m-d H:i:s', $created),
			]);
			if (!$shipment_id || is_wp_error($shipment_id)) {
				continue;
			}

			update_post_meta($shipment_id, '_tracking_number', $tracking);
			update_post_meta($shipment_id, '_service_type', $service);
			update_post_meta($shipment_id, '_fedex_shipment_order_id', $order->get_id());
			update_post_meta($shipment_id, '_total_charge', $charge . 'USD');
			update_post_meta($shipment_id, '_total_charge_amount', $charge);
			update_post_meta($shipment_id, '_total_charge_currency', 'USD');
			update_post_meta($shipment_id, '_shipping_label', $label_url);
			update_post_meta($shipment_id, '_transaction_id', 'TXN-DEMO-' . str_pad((string) ($i + 1), 4, '0', STR_PAD_LEFT));
			update_post_meta($shipment_id, '_ship_date', gmdate('Y-m-d', $created));
			update_post_meta($shipment_id, 'order_status', $lifecycle === 'canceled' ? 'canceled' : 'created');

			$printed = 'yes';
			if (in_array($lifecycle, ['label_created', 'not_printed', 'canceled'], true)) {
				$printed = 'no';
			}
			update_post_meta($shipment_id, '_fshipping_label_printed', $printed);

			// Status badge data.
			switch ($lifecycle) {
				case 'delivered':
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'DL', 'description' => 'Delivered — Left at front door. Signed for by: ' . strtoupper(substr($name, 0, 1)) . '.' . strtoupper(substr(explode(' ', $name, 2)[1] ?? 'R', 0, 1)),
					]);
					update_post_meta($shipment_id, '_delivery_date', gmdate('Y-m-d', $created + 3 * DAY_IN_SECONDS));
					update_post_meta($shipment_id, '_fshipping_spod_pdf_url', self::LABEL_BASE . '/spod.pdf');
					break;
				case 'in_transit':
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'IT', 'description' => 'In transit — Shipment is moving within the FedEx network.',
					]);
					break;
				case 'out_for_delivery':
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'OD', 'description' => 'On FedEx vehicle for delivery.',
					]);
					break;
				case 'exception':
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'DE', 'description' => 'Delivery exception — Recipient not available; delivery re-attempt scheduled.',
					]);
					break;
				case 'customs_hold':
					update_post_meta($shipment_id, '_fshipping_customs_state', 'hold');
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'RR', 'description' => 'Hold at location — Clearance delay: import documents required.',
					]);
					break;
				case 'label_created':
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'OC', 'description' => 'Shipment information sent to FedEx.',
					]);
					break;
				case 'canceled':
					delete_post_meta($shipment_id, '_fshipping_aiv_last_event');
					break;
			}

			$shipment_ids[] = (int) $shipment_id;
		}

		return $shipment_ids;
	}

	private static function tracking_for($service, $i) {
		if (strpos($service, 'GROUND') !== false || strpos($service, 'SMART') !== false) {
			return '9611028975' . str_pad((string) (50341 + $i), 5, '0', STR_PAD_LEFT);
		}
		return '7946' . str_pad((string) (589120 + $i * 137), 8, '0', STR_PAD_LEFT);
	}

	private static function seed_pickup_history($shipment_ids) {
		if (empty($shipment_ids)) {
			return;
		}
		$pick = function ($idx) use ($shipment_ids) {
			return isset($shipment_ids[$idx]) ? $shipment_ids[$idx] : 0;
		};
		$now = time();
		$records = [
			[
				'id' => wp_generate_uuid4(),
				'created_at' => gmdate('Y-m-d H:i:s', $now - 2 * DAY_IN_SECONDS),
				'confirmation' => 'ETPRD0482190',
				'scope' => 'global',
				'status' => 'scheduled',
				'shipment_ids' => [$pick(0), $pick(1), $pick(2), $pick(3)],
				'tracking_numbers' => [],
				'shipment_count' => 4,
				'ready' => gmdate('Y-m-d H:i', $now + DAY_IN_SECONDS),
				'carrier_code' => 'FDXG',
				'weight' => 14.8,
				'weight_unit' => 'KG',
			],
			[
				'id' => wp_generate_uuid4(),
				'created_at' => gmdate('Y-m-d H:i:s', $now - 5 * DAY_IN_SECONDS),
				'confirmation' => 'ETPRD0477013',
				'scope' => 'global',
				'status' => 'scheduled',
				'shipment_ids' => [$pick(4), $pick(5), $pick(6)],
				'tracking_numbers' => [],
				'shipment_count' => 3,
				'ready' => gmdate('Y-m-d H:i', $now - 4 * DAY_IN_SECONDS),
				'carrier_code' => 'FDXE',
				'weight' => 9.3,
				'weight_unit' => 'KG',
			],
			[
				'id' => wp_generate_uuid4(),
				'created_at' => gmdate('Y-m-d H:i:s', $now - 8 * DAY_IN_SECONDS),
				'confirmation' => 'ETPRD0461227',
				'scope' => 'single',
				'status' => 'canceled',
				'shipment_ids' => [$pick(1)],
				'tracking_numbers' => [],
				'shipment_count' => 1,
				'ready' => gmdate('Y-m-d H:i', $now - 7 * DAY_IN_SECONDS),
				'carrier_code' => 'FDXE',
				'weight' => 3.6,
				'weight_unit' => 'KG',
				'canceled_at' => gmdate('Y-m-d H:i:s', $now - 7 * DAY_IN_SECONDS + 45 * MINUTE_IN_SECONDS),
			],
		];
		update_option('fshipping_pickup_history', $records);
	}
}

register_activation_hook(__FILE__, ['FSH_Demo_Data_Seed', 'activate']);
