<?php
/**
 * Plugin Name: TeamzLab FedEx Demo Data
 * Description: Seeds realistic display-only demo data (products, orders, shipments, pickup history, box catalog) and locks the admin to the FedEx Shipping menu for the TeamzLab FedEx live demo.
 * Version: 1.3.0
 * Author: TeamzLab
 * Requires Plugins: woocommerce, teamzlab-fedex
 * Text Domain: teamzlab-fedex-demo-data
 */

defined('ABSPATH') || exit;

final class FSH_Demo_Data_Seed {

	const SEEDED_KEY = 'fshipping_demo_data_seeded';
	const ENABLE_KEY = 'fshipping_demo_seed_enabled';
	const LOG_KEY    = 'fshipping_demo_data_log';

	const LABEL_BASE    = 'https://mdhemalakanda.github.io/demo/labels';
	const PRODUCT_BASE  = 'https://mdhemalakanda.github.io/demo/products';

	public function __construct() {
		add_action('admin_init', [$this, 'maybe_seed'], 1);
		add_action('admin_menu', [$this, 'lock_menus'], 9999);
		add_action('admin_init', [$this, 'guard_admin'], 0);
		add_action('admin_bar_menu', [$this, 'strip_admin_bar'], 9999);
		add_filter('wp_get_attachment_url', [$this, 'external_attachment_url'], 10, 2);
		add_filter('wp_get_attachment_image_src', [$this, 'external_attachment_src'], 10, 2);
	}

	/* ---------------------------------------------------------------------
	 * Access lockdown: demo visitors may only browse the FedEx Shipping menu.
	 * ------------------------------------------------------------------- */

	private function current_request_allowed() {
		global $pagenow;

		if (wp_doing_ajax() || in_array($pagenow, ['load-styles.php', 'load-scripts.php'], true)) {
			return true;
		}

		$page    = isset($_GET['page']) ? (string) $_GET['page'] : '';
		$post_id = isset($_GET['post']) ? (int) $_GET['post'] : 0;

		// admin-post.php form target used by the Product Box screen.
		if ('admin-post.php' === $pagenow && strpos((string) ($_REQUEST['action'] ?? ''), 'fshipping') === 0) {
			return true;
		}

		// Theme browsing ("navigate theme") — view, activate, preview only.
		if ('themes.php' === $pagenow) {
			$action = isset($_GET['action']) ? (string) $_GET['action'] : '';
			return in_array($action, ['', 'activate', 'preview'], true);
		}

		// Plugins: view-only list — every state-changing action is blocked.
		if ('plugins.php' === $pagenow) {
			$actions = [isset($_GET['action']) ? (string) $_GET['action'] : '', isset($_POST['action']) ? (string) $_POST['action'] : '', isset($_POST['action2']) ? (string) $_POST['action2'] : ''];
			return array_diff(array_unique($actions), ['', '-1']) === [];
		}

		if ('admin.php' === $pagenow) {
			if (strpos($page, 'fedex_shipping') === 0 || strpos($page, 'fshipping') === 0) {
				return true;
			}
			// HPOS order edit (opened from the shipment's "View Order" action).
			if ('wc-orders' === $page && isset($_GET['id'])) {
				return true;
			}
			return false;
		}

		if (in_array($pagenow, ['edit.php', 'post-new.php'], true)) {
			return isset($_GET['post_type']) && 'fedex_shipping' === $_GET['post_type'];
		}

		if ('post.php' === $pagenow && $post_id) {
			return 'fedex_shipping' === get_post_type($post_id);
		}

		return false;
	}

	public function guard_admin() {
		if (!current_user_can('manage_options') || $this->current_request_allowed()) {
			return;
		}
		wp_safe_redirect(admin_url('admin.php?page=fedex_shipping'));
		exit;
	}

	private function menu_slug_allowed($slug) {
		$slug = (string) $slug;
		return $slug === 'fedex_shipping'
			|| $slug === 'edit.php?post_type=fedex_shipping'
			|| strpos($slug, 'fedex_shipping') === 0
			|| strpos($slug, 'fshipping') === 0;
	}

	public function lock_menus() {
		global $menu, $submenu;
		if (!current_user_can('manage_options')) {
			return;
		}
		foreach ($menu as $key => $item) {
			if (!isset($item[2]) || !$this->menu_slug_allowed($item[2])) {
				unset($menu[$key]);
			}
		}
		// Inside the FedEx top-levels, keep only FedEx children.
		foreach ($submenu as $parent => $items) {
			if (!$this->menu_slug_allowed($parent)) {
				continue;
			}
			foreach ($items as $key => $item) {
				$slug = $item[2] ?? '';
				if ($slug === $parent) {
					continue;
				}
				if (!$this->menu_slug_allowed($slug)) {
					unset($submenu[$parent][$key]);
				}
			}
		}
	}

	public function strip_admin_bar($bar) {
		if (is_admin()) {
			foreach ($bar->get_nodes() as $node) {
				if (!in_array($node->id, ['my-account', 'user-actions', 'logout'], true)) {
					$bar->remove_node($node->id);
				}
			}
			return;
		}

		// Frontend (shop homepage): only the site-name dropdown —
		// Dashboard / Plugins / Themes, nothing else.
		foreach ($bar->get_nodes() as $node) {
			if ($node->id !== 'site-name') {
				$bar->remove_node($node->id);
			}
		}
		$bar->add_node([
			'id' => 'demo-dashboard', 'parent' => 'site-name',
			'title' => 'Dashboard', 'href' => admin_url('/'),
		]);
		$bar->add_node([
			'id' => 'demo-plugins', 'parent' => 'site-name',
			'title' => 'Plugins', 'href' => admin_url('plugins.php'),
		]);
		$bar->add_node([
			'id' => 'demo-themes', 'parent' => 'site-name',
			'title' => 'Themes', 'href' => admin_url('themes.php'),
		]);
	}

	/* ---------------------------------------------------------------------
	 * Seeding.
	 * ------------------------------------------------------------------- */

	public function maybe_seed() {
		if ('yes' !== get_option(self::ENABLE_KEY) || get_option(self::SEEDED_KEY)) {
			return;
		}
		if (!class_exists('WooCommerce')) {
			return;
		}

		try {
			// Demo storefront should not show the WooCommerce "coming soon" banner.
			update_option('woocommerce_coming_soon', 'no');
			update_option('woocommerce_store_pages_only', 'no');
			update_option('woocommerce_private_link', 'no');

			// The shop page is the public homepage of the demo.
			$shop_id = (int) wc_get_page_id('shop');
			if ($shop_id > 0) {
				update_option('show_on_front', 'page');
				update_option('page_on_front', $shop_id);
				update_option('page_for_posts', 0);
			}

			$products = $this->seed_products();

			$box_map   = $this->seed_box_catalog($products);
			$shipments = $this->seed_orders_and_shipments($products, $box_map);
			$this->seed_pickup_history($shipments);

			update_option(self::SEEDED_KEY, gmdate('c'));
			update_option(self::LOG_KEY, 'seeded ' . count($shipments) . ' shipments, ' . count($products) . ' products at ' . gmdate('c'));
		} catch (\Throwable $e) {
			update_option(self::LOG_KEY, 'error: ' . $e->getMessage() . ' @' . $e->getFile() . ':' . $e->getLine());
		}
	}

	private function product_id_by_sku($sku) {
		// Direct meta query: the WXR importer does not sync wc_product_meta_lookup.
		$ids = get_posts([
			'post_type'   => 'product',
			'post_status' => 'publish',
			'fields'      => 'ids',
			'numberposts' => 1,
			'meta_query'  => [[ 'key' => '_sku', 'value' => $sku ]],
		]);
		return !empty($ids) ? (int) $ids[0] : 0;
	}

	private function seed_products() {
		$defs = [
			'DEMO-TSHIRT' => [
				'name' => 'Botanical Print T-Shirt', 'price' => '24.99', 'sale' => '19.99', 'weight' => '0.28',
				'file' => 'botanical-t-shirt.svg', 'cat' => 'Apparel',
				'short' => 'Soft combed-cotton tee with an original botanical line print. Pre-shrunk, breathable, and cut for everyday comfort.',
				'long' => "<p>The Botanical Print T-Shirt is our best-selling everyday tee, woven from 100% combed ring-spun cotton for a soft, broken-in feel from the very first wear.</p>\n<ul>\n<li>100% combed ring-spun cotton, 180 gsm</li>\n<li>Pre-shrunk and enzyme-washed for zero break-in time</li>\n<li>Original botanical line print, water-based inks</li>\n<li>Reinforced shoulder-to-shoulder taping</li>\n</ul>\n<p>Machine wash cold with like colors. Tumble dry low. Every order ships in plastic-free packaging via FedEx.</p>",
				'attrs' => ['Fabric' => '100% combed cotton', 'Fit' => 'Unisex regular fit', 'Care' => 'Machine wash cold'],
				'reviews' => [
					['Sarah Mitchell', 5, 'The print is crisp and the cotton feels premium. Ordered on Tuesday, FedEx delivered Friday — brilliant service.'],
					['James Okafor', 5, 'Fit is true to size and it survived a dozen washes without fading. Shipping label tracked perfectly.'],
					['Emily Chen', 4, 'Lovely fabric and colour. Slightly longer than expected but I like it that way.'],
				],
			],
			'DEMO-TOTE' => [
				'name' => 'Canvas Tote Bag', 'price' => '19.50', 'sale' => '', 'weight' => '0.34',
				'file' => 'canvas-tote.svg', 'cat' => 'Accessories',
				'short' => 'Heavy-duty 16 oz canvas tote with reinforced webbing handles and an interior zip pocket.',
				'long' => "<p>A workhorse tote built from 16 oz natural cotton canvas with cross-stitched webbing handles that shrug off heavy grocery runs.</p>\n<ul>\n<li>16 oz natural cotton canvas</li>\n<li>Reinforced cross-stitched handles</li>\n<li>Interior zip pocket plus two slip pockets</li>\n<li>Water-resistant base panel</li>\n</ul>\n<p>Spot clean and air dry. Ships flat in a protective mailer.</p>",
				'attrs' => ['Material' => '16 oz cotton canvas', 'Capacity' => '18 L', 'Dimensions' => '38 × 40 × 12 cm'],
				'reviews' => [
					['Priya Sharma', 5, 'Holds my laptop, lunch and a gym kit with room to spare. The handles have not frayed at all.'],
					['Noah Williams', 4, 'Sturdy and well stitched. Would love a couple more colour options.'],
				],
			],
			'DEMO-BEANIE' => [
				'name' => 'Ribbed Knit Beanie', 'price' => '15.99', 'sale' => '', 'weight' => '0.19',
				'file' => 'knit-beanie.svg', 'cat' => 'Apparel',
				'short' => 'Chunky ribbed beanie in a double-layer knit with a soft fold-over brim and pom top.',
				'long' => "<p>Our Ribbed Knit Beanie uses a chunky double-layer acrylic-wool blend that holds its shape and warmth all winter.</p>\n<ul>\n<li>70% acrylic / 30% wool blend</li>\n<li>Double-layer knit for wind resistance</li>\n<li>Soft fold-over brim, itch-free forehead band</li>\n<li>Detachable pom</li>\n</ul>\n<p>Hand wash cool, dry flat.</p>",
				'attrs' => ['Material' => 'Acrylic / wool blend', 'Size' => 'One size', 'Care' => 'Hand wash cool'],
				'reviews' => [
					['Daniel Müller', 5, 'Warm without being sweaty, and the brim sits perfectly. Shipped from the US to Berlin in four days.'],
					['Olivia Bennett', 5, 'Great quality knit, exactly like the photos.'],
				],
			],
			'DEMO-HOODIE' => [
				'name' => 'Fleece-Lined Hoodie', 'price' => '39.99', 'sale' => '34.99', 'weight' => '0.62',
				'file' => 'fleece-hoodie.svg', 'cat' => 'Apparel',
				'short' => 'Mid-weight hoodie brushed with a soft fleece interior, finished with a double-lined hood and kangaroo pocket.',
				'long' => "<p>The Fleece-Lined Hoodie layers a brushed-fleece interior under a sturdy cotton-poly face, so it feels broken-in on day one.</p>\n<ul>\n<li>80% cotton / 20% polyester, 320 gsm</li>\n<li>Brushed fleece interior</li>\n<li>Double-lined hood with flat drawcords</li>\n<li>Kangaroo pocket with phone sleeve</li>\n</ul>\n<p>Machine wash cold, inside out.</p>",
				'attrs' => ['Fabric' => 'Cotton / poly fleece', 'Fit' => 'Relaxed fit', 'Care' => 'Machine wash cold'],
				'reviews' => [
					['Michael Rodriguez', 5, 'Heavy in the good way. The fleece lining is genuinely warm for Miami winters and the sizing chart is accurate.'],
					['Aisha Mohammed', 4, 'Beautiful colour. Sleeves run slightly long but the quality is excellent.'],
				],
			],
			'DEMO-BOTTLE' => [
				'name' => 'Insulated Water Bottle', 'price' => '29.00', 'sale' => '', 'weight' => '0.51',
				'file' => 'water-bottle.svg', 'cat' => 'Accessories',
				'short' => 'Double-wall vacuum-insulated 750 ml bottle that keeps drinks cold for 24 hours or hot for 12.',
				'long' => "<p>Cold for 24 hours, hot for 12 — the Insulated Water Bottle pairs a double-wall 18/8 stainless body with a leak-proof twist cap.</p>\n<ul>\n<li>750 ml, 18/8 food-grade stainless steel</li>\n<li>Double-wall vacuum insulation</li>\n<li>Powder-coated grip finish, sweat-free</li>\n<li>Leak-proof twist cap with carry loop</li>\n</ul>\n<p>Hand wash recommended.</p>",
				'attrs' => ['Capacity' => '750 ml', 'Material' => '18/8 stainless steel', 'Insulation' => '24 h cold / 12 h hot'],
				'reviews' => [
					['Hannah Kim', 5, 'Ice cubes were still rattling around the next evening. Zero condensation on my desk.'],
					['Lucas Silva', 4, 'Great bottle. The powder coat scratches if you are rough with it, otherwise perfect.'],
					['Ryan Thompson', 5, 'Second one I have bought. Keeps coffee hot through a full workday.'],
				],
			],
			'DEMO-MUG' => [
				'name' => 'Ceramic Coffee Mug', 'price' => '16.00', 'sale' => '', 'weight' => '0.45',
				'file' => 'ceramic-mug.svg', 'cat' => 'Drinkware',
				'short' => 'Hand-glazed 350 ml stoneware mug with a comfortable rounded handle and speckled matte finish.',
				'long' => "<p>Thrown from speckled stoneware and finished in a soft matte glaze, this 350 ml mug keeps its heat while staying comfortable in the hand.</p>\n<ul>\n<li>350 ml speckled stoneware</li>\n<li>Matte reactive glaze — every piece varies slightly</li>\n<li>Dishwasher and microwave safe</li>\n</ul>\n<p>Packed in a double-wall carton for safe delivery.</p>",
				'attrs' => ['Capacity' => '350 ml', 'Material' => 'Speckled stoneware', 'Care' => 'Dishwasher safe'],
				'reviews' => [
					['Sarah Mitchell', 5, 'The glaze is gorgeous — exactly the warm speckle shown in the photos. Arrived double-boxed without a chip.'],
				],
			],
		];

		$map = [];
		foreach ($defs as $sku => $d) {
			$id = $this->product_id_by_sku($sku);
			if (!$id) {
				$product = new WC_Product_Simple();
				$product->set_sku($sku);
				$product->set_name($d['name']);
			} else {
				$product = wc_get_product($id);
				$product->set_name($d['name']);
			}
			$product->set_regular_price($d['price']);
			if ($d['sale']) {
				$product->set_sale_price($d['sale']);
			}
			$product->set_weight($d['weight']);
			$product->set_length('28');
			$product->set_width('22');
			$product->set_height('8');
			$product->set_stock_status('instock');
			$product->set_manage_stock(true);
			$product->set_stock_quantity(120);
			$product->set_sold_individually(false);
			$product->set_virtual(false);
			$product->set_downloadable(false);
			$product->set_short_description($d['short']);
			$product->set_description($d['long']);

			// Local (custom) attributes -> "Additional information" tab.
			$attrs = [];
			foreach ($d['attrs'] as $label => $value) {
				$attr = new WC_Product_Attribute();
				$attr->set_name($label);
				$attr->set_options([$value]);
				$attr->set_position(count($attrs));
				$attr->set_visible(true);
				$attr->set_variation(false);
				$attrs[] = $attr;
			}
			$product->set_attributes($attrs);

			// Category.
			$term = get_term_by('name', $d['cat'], 'product_cat');
			if (!$term) {
				$res = wp_insert_term($d['cat'], 'product_cat');
				$term_id = is_wp_error($res) ? 0 : (int) $res['term_id'];
			} else {
				$term_id = (int) $term->term_id;
			}
			if ($term_id) {
				$product->set_category_ids([$term_id]);
			}

			// Featured image: attachment pointing at the hosted demo artwork.
			$att = $this->ensure_product_image($d['name'] . ' — product photo', self::PRODUCT_BASE . '/' . $d['file']);
			if ($att) {
				$product->set_image_id($att);
			}

			$id = $product->save();
			if (!$id) {
				continue;
			}

			$this->seed_reviews($id, $d['reviews']);
			$map[$sku] = wc_get_product($id);
		}

		return $map;
	}

	private function ensure_product_image($title, $url) {
		$existing = get_posts([
			'post_type'   => 'attachment',
			'post_status' => 'inherit',
			'fields'      => 'ids',
			'numberposts' => 1,
			'title'       => $title,
		]);
		if (!empty($existing)) {
			return (int) $existing[0];
		}
		$att_id = wp_insert_post([
			'post_title'  => $title,
			'post_status' => 'inherit',
			'post_type'   => 'attachment',
			'guid'        => $url,
		]);
		if (!$att_id || is_wp_error($att_id)) {
			return 0;
		}
		update_post_meta($att_id, '_wp_attached_file', basename($url));
		update_post_meta($att_id, '_fshipping_demo_external_image', 1);
		update_post_meta($att_id, '_fshipping_demo_ext_src', $url);
		clean_post_cache($att_id);
		return (int) $att_id;
	}

	private function external_src_for($attachment_id) {
		$src = get_post_meta((int) $attachment_id, '_fshipping_demo_ext_src', true);
		return ($src && strpos($src, self::PRODUCT_BASE) === 0) ? $src : '';
	}

	public function external_attachment_url($url, $attachment_id) {
		$src = $this->external_src_for($attachment_id);
		return $src ? $src : $url;
	}

	public function external_attachment_src($image, $attachment_id = 0, $size = null, $icon = false) {
		$src = $this->external_src_for($attachment_id);
		return $src ? [$src, 800, 800, false] : $image;
	}

	private function seed_reviews($product_id, $reviews) {
		if (!is_array($reviews)) {
			return;
		}
		$existing = get_comments([
			'post_id' => $product_id, 'status' => 'approve', 'type' => 'review', 'count' => true,
		]);
		if ((int) $existing > 0) {
			return;
		}
		foreach ($reviews as $i => [$name, $rating, $text]) {
			$cid = wp_insert_comment([
				'comment_post_ID'      => $product_id,
				'comment_author'       => $name,
				'comment_author_email' => strtolower(str_replace(' ', '.', $name)) . '@example.com',
				'comment_content'      => $text,
				'comment_type'         => 'review',
				'comment_approved'     => 1,
				'comment_date'         => gmdate('Y-m-d H:i:s', time() - ($i + 1) * 2 * DAY_IN_SECONDS - rand(0, 86400)),
			]);
			if ($cid && !is_wp_error($cid)) {
				update_comment_meta($cid, 'rating', (int) $rating);
				update_comment_meta($cid, 'verified', 1);
			}
		}
	}

	private function seed_box_catalog($products) {
		$rules = [];
		$cap = ['DEMO-TSHIRT' => 12, 'DEMO-TOTE' => 8, 'DEMO-BEANIE' => 14, 'DEMO-HOODIE' => 6, 'DEMO-BOTTLE' => 6, 'DEMO-MUG' => 9];
		foreach ($cap as $sku => $qty) {
			if (isset($products[$sku])) {
				$rules[] = [
					'product_id'   => (int) $products[$sku]->get_id(),
					'capacity_qty' => $qty,
				];
			}
		}

		$catalog = [
			'weight_output_unit' => 'KG',
			'dimension_unit'     => 'CM',
			'boxes'              => [
				[
					'id' => 'demo-box-s', 'name' => 'Small Apparel Box', 'preset' => '',
					'dimensions' => ['length' => 25.0, 'width' => 18.0, 'height' => 10.0, 'units' => 'CM'],
					'empty_weight' => ['value' => 0.12, 'unit' => 'KG'],
					'product_rules' => array_slice($rules, 2, 1),
				],
				[
					'id' => 'demo-box-m', 'name' => 'Medium Apparel Box', 'preset' => '',
					'dimensions' => ['length' => 35.0, 'width' => 25.0, 'height' => 18.0, 'units' => 'CM'],
					'empty_weight' => ['value' => 0.24, 'unit' => 'KG'],
					'product_rules' => array_slice($rules, 0, 1),
				],
				[
					'id' => 'demo-box-l', 'name' => 'Large Multi-Item Box', 'preset' => '',
					'dimensions' => ['length' => 45.0, 'width' => 35.0, 'height' => 28.0, 'units' => 'CM'],
					'empty_weight' => ['value' => 0.45, 'unit' => 'KG'],
					'product_rules' => array_slice($rules, 1, 1),
				],
			],
		];
		update_option('fshipping_product_boxes', $catalog);

		return [
			'demo-box-s' => 'Small Apparel Box (25×18×10 cm)',
			'demo-box-m' => 'Medium Apparel Box (35×25×18 cm)',
			'demo-box-l' => 'Large Multi-Item Box (45×35×28 cm)',
		];
	}

	private function seed_orders_and_shipments($products, $box_map) {
		$demo = [
			[
				'Sarah Mitchell', 'US', 'Austin', 'TX', '78701', '406 Congress Ave', 'Suite 4',
				['DEMO-TSHIRT' => 2], 'FEDEX_GROUND', 9, 'completed', 'delivered', 'demo-box-m', '9.42',
			],
			[
				'James Okafor', 'US', 'Brooklyn', 'NY', '11201', '88 Vanderbilt Ave', 'Apt 3B',
				['DEMO-TOTE' => 1, 'DEMO-BEANIE' => 2], 'FEDEX_2_DAY', 11, 'completed', 'delivered', 'demo-box-l', '12.86',
			],
			[
				'Emily Chen', 'US', 'Seattle', 'WA', '98101', '1200 Westlake Ave N', 'Floor 3',
				['DEMO-TSHIRT' => 1], 'FEDEX_EXPRESS_SAVER', 7, 'completed', 'in_transit', 'demo-box-m', '11.20',
			],
			[
				'Michael Rodriguez', 'US', 'Miami', 'FL', '33101', '2550 Biscayne Blvd', '',
				['DEMO-TOTE' => 3], 'GROUND_HOME_DELIVERY', 6, 'processing', 'out_for_delivery', 'demo-box-l', '8.75',
			],
			[
				'Priya Sharma', 'CA', 'Toronto', 'ON', 'M5H 2N2', '135 King Street West', '',
				['DEMO-TSHIRT' => 1, 'DEMO-TOTE' => 1], 'INTERNATIONAL_ECONOMY', 8, 'completed', 'in_transit', 'demo-box-l', '24.60',
			],
			[
				'Daniel Müller', 'DE', 'Berlin', '', '10115', 'Torstraße 118', '',
				['DEMO-TSHIRT' => 2, 'DEMO-BEANIE' => 1], 'PRIORITY_OVERNIGHT', 6, 'completed', 'delivered', 'demo-box-m', '38.15',
			],
			[
				'Olivia Bennett', 'GB', 'London', '', 'EC1A 1BB', '52 Fleet Street', '',
				['DEMO-TOTE' => 2, 'DEMO-BEANIE' => 3], 'FEDEX_INTERNATIONAL_PRIORITY', 4, 'processing', 'in_transit', 'demo-box-l', '31.90',
			],
			[
				'Lucas Silva', 'BR', 'São Paulo', 'SP', '01310-100', 'Av. Paulista 1578', '',
				['DEMO-TSHIRT' => 3], 'FEDEX_INTERNATIONAL_CONNECT_PLUS', 5, 'processing', 'exception', 'demo-box-m', '27.44',
			],
			[
				'Hannah Kim', 'KR', 'Seoul', '', '04524', '541 Eulji-ro, Jung-gu', '',
				['DEMO-BEANIE' => 4], 'FEDEX_INTERNATIONAL_PRIORITY_EXPRESS', 3, 'processing', 'customs_hold', 'demo-box-s', '22.08',
			],
			[
				'Ryan Thompson', 'US', 'Denver', 'CO', '80202', '1625 Broadway', 'Suite 250',
				['DEMO-TOTE' => 1], 'FEDEX_GROUND', 2, 'processing', 'canceled', 'demo-box-s', '7.35',
			],
			[
				'Aisha Mohammed', 'AE', 'Dubai', '', '00000', 'Sheikh Zayed Road, Downtown', '',
				['DEMO-TSHIRT' => 1, 'DEMO-BEANIE' => 2], 'INTERNATIONAL_FIRST', 1, 'processing', 'label_created', 'demo-box-m', '44.70',
			],
			[
				'Noah Williams', 'US', 'Chicago', 'IL', '60601', '233 S Wacker Dr', 'Unit 5104',
				['DEMO-TOTE' => 2, 'DEMO-TSHIRT' => 1], 'FEDEX_2_DAY', 0, 'processing', 'not_printed', 'demo-box-l', '10.95',
			],
		];

		$shipment_ids = [];
		$now = time();

		foreach ($demo as $i => $row) {
			list($name, $country, $city, $state, $zip, $addr1, $addr2, $items, $service, $days, $wc_status, $lifecycle, $box, $charge) = $row;

			$order = wc_create_order(['created_via' => 'checkout']);
			if (is_wp_error($order)) {
				continue;
			}
			foreach ($items as $sku => $qty) {
				if (isset($products[$sku])) {
					$order->add_product($products[$sku], $qty);
				}
			}
			$first = explode(' ', $name)[0];
			$last  = explode(' ', $name, 2)[1] ?? '';
			$order->set_billing_first_name($first);
			$order->set_billing_last_name($last);
			$order->set_billing_address_1($addr1);
			if ($addr2) { $order->set_billing_address_2($addr2); }
			$order->set_billing_city($city);
			$order->set_billing_state($state);
			$order->set_billing_postcode($zip);
			$order->set_billing_country($country);
			$email = sanitize_email(strtolower(str_replace(' ', '.', $name)) . '@example.com');
			if (!$email || !is_email($email)) {
				$email = 'demo.customer' . ($i + 1) . '@example.com';
			}
			$order->set_billing_email($email);
			$order->set_billing_phone('+1-555-01' . str_pad((string) ($i + 10), 2, '0', STR_PAD_LEFT));
			$order->set_shipping_first_name($first);
			$order->set_shipping_last_name($last);
			$order->set_shipping_address_1($addr1);
			if ($addr2) { $order->set_shipping_address_2($addr2); }
			$order->set_shipping_city($city);
			$order->set_shipping_state($state);
			$order->set_shipping_postcode($zip);
			$order->set_shipping_country($country);
			$ship_item = new WC_Order_Item_Shipping();
			$ship_item->set_method_title('FedEx ' . ucwords(strtolower(str_replace('_', ' ', $service))));
			$ship_item->set_method_id('flat_rate');
			$ship_item->set_total((float) $charge);
			$order->add_item($ship_item);
			$order->set_date_created($now - $days * DAY_IN_SECONDS - ($i + 1) * HOUR_IN_SECONDS);
			$order->calculate_totals();
			$order->update_status($wc_status, 'Demo seed', false);

			$box_display = [[
				'box' => $box_map[$box],
				'products' => array_map(
					function ($sku, $qty) use ($products) {
						return ['name' => $products[$sku]->get_name(), 'qty' => (int) $qty];
					},
					array_keys($items),
					$items
				),
			]];
			$order->update_meta_data('_fshipping_product_box_display_json', wp_json_encode($box_display));

			$label_url = self::LABEL_BASE . '/' . ($country === 'US' ? 'label-ground.pdf' : 'label-intl.pdf');
			$order->update_meta_data('_fedex_label_url', $label_url);
			$order->save();

			$tracking = $this->tracking_for($service, $i);
			$created  = $now - $days * DAY_IN_SECONDS - 2 * HOUR_IN_SECONDS;

			$shipment_id = wp_insert_post([
				'post_title'    => 'Shipment for Order #' . $order->get_id(),
				'post_type'     => 'fedex_shipping',
				'post_status'   => 'publish',
				'post_date'     => gmdate('Y-m-d H:i:s', $created),
				'post_date_gmt' => gmdate('Y-m-d H:i:s', $created),
			]);
			if (!$shipment_id || is_wp_error($shipment_id)) {
				continue;
			}

			update_post_meta($shipment_id, '_tracking_number', $tracking);
			update_post_meta($shipment_id, '_service_type', $service);
			update_post_meta($shipment_id, '_fedex_shipment_order_id', $order->get_id());
			update_post_meta($shipment_id, '_total_charge', $charge . 'USD');
			update_post_meta($shipment_id, '_total_charge_amount', $charge);
			update_post_meta($shipment_id, '_total_charge_currency', 'USD');
			update_post_meta($shipment_id, '_shipping_label', $label_url);
			update_post_meta($shipment_id, '_transaction_id', 'TXN-DEMO-' . str_pad((string) ($i + 1), 4, '0', STR_PAD_LEFT));
			update_post_meta($shipment_id, '_ship_date', gmdate('Y-m-d', $created));
			update_post_meta($shipment_id, 'order_status', $lifecycle === 'canceled' ? 'canceled' : 'created');

			$printed = 'yes';
			if (in_array($lifecycle, ['label_created', 'not_printed', 'canceled'], true)) {
				$printed = 'no';
			}
			update_post_meta($shipment_id, '_fshipping_label_printed', $printed);

			switch ($lifecycle) {
				case 'delivered':
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'DL', 'description' => 'Delivered — Left at front door. Signed for by: ' . strtoupper(substr($first, 0, 1)) . '.' . strtoupper(substr($last, 0, 1)),
					]);
					update_post_meta($shipment_id, '_delivery_date', gmdate('Y-m-d', $created + 3 * DAY_IN_SECONDS));
					update_post_meta($shipment_id, '_fshipping_spod_pdf_url', self::LABEL_BASE . '/spod.pdf');
					break;
				case 'in_transit':
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'IT', 'description' => 'In transit — Shipment is moving within the FedEx network.',
					]);
					break;
				case 'out_for_delivery':
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'OD', 'description' => 'On FedEx vehicle for delivery.',
					]);
					break;
				case 'exception':
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'DE', 'description' => 'Delivery exception — Recipient not available; delivery re-attempt scheduled.',
					]);
					break;
				case 'customs_hold':
					update_post_meta($shipment_id, '_fshipping_customs_state', 'hold');
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'RR', 'description' => 'Hold at location — Clearance delay: import documents required.',
					]);
					break;
				case 'label_created':
					update_post_meta($shipment_id, '_fshipping_aiv_last_event', [
						'status' => 'OC', 'description' => 'Shipment information sent to FedEx.',
					]);
					break;
			}

			$shipment_ids[] = (int) $shipment_id;
		}

		return $shipment_ids;
	}

	private function tracking_for($service, $i) {
		if (strpos($service, 'GROUND') !== false || strpos($service, 'SMART') !== false) {
			return '9611028975' . str_pad((string) (50341 + $i), 5, '0', STR_PAD_LEFT);
		}
		return '7946' . str_pad((string) (589120 + $i * 137), 8, '0', STR_PAD_LEFT);
	}

	private function seed_pickup_history($shipment_ids) {
		if (empty($shipment_ids)) {
			return;
		}
		$pick = function ($idx) use ($shipment_ids) {
			return isset($shipment_ids[$idx]) ? $shipment_ids[$idx] : 0;
		};
		$now = time();
		$records = [
			[
				'id' => wp_generate_uuid4(),
				'created_at' => gmdate('Y-m-d H:i:s', $now - 2 * DAY_IN_SECONDS),
				'confirmation' => 'ETPRD0482190',
				'scope' => 'global',
				'status' => 'scheduled',
				'shipment_ids' => [$pick(0), $pick(1), $pick(2), $pick(3)],
				'tracking_numbers' => [],
				'shipment_count' => 4,
				'ready' => gmdate('Y-m-d H:i', $now + DAY_IN_SECONDS),
				'carrier_code' => 'FDXG',
				'weight' => 14.8,
				'weight_unit' => 'KG',
			],
			[
				'id' => wp_generate_uuid4(),
				'created_at' => gmdate('Y-m-d H:i:s', $now - 5 * DAY_IN_SECONDS),
				'confirmation' => 'ETPRD0477013',
				'scope' => 'global',
				'status' => 'scheduled',
				'shipment_ids' => [$pick(4), $pick(5), $pick(6)],
				'tracking_numbers' => [],
				'shipment_count' => 3,
				'ready' => gmdate('Y-m-d H:i', $now - 4 * DAY_IN_SECONDS),
				'carrier_code' => 'FDXE',
				'weight' => 9.3,
				'weight_unit' => 'KG',
			],
			[
				'id' => wp_generate_uuid4(),
				'created_at' => gmdate('Y-m-d H:i:s', $now - 8 * DAY_IN_SECONDS),
				'confirmation' => 'ETPRD0461227',
				'scope' => 'single',
				'status' => 'canceled',
				'shipment_ids' => [$pick(1)],
				'tracking_numbers' => [],
				'shipment_count' => 1,
				'ready' => gmdate('Y-m-d H:i', $now - 7 * DAY_IN_SECONDS),
				'carrier_code' => 'FDXE',
				'weight' => 3.6,
				'weight_unit' => 'KG',
				'canceled_at' => gmdate('Y-m-d H:i:s', $now - 7 * DAY_IN_SECONDS + 45 * MINUTE_IN_SECONDS),
			],
		];
		update_option('fshipping_pickup_history', $records);
	}
}

new FSH_Demo_Data_Seed();
